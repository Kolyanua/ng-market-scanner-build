import sys, os, re, json, time, unicodedata, traceback, csv, importlib.util, math, hashlib, shutil
from collections import deque
from pathlib import Path
from datetime import datetime

def _enable_windows_dpi_awareness():
    """Set DPI awareness before importing Qt or creating any HWNDs."""
    if os.name != 'nt':
        return 'not-windows'
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        set_context = getattr(user32, 'SetProcessDpiAwarenessContext', None)
        if set_context is not None:
            set_context.argtypes = [ctypes.c_void_p]
            set_context.restype = wintypes.BOOL
            if set_context(ctypes.c_void_p(-4)):  # DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2
                return 'PerMonitorV2'
    except Exception:
        pass
    try:
        import ctypes
        shcore = ctypes.WinDLL('shcore', use_last_error=True)
        set_awareness = shcore.SetProcessDpiAwareness
        set_awareness.argtypes = [ctypes.c_int]
        set_awareness.restype = ctypes.c_long
        # S_OK (0) means per-monitor awareness was successfully applied.
        if set_awareness(2) == 0:
            return 'PerMonitor'
    except Exception:
        pass
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        set_aware = user32.SetProcessDPIAware
        set_aware.argtypes = []
        set_aware.restype = wintypes.BOOL
        if set_aware():
            return 'SystemAware fallback'
    except Exception:
        pass
    return 'Windows default / awareness already set'


# Must execute before any PySide6/Qt imports to keep GetSystemMetrics,
# DXcam capture pixels and SendInput click coordinates in the same space.
_WINDOWS_DPI_AWARENESS = _enable_windows_dpi_awareness()

from scanner_stats_logic import purchase_dynamics_series
from PySide6.QtCore import Qt, QTimer, QThread, Signal, QPropertyAnimation, QEasingCurve, QSize, QPointF, QEvent
from PySide6.QtGui import QFont, QPixmap, QTextCursor, QPainter, QIcon, QColor, QPen, QPainterPath, QImageReader
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QCheckBox, QTableWidget, QTableWidgetItem, QHeaderView, QFrame,
    QTextEdit, QPlainTextEdit, QMessageBox, QGridLayout, QStackedWidget, QSpinBox, QDoubleSpinBox, QSizePolicy,
    QLineEdit, QFileDialog, QAbstractItemView, QScrollArea, QFormLayout,
    QGraphicsOpacityEffect, QDialog, QDialogButtonBox
)

# Keep the single-file EXE genuinely portable: bundled read-only assets live in
# PyInstaller's extraction directory, while mutable settings/logs live in LocalAppData.
# In development and the existing onedir build, data remains beside the project/EXE.
_FROZEN = bool(getattr(sys, 'frozen', False))
_APP_DIR = Path(sys.executable).resolve().parent if _FROZEN else Path(__file__).resolve().parent
_BUNDLE_DIR = Path(getattr(sys, '_MEIPASS', str(_APP_DIR))).resolve() if _FROZEN else _APP_DIR
_IS_ONEFILE = bool(_FROZEN and _BUNDLE_DIR.name.casefold().startswith('_mei'))
if _IS_ONEFILE:
    _LOCAL_ROOT = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local'))
    DATA = _LOCAL_ROOT / 'NGMarketScanner'
else:
    DATA = _APP_DIR
RESOURCE_DIR = _BUNDLE_DIR if _IS_ONEFILE else DATA

if _IS_ONEFILE:
    # Seed per-user mutable files once; never overwrite the user's own settings/history.
    DATA.mkdir(parents=True, exist_ok=True)
    for _seed_name in ('all_vehicles.txt', 'vehicle_rules.txt', 'selected_vehicles.txt',
                       'blacklist_vehicles.txt', 'priority_vehicles.txt', 'special_vehicles.txt',
                       'settings.json', 'stats_history.json'):
        _seed_source = RESOURCE_DIR / _seed_name
        _seed_target = DATA / _seed_name
        if _seed_source.is_file() and not _seed_target.exists():
            shutil.copy2(_seed_source, _seed_target)
    _custom_seed_source = RESOURCE_DIR / 'vehicle_photos' / 'custom'
    _custom_seed_target = DATA / 'vehicle_photos' / 'custom'
    _custom_seed_target.mkdir(parents=True, exist_ok=True)
    if _custom_seed_source.is_dir():
        for _custom_seed_file in _custom_seed_source.iterdir():
            if _custom_seed_file.is_file() and not (_custom_seed_target / _custom_seed_file.name).exists():
                shutil.copy2(_custom_seed_file, _custom_seed_target / _custom_seed_file.name)

RULES = DATA / 'vehicle_rules.txt'
ALL = DATA / 'all_vehicles.txt'
SELECTED = DATA / 'selected_vehicles.txt'
BLACKLIST = DATA / 'blacklist_vehicles.txt'
CONFIG = DATA / 'settings.json'
LOG = DATA / 'scanner.log'
STAT_HISTORY = DATA / 'stats_history.json'
ICON_PATH = RESOURCE_DIR / 'assets' / 'ng_market_scanner.ico'
# Native 2K reference canvas; actual UI scales with the active monitor without
# changing the game-capture or calibrated click coordinates.
REFERENCE_2K_WIDTH = 2560
REFERENCE_2K_HEIGHT = 1440
REFERENCE_2K_LABEL = f'{REFERENCE_2K_WIDTH}×{REFERENCE_2K_HEIGHT} (2K)'
DEFAULTS = {
    'config_version': 31,
    'threshold': 20, 'interval_ms': 20, 'auto_click': False, 'auto_confirm': False,
    'resolution_profile': 'auto', 'animations_enabled': False,
    'fast_color_filter_enabled': True, 'blacklist_protection_enabled': True,
    'confidence_protection_enabled': True,
    'auto_refresh_enabled': False, 'auto_refresh_interval_min': 5,
    'continue_after_purchase': True,
    'click_delay_ms': 1,
    'grid': {'left': .153, 'top': .095, 'right': .985, 'bottom': .895, 'cols': 5, 'rows': 3},
    'model_thresholds': {}, 'custom_vehicles': {}, 'vehicle_photos': {}
}
INTERVALS = {'Ультра++ · 20 мс': 20, 'Ультра+ · 50 мс': 50, 'Ультра · 100 мс': 100, 'Швидкий · 250 мс': 250, 'Збалансований · 500 мс': 500, 'Кожну секунду': 1000}
CLICK_SPEEDS = {'Миттєво · 1 мс': 1, 'Дуже швидко · 5 мс': 5, 'Швидко · 8 мс': 8,
                'Збалансовано · 20 мс': 20, 'Обережно · 60 мс': 60}

RESOLUTION_PROFILES = {
    'Авто · за фактичним екраном': 'auto',
    'Full HD · 1920×1080': '1920x1080',
    '2K · 2560×1440': '2560x1440',
}
RESOLUTION_PROFILE_LABELS = {value: label for label, value in RESOLUTION_PROFILES.items()}
DEFAULT_MODEL_THRESHOLDS = {
    'Obey RS6 C8': 50, 'Dinka Civic EK6': 50, 'Karin Supra A80': 50,
    'Albany Fury': 50, 'Land Rover Range Rover': 50, 'Bollokan Rio QB': 50,
    'BF Golf VII R': 50, 'Benefactor G-Class W464': 20, 'BF Polo': 50,
    'Pegassi Urus': 30, 'Benefactor AVTR': 50, 'Shitzu Matiz': 20,
}
_CACHED_SCAN_CORE = None
_CACHED_SCAN_CORE_STAMP = None
_CACHED_ACTION_CORE = None
_CACHED_ACTION_CORE_STAMP = None
EXPECTED_CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"
POST_PURCHASE_CONFIRM_GRACE_SECONDS = 1.10
POST_PURCHASE_CONFIRM_MIN_FRESH_FRAMES = 2
POST_PURCHASE_DETAIL_BACK_MIN_WAIT_SECONDS = 0.85
POST_PURCHASE_UNKNOWN_BACK_MIN_WAIT_SECONDS = 1.05
EXPECTED_OCR_CORE_VERSION = "1.2.60-position-independent-discount-watch"
EXPECTED_OCR_SPEED_PATCH_VERSION = "1.2.60-responsive-ui-fast-detail"
EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION = "1.2.63-shared-watch-frame-detail-capture"
EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION = "1.2.65-retry-confirm-detail-discount"
EXPECTED_CLICK_LATENCY_PATCH_VERSION = "1.2.65-fast-coalesce-compact-detail-ocr"
EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION = "1.2.75-cancellable-highres-wait"
EXPECTED_CLICK_BUTTON_PROBE_PATCH_VERSION = "1.2.65.1-2k-offtext-probes"
EXPECTED_CLICK_MARKET_RETURN_PATCH_VERSION = "1.2.66-return-market-recover"
EXPECTED_MARKET_PREFLIGHT_PATCH_VERSION = "1.2.67-persistent-dxcam-market-roi"
EXPECTED_CAPTURE_FASTPATH_PATCH_VERSION = "1.2.68-dxcam-bgra-fastpath"
EXPECTED_RECOGNITION_ONLY_PATCH_VERSION = "1.2.69-known-roi-batched-recognition-only"
EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION = "1.2.70-single-card-batched-recognition-only"
EXPECTED_BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"
EXPECTED_PURCHASE_DIAGNOSTICS_PATCH_VERSION = "1.2.73-offer-signature-dedupe-and-scan-profile"
EXPECTED_FAST_BADGE_CONSENSUS_PATCH_VERSION = "1.2.74-fast-badge-consensus-no-detector-fallback"
EXPECTED_MARKET_RETURN_GATE_PATCH_VERSION = "1.2.75-market-return-state-gate"
EXPECTED_DYNAMIC_CONFIRM_PATCH_VERSION = "1.2.70-dynamic-cta-and-lot-not-found-guard"
EXPECTED_FAST_COORDINATE_FLOW_VERSION = "1.2.71-fixed-coordinate-fast-chain-no-postcheck"
EXPECTED_DPI_BOOTSTRAP_VERSION = "1.2.75-runtime-dpi-before-qt-no-custom-manifest"
# Stable click-chain base from NG Market Scanner v1.2.71 remains unchanged in v1.2.75.
CUSTOM_VEHICLE_PHOTOS = {}


def read_lines(path):
    try:
        return [x.strip() for x in path.read_text(encoding='utf-8-sig').splitlines()
                if x.strip() and not x.lstrip().startswith('#')]
    except Exception:
        return []


def norm(s):
    s = unicodedata.normalize('NFKD', str(s or '')).encode('ascii', 'ignore').decode().lower()
    return re.sub(r'[^a-z0-9]', '', s)


def normalize_blacklist_entries(lines, model_names=None):
    """Deduplicate blacklist lines and canonicalize known model spellings."""
    canonical = {norm(name): str(name).strip() for name in (model_names or []) if norm(name)}
    result, seen = [], set()
    for raw in lines or []:
        name = ' '.join(str(raw or '').strip().split())
        key = norm(name)
        if not key or key in seen:
            continue
        result.append(canonical.get(key, name))
        seen.add(key)
    return result


def load_blacklist_models(model_names=None, entries=None):
    """Return canonical catalog names on the blacklist, matching case/punctuation-insensitively."""
    names = list(model_names if model_names is not None else read_lines(ALL))
    raw = read_lines(BLACKLIST) if entries is None else list(entries)
    keys = {norm(value) for value in raw if norm(value)}
    return {str(name) for name in names if norm(name) in keys}


BLACKLIST_CATEGORY = 'Чорний список'
CATALOG_CATEGORIES = ('Пріоритетне', 'Звичайне', 'Спеціальне', BLACKLIST_CATEGORY)


# Exact high-resolution cutouts are preferred. A few fictional NG names have no
# one-to-one visual asset; their nearby body-style reference is explicitly labelled.
VEHICLE_RENDER_ALIASES = {
    # The market calls this helicopter "Buckingham 429"; visual reference is a Bell 429-style cutout.
    'Buckingham 429': 'Buckingham_429.png',
    'Dinka Civic EK6': 'Dinka_Civic_FK2.png',
    'Albany Fury': 'Lampadati_Giulia.png',
    'Land Rover Range Rover': 'Benefactor_G_Class_W463.png',
    'BF Golf VII R': 'BF_Golf_VIII.png',
    'Benefactor G-Class W464': 'Benefactor_G_Class_W463.png',
    'BF Polo': 'Bollokan_Rio_QB.png',
    'Pegassi Urus': 'Canis_Track_Hawk.png',
    'Ubermacht M5 F10': 'Benefactor_S_Class_W223.png',
    'Maxwell Astra J': 'Bollokan_Rio_QB.png',
    'Bravado Charger Redeye': 'Vapid_Mustang_GT_S550.png',
    'Bravado Charger Redeve': 'Vapid_Mustang_GT_S550.png',
    'Pfister Macan EV': 'Pfister_Macan_95B.png',
    'Annis S-3': 'BF_Golf_VIII.png',
    'Fathom Q60 S': 'Benefactor_CLS_Class_C257.png',
    'Benefactor Sprinter W906': 'Vapid_Transit_V347.png',
    'Obey RS7 C8': 'Obey_RS6_C8.png',
    'Enus Cullinan': 'Benefactor_G_Class_W463.png',
    'Penaud Logan': 'Bollokan_Rio_QB.png',
    'Obey 80 B4': 'Benefactor_S_Class_W223.png',
    'Weeny Cooper EV': 'BF_Golf_VIII.png',
    'Karin Camry V55': 'Benefactor_S_Class_W223.png',
    'Enus Bentayga 4V': 'Benefactor_G_Class_W463.png',
    'Pfister Taycan Turbo S': 'Coil_Model_3.png',
    'Benefactor AVTR': 'Benefactor_S_Class_W223.png',
    # High-resolution fallback references for legacy extra models that previously
    # had only 420x220 screenshots; they are labelled as references in the UI.
    'Pegassi Huracan': 'Progen_Senna.png',
    'Grotti F40': 'Progen_Senna.png',
    'Declasse Volt': 'Coil_Model_3.png',
    'Annis RX7 FD3S': 'Karin_Supra_A80.png',
    'Maibatsu Lancer EVO IX': 'Karin_WRX_STI_GDB.png',
    'Karin Land Cruiser 100': 'Canis_Track_Hawk.png',
    'Shitzu Matiz': 'Bollokan_Rio_QB.png',
    'Vapid F-150 Raptor': 'Karin_Tundra.png',
    'Grotti Roma': 'Annis_GT_R_R35_Japan_Spec.png',
    'Obey E Tron GT': 'Coil_Model_3.png',
    'Bravado Charger Daytona EV': 'Vapid_Mustang_GT_S550.png',
    'BF T6.1': 'Vapid_Transit_V347.png',
}
APPROXIMATE_RENDER_MODELS = set(VEHICLE_RENDER_ALIASES)


MIN_PREVIEW_WIDTH = 1000
MIN_PREVIEW_HEIGHT = 500
_PREVIEW_VALIDATION_CACHE = {}
_PIXMAP_CACHE = {}
_MAX_PIXMAP_CACHE_ITEMS = 96


def _is_high_resolution_preview(path):
    """Validate a preview once per file version to avoid repeated disk/decoder work."""
    try:
        path = Path(path)
        if not path.is_file():
            return False
        stat = path.stat()
        key = (str(path.resolve()), int(stat.st_mtime_ns), int(stat.st_size))
        cached = _PREVIEW_VALIDATION_CACHE.get(key)
        if cached is not None:
            return cached
        if stat.st_size < 4096:
            _PREVIEW_VALIDATION_CACHE[key] = False
            return False
        reader = QImageReader(str(path))
        size = reader.size()
        valid = bool(size.isValid() and size.width() >= MIN_PREVIEW_WIDTH and size.height() >= MIN_PREVIEW_HEIGHT)
        # Drop stale versions of the same path and keep the cache bounded.
        for old_key in list(_PREVIEW_VALIDATION_CACHE):
            if old_key[0] == key[0] and old_key != key:
                _PREVIEW_VALIDATION_CACHE.pop(old_key, None)
        if len(_PREVIEW_VALIDATION_CACHE) > 512:
            _PREVIEW_VALIDATION_CACHE.clear()
        _PREVIEW_VALIDATION_CACHE[key] = valid
        return valid
    except Exception:
        return False


def _load_cached_pixmap(value):
    """Decode each on-disk preview once and reuse Qt's implicitly shared pixmap."""
    if isinstance(value, QPixmap):
        return QPixmap(value)
    if not isinstance(value, (str, Path)) or not str(value):
        return QPixmap()
    try:
        path = Path(value)
        if not path.is_file():
            return QPixmap()
        stat = path.stat()
        key = (str(path.resolve()), int(stat.st_mtime_ns), int(stat.st_size))
        cached = _PIXMAP_CACHE.get(key)
        if cached is not None:
            return QPixmap(cached)
        pixmap = QPixmap(str(path))
        if pixmap.isNull():
            return pixmap
        for old_key in list(_PIXMAP_CACHE):
            if old_key[0] == key[0] and old_key != key:
                _PIXMAP_CACHE.pop(old_key, None)
        if len(_PIXMAP_CACHE) >= _MAX_PIXMAP_CACHE_ITEMS:
            _PIXMAP_CACHE.pop(next(iter(_PIXMAP_CACHE)))
        _PIXMAP_CACHE[key] = QPixmap(pixmap)
        return pixmap
    except Exception:
        return QPixmap()


def vehicle_render_path(model):
    """Resolve only high-resolution local assets; never stretch a tiny legacy thumbnail."""
    model = str(model or '').strip()
    directory = RESOURCE_DIR / 'vehicle_renders'
    candidates = []
    if model in VEHICLE_RENDER_ALIASES:
        candidates.append(directory / VEHICLE_RENDER_ALIASES[model])
    # Legacy filename correction for an old misspelling.
    legacy_aliases = {'Bravado Charger Redeve': 'Bravado_Charger_Redeye'}
    stem = legacy_aliases.get(model, re.sub(r'[^A-Za-z0-9]+', '_', model).strip('_'))
    candidates.extend((directory / (stem + '.png'), directory / (stem + '.jpg')))
    seen = set()
    for candidate in candidates:
        key = str(candidate).casefold()
        if key in seen:
            continue
        seen.add(key)
        if _is_high_resolution_preview(candidate):
            return candidate
    return None


# Real, freely licensed reference photos are downloaded by tools/download_vehicle_photos.ps1.
# If a photo is missing, the UI uses the game's existing render and labels it as a render.
VEHICLE_PHOTO_FILES = {
    'Dinka Civic EK6': 'Dinka_Civic_EK6.jpg',
    'Ubermacht M4 F82': 'Ubermacht_M4_F82.jpg',
    'Ubermacht M4 G82': 'Ubermacht_M4_G82.jpg',
    'Benefactor CLS-Class C257': 'Benefactor_CLS_Class_C257.jpg',
    'Maibatsu Lancer EVO IX': 'Maibatsu_Lancer_EVO_IX.jpg',
    'Coil Model 3': 'Coil_Model_3.jpg',
    'Obey A8 D5': 'Obey_A8_D5.jpg',
    'Bravado Charger Redeye': 'Bravado_Charger_Redeye.jpg',
    'Bravado Charger Redeve': 'Bravado_Charger_Redeye.jpg',
    'Progen Senna': 'Progen_Senna.jpg',
    'Ubermacht M5 F10': 'Ubermacht_M5_F10.jpg',
    'BF Golf VIII': 'BF_Golf_VIII.jpg',
    'Vapid Mustang GT S550': 'Vapid_Mustang_GT_S550.jpg',
}


_CUSTOM_PHOTO_EXTENSIONS = {'.jpg', '.jpeg', '.png', '.webp'}


def _safe_custom_photo_relative(value):
    """Accept only a single image filename inside vehicle_photos/custom."""
    raw = str(value or '').replace('\\', '/').strip()
    parts = raw.split('/')
    if len(parts) != 3 or parts[0] != 'vehicle_photos' or parts[1] != 'custom':
        return ''
    name = parts[2]
    if not name or name in ('.', '..') or Path(name).name != name:
        return ''
    if Path(name).suffix.lower() not in _CUSTOM_PHOTO_EXTENSIONS:
        return ''
    return '/'.join(parts)


def vehicle_custom_photo_path(model):
    """Resolve a user-selected image without allowing a path outside the custom-photo folder."""
    relative = _safe_custom_photo_relative(CUSTOM_VEHICLE_PHOTOS.get(str(model or '').strip()))
    if not relative:
        return None
    root = (DATA / 'vehicle_photos' / 'custom').resolve()
    path = (DATA / Path(*relative.split('/'))).resolve()
    try:
        if path.parent != root or not path.is_file() or path.stat().st_size <= 0:
            return None
    except OSError:
        return None
    return path


def vehicle_photo_path(model):
    """Return a curated CC-licensed/public-domain reference photo, if available."""
    filename = VEHICLE_PHOTO_FILES.get(str(model or '').strip())
    if not filename:
        return None
    # In one-file builds curated photos are bundled read-only in _MEIPASS;
    # allow an explicit local override next to the user's persistent data as well.
    for root in dict.fromkeys((DATA, RESOURCE_DIR)):
        path = root / 'vehicle_photos' / filename
        if path.is_file() and path.stat().st_size > 4096 and _is_high_resolution_preview(path):
            return path
    return None


def vehicle_image_path(model):
    """Prefer user overrides, then transparent PNG cutouts, then reference photos/fallback renders."""
    custom = vehicle_custom_photo_path(model)
    if custom:
        return custom, 'custom'
    render = vehicle_render_path(model)
    if render and model in APPROXIMATE_RENDER_MODELS:
        # Tooltip/UI labels the image as a body-style reference, not a verified exact photo.
        return render, 'approximate'
    if render and Path(render).suffix.lower() == '.png':
        return render, 'render'
    photo = vehicle_photo_path(model)
    if photo:
        return photo, 'photo'
    return (render, 'render') if render else (None, 'none')


def load_rules():
    rules = {}
    for line in read_lines(RULES):
        p = line.split('|')
        if len(p) >= 3:
            try:
                rules[p[0]] = {'category': p[1].strip(), 'threshold': int(p[2])}
            except ValueError:
                pass
    return rules


def read_settings():
    settings = json.loads(json.dumps(DEFAULTS))
    old_version = 0
    try:
        loaded = json.loads(CONFIG.read_text(encoding='utf-8'))
        old_version = int(loaded.get('config_version', 0) or 0)
        settings.update({k: v for k, v in loaded.items() if k != 'grid'})
        settings['grid'].update(loaded.get('grid', {}))
        # Migrate old user settings while preserving thresholds and purchase rules.
        if old_version < 12 and int(loaded.get('interval_ms', 1200)) == 1200:
            settings['interval_ms'] = 200
        if old_version < 12 and int(loaded.get('click_delay_ms', 20) or 20) == 20:
            settings['click_delay_ms'] = 15
        # v1.2.37: start with the AHK-inspired 250 ms poll interval. The single-flight
        # worker prevents overlap; an OCR overrun skips the wait instead of queuing work.
        if old_version < 18:
            settings['interval_ms'] = 250
        try:
            configured_interval = int(settings.get('interval_ms', 50))
        except (TypeError, ValueError):
            configured_interval = 50
        # v1.2.48: the previous release's default was 250 ms. Move that default
        # to 100 ms once on upgrade; deliberate slower choices (500/1000 ms) remain.
        if old_version < 24 and configured_interval == 250:
            configured_interval = 100
        # v1.2.53: provide a 50 ms ultra-poll option. Migrate the prior 100 ms
        # default once on upgrade, while preserving explicitly slower 250/500/1000 ms choices.
        if old_version < 27 and configured_interval == 100:
            configured_interval = 50
        # v1.2.67: 20-ms ultra-poll uses the single-flight worker; a slow cycle is
        # never queued or overlapped. Migrate the previous default (50 ms) once,
        # while preserving deliberately slower settings (100/250/500/1000 ms).
        if old_version < 31 and configured_interval == 50:
            configured_interval = 20
        settings['interval_ms'] = min((20, 50, 100, 250, 500, 1000), key=lambda value: abs(value - configured_interval))
        # v1.2.45: migrate the prior default 15 ms click interval to the fastest
        # selectable value (8 ms). Intentional slower settings remain untouched.
        if old_version < 21 and int(settings.get('click_delay_ms', 15) or 15) == 15:
            settings['click_delay_ms'] = 8
        # v1.2.46: 1 ms click gesture; auto purchase + final confirmation are migration defaults
        # for this user's explicit request. They only run after the user starts scanning.
        if old_version < 22:
            settings['click_delay_ms'] = 1
            settings['auto_click'] = True
            settings['auto_confirm'] = True
        # v1.2.51 adds seven user-requested catalogue vehicles. When migrating an
        # older saved selection, append these additions once, but never add Vapid Model T
        # or Gallivanter. Existing explicit thresholds/selection values are preserved.
        if old_version < 26:
            added_models = [
                'Karin Land Cruiser 100', 'Shitzu Matiz', 'Vapid F-150 Raptor',
                'BF Surfer', 'Grotti Roma', 'Vapid Transit V347', 'BF T6.1',
            ]
            if isinstance(settings.get('selected_models'), list):
                settings['selected_models'] = list(dict.fromkeys(settings['selected_models'] + added_models))
            if isinstance(settings.get('model_thresholds'), dict):
                settings['model_thresholds'].setdefault('Shitzu Matiz', 20)
        # v1.2.60: keep menu switches responsive on upgrade. The user may
        # explicitly turn animations back on in Settings after trying the build.
        if old_version < 29:
            settings['animations_enabled'] = False
        # 2K personalized hotfix: previous settings may have left AUTO_CONFIRM off,
        # which is exactly the state that leaves the green final purchase dialog open.
        # Apply this once per user's existing v29 config; the user can still disable
        # either automation switch later in Settings and the new v30 config preserves it.
        if old_version < 30:
            settings['auto_click'] = True
            settings['auto_confirm'] = True
            if str(settings.get('resolution_profile', 'auto') or 'auto') == 'auto':
                settings['resolution_profile'] = '2560x1440'
        settings['config_version'] = 31
    except Exception:
        settings['interval_ms'] = 20
        settings['config_version'] = 31
    profile = str(settings.get('resolution_profile', 'auto') or 'auto')
    settings['resolution_profile'] = profile if profile in {'auto', '1920x1080', '2560x1440'} else 'auto'
    settings['animations_enabled'] = bool(settings.get('animations_enabled', False))
    # GREEN ONLY hard lock: never spend OCR time on red/unknown badges.
    settings['fast_color_filter_enabled'] = True
    settings['blacklist_protection_enabled'] = bool(settings.get('blacklist_protection_enabled', True))
    settings['confidence_protection_enabled'] = bool(settings.get('confidence_protection_enabled', True))
    settings['auto_refresh_enabled'] = bool(settings.get('auto_refresh_enabled', False))
    try:
        settings['auto_refresh_interval_min'] = max(1, min(10, int(settings.get('auto_refresh_interval_min', 5) or 5)))
    except (TypeError, ValueError):
        settings['auto_refresh_interval_min'] = 5
    settings['continue_after_purchase'] = bool(settings.get('continue_after_purchase', True))
    settings['auto_click'] = bool(settings.get('auto_click', False))
    settings['auto_confirm'] = bool(settings.get('auto_confirm', False)) and settings['auto_click']
    settings['click_delay_ms'] = max(1, min(100, int(settings.get('click_delay_ms', 1) or 1)))
    if not isinstance(settings.get('model_thresholds'), dict):
        settings['model_thresholds'] = {}
    # Custom catalog entries are stored in settings.json so the scanner can use
    # their names/rules on the next launch without editing bundled text files.
    raw_custom = settings.get('custom_vehicles', {})
    clean_custom = {}
    valid_categories = {'Пріоритетне', 'Звичайне', 'Спеціальне'}
    if isinstance(raw_custom, dict):
        for raw_name, raw_meta in raw_custom.items():
            name = ' '.join(str(raw_name or '').split())
            if not name or len(name) > 120 or not isinstance(raw_meta, dict):
                continue
            category = str(raw_meta.get('category', 'Звичайне')).strip()
            if category not in valid_categories:
                category = 'Звичайне'
            try:
                threshold = max(0, min(100, int(raw_meta.get('threshold', 20))))
            except (TypeError, ValueError):
                threshold = 20
            clean_custom[name] = {
                'category': category,
                'threshold': threshold,
                'photo_file': _safe_custom_photo_relative(raw_meta.get('photo_file', '')),
            }
    settings['custom_vehicles'] = clean_custom
    raw_photos = settings.get('vehicle_photos', {})
    clean_photos = {}
    if isinstance(raw_photos, dict):
        for raw_name, raw_path in raw_photos.items():
            name = ' '.join(str(raw_name or '').split())
            safe_path = _safe_custom_photo_relative(raw_path)
            if name and len(name) <= 120 and safe_path:
                clean_photos[name] = safe_path
    settings['vehicle_photos'] = clean_photos
    settings['config_version'] = 31
    # Seed the per-model thresholds requested by the user, without overwriting
    # any values they have explicitly customized in settings.json.
    for model, value in DEFAULT_MODEL_THRESHOLDS.items():
        if old_version < 12:
            settings['model_thresholds'][model] = value
        else:
            settings['model_thresholds'].setdefault(model, value)
    # Migrate the previous misspelling without losing selection or per-model rules.
    old_name, new_name = 'Bravado Charger Redeve', 'Bravado Charger Redeye'
    if isinstance(settings.get('selected_models'), list):
        settings['selected_models'] = [new_name if m == old_name else m for m in settings['selected_models']]
    for key_name in ('model_thresholds', 'category_overrides'):
        mapping = settings.get(key_name, {})
        if isinstance(mapping, dict) and old_name in mapping and new_name not in mapping:
            mapping[new_name] = mapping.pop(old_name)
    return settings


class TransparentVehiclePreview(QLabel):
    """Show a cropped transparent vehicle cutout with no checkerboard or image panel."""
    def __init__(self, pixmap=None, min_height=178, parent=None):
        super().__init__(parent)
        self._source_pixmap = _load_cached_pixmap(pixmap)
        self._source_signature = str(pixmap) if isinstance(pixmap, (str, Path)) else ''
        self.setObjectName('vehiclePreview')
        self.setFixedHeight(max(90, int(min_height)))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setAttribute(Qt.WA_TranslucentBackground, True)
        self.setAutoFillBackground(False)
        self.setToolTip('Зображення автомобіля на фоні картки без зайвої підкладки.')

    def set_source(self, pixmap):
        signature = str(pixmap) if isinstance(pixmap, (str, Path)) else ''
        self._source_pixmap = _load_cached_pixmap(pixmap)
        self._source_signature = signature
        self.update()

    def paintEvent(self, event):
        # Deliberately do not fill the widget or draw a checkerboard. PNG alpha
        # reveals the vehicle-card gradient, which is the desired clean cutout UI.
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        if not self._source_pixmap.isNull():
            margin_x = max(1, int(2 * getattr(self, 'ui_scale', 1.0)))
            margin_y = max(1, int(3 * getattr(self, 'ui_scale', 1.0)))
            target = self.rect().adjusted(margin_x, margin_y, -margin_x, -margin_y)
            fitted = self._source_pixmap.scaled(target.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            x = target.x() + (target.width() - fitted.width()) // 2
            y = target.y() + (target.height() - fitted.height()) // 2
            painter.drawPixmap(x, y, fitted)
        painter.end()


class HeroImage(QLabel):
    """Cinematic right-side image: crop to fill while preserving the source aspect ratio."""
    def __init__(self, path, parent=None):
        super().__init__(parent)
        self.source = QPixmap(str(path)) if Path(path).exists() else QPixmap()
        self.setObjectName('hero')
        self.setMinimumWidth(220)
        self.setMaximumWidth(270)
        self.setFixedWidth(250)
        self.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Expanding)
        self.setAlignment(Qt.AlignCenter)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.fillRect(self.rect(), Qt.black)
        if self.source.isNull():
            painter.setPen(Qt.white)
            painter.drawText(self.rect(), Qt.AlignCenter, 'NG  ·  ENRIQUE')
            return
        # Fill the panel with a subdued full-bleed backdrop, then draw the complete
        # original image on top with KeepAspectRatio so neither ENRIQUE nor NG logos
        # are cut off or stretched.
        painter.setRenderHint(QPainter.SmoothPixmapTransform, True)
        painter.setClipRect(self.rect())
        backdrop = self.source.scaled(self.size(), Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        bx = (self.width() - backdrop.width()) // 2
        by = (self.height() - backdrop.height()) // 2
        painter.setOpacity(0.30)
        painter.drawPixmap(bx, by, backdrop)
        painter.setOpacity(1.0)
        painter.fillRect(self.rect(), QColor(0, 0, 0, 95))
        fitted = self.source.scaled(self.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
        fx = (self.width() - fitted.width()) // 2
        fy = (self.height() - fitted.height()) // 2
        painter.drawPixmap(fx, fy, fitted)


def _draw_vector_icon(painter, name, color):
    """Draw simple consistent line icons; no font glyphs or platform-specific system icons."""
    painter.save()
    painter.setRenderHint(QPainter.Antialiasing, True)
    painter.scale(painter.device().width() / 64.0, painter.device().height() / 64.0)
    pen = QPen(QColor(color))
    pen.setWidthF(4.2)
    pen.setCapStyle(Qt.RoundCap)
    pen.setJoinStyle(Qt.RoundJoin)
    painter.setPen(pen)
    painter.setBrush(Qt.NoBrush)

    if name == 'scan':
        painter.drawRoundedRect(12, 12, 40, 40, 8, 8)
        painter.drawLine(32, 21, 32, 43)
        painter.drawLine(21, 32, 43, 32)
        painter.drawEllipse(27, 27, 10, 10)
    elif name in ('car', 'catalog', 'models'):
        painter.drawLine(17, 31, 23, 21)
        painter.drawLine(23, 21, 41, 21)
        painter.drawLine(41, 21, 48, 31)
        painter.drawRoundedRect(12, 29, 40, 18, 5, 5)
        painter.drawLine(18, 37, 25, 37)
        painter.drawLine(39, 37, 46, 37)
        painter.drawEllipse(18, 42, 9, 9)
        painter.drawEllipse(37, 42, 9, 9)
    elif name == 'settings':
        painter.drawEllipse(21, 21, 22, 22)
        painter.drawEllipse(27, 27, 10, 10)
        for angle in range(0, 360, 45):
            import math
            a = math.radians(angle)
            painter.drawLine(QPointF(32 + 14*math.cos(a), 32 + 14*math.sin(a)),
                             QPointF(32 + 22*math.cos(a), 32 + 22*math.sin(a)))
    elif name == 'stats':
        painter.drawLine(12, 52, 52, 52)
        painter.drawRoundedRect(16, 35, 8, 17, 2, 2)
        painter.drawRoundedRect(28, 25, 8, 27, 2, 2)
        painter.drawRoundedRect(40, 15, 8, 37, 2, 2)
    elif name in ('log', 'journal'):
        painter.drawRoundedRect(15, 10, 34, 44, 6, 6)
        for y in (23, 33, 43):
            painter.drawEllipse(21, y-2, 4, 4)
            painter.drawLine(30, y, 42, y)
    elif name in ('about', 'info'):
        painter.drawEllipse(13, 13, 38, 38)
        painter.drawEllipse(29, 21, 6, 6)
        painter.drawLine(32, 31, 32, 42)
    elif name == 'grid':
        for x, y in ((13, 13), (36, 13), (13, 36), (36, 36)):
            painter.drawRoundedRect(x, y, 15, 15, 3, 3)
    elif name == 'check':
        painter.drawEllipse(12, 12, 40, 40)
        path = QPainterPath(); path.moveTo(22, 32); path.lineTo(29, 39); path.lineTo(43, 24)
        painter.drawPath(path)
    elif name == 'clock':
        painter.drawEllipse(12, 12, 40, 40)
        painter.drawLine(32, 20, 32, 33)
        painter.drawLine(32, 33, 42, 38)
    elif name == 'refresh':
        painter.drawArc(15, 15, 34, 34, 35 * 16, 260 * 16)
        path = QPainterPath(); path.moveTo(42, 13); path.lineTo(51, 14); path.lineTo(48, 23)
        painter.drawPath(path)
        painter.drawArc(15, 15, 34, 34, 215 * 16, 260 * 16)
        path = QPainterPath(); path.moveTo(22, 51); path.lineTo(13, 50); path.lineTo(16, 41)
        painter.drawPath(path)
    elif name == 'play':
        painter.setPen(Qt.NoPen); painter.setBrush(QColor(color))
        path = QPainterPath(); path.moveTo(23, 15); path.lineTo(48, 32); path.lineTo(23, 49); path.closeSubpath()
        painter.drawPath(path)
    elif name == 'stop':
        painter.setPen(Qt.NoPen); painter.setBrush(QColor(color))
        painter.drawRoundedRect(18, 18, 28, 28, 5, 5)
    elif name == 'save':
        painter.drawRoundedRect(14, 11, 36, 42, 5, 5)
        painter.drawRoundedRect(23, 11, 18, 12, 2, 2)
        painter.drawRoundedRect(22, 34, 20, 13, 2, 2)
        painter.drawLine(22, 28, 42, 28)
    painter.restore()


def make_ui_icon_pixmap(name, color='#55D6AE', size=18):
    """High-DPI rendered icon pixmap with a predictable silhouette on every Windows theme."""
    scale = 3
    pixmap = QPixmap(max(1, size*scale), max(1, size*scale))
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    _draw_vector_icon(painter, name, color)
    painter.end()
    return pixmap.scaled(size, size, Qt.IgnoreAspectRatio, Qt.SmoothTransformation)


def make_ui_icon(name, color='#55D6AE'):
    """Return a scalable QIcon generated from the same vector drawing routine."""
    pixmap = QPixmap(192, 192)
    pixmap.fill(Qt.transparent)
    painter = QPainter(pixmap)
    _draw_vector_icon(painter, name, color)
    painter.end()
    return QIcon(pixmap)


def make_icon_label(name, size=16, color='#55D6AE'):
    label = QLabel()
    label.setObjectName('sectionIcon')
    label.setPixmap(make_ui_icon_pixmap(name, color, size))
    label.setFixedSize(size, size)
    label.setAlignment(Qt.AlignCenter)
    return label


def _load_sidecar(path: Path, module_name: str, required_files=()):
    if not path.is_file():
        raise FileNotFoundError(f'Не знайдено вбудований модуль: {path.name}')
    for required in required_files:
        if not (RESOURCE_DIR / required).is_file():
            raise FileNotFoundError(f'Не знайдено вбудований ресурс {required}. Перевстановіть програму з повного комплекту.')
    if str(RESOURCE_DIR) not in sys.path:
        sys.path.insert(0, str(RESOURCE_DIR))
    stamp = (path.stat().st_mtime_ns, path.stat().st_size,
             tuple((RESOURCE_DIR / r).stat().st_mtime_ns for r in required_files))
    global _CACHED_SCAN_CORE, _CACHED_SCAN_CORE_STAMP, _CACHED_ACTION_CORE, _CACHED_ACTION_CORE_STAMP
    if module_name == 'ng_external_scanner_core' and _CACHED_SCAN_CORE is not None and stamp == _CACHED_SCAN_CORE_STAMP:
        return _CACHED_SCAN_CORE
    if module_name == 'ng_external_scanner_actions' and _CACHED_ACTION_CORE is not None and stamp == _CACHED_ACTION_CORE_STAMP:
        return _CACHED_ACTION_CORE
    if module_name == 'ng_external_scanner_core':
        # Ensure a changed external logic file is actually imported with the next core load.
        sys.modules.pop('scanner_core_logic', None)
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f'Не вдалося завантажити модуль: {path}')
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception:
        sys.modules.pop(module_name, None)
        raise
    if module_name == 'ng_external_scanner_core':
        _CACHED_SCAN_CORE, _CACHED_SCAN_CORE_STAMP = module, stamp
    else:
        _CACHED_ACTION_CORE, _CACHED_ACTION_CORE_STAMP = module, stamp
    return module


def load_external_scan_core():
    """Cache sidecar imports between cycles so RapidOCR's ONNX model is reused."""
    return _load_sidecar(RESOURCE_DIR / 'scanner_core.py', 'ng_external_scanner_core', ('scanner_core_logic.py',))


def load_external_action_core():
    """Load click automation independently from the EXE; fail closed if missing."""
    return _load_sidecar(RESOURCE_DIR / 'scanner_actions.py', 'ng_external_scanner_actions')


class MiniLineChart(QWidget):
    """Lightweight chart painted with QPainter; displays real measurements only."""
    def __init__(self, title, unit='с', parent=None):
        super().__init__(parent)
        self.title = title
        self.unit = unit
        self.values = []
        self.setObjectName('miniChart')
        self.setMinimumHeight(154)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_values(self, values):
        cleaned = []
        for value in list(values or []):
            try:
                number = float(value)
                if math.isfinite(number) and number >= 0:
                    cleaned.append(number)
            except (TypeError, ValueError):
                continue
        self.values = cleaned[-60:]
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing, True)
        rect = self.rect().adjusted(1, 1, -1, -1)
        painter.setPen(QPen(QColor('#26394B'), 1))
        painter.setBrush(QColor('#101B26'))
        painter.drawRoundedRect(rect, 12, 12)
        painter.setPen(QColor('#E7EDF5'))
        painter.setFont(QFont('Segoe UI', 9, QFont.DemiBold))
        painter.drawText(rect.adjusted(14, 10, -14, -4), Qt.AlignTop | Qt.AlignLeft, self.title)
        plot = rect.adjusted(14, 38, -14, -25)
        if len(self.values) < 2:
            painter.setPen(QColor('#8093A8'))
            painter.setFont(QFont('Segoe UI', 8))
            painter.drawText(plot, Qt.AlignCenter, 'Недостатньо фактичних вимірювань')
            painter.end()
            return
        low = min(self.values)
        high = max(self.values)
        if high - low < 0.000001:
            pad = max(0.02, abs(high) * 0.15)
            low, high = max(0.0, low - pad), high + pad
        else:
            pad = (high - low) * 0.14
            low, high = max(0.0, low - pad), high + pad
        painter.setPen(QPen(QColor('#26394B'), 1, Qt.PenStyle.DashLine))
        for index in range(4):
            y = plot.top() + plot.height() * index / 3
            painter.drawLine(int(plot.left()), int(y), int(plot.right()), int(y))
        path = QPainterPath()
        count = len(self.values)
        points = []
        for i, value in enumerate(self.values):
            x = plot.left() + (plot.width() * i / max(1, count - 1))
            y = plot.bottom() - ((value - low) / max(0.000001, high - low)) * plot.height()
            points.append(QPointF(x, y))
        if points:
            path.moveTo(points[0])
            for point in points[1:]:
                path.lineTo(point)
        pen = QPen(QColor('#56E6B7'), 2.2)
        pen.setCapStyle(Qt.RoundCap)
        pen.setJoinStyle(Qt.RoundJoin)
        painter.setPen(pen)
        painter.setBrush(Qt.NoBrush)
        painter.drawPath(path)
        last = points[-1]
        painter.setPen(Qt.NoPen)
        painter.setBrush(QColor('#56E6B7'))
        painter.drawEllipse(last, 3.5, 3.5)
        painter.setPen(QColor('#9CB0C2'))
        painter.setFont(QFont('Segoe UI', 8))
        painter.drawText(rect.adjusted(14, 0, -14, -8), Qt.AlignBottom | Qt.AlignLeft,
                         f'{len(self.values)} вимірювань')
        painter.drawText(rect.adjusted(14, 0, -14, -8), Qt.AlignBottom | Qt.AlignRight,
                         f'{self.values[-1]:.3f} {self.unit}')
        painter.end()


class CoverPhotoLabel(QLabel):
    """Large image area for recognizable vehicles; dimensions adapt to the active UI scale."""
    def __init__(self, parent=None, min_height=220, max_height=300):
        super().__init__(parent)
        self._source_pixmap = QPixmap()
        self.setObjectName('vehiclePhoto')
        self.setAlignment(Qt.AlignCenter)
        self.setMinimumHeight(int(min_height))
        self.setMaximumHeight(int(max(max_height, min_height)))
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

    def set_image(self, path):
        self._source_pixmap = QPixmap(str(path)) if path else QPixmap()
        self._refresh_image()

    def _refresh_image(self):
        if self._source_pixmap.isNull() or self.width() < 2 or self.height() < 2:
            self.setPixmap(QPixmap())
            if self._source_pixmap.isNull():
                self.setText('Зображення для моделі недоступне')
            return
        target = self.size()
        if self._source_pixmap.hasAlphaChannel():
            # Transparent vehicle cutouts must fit completely; cover-cropping
            # would clip bumpers and make the silhouette inconsistent by model.
            scaled = self._source_pixmap.scaled(target, Qt.KeepAspectRatio, Qt.SmoothTransformation)
            self.setText('')
            self.setPixmap(scaled)
            return
        scaled = self._source_pixmap.scaled(target, Qt.KeepAspectRatioByExpanding, Qt.SmoothTransformation)
        x = max(0, (scaled.width() - target.width()) // 2)
        y = max(0, (scaled.height() - target.height()) // 2)
        crop = scaled.copy(x, y, target.width(), target.height())
        self.setText('')
        self.setPixmap(crop)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self._refresh_image()


class VehicleEditorDialog(QDialog):
    """Small native dialog for adding a custom model or editing a model's photo/rules."""
    def __init__(self, parent=None, *, name='', category='Звичайне', threshold=20,
                 photo_path=None, preview_path=None, name_editable=True, is_new=False,
                 active_by_default=True):
        super().__init__(parent)
        self.setWindowTitle('Додати автомобіль' if is_new else 'Редагувати автомобіль')
        self.setMinimumWidth(490)
        self._photo_path = str(photo_path or '')
        self.photo_changed = False
        outer = QVBoxLayout(self)
        outer.setContentsMargins(18, 16, 18, 16)
        outer.setSpacing(12)
        form_box = QFrame(self)
        form_box.setObjectName('glassPanel')
        form = QFormLayout(form_box)
        form.setContentsMargins(14, 12, 14, 12)
        form.setSpacing(10)
        self.name_input = QLineEdit(str(name or ''))
        self.name_input.setMaxLength(120)
        self.name_input.setPlaceholderText('Наприклад: Benefactor S-Class W223')
        self.name_input.setReadOnly(not name_editable)
        if not name_editable:
            self.name_input.setToolTip('Назва наявної ігрової моделі незмінна, щоб OCR зіставляв її з правильним авто.')
        form.addRow('Назва моделі', self.name_input)
        self.category_input = QComboBox()
        self.category_input.addItems(['Пріоритетне', 'Звичайне', 'Спеціальне'])
        self.category_input.setCurrentText(category if category in ('Пріоритетне', 'Звичайне', 'Спеціальне') else 'Звичайне')
        form.addRow('Категорія', self.category_input)
        self.threshold_input = QSpinBox()
        self.threshold_input.setRange(0, 100)
        self.threshold_input.setSuffix(' %')
        self.threshold_input.setValue(max(0, min(100, int(threshold))))
        form.addRow('Мінімальна знижка', self.threshold_input)
        outer.addWidget(form_box)

        photo_box = QFrame(self)
        photo_box.setObjectName('glassPanel')
        photo_layout = QVBoxLayout(photo_box)
        photo_layout.setContentsMargins(14, 12, 14, 12)
        photo_layout.setSpacing(8)
        self.preview = QLabel()
        self.preview.setObjectName('vehicleEditorPhoto')
        self.preview.setMinimumSize(280, 150)
        self.preview.setMaximumHeight(190)
        self.preview.setAlignment(Qt.AlignCenter)
        self.preview.setWordWrap(True)
        self.preview.setText('Фото не вибрано. Для моделі буде використано доступний рендер.')
        photo_layout.addWidget(self.preview, 0, Qt.AlignHCenter)
        photo_buttons = QHBoxLayout()
        choose = QPushButton('Вибрати фото…')
        choose.setObjectName('ghost')
        choose.clicked.connect(self._choose_photo)
        clear = QPushButton('Прибрати власне фото')
        clear.setObjectName('ghost')
        clear.clicked.connect(self._clear_photo)
        photo_buttons.addWidget(choose)
        photo_buttons.addWidget(clear)
        photo_layout.addLayout(photo_buttons)
        outer.addWidget(photo_box)
        self.active_input = QCheckBox('Одразу додати модель до активного пошуку')
        self.active_input.setChecked(bool(active_by_default))
        self.active_input.setVisible(bool(is_new))
        outer.addWidget(self.active_input)
        note = QLabel('Додай власне фото для візуального розпізнавання моделі. Файл буде скопійовано до папки даних програми, тому його не потрібно зберігати за старим шляхом.')
        note.setObjectName('mutedNote')
        note.setWordWrap(True)
        outer.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Save | QDialogButtonBox.StandardButton.Cancel)
        buttons.accepted.connect(self._validate_and_accept)
        buttons.rejected.connect(self.reject)
        outer.addWidget(buttons)
        initial_preview = preview_path or photo_path
        self._show_preview(initial_preview)

    def _show_preview(self, path):
        pixmap = QPixmap(str(path)) if path else QPixmap()
        if pixmap.isNull():
            self.preview.setPixmap(QPixmap())
            self.preview.setText('Фото не вибрано. Для моделі буде використано доступний рендер.')
            return
        self.preview.setText('')
        self.preview.setPixmap(pixmap.scaled(440, 180, Qt.KeepAspectRatio, Qt.SmoothTransformation))

    def _choose_photo(self):
        path, _ = QFileDialog.getOpenFileName(
            self, 'Вибрати фото автомобіля', '',
            'Файли зображень (*.jpg *.jpeg *.png *.webp)'
        )
        if not path:
            return
        pixmap = QPixmap(path)
        if pixmap.isNull():
            QMessageBox.warning(self, 'Некоректне фото', 'Не вдалося відкрити цей файл як зображення.')
            return
        self._photo_path = path
        self.photo_changed = True
        self._show_preview(path)

    def _clear_photo(self):
        self._photo_path = ''
        self.photo_changed = True
        self._show_preview(None)

    def _validate_and_accept(self):
        name = ' '.join(self.name_input.text().split())
        if not name:
            QMessageBox.warning(self, 'Потрібна назва', 'Введи назву автомобіля.')
            self.name_input.setFocus()
            return
        if len(name) > 120:
            QMessageBox.warning(self, 'Задовга назва', 'Назва моделі має містити не більше 120 символів.')
            return
        self.name_input.setText(name)
        self.accept()

    def values(self):
        return {
            'name': ' '.join(self.name_input.text().split()),
            'category': self.category_input.currentText(),
            'threshold': int(self.threshold_input.value()),
            'photo_path': self._photo_path,
            'photo_changed': bool(self.photo_changed),
            'active': bool(self.active_input.isChecked()),
        }


class Main(QMainWindow):
    @staticmethod
    def _detect_ui_scale(profile='auto'):
        """Choose UI density; scanner and click coordinates always use the live physical screen size."""
        profile = str(profile or 'auto')
        if profile == '1920x1080':
            return 1.0
        if profile == '2560x1440':
            return 1.18
        physical_width, physical_height = Main._physical_screen_size()
        if physical_width <= 0 or physical_height <= 0:
            screen = QApplication.primaryScreen()
            if screen is None:
                return 1.0
            geometry = screen.availableGeometry()
            ratio = max(1.0, float(screen.devicePixelRatio()))
            physical_width = int(round(geometry.width() * ratio))
            physical_height = int(round(geometry.height() * ratio))
        if physical_width >= 2400 and physical_height >= 1300:
            return 1.18
        if physical_width >= 1900 and physical_height >= 1000:
            return 1.08
        return 1.0

    @staticmethod
    def _physical_screen_size():
        """Return physical primary-monitor pixels in the same space used by DXcam and Win32 clicks."""
        if os.name == 'nt':
            try:
                import ctypes
                user32 = ctypes.windll.user32
                user32.GetSystemMetrics.argtypes = [ctypes.c_int]
                user32.GetSystemMetrics.restype = ctypes.c_int
                width = int(user32.GetSystemMetrics(0))
                height = int(user32.GetSystemMetrics(1))
                if width > 0 and height > 0:
                    return (width, height)
            except Exception:
                pass
        # Qt fallback for non-Windows development and unusual Win32 API failures.
        screen = QApplication.primaryScreen()
        if screen is None:
            return (0, 0)
        geometry = screen.geometry()
        ratio = max(1.0, float(screen.devicePixelRatio()))
        return (int(round(geometry.width() * ratio)), int(round(geometry.height() * ratio)))

    def _screen_profile_status_text(self):
        width, height = self._physical_screen_size()
        mode = '2K' if width >= 2400 and height >= 1300 else ('Full HD' if width >= 1850 and height >= 1000 else 'виявлено')
        profile = str(getattr(self, '_pending_resolution_profile', self.settings.get('resolution_profile', 'auto')))
        profile_label = RESOLUTION_PROFILE_LABELS.get(profile, RESOLUTION_PROFILE_LABELS['auto'])
        if profile != getattr(self, '_startup_resolution_profile', profile):
            apply_note = ' · профіль застосовується після перезапуску'
        else:
            apply_note = ''
        if width and height:
            return f'Фактичний екран: {width}×{height} ({mode}) · профіль UI: {profile_label}{apply_note}. Координати сканера масштабуються за фактичним екраном.'
        return f'Масштаб UI: {profile_label}{apply_note}. Координати сканера масштабуються за фактичним екраном.'

    def __init__(self):
        super().__init__()
        self.settings = read_settings()
        self._startup_resolution_profile = str(self.settings.get('resolution_profile', 'auto'))
        self._pending_resolution_profile = self._startup_resolution_profile
        self.ui_scale = self._detect_ui_scale(self._startup_resolution_profile)
        self.setWindowIcon(QIcon(str(ICON_PATH)) if ICON_PATH.is_file() else make_ui_icon('car', '#45F0B5'))
        self.setWindowTitle('NG Market Scanner v1.2.81 — POST-PURCHASE NAVIGATION + CONTINUOUS BUY / Full HD / 2K')
        screen = QApplication.primaryScreen()
        available = screen.availableGeometry() if screen is not None else None
        if available is not None:
            initial_width = min(available.width(), max(int(1380 * self.ui_scale), int(available.width() * 0.88)))
            initial_height = min(available.height(), max(int(820 * self.ui_scale), int(available.height() * 0.86)))
            self.resize(initial_width, initial_height)
        else:
            self.resize(1380, 820)
        self.setMinimumSize(int(1040 * self.ui_scale), int(650 * self.ui_scale))
        self.rules = load_rules()
        custom_vehicles = self.settings.get('custom_vehicles', {})
        if isinstance(custom_vehicles, dict):
            for model, meta in custom_vehicles.items():
                self.rules[model] = {
                    'category': meta.get('category', 'Звичайне'),
                    'threshold': int(meta.get('threshold', 20)),
                }
        bundled_models = read_lines(ALL)
        # Keep built-in order, then append any rule-only/custom names exactly once.
        self.all_models = list(dict.fromkeys((bundled_models or list(self.rules)) + list(self.rules)))
        for model, category in self.settings.get('category_overrides', {}).items():
            if model in self.rules and category in ('Пріоритетне', 'Звичайне', 'Спеціальне'):
                self.rules[model]['category'] = category
        CUSTOM_VEHICLE_PHOTOS.clear()
        for model, relative in self.settings.get('vehicle_photos', {}).items():
            safe_relative = _safe_custom_photo_relative(relative)
            if safe_relative:
                CUSTOM_VEHICLE_PHOTOS[model] = safe_relative
        if isinstance(custom_vehicles, dict):
            for model, meta in custom_vehicles.items():
                safe_relative = _safe_custom_photo_relative(meta.get('photo_file', ''))
                if safe_relative:
                    CUSTOM_VEHICLE_PHOTOS[model] = safe_relative
        self.running = False
        self.busy = False
        # Single-flight latch survives until QThread.finished, even after result emission.
        self._scan_request_active = False
        self._scan_result_received = False
        self._scan_finish_waits = 0
        self._scan_cycle_started_at = None
        self.worker = None
        self.action_worker = None
        self.green_watch_worker = None
        self.green_badge_worker = None
        self._green_watch_mode = False
        self._green_badge_context = None
        self._green_batch_candidates = None
        self._green_direct_context = None
        self._green_resume_pending = False
        self.action_in_progress = False
        self._urgent_candidate_started = False
        self._ocr_core_compatible = False
        self._action_result_received = False
        self._action_result_handled = False
        self._last_action_success = False
        # Persist user intent separately from `running`, which is temporarily cleared
        # while a purchase worker owns the UI. This prevents worker finalization from
        # accidentally converting a continuous session into a one-shot scan.
        self._continuous_scan_requested = False
        # Resume only a continuous session interrupted by an auto-purchase.
        self._resume_scan_after_action = False
        self._resume_focus_recovery_attempted = False
        # A short post-click cool-down is followed by a cheap UI-state gate. OCR is not
        # restarted until the actual 3x5 market grid is visible on two fresh frames.
        self._resume_scan_not_before = 0.0
        self._resume_market_wait_started = 0.0
        self._resume_market_good_frames = 0
        self._resume_market_good_since = None
        self._resume_market_last_frame_token = None
        self._resume_market_last_state_logged = ''
        self._resume_market_back_attempted = False
        self._resume_market_cancel_attempts = 0
        self._resume_market_cancel_last_attempt_at = 0.0
        self._resume_market_confirm_started_at = 0.0
        self._resume_market_confirm_good_frames = 0
        self._resume_market_confirm_last_frame_token = None
        self._resume_market_screen_size = None
        self._resume_after_purchase_navigation = False
        # Preserve the game HWND while result handling resets the ordinary scan latch.
        self._resume_market_target_hwnd = None
        # Periodic market refresh is separate from the scan cadence so it never
        # interrupts an OCR worker or overlaps a purchase click workflow.
        self._auto_refresh_in_progress = False
        self._auto_refresh_pending = False
        self._auto_refresh_sequence_id = 0
        self._auto_refresh_target_hwnd = None
        self._auto_refresh_screen_size = None
        self._auto_refresh_wait_reason = ''
        self._purchase_was_continuous_scan = False
        self._stop_hotkey_latched = False
        self._catalog_manual_thresholds = set()
        self.last = []
        # Performance histories contain only real scanner/OCR measurements, never demo values.
        self._cycle_history = deque(maxlen=60)
        self._ocr_history = deque(maxlen=60)
        self._cycle_timestamps = deque(maxlen=180)
        self._last_actual_ocr_seconds = None
        self._last_cycle_elapsed = None
        self._last_cache_hits = 0
        self._last_changed_cards = None
        self._last_ocr_calls = 0
        self._last_green_count = 0
        self._last_backend = 'Підготовка OCR…'
        self._gallery_signature = None
        # Log a continuously visible offer once until it disappears from scan results.
        self._seen_eligible_offer_keys = set()
        self._seen_blocked_discount_keys = set()
        # Journal each card on first observation and again only when its visible result changes.
        self._last_logged_vehicle_snapshots = {}
        self._scan_cycle_number = 0
        self._last_core_version_logged = None
        self.capture_hidden = False
        # Cached only during one scan session; matches the AHK TargetHwnd guard.
        self._scan_target_hwnd = None
        self._waiting_for_game_logged = False
        self.pending_scan = None
        self.nav_buttons = {}
        self.page_index = {}
        self.event_lines = []
        self._log_views_refresh_pending = False
        self._stats_events = []
        self._stats_flush_pending = False
        self._stats_refresh_pending = False
        self._stats_confirmation_keys = set()
        self._purchase_offer_keys_attempted = set()
        self._purchase_offer_skip_logged = set()
        self._active_purchase_attempt_key = None
        self._active_purchase_click_sent = False
        self._active_purchase_candidate = None
        self._active_purchase_started = None
        self._catalog_grid_refresh_pending = False
        self._catalog_grid_needs_refresh = True
        self._catalog_build_token = 0
        self._catalog_built_signature = None
        self.pages = {}
        self._load_old_log()
        self._load_stats_history()
        self._build_ui()
        self._apply_style()
        # Each page fades independently. Avoid nested QGraphicsEffects on buttons/cards: on
        # some Windows Qt builds they cause children to disappear inside the stacked page.
        self._page_fade_effects = {}
        self._fade = None
        self._refresh_safe_note()
        self.refresh_catalog()
        self.refresh_stats()
        self.refresh_log_views()
        self.refresh_vehicle_gallery()
        self._refresh_performance_widgets()
        self.ocr_ready = False
        self.ocr_warmup_worker = None
        self.navigate('scan')
        self.hotkey_timer = QTimer(self)
        self.hotkey_timer.timeout.connect(self._poll_global_stop_hotkey)
        self.hotkey_timer.start(50)
        # One-time startup preparation: initialize and warm OCR outside the UI
        # thread so the first user-requested scan avoids model cold-start time.
        self.start_btn.setEnabled(False)
        self.once_btn.setEnabled(False)
        self.state.setText('● ПІДГОТОВКА OCR')
        self.logline('NG Market Scanner v1.2.81 — POST-PURCHASE NAVIGATION FIX. Ланцюжок покупки CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM збережено; після покупки модальне вікно закривається через «Скасувати» за динамічною позицією кнопки, потім натискається «назад», а сканування відновлюється лише після підтвердження каталогу. Автооновлення використовує ESC → стрілка вниз → екран планшета → Маркет → Транспорт. Масштабування координат за фізичними пікселями; профіль UI 2K/Full HD. Зупинка: Ctrl+Alt+F8.')
        QTimer.singleShot(80, self._start_ocr_warmup)

    def _start_ocr_warmup(self):
        try:
            core = load_external_scan_core()
            core_version = str(getattr(core, 'OCR_PATCH_VERSION', 'unknown'))
            speed_version = str(getattr(core, 'OCR_SPEED_PATCH_VERSION', 'unknown'))
            capture_version = str(getattr(core, 'DETAIL_CAPTURE_CACHE_PATCH_VERSION', 'unknown'))
            detail_discount_version = str(getattr(core, 'DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION', 'unknown'))
            recognition_only_version = str(getattr(core, 'RECOGNITION_ONLY_PATCH_VERSION', 'unknown'))
            single_card_batch_version = str(getattr(core, 'SINGLE_CARD_BATCH_PATCH_VERSION', 'unknown'))
            badge_color_vector_version = str(getattr(core, 'BADGE_COLOR_VECTOR_PATCH_VERSION', 'unknown'))
            purchase_diagnostics_version = str(getattr(core, 'PURCHASE_DIAGNOSTICS_PATCH_VERSION', 'unknown'))
            fast_badge_consensus_version = str(getattr(core, 'FAST_BADGE_CONSENSUS_PATCH_VERSION', 'unknown'))
            market_return_gate_version = str(getattr(core, 'MARKET_RETURN_GATE_PATCH_VERSION', 'unknown'))
            if (core_version != EXPECTED_OCR_CORE_VERSION or speed_version != EXPECTED_OCR_SPEED_PATCH_VERSION
                    or capture_version != EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION
                    or detail_discount_version != EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION
                    or recognition_only_version != EXPECTED_RECOGNITION_ONLY_PATCH_VERSION
                    or single_card_batch_version != EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION
                    or badge_color_vector_version != EXPECTED_BADGE_COLOR_VECTOR_PATCH_VERSION
                    or purchase_diagnostics_version != EXPECTED_PURCHASE_DIAGNOSTICS_PATCH_VERSION
                    or fast_badge_consensus_version != EXPECTED_FAST_BADGE_CONSENSUS_PATCH_VERSION
                    or market_return_gate_version != EXPECTED_MARKET_RETURN_GATE_PATCH_VERSION):
                self._ocr_core_compatible = False
                message = (f'НЕСУМІСНА ЗБІРКА: потрібні OCR {EXPECTED_OCR_CORE_VERSION} і GREEN ONLY '
                           f'{EXPECTED_OCR_SPEED_PATCH_VERSION}, capture {EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION}, '
                           f'detail-validation {EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION}, recognition-only {EXPECTED_RECOGNITION_ONLY_PATCH_VERSION}, single-card batch {EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION}; завантажено '
                           f'{core_version} / {speed_version} / {capture_version} / {detail_discount_version} / {recognition_only_version} / {single_card_batch_version} / {badge_color_vector_version} / {purchase_diagnostics_version} / {fast_badge_consensus_version}. '
                           'Сканування заблоковано, щоб стара версія не видала себе за швидкий режим.')
                self.logline(message)
                self.on_ocr_warmup_done(False, message, 0.0)
                return
            self._ocr_core_compatible = True
            self.logline(f'OCR-ядро перевірено: {core_version}; режим: {speed_version}; known-ROI recognition-only: {recognition_only_version}; single-card batch: {single_card_batch_version}; purchase diagnostics: {purchase_diagnostics_version}; badge consensus: {fast_badge_consensus_version}; market-return gate: {market_return_gate_version}.')
            # Pre-import the small click sidecar before START becomes available, so
            # first-candidate handling does not pay the one-time module import cost.
            self._prewarm_action_core()
            if not hasattr(core, 'OCRWarmupWorker'):
                self.on_ocr_warmup_done(False, 'У scanner_core.py немає OCRWarmupWorker.', 0.0)
                return
            self.ocr_warmup_worker = core.OCRWarmupWorker()
            self.ocr_warmup_worker.completed.connect(self.on_ocr_warmup_done)
            self.ocr_warmup_worker.start()
        except Exception as exc:
            self._ocr_core_compatible = False
            self.on_ocr_warmup_done(False, f'{type(exc).__name__}: {exc}', 0.0)

    def _prewarm_action_core(self):
        """Load and verify the click sidecar during startup, not after a discount is detected."""
        started = time.perf_counter()
        try:
            actions = load_external_action_core()
            compatible = (
                str(getattr(actions, 'CLICK_WORKFLOW_VERSION', '')) == EXPECTED_CLICK_WORKFLOW_VERSION
                and str(getattr(actions, 'CLICK_LATENCY_PATCH_VERSION', '')) == EXPECTED_CLICK_LATENCY_PATCH_VERSION
                and str(getattr(actions, 'CLICK_WAIT_TIMER_PATCH_VERSION', '')) == EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION
                and str(getattr(actions, 'CLICK_BUTTON_PROBE_PATCH_VERSION', '')) == EXPECTED_CLICK_BUTTON_PROBE_PATCH_VERSION
                and str(getattr(actions, 'CLICK_MARKET_RETURN_PATCH_VERSION', '')) == EXPECTED_CLICK_MARKET_RETURN_PATCH_VERSION
                and str(getattr(actions, 'CLICK_DYNAMIC_CONFIRM_PATCH_VERSION', '')) == EXPECTED_DYNAMIC_CONFIRM_PATCH_VERSION
                and str(getattr(actions, 'FAST_COORDINATE_FLOW_VERSION', '')) == EXPECTED_FAST_COORDINATE_FLOW_VERSION
            )
            self._action_core_preloaded = bool(compatible)
            elapsed_ms = (time.perf_counter() - started) * 1000.0
            if compatible:
                self.logline(f'CLICK CORE PREWARM: модуль швидкої автодії перевірено й завантажено за {elapsed_ms:.1f} мс до START.')
            else:
                self.logline('CLICK CORE PREWARM: маркери версії не збігаються; автодію заблокують захисні перевірки.')
        except Exception as exc:
            self._action_core_preloaded = False
            self.logline(f'CLICK CORE PREWARM: не вдалося попередньо завантажити модуль ({type(exc).__name__}: {exc}); буде безпечна повторна спроба при автодії.')

    def on_ocr_warmup_done(self, success, message, elapsed):
        compatible = bool(getattr(self, '_ocr_core_compatible', False))
        self.ocr_ready = bool(success and compatible)
        backend_match = re.search(r'backend\s+([^\s]+)', str(message), re.IGNORECASE)
        self._last_backend = backend_match.group(1) if backend_match else ('Готовий' if self.ocr_ready else 'Помилка')
        # An older sidecar must never be allowed to run merely because the OCR model loaded.
        self.start_btn.setEnabled(compatible)
        self.once_btn.setEnabled(compatible)
        if not compatible:
            self.state.setText('● НЕСУМІСНА ЗБІРКА')
            self.logline(f'Сканування вимкнено до встановлення відповідного комплекту: {message}')
            self._refresh_live_monitor()
            return
        if success:
            self.state.setText('● ГОТОВИЙ · GREEN ONLY')
            self.logline(f'{message} за {float(elapsed):.2f} с. OCR підготовлений до першого сканування; червоні бейджі пропускаються.')
            self._refresh_live_monitor()
        else:
            self.state.setText('● OCR ПОМИЛКА')
            self.logline(f'Не вдалося підготувати OCR: {message}. Перевір журнал перед використанням автодій.')
            self._refresh_live_monitor()

    def _load_old_log(self):
        if LOG.exists():
            try:
                self.event_lines = LOG.read_text(encoding='utf-8').splitlines()[-1000:]
            except Exception:
                self.event_lines = []

    def _load_stats_history(self):
        """Load persisted real scan/action events; no demo metrics are synthesized."""
        try:
            raw = json.loads(STAT_HISTORY.read_text(encoding='utf-8'))
            self._stats_events = [e for e in raw if isinstance(e, dict) and e.get('ts') and e.get('type')][-15000:]
        except Exception:
            self._stats_events = []

    def _queue_stats_event(self, event_type, **values):
        """Queue telemetry in memory and batch-write it to avoid slowing the 100 ms scan loop."""
        event = {'ts': datetime.now().isoformat(timespec='seconds'), 'type': str(event_type)}
        for key, value in values.items():
            if isinstance(value, (str, int, float, bool)) or value is None:
                event[str(key)] = value
        self._stats_events.append(event)
        if len(self._stats_events) > 15000:
            self._stats_events = self._stats_events[-15000:]
        if not self._stats_flush_pending:
            self._stats_flush_pending = True
            QTimer.singleShot(4000, self._flush_stats_history)
        # Debounce stats rendering; it must not become an OCR/scan hot-path cost.
        if not self._stats_refresh_pending:
            self._stats_refresh_pending = True
            QTimer.singleShot(350, self._debounced_stats_refresh)

    def _flush_stats_history(self):
        self._stats_flush_pending = False
        try:
            STAT_HISTORY.parent.mkdir(parents=True, exist_ok=True)
            temporary = STAT_HISTORY.with_suffix('.json.tmp')
            temporary.write_text(json.dumps(self._stats_events[-15000:], ensure_ascii=False, separators=(',', ':')) + '\n', encoding='utf-8')
            temporary.replace(STAT_HISTORY)
        except Exception as exc:
            try:
                self.event_lines.append(f'{datetime.now():%H:%M:%S}    Статистика: не вдалося зберегти історію ({type(exc).__name__}: {exc}).')
            except Exception:
                pass

    def _debounced_stats_refresh(self):
        self._stats_refresh_pending = False
        current_key = None
        try:
            current_widget = self.stack.currentWidget()
            current_key = next((key for key, page in self.pages.items() if page is current_widget), None)
        except Exception:
            pass
        if current_key in ('stats', 'top'):
            self.refresh_stats()

    def _observe_stats_message(self, message):
        """Only explicit, distinct confirmation messages count as a verified purchase."""
        folded = ' '.join(str(message or '').casefold().split())
        confirmation_phrases = (
            'покупка підтверджена', 'покупку підтверджено', 'купівля підтверджена',
            'купівлю підтверджено', 'авто успішно придбано', 'покупка успішна',
            'purchase confirmed', 'vehicle purchased successfully',
        )
        if not any(phrase in folded for phrase in confirmation_phrases):
            return
        fingerprint = hashlib.sha1((datetime.now().strftime('%Y%m%d%H%M%S') + '|' + folded).encode('utf-8')).hexdigest()
        if fingerprint in self._stats_confirmation_keys:
            return
        self._stats_confirmation_keys.add(fingerprint)
        candidate = self._active_purchase_candidate or {}
        model = str(candidate.get('catalog_model') or candidate.get('model') or '')
        if not model:
            for known in self.all_models:
                if str(known).casefold() in folded:
                    model = str(known)
                    break
        price_value = candidate.get('price_value')
        if price_value is None:
            money = re.search(r'(?:\$|usd\s*)([0-9][0-9\s,._]*)', str(message), re.IGNORECASE)
            if money:
                digits = re.sub(r'\D', '', money.group(1))
                price_value = int(digits) if digits else None
        discount_value = candidate.get('discount_value')
        if discount_value is None:
            pct = re.search(r'(-?\d{1,3})\s*%', str(message))
            if pct:
                discount_value = abs(int(pct.group(1)))
        estimated_savings = None
        try:
            pct = abs(float(discount_value))
            price = float(price_value)
            if 0 < pct < 100 and price >= 0:
                estimated_savings = round(price * pct / (100.0 - pct), 2)
        except (TypeError, ValueError):
            pass
        self._queue_stats_event('purchase_confirmed', model=model, price_value=price_value,
                                discount_pct=discount_value, estimated_savings=estimated_savings,
                                message=str(message)[:400])

    def _build_ui(self):
        root = QWidget(); root.setObjectName('root'); self.setCentralWidget(root)
        outer = QHBoxLayout(root); outer.setContentsMargins(0, 0, 0, 0); outer.setSpacing(0)
        sidebar = QFrame(); sidebar.setObjectName('sidebar'); sidebar.setFixedWidth(166)
        sl = QVBoxLayout(sidebar); sl.setContentsMargins(12, 16, 12, 14); sl.setSpacing(7)
        brand = QLabel('NG'); brand.setObjectName('sideBrand'); brand.setAlignment(Qt.AlignCenter); sl.addWidget(brand)
        brand_sub = QLabel('MARKET SCANNER'); brand_sub.setObjectName('sideSub'); brand_sub.setAlignment(Qt.AlignCenter); sl.addWidget(brand_sub)
        sl.addSpacing(18)
        navs = [('Сканер ринку', 'scan', 'scan'),
                ('Каталог авто', 'catalog', 'catalog'),
                ('Налаштування', 'settings', 'settings'),
                ('Статистика', 'stats', 'stats'),
                ('Топ авто', 'top', 'stats'),
                ('Журнал', 'log', 'log'),
                ('Про програму', 'about', 'about')]
        for label, key, icon_id in navs:
            b = QPushButton(label); b.setObjectName('nav'); b.setIcon(make_ui_icon(icon_id, '#57D8B0')); b.setIconSize(QSize(18, 18)); b.setCursor(Qt.PointingHandCursor)
            b.clicked.connect(lambda checked=False, name=key: self.navigate(name))
            sl.addWidget(b); self.nav_buttons[key] = b
        sl.addStretch()
        watermark = QLabel('NG'); watermark.setObjectName('sideWatermark'); watermark.setAlignment(Qt.AlignCenter); sl.addWidget(watermark)
        ver = QLabel('v1.2.81 · POST-PURCHASE NAVIGATION · FULL HD / 2K'); ver.setObjectName('version'); ver.setAlignment(Qt.AlignCenter); sl.addWidget(ver)
        outer.addWidget(sidebar)

        self.stack = QStackedWidget(); self.stack.setObjectName('pageStack')
        # Let the main content keep its natural width; the image column is fixed-width.
        self.stack.setMinimumWidth(0)
        outer.addWidget(self.stack, 1)
        self.pages['scan'] = self._make_scan_page()
        self.pages['catalog'] = self._make_catalog_page()
        self.pages['settings'] = self._make_settings_page()
        self.pages['stats'] = self._make_stats_page()
        self.pages['top'] = self._make_top_page()
        self.pages['log'] = self._make_log_page()
        self.pages['about'] = self._make_about_page()
        for key in ['scan', 'catalog', 'settings', 'stats', 'top', 'log', 'about']:
            self.page_index[key] = self.stack.addWidget(self.pages[key])

        # The old fixed-width hero consumed dashboard space; vehicle photos now live in large cards.
        self.timer = QTimer(self)
        self.timer.setTimerType(Qt.PreciseTimer)
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self._on_scan_timer)
        self.auto_refresh_timer = QTimer(self)
        self.auto_refresh_timer.setTimerType(Qt.PreciseTimer)
        self.auto_refresh_timer.setSingleShot(True)
        self.auto_refresh_timer.timeout.connect(self._on_auto_refresh_timeout)

    def _page(self, title, subtitle=''): 
        # Scroll wrapper is important on smaller Windows/DPI-scaled screens: it keeps
        # the action row and KPI cards in the layout instead of compressing them away.
        page = QWidget(); page.setObjectName('page')
        lay = QVBoxLayout(page); lay.setContentsMargins(22, 18, 20, 16); lay.setSpacing(10)
        head = QHBoxLayout(); head.setSpacing(12)
        h = QLabel(title); h.setObjectName('pageTitle'); head.addWidget(h); head.addStretch()
        badge = QLabel('● ГОТОВИЙ'); badge.setObjectName('statePill'); head.addWidget(badge)
        lay.addLayout(head)
        if subtitle:
            sub = QLabel(subtitle); sub.setObjectName('subtitle'); sub.setWordWrap(True); lay.addWidget(sub)
        scroll = QScrollArea(); scroll.setObjectName('pageScroll')
        scroll.setWidgetResizable(True); scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setWidget(page)
        return scroll, lay, badge

    def _make_scan_page(self):
        page, lay, self.state = self._page('NG Market Scanner', 'Сканує 15 карток авторинку, розпізнає моделі, ціну та знижку й показує, які пропозиції відповідають порогам.')

        # Bento KPIs: all values below are refreshed from actual scan results.
        kpis = QGridLayout(); kpis.setContentsMargins(0, 0, 0, 0); kpis.setSpacing(9)
        self.kpi_values = []
        kpi_defs = [
            ('Карток у кадрі', '0', 'grid'),
            ('Моделі розпізнано', '0', 'car'),
            ('Зелені знижки', '0', 'check'),
            ('Відповідають порогу', '0', 'stats'),
            ('Останній цикл', '—', 'clock'),
        ]
        for i, (title, value, icon_name) in enumerate(kpi_defs):
            box = QFrame(); box.setObjectName('kpi'); box.setMinimumHeight(82)
            row = QHBoxLayout(box); row.setContentsMargins(13, 11, 11, 10); row.setSpacing(10)
            ico = QLabel(); ico.setObjectName('kpiIcon'); ico.setPixmap(make_ui_icon_pixmap(icon_name, '#55D6AE', 25)); ico.setFixedSize(32, 32); ico.setAlignment(Qt.AlignCenter); row.addWidget(ico)
            col = QVBoxLayout(); col.setSpacing(2)
            lab = QLabel(title); lab.setObjectName('kpiLabel')
            val = QLabel(value); val.setObjectName('kpiValue')
            col.addWidget(lab); col.addWidget(val); row.addLayout(col, 1)
            kpis.addWidget(box, i // 5, i % 5); self.kpi_values.append(val)
        lay.addLayout(kpis)

        # Compact, functional control strip.
        panel = QFrame(); panel.setObjectName('glassPanel')
        grid = QGridLayout(panel); grid.setContentsMargins(13, 10, 13, 9); grid.setHorizontalSpacing(10); grid.setVerticalSpacing(5)
        threshold_label = QLabel('Поріг звичайних моделей'); threshold_label.setObjectName('fieldLabel'); grid.addWidget(threshold_label, 0, 0)
        self.threshold = QComboBox(); self.threshold.addItems([f'-{x}%' for x in range(5, 101, 5)]); self.threshold.setCurrentText(f"-{int(self.settings['threshold'])}%"); grid.addWidget(self.threshold, 0, 1)
        interval_label = QLabel('Інтервал циклу'); interval_label.setObjectName('fieldLabel'); grid.addWidget(interval_label, 0, 2)
        self.interval = QComboBox(); self.interval.addItems(list(INTERVALS)); self.interval.setCurrentText(self.interval_text()); grid.addWidget(self.interval, 0, 3)
        resolution_label = QLabel('Масштаб інтерфейсу'); resolution_label.setObjectName('fieldLabel'); grid.addWidget(resolution_label, 2, 0)
        self.scan_resolution_combo = QComboBox(); self.scan_resolution_combo.addItems(list(RESOLUTION_PROFILES)); self.scan_resolution_combo.setCurrentText(RESOLUTION_PROFILE_LABELS.get(self.settings.get('resolution_profile', 'auto'), RESOLUTION_PROFILE_LABELS['auto']))
        self.scan_resolution_combo.setToolTip('Вибирає щільність інтерфейсу. Фактична роздільність гри визначається автоматично, а координати кліків масштабуються до неї.')
        self.scan_resolution_combo.currentTextChanged.connect(self._on_resolution_profile_changed); grid.addWidget(self.scan_resolution_combo, 2, 1)
        self.scan_resolution_status = QLabel(self._screen_profile_status_text()); self.scan_resolution_status.setObjectName('mutedNote'); self.scan_resolution_status.setWordWrap(True); grid.addWidget(self.scan_resolution_status, 2, 2, 1, 2)
        self.safe_note = QLabel('OCR готовий до запуску після прогрівання. Кеш незмінених карток не запускає повторне розпізнавання.'); self.safe_note.setObjectName('safeNote'); self.safe_note.setWordWrap(True); grid.addWidget(self.safe_note, 1, 0, 1, 4)
        lay.addWidget(panel)

        buttons = QHBoxLayout(); buttons.setSpacing(7)
        self.start_btn = QPushButton('Почати сканування'); self.start_btn.setObjectName('primary'); self.start_btn.setIcon(make_ui_icon('play', '#0B3026')); self.start_btn.setIconSize(QSize(18, 18)); self.start_btn.clicked.connect(self.toggle_scanning); buttons.addWidget(self.start_btn, 2)
        self.once_btn = QPushButton('Сканувати раз'); self.once_btn.setObjectName('ghost'); self.once_btn.setIcon(make_ui_icon('scan', '#DCE7F1')); self.once_btn.setIconSize(QSize(17, 17)); self.once_btn.clicked.connect(lambda: self.scan_once()); buttons.addWidget(self.once_btn, 1)
        self.save_btn = QPushButton('Зберегти'); self.save_btn.setObjectName('ghost'); self.save_btn.setIcon(make_ui_icon('save', '#DCE7F1')); self.save_btn.setIconSize(QSize(17, 17)); self.save_btn.clicked.connect(self.save_settings); buttons.addWidget(self.save_btn, 1)
        self.export_results_btn = QPushButton('Експорт CSV'); self.export_results_btn.setObjectName('ghost'); self.export_results_btn.setIcon(make_ui_icon('save', '#DCE7F1')); self.export_results_btn.setIconSize(QSize(16, 16)); self.export_results_btn.clicked.connect(self.export_results_csv); buttons.addWidget(self.export_results_btn, 1)
        self.diagnostics_btn = QPushButton('Діагностика'); self.diagnostics_btn.setObjectName('ghost'); self.diagnostics_btn.setIcon(make_ui_icon('info', '#DCE7F1')); self.diagnostics_btn.setIconSize(QSize(16, 16)); self.diagnostics_btn.clicked.connect(self.show_scan_diagnostics); buttons.addWidget(self.diagnostics_btn, 1)
        lay.addLayout(buttons)

        # Live monitor and performance charts. Both histories update from on_result only.
        monitor_layout = QGridLayout(); monitor_layout.setSpacing(9)
        live = QFrame(); live.setObjectName('livePanel')
        lv = QVBoxLayout(live); lv.setContentsMargins(14, 13, 14, 13); lv.setSpacing(8)
        live_header = QHBoxLayout(); live_title = QLabel('Live Scan Monitor'); live_title.setObjectName('sectionTitle'); live_header.addWidget(live_title); live_header.addStretch()
        self.live_dot = QLabel('●'); self.live_dot.setObjectName('liveDot'); live_header.addWidget(self.live_dot)
        self.live_status_label = QLabel('Очікує запуску'); self.live_status_label.setObjectName('liveStatus'); live_header.addWidget(self.live_status_label)
        lv.addLayout(live_header)
        self.live_backend_value = QLabel('OCR: ініціалізація…'); self.live_backend_value.setObjectName('liveBackend'); self.live_backend_value.setWordWrap(True); lv.addWidget(self.live_backend_value)
        live_grid = QGridLayout(); live_grid.setSpacing(7)
        self.live_cycle_value = self._make_live_metric(live_grid, 0, 0, 'Останній цикл', '—')
        self.live_ocr_value = self._make_live_metric(live_grid, 0, 1, 'Останній OCR', 'Ще немає')
        self.live_cache_value = self._make_live_metric(live_grid, 1, 0, 'Кеш', '—')
        self.live_cpm_value = self._make_live_metric(live_grid, 1, 1, 'Циклів/хв', '—')
        lv.addLayout(live_grid)
        self.live_change_note = QLabel('Очікуються перші реальні вимірювання. OCR і кеш показуються окремо.'); self.live_change_note.setObjectName('mutedNote'); self.live_change_note.setWordWrap(True); lv.addWidget(self.live_change_note)
        monitor_layout.addWidget(live, 0, 0, 2, 1)

        perf = QFrame(); perf.setObjectName('perfPanel')
        pv = QVBoxLayout(perf); pv.setContentsMargins(10, 10, 10, 10); pv.setSpacing(8)
        perfhead = QHBoxLayout(); ph = QLabel('Продуктивність'); ph.setObjectName('sectionTitle'); perfhead.addWidget(ph); perfhead.addStretch()
        self.chart_range = QComboBox(); self.chart_range.addItems(['Останні 15 циклів', 'Останні 30 циклів', 'Останні 60 циклів']); self.chart_range.setCurrentIndex(0); self.chart_range.currentIndexChanged.connect(self._refresh_performance_widgets); self.chart_range.setMaximumWidth(190); perfhead.addWidget(self.chart_range); pv.addLayout(perfhead)
        charts = QGridLayout(); charts.setSpacing(8)
        self.cycle_chart = MiniLineChart('Час повного циклу', 'с')
        self.ocr_chart = MiniLineChart('Час OCR (лише OCR-цикли)', 'с')
        charts.addWidget(self.cycle_chart, 0, 0); charts.addWidget(self.ocr_chart, 0, 1); pv.addLayout(charts)
        monitor_layout.addWidget(perf, 0, 1, 2, 1)
        monitor_layout.setColumnStretch(0, 1); monitor_layout.setColumnStretch(1, 2)
        lay.addLayout(monitor_layout)

        # Large photo gallery: genuine CC photos where available, explicitly labeled renders otherwise.
        gallery_head = QHBoxLayout(); gallery_head.setSpacing(8)
        gallery_title = QLabel('Галерея автомобілів · результати сканування'); gallery_title.setObjectName('sectionTitle'); gallery_head.addWidget(gallery_title); gallery_head.addStretch()
        self.gallery_count = QLabel('0 карток'); self.gallery_count.setObjectName('smallBadge'); gallery_head.addWidget(self.gallery_count)
        self.gallery_filter = QComboBox(); self.gallery_filter.addItems(['Усі розпізнані', 'Зелені бейджі', 'Відповідають порогу', 'Потрібна перевірка']); self.gallery_filter.currentTextChanged.connect(self.refresh_vehicle_gallery); self.gallery_filter.setMaximumWidth(220); gallery_head.addWidget(self.gallery_filter)
        lay.addLayout(gallery_head)
        self.gallery_hint = QLabel('Після сканування тут відображаються знайдені пропозиції та їхній статус. До першого сканування показані лише приклади авто з каталогу — вони не є результатами сканування.'); self.gallery_hint.setObjectName('mutedNote'); self.gallery_hint.setWordWrap(True); lay.addWidget(self.gallery_hint)
        self.vehicle_gallery = QFrame(); self.vehicle_gallery.setObjectName('vehicleGallery')
        self.vehicle_grid = QGridLayout(self.vehicle_gallery); self.vehicle_grid.setContentsMargins(0, 0, 0, 0); self.vehicle_grid.setSpacing(10)
        lay.addWidget(self.vehicle_gallery)

        title_row = QHBoxLayout(); title_row.setSpacing(8); title_row.addWidget(make_icon_label('grid', 16)); title = QLabel('Детальна таблиця результатів'); title.setObjectName('sectionTitle'); title_row.addWidget(title); title_row.addStretch()
        self.found_badge = QLabel('Знайдено: 0'); self.found_badge.setObjectName('smallBadge'); title_row.addWidget(self.found_badge)
        self.match_badge = QLabel('Відповідають: 0'); self.match_badge.setObjectName('greenBadge'); title_row.addWidget(self.match_badge); lay.addLayout(title_row)
        self.results_table = QTableWidget(0, 7); self.results_table.setHorizontalHeaderLabels(['№', 'Фото', 'Модель', 'Ціна', 'Знижка', 'Поріг', 'Статус'])
        self._style_table(self.results_table)
        result_header = self.results_table.horizontalHeader()
        for col in (0, 1, 3, 4, 5): result_header.setSectionResizeMode(col, QHeaderView.Fixed)
        result_header.setSectionResizeMode(2, QHeaderView.Stretch); result_header.setSectionResizeMode(6, QHeaderView.Stretch)
        for col, width in [(0, 42), (1, 62), (3, 95), (4, 78), (5, 66)]: self.results_table.setColumnWidth(col, width)
        self.results_table.setIconSize(QSize(56, 34)); self.results_table.setWordWrap(False)
        self.results_table.setMaximumHeight(310); self.results_table.setMinimumHeight(190); lay.addWidget(self.results_table, 1)
        loghead = QHBoxLayout(); loghead.setSpacing(8); loghead.addWidget(make_icon_label('log', 16)); label = QLabel('Останні події'); label.setObjectName('sectionTitle'); loghead.addWidget(label); loghead.addStretch()
        openlog = QPushButton('Відкрити журнал'); openlog.setObjectName('tinyButton'); openlog.setIcon(make_ui_icon('log', '#91A5BC')); openlog.setIconSize(QSize(15, 15)); openlog.clicked.connect(lambda: self.navigate('log')); loghead.addWidget(openlog); lay.addLayout(loghead)
        self.log_preview = QPlainTextEdit(); self.log_preview.setReadOnly(True); self.log_preview.setMinimumHeight(74); self.log_preview.setMaximumHeight(112); self.log_preview.setPlaceholderText('Тут з’являтимуться події сканування.'); self.log_preview.document().setMaximumBlockCount(80); lay.addWidget(self.log_preview)
        return page

    def _make_live_metric(self, grid, row, col, title, value):
        box = QFrame(); box.setObjectName('liveMetric')
        v = QVBoxLayout(box); v.setContentsMargins(9, 8, 9, 8); v.setSpacing(3)
        lab = QLabel(title); lab.setObjectName('liveMetricLabel')
        val = QLabel(value); val.setObjectName('liveMetricValue'); val.setWordWrap(True)
        v.addWidget(lab); v.addWidget(val); grid.addWidget(box, row, col)
        return val

    def _record_performance_measurement(self, elapsed, worker):
        """Capture real cycle and actual OCR durations, separately from cache-only cycles."""
        now = time.monotonic()
        self._cycle_history.append(float(elapsed))
        self._cycle_timestamps.append(now)
        while self._cycle_timestamps and now - self._cycle_timestamps[0] > 300:
            self._cycle_timestamps.popleft()
        try:
            calls = int(getattr(worker, '_ocr_call_count', 0) or 0) if worker is not None else 0
            ocr_seconds = float(getattr(worker, '_ocr_elapsed_seconds', 0.0) or 0.0) if worker is not None else 0.0
            cache_hits = int(getattr(worker, '_cache_hits', 0) or 0) if worker is not None else 0
            changed = int(getattr(worker, '_changed_cards', 0) or 0) if worker is not None else 0
        except (TypeError, ValueError):
            calls, ocr_seconds, cache_hits, changed = 0, 0.0, 0, 0
        self._last_cycle_elapsed = float(elapsed)
        self._last_ocr_calls = calls
        self._last_cache_hits = max(0, min(15, cache_hits))
        self._last_changed_cards = changed
        if calls > 0 and ocr_seconds > 0:
            self._last_actual_ocr_seconds = ocr_seconds
            self._ocr_history.append(ocr_seconds)

    def _refresh_performance_widgets(self, *_):
        count = [15, 30, 60][self.chart_range.currentIndex()] if hasattr(self, 'chart_range') else 15
        if hasattr(self, 'cycle_chart'):
            self.cycle_chart.set_values(list(self._cycle_history)[-count:])
        if hasattr(self, 'ocr_chart'):
            self.ocr_chart.set_values(list(self._ocr_history)[-count:])
        if hasattr(self, 'stats_cycle_chart'):
            self.stats_cycle_chart.set_values(list(self._cycle_history)[-count:])
            self.stats_ocr_chart.set_values(list(self._ocr_history)[-count:])

    def _refresh_live_monitor(self):
        if not hasattr(self, 'live_status_label'):
            return
        if self.running:
            self.live_status_label.setText('Активне')
            self.live_dot.setStyleSheet('color: #56E6B7;')
        elif self.busy:
            self.live_status_label.setText('Обробка')
            self.live_dot.setStyleSheet('color: #F1C875;')
        else:
            self.live_status_label.setText('Готовий' if self.ocr_ready else 'Підготовка')
            self.live_dot.setStyleSheet('color: #8193A8;')
        self.live_backend_value.setText('OCR backend: ' + self._last_backend)
        self.live_cycle_value.setText(f'{self._last_cycle_elapsed:.3f} с' if self._last_cycle_elapsed is not None else 'Немає вимірів')
        self.live_ocr_value.setText(f'{self._last_actual_ocr_seconds:.3f} с' if self._last_actual_ocr_seconds is not None else 'Ще не вимірювався')
        self.live_cache_value.setText(f'{self._last_cache_hits}/15') if self._last_cycle_elapsed is not None else self.live_cache_value.setText('—')
        now = time.monotonic()
        recent = [t for t in self._cycle_timestamps if now - t <= 60]
        if len(recent) >= 2:
            # Use completed intervals, not the number of observations. A single
            # first cycle must not masquerade as 60 cycles/minute.
            span_seconds = max(0.001, recent[-1] - recent[0])
            completed_intervals = len(recent) - 1
            self.live_cpm_value.setText(str(round(completed_intervals * 60.0 / span_seconds)))
        else:
            self.live_cpm_value.setText('—' if not recent else 'Вимірювання…')
        if self._last_cycle_elapsed is None:
            note = 'Очікуються перші реальні вимірювання. Кеш та OCR мають окремі лічильники.'
        elif self._last_ocr_calls > 0:
            note = f'Останній прохід: OCR-пакетів {self._last_ocr_calls}, змінених карток {self._last_changed_cards or 0}. Час OCR не змішується з кеш-циклами.'
        else:
            note = f'Останній прохід використав кеш; фактичний останній OCR: {self._last_actual_ocr_seconds:.3f} с.' if self._last_actual_ocr_seconds is not None else 'Останній прохід був кешований; реальний час OCR з’явиться після зміни картки.'
        self.live_change_note.setText(note)
        self._refresh_performance_widgets()

    def refresh_vehicle_gallery(self, *_):
        if not hasattr(self, 'vehicle_grid'):
            return
        filter_name = self.gallery_filter.currentText() if hasattr(self, 'gallery_filter') else 'Усі розпізнані'
        rows = list(self.last or [])
        # Show a real transparent-PNG showcase on the home screen before the first
        # scan. It is explicitly marked as examples and never enters scan results,
        # the OCR cache, statistics, or purchase eligibility logic.
        if not rows and not self.last and getattr(self, '_scan_cycle_number', 0) == 0 and filter_name == 'Усі розпізнані':
            preferred = [
                'BF Golf VIII', 'Benefactor AVTR', 'Progen Senna', 'Coil Semi',
                'Ubermacht M4 G82', 'Bravado Charger Redeye', 'Annis RX8 SE3P',
                'Benefactor G-Class W463',
            ]
            demo_models = []
            seen = set()
            for model in preferred + list(getattr(self, 'all_models', [])):
                if model in seen:
                    continue
                seen.add(model)
                path = vehicle_render_path(model)
                if path and Path(path).suffix.lower() == '.png' and Path(path).is_file():
                    demo_models.append((model, path))
                if len(demo_models) >= 4:
                    break
            demo_signature = ('catalog-example-cards', filter_name, tuple((m, p.name) for m, p in demo_models))
            if demo_signature == self._gallery_signature:
                return
            self._gallery_signature = demo_signature
            while self.vehicle_grid.count():
                old_widget = self.vehicle_grid.takeAt(0).widget()
                if old_widget is not None:
                    old_widget.deleteLater()
            self.gallery_count.setText(f'{len(demo_models)} приклади з каталогу')
            self.gallery_hint.setText('Це приклади авто з каталогу, а не знайдені пропозиції. Після першого сканування тут відображатимуться фактичні результати й причини, з яких автодія дозволена або заблокована.')
            for i, (model, path) in enumerate(demo_models):
                card = QFrame(); card.setObjectName('vehicleCard'); card.setMinimumWidth(280)
                v = QVBoxLayout(card); v.setContentsMargins(12, 12, 12, 12); v.setSpacing(8)
                image = CoverPhotoLabel(min_height=int(230 * self.ui_scale), max_height=int(310 * self.ui_scale))
                image.set_image(path)
                image.setToolTip('Ілюстративне зображення автомобіля для швидкої візуальної ідентифікації.')
                v.addWidget(image)
                tags = QHBoxLayout(); tags.setSpacing(7)
                source_tag = QLabel('ЗОБРАЖЕННЯ КАТАЛОГУ'); source_tag.setObjectName('photoSourceRender'); tags.addWidget(source_tag)
                tags.addStretch()
                example_tag = QLabel('ПРИКЛАД'); example_tag.setObjectName('discountChipNeutral'); tags.addWidget(example_tag)
                v.addLayout(tags)
                title = QLabel(model); title.setObjectName('vehicleName'); title.setWordWrap(True); v.addWidget(title)
                note = QLabel('Зображення каталогу · не результат сканування'); note.setObjectName('vehicleStatus'); note.setWordWrap(True); v.addWidget(note)
                self.vehicle_grid.addWidget(card, i // 2, i % 2)
            for col in range(2):
                self.vehicle_grid.setColumnStretch(col, 1)
            if demo_models:
                return
        if filter_name == 'Усі розпізнані':
            rows = [x for x in rows if x.get('model') not in ('', '—', None)]
        elif filter_name == 'Зелені бейджі':
            rows = [x for x in rows if x.get('badge_color') == 'GREEN' and x.get('model') not in ('', '—', None)]
        elif filter_name == 'Відповідають порогу':
            rows = [x for x in rows if x.get('eligible') and x.get('model') not in ('', '—', None)]
        elif filter_name == 'Потрібна перевірка':
            rows = [x for x in rows if x.get('badge_color') == 'GREEN' and (x.get('model') in ('', '—', None) or x.get('discount_value') is None or not x.get('catalog_model'))]
        rows.sort(key=lambda x: (not bool(x.get('eligible')), x.get('badge_color') != 'GREEN', int(x.get('card', 99))))
        signature = (filter_name, tuple((x.get('card'), x.get('model'), x.get('price'), x.get('discount'), x.get('status'), x.get('badge_color'), x.get('eligible')) for x in rows))
        if signature == self._gallery_signature:
            return
        self._gallery_signature = signature
        while self.vehicle_grid.count():
            item = self.vehicle_grid.takeAt(0)
            widget = item.widget()
            if widget is not None:
                widget.deleteLater()
        if hasattr(self, 'gallery_count'):
            self.gallery_count.setText(f'{len(rows)} карток')
        if not rows:
            empty = QLabel('Для цього фільтра результатів немає. Колір бейджа не підміняє назву або ціну; непідтверджена модель не отримує випадкове зображення й не допускається до автодії.'); empty.setObjectName('galleryEmpty'); empty.setWordWrap(True)
            self.vehicle_grid.addWidget(empty, 0, 0, 1, 2)
            return
        for i, item in enumerate(rows):
            card = QFrame(); card.setObjectName('vehicleCard'); card.setMinimumWidth(280)
            v = QVBoxLayout(card); v.setContentsMargins(10, 10, 10, 11); v.setSpacing(8)
            photo, source = vehicle_image_path(item.get('catalog_model') or item.get('model'))
            image = CoverPhotoLabel(min_height=int(220 * self.ui_scale), max_height=int(300 * self.ui_scale)); image.set_image(photo)
            if not photo:
                image.setText('Зображення недоступне')
            v.addWidget(image)
            chiprow = QHBoxLayout(); chiprow.setSpacing(6)
            source_chip = QLabel('ВЛАСНЕ ФОТО' if source == 'custom' else ('ФОТО' if source == 'photo' else ('ЗОБРАЖЕННЯ МОДЕЛІ' if source == 'render' else 'ФОТО НЕМАЄ')))
            source_chip.setObjectName('photoSourceCustom' if source == 'custom' else ('photoSourceReal' if source == 'photo' else 'photoSourceRender'))
            if source == 'photo' and photo:
                source_chip.setToolTip('Фотографія з Wikimedia Commons. Автор, ліцензія та сторінка джерела — в REAL_CAR_PHOTO_CREDITS_UA.txt.')
            elif source == 'custom':
                source_chip.setToolTip('Зображення вибране й збережене користувачем у папці програми.')
            chiprow.addWidget(source_chip); chiprow.addStretch()
            badge_color = str(item.get('badge_color', 'UNKNOWN')).upper()
            discount_chip = QLabel(str(item.get('discount', '—')))
            discount_chip.setObjectName('discountChipGreen' if badge_color == 'GREEN' else ('discountChipRed' if badge_color == 'RED' else 'discountChipNeutral'))
            chiprow.addWidget(discount_chip); v.addLayout(chiprow)
            model = QLabel(str(item.get('model') or 'Модель не розпізнано')); model.setObjectName('vehicleName'); model.setWordWrap(True); v.addWidget(model)
            price_row = QHBoxLayout(); price_label = QLabel(str(item.get('price') or 'Ціна не прочитана')); price_label.setObjectName('vehiclePrice'); price_row.addWidget(price_label); price_row.addStretch()
            threshold = item.get('threshold')
            threshold_label = QLabel(f"Поріг −{int(threshold)}%" if threshold is not None else 'Поріг —')
            threshold_label.setObjectName('vehicleThreshold'); price_row.addWidget(threshold_label); v.addLayout(price_row)
            status = QLabel(str(item.get('status') or 'Потрібна перевірка')); status.setObjectName('vehicleStatus'); status.setWordWrap(True); v.addWidget(status)
            actions = QHBoxLayout(); actions.setSpacing(7)
            row_btn = QPushButton('До таблиці'); row_btn.setObjectName('tinyButton'); row_btn.setIcon(make_ui_icon('grid', '#91A5BC')); row_btn.clicked.connect(lambda checked=False, card_no=int(item.get('card', i + 1)): self._select_vehicle_row(card_no)); actions.addWidget(row_btn)
            details_btn = QPushButton('Деталі'); details_btn.setObjectName('ghost'); details_btn.clicked.connect(lambda checked=False, data=dict(item): self.show_vehicle_details(data)); actions.addWidget(details_btn)
            v.addLayout(actions)
            self.vehicle_grid.addWidget(card, i // 2, i % 2)
        if len(rows) % 2:
            self.vehicle_grid.setColumnStretch(0, 1); self.vehicle_grid.setColumnStretch(1, 1)

    def _select_vehicle_row(self, card_number):
        if not self.last or not hasattr(self, 'results_table'):
            QMessageBox.information(self, 'Таблиця результатів', 'Спочатку виконай сканування.'); return
        self.navigate('scan')
        target_row = None
        for row in range(self.results_table.rowCount()):
            cell = self.results_table.item(row, 0)
            if cell and cell.text().strip() == str(card_number):
                target_row = row; break
        if target_row is None:
            QMessageBox.information(self, 'Таблиця результатів', 'Картка ще не відображена в таблиці. Виконай новий цикл сканування.'); return
        self.results_table.selectRow(target_row)
        item = self.results_table.item(target_row, 2) or self.results_table.item(target_row, 0)
        if item: self.results_table.scrollToItem(item, QAbstractItemView.PositionAtCenter)

    def show_vehicle_details(self, item):
        threshold = item.get('threshold')
        threshold_text = f"−{int(threshold)}%" if threshold is not None else 'Не заданий'
        details = [
            f"Картка: {item.get('card', '—')}",
            f"Модель: {item.get('model', '—')}",
            f"Каталог: {item.get('catalog_model') or 'Поза каталогом'}",
            f"Ціна: {item.get('price', 'Не прочитано')}",
            f"Знижка/націнка: {item.get('discount', '—')}",
            f"Колір бейджа: {item.get('badge_color', 'UNKNOWN')}",
            f"Поріг: {threshold_text}",
            f"Статус: {item.get('status', '—')}",
            f"Впевненість назви: {float(item.get('name_confidence', 0) or 0):.3f}",
            f"Впевненість ціни: {float(item.get('price_confidence', 0) or 0):.3f}",
            f"Впевненість бейджа: {float(item.get('badge_confidence', 0) or 0):.3f}",
        ]
        QMessageBox.information(self, 'Деталі автомобіля', '\n'.join(details))

    def export_results_csv(self):
        if not self.last:
            QMessageBox.information(self, 'Експорт CSV', 'Поки немає результатів сканування для експорту.')
            return
        path, _ = QFileDialog.getSaveFileName(self, 'Експорт результатів', 'NG_Market_Scanner_results.csv', 'CSV (*.csv)')
        if not path:
            return
        fields = ['card', 'model', 'catalog_model', 'price', 'price_value', 'discount', 'discount_value', 'discount_kind', 'badge_color', 'threshold', 'eligible', 'status', 'model_confidence', 'name_confidence', 'price_confidence', 'badge_confidence']
        try:
            with open(path, 'w', newline='', encoding='utf-8-sig') as file:
                writer = csv.DictWriter(file, fieldnames=fields, extrasaction='ignore', delimiter=';')
                writer.writeheader()
                for row in self.last:
                    writer.writerow({key: row.get(key, '') for key in fields})
            self.logline(f'Результати сканування експортовано в CSV: {path}')
            QMessageBox.information(self, 'Експорт CSV', f'Збережено {len(self.last)} карток:\n{path}')
        except Exception as exc:
            QMessageBox.critical(self, 'Помилка експорту CSV', f'{type(exc).__name__}: {exc}')

    def show_scan_diagnostics(self):
        path = DATA / 'last_scan_diagnostics.json'
        if not path.is_file():
            QMessageBox.information(self, 'Діагностика OCR', 'Файл last_scan_diagnostics.json ще не створено. Виконай сканування.')
            return
        try:
            data = json.loads(path.read_text(encoding='utf-8-sig'))
            perf = data.get('performance', {})
            providers = perf.get('onnxruntime_active_providers') or []
            elapsed = data.get('elapsed_seconds')
            lines = [
                f"Версія ядра: {data.get('scanner_core_version', 'невідомо')}",
                f"Час циклу: {float(elapsed):.3f} с" if elapsed is not None else 'Час циклу: —',
                f"OCR-викликів: {perf.get('ocr_calls', '—')}",
                f"Час OCR: {perf.get('ocr_seconds', '—')} с",
                f"Кеш: {perf.get('unchanged_cards_cache_hits', perf.get('cache_hit_count', '—'))}/15",
                f"Активні провайдери: {', '.join(providers) if providers else 'не визначено'}",
                f"GPU активний: {'Так' if perf.get('gpu_acceleration_active') else 'Ні/не визначено'}",
                f"Помилка: {perf.get('ocr_engine_warmup_error') or data.get('error') or 'немає'}",
            ]
            QMessageBox.information(self, 'Діагностика OCR', '\n'.join(lines))
        except Exception as exc:
            QMessageBox.warning(self, 'Діагностика OCR', f'Не вдалося прочитати {path.name}: {type(exc).__name__}: {exc}')

    def _make_catalog_page(self):
        page, lay, self.catalog_state = self._page('Каталог автомобілів', 'Керуй моделями, які беруть участь у зіставленні: увімкненням, категорією, мінімальною знижкою, фото та власними авто.')
        row = QHBoxLayout(); row.setSpacing(8)
        self.catalog_search = QLineEdit(); self.catalog_search.setPlaceholderText('Пошук моделі або класу…'); self.catalog_search.textChanged.connect(self.filter_catalog); row.addWidget(self.catalog_search, 1)
        self.catalog_filter = QComboBox(); self.catalog_filter.addItems(['Усі категорії', 'Пріоритетне', 'Звичайне', 'Спеціальне', BLACKLIST_CATEGORY]); self.catalog_filter.currentTextChanged.connect(self.filter_catalog); row.addWidget(self.catalog_filter)
        self.catalog_sort = QComboBox(); self.catalog_sort.addItems(['За назвою', 'Спочатку активні', 'Власні авто']); self.catalog_sort.currentTextChanged.connect(self.filter_catalog); row.addWidget(self.catalog_sort)
        reload_btn = QPushButton('Оновити'); reload_btn.setObjectName('ghost'); reload_btn.setIcon(make_ui_icon('refresh', '#DCE7F1')); reload_btn.clicked.connect(lambda checked=False: self.refresh_catalog(force=True)); row.addWidget(reload_btn)
        lay.addLayout(row)

        # Keep the proven QTableWidget as a hidden data/selection model so existing save/edit
        # handlers and migration code remain compatible, while the user sees a modern tile grid.
        self.catalog_table = QTableWidget(0, 5); self.catalog_table.setObjectName('catalogTable')
        self._catalog_cards = {}
        self._catalog_grid_layout_signature = None
        self._catalog_row_lookup = {}
        self.catalog_table.setHorizontalHeaderLabels(['✓', 'Зображення авто', 'Модель', 'Категорія', 'Поріг знижки'])
        self._style_table(self.catalog_table)
        self.catalog_table.setIconSize(QSize(int(280 * self.ui_scale), int(160 * self.ui_scale)))
        self.catalog_table.setMinimumSize(0, 0); self.catalog_table.setMaximumSize(0, 0); self.catalog_table.setVisible(False)
        lay.addWidget(self.catalog_table)

        self.catalog_grid_scroll = QScrollArea(); self.catalog_grid_scroll.setObjectName('catalogGridScroll')
        self.catalog_grid_scroll.setWidgetResizable(True); self.catalog_grid_scroll.setFrameShape(QFrame.NoFrame)
        self.catalog_grid_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        self.catalog_grid_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAlwaysOn)
        self._catalog_last_columns = None
        self.catalog_grid_host = QWidget(); self.catalog_grid_host.setObjectName('catalogGridHost')
        self.catalog_grid_layout = QGridLayout(self.catalog_grid_host)
        self.catalog_grid_layout.setContentsMargins(2, 2, 8, 8); self.catalog_grid_layout.setHorizontalSpacing(11); self.catalog_grid_layout.setVerticalSpacing(11)
        self.catalog_grid_scroll.setWidget(self.catalog_grid_host); lay.addWidget(self.catalog_grid_scroll, 1)
        self.catalog_grid_scroll.viewport().installEventFilter(self)
        self.catalog_grid_host.setMinimumWidth(0)

        note = QLabel('Зображення допомагають швидко знайти модель у списку. Позначка «Референс» означає схожий кузов, а не точний відповідник. Активність, категорія та мінімальна знижка налаштовуються окремо для кожної моделі.'); note.setObjectName('mutedNote'); note.setWordWrap(True); lay.addWidget(note)
        actions = QHBoxLayout(); save = QPushButton('Зберегти каталог'); save.setObjectName('primary'); save.setIcon(make_ui_icon('save', '#0B3026')); save.clicked.connect(self.save_catalog); actions.addWidget(save)
        select_all = QPushButton('Вибрати всі'); select_all.setObjectName('ghost'); select_all.clicked.connect(lambda: self.set_catalog_checks(True)); actions.addWidget(select_all)
        select_none = QPushButton('Зняти вибір'); select_none.setObjectName('ghost'); select_none.clicked.connect(lambda: self.set_catalog_checks(False)); actions.addWidget(select_none); lay.addLayout(actions)
        custom_actions = QHBoxLayout()
        add_custom = QPushButton('＋ Додати авто'); add_custom.setObjectName('primary'); add_custom.clicked.connect(self.add_custom_vehicle); custom_actions.addWidget(add_custom)
        edit_vehicle = QPushButton('Редагувати фото / дані'); edit_vehicle.setObjectName('ghost'); edit_vehicle.clicked.connect(self.edit_selected_vehicle); custom_actions.addWidget(edit_vehicle)
        delete_vehicle = QPushButton('Видалити власне авто'); delete_vehicle.setObjectName('ghost'); delete_vehicle.clicked.connect(self.delete_custom_vehicle); custom_actions.addWidget(delete_vehicle)
        lay.addLayout(custom_actions)
        return page

    def _catalog_columns_for_width(self, viewport_width):
        card_min = max(235, int(270 * self.ui_scale))
        spacing = max(8, int(12 * self.ui_scale))
        return max(1, min(5, (max(1, int(viewport_width)) + spacing) // (card_min + spacing)))

    def eventFilter(self, watched, event):
        if hasattr(self, 'catalog_grid_scroll') and watched is self.catalog_grid_scroll.viewport():
            try:
                if event.type() == QEvent.Type.Resize:
                    columns = self._catalog_columns_for_width(self.catalog_grid_scroll.viewport().width())
                    # A resize that keeps the same column count must not rebuild the tile grid.
                    if columns != self._catalog_last_columns:
                        self._catalog_last_columns = columns
                        self._schedule_catalog_grid_rebuild()
            except Exception:
                pass
        return super().eventFilter(watched, event)

    def _schedule_catalog_grid_rebuild(self):
        """Debounce grid work; if Catalog is hidden, postpone widget creation until it is opened."""
        self._catalog_grid_needs_refresh = True
        if getattr(self, '_catalog_grid_refresh_pending', False):
            return
        self._catalog_grid_refresh_pending = True
        QTimer.singleShot(45, self._refresh_catalog_grid)

    def _find_catalog_row_for_model(self, model):
        table = getattr(self, 'catalog_table', None)
        if table is None:
            return -1
        wanted = str(model or '').casefold()
        for row in range(table.rowCount()):
            item = table.item(row, 2)
            if item and str(item.data(Qt.UserRole) or item.text()).casefold() == wanted:
                return row
        return -1

    def _select_catalog_model(self, model):
        row = self._find_catalog_row_for_model(model)
        if row >= 0:
            self.catalog_table.setCurrentCell(row, 2)

    def _set_catalog_active_for_model(self, model, checked):
        row = self._find_catalog_row_for_model(model)
        if row >= 0:
            self._set_catalog_active_from_card(row, checked)

    def _set_catalog_category_for_model(self, model, value):
        row = self._find_catalog_row_for_model(model)
        if row >= 0:
            self._set_catalog_category_from_card(row, value)
            self._update_catalog_card_for_row(model, row)

    def _set_catalog_threshold_for_model(self, model, value):
        row = self._find_catalog_row_for_model(model)
        if row >= 0:
            self._set_catalog_threshold_from_card(row, value)
            self._update_catalog_card_for_row(model, row)

    def _edit_catalog_model(self, model):
        row = self._find_catalog_row_for_model(model)
        if row >= 0:
            self._edit_catalog_row(row)

    def _create_catalog_card(self, model):
        card = QFrame(); card.setObjectName('catalogVehicleCard')
        card.setProperty('vehicleModel', model)
        card.setMinimumWidth(max(235, int(270 * self.ui_scale)))
        card.setMinimumHeight(max(500, int(510 * self.ui_scale)))
        card.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Preferred)
        outer = QVBoxLayout(card); outer.setContentsMargins(10, 9, 10, 10); outer.setSpacing(5)

        head = QHBoxLayout(); head.setSpacing(5)
        enabled = QCheckBox('Активна')
        enabled.setToolTip('Якщо вимкнено, сканер не зіставлятиме цю модель для автопокупки.')
        enabled.toggled.connect(lambda checked, model=model: self._set_catalog_active_for_model(model, checked))
        head.addWidget(enabled); head.addStretch()
        badge = QLabel('ЗОБРАЖЕННЯ'); badge.setObjectName('catalogSourceBadge')
        head.addWidget(badge); outer.addLayout(head)

        image = TransparentVehiclePreview(QPixmap(), min_height=max(190, int(230 * self.ui_scale)))
        image.ui_scale = self.ui_scale
        image.setObjectName('vehiclePreview')
        outer.addWidget(image)

        title = QLabel(model); title.setObjectName('catalogVehicleName'); title.setWordWrap(True)
        title.setMinimumHeight(max(32, int(34 * self.ui_scale))); title.setToolTip(model); outer.addWidget(title)
        meta = QLabel('Звичайне · Поріг знижки: −20%'); meta.setObjectName('catalogVehicleMeta')
        meta.setWordWrap(True); outer.addWidget(meta)

        controls = QGridLayout(); controls.setHorizontalSpacing(6); controls.setVerticalSpacing(4)
        cat_label = QLabel('Категорія'); cat_label.setObjectName('catalogControlLabel'); controls.addWidget(cat_label, 0, 0)
        cat_combo = QComboBox(); cat_combo.addItems(list(CATALOG_CATEGORIES)); cat_combo.setObjectName('catalogCardCombo')
        cat_combo.currentTextChanged.connect(lambda value, model=model: self._set_catalog_category_for_model(model, value))
        controls.addWidget(cat_combo, 0, 1)
        threshold_label = QLabel('Поріг'); threshold_label.setObjectName('catalogControlLabel'); controls.addWidget(threshold_label, 1, 0)
        threshold_spin = QSpinBox(); threshold_spin.setRange(0, 100); threshold_spin.setSuffix(' %'); threshold_spin.setObjectName('catalogCardSpin')
        threshold_spin.valueChanged.connect(lambda value, model=model: self._set_catalog_threshold_for_model(model, value))
        controls.addWidget(threshold_spin, 1, 1); outer.addLayout(controls)

        buttons = QHBoxLayout(); buttons.setSpacing(6)
        select_btn = QPushButton('Вибрати'); select_btn.setObjectName('tinyButton')
        select_btn.clicked.connect(lambda checked=False, model=model: self._select_catalog_model(model)); buttons.addWidget(select_btn)
        edit_btn = QPushButton('Редагувати'); edit_btn.setObjectName('tinyButton')
        edit_btn.clicked.connect(lambda checked=False, model=model: self._edit_catalog_model(model)); buttons.addWidget(edit_btn)
        outer.addLayout(buttons)

        card._catalog_controls = {
            'enabled': enabled, 'badge': badge, 'image': image, 'title': title,
            'meta': meta, 'category': cat_combo, 'threshold': threshold_spin,
        }
        card._catalog_asset_signature = None
        return card

    def _update_catalog_card_for_row(self, model, row):
        table = self.catalog_table
        if row < 0 or row >= table.rowCount():
            return
        card = getattr(self, '_catalog_cards', {}).get(model)
        if card is None:
            return
        controls = card._catalog_controls
        name_item = table.item(row, 2)
        active_item = table.item(row, 0)
        if name_item is None or active_item is None:
            return
        category_model = table.cellWidget(row, 3)
        threshold_model = table.cellWidget(row, 4)
        category = category_model.currentText() if category_model else 'Звичайне'
        threshold = threshold_model.value() if threshold_model else int(self.settings.get('threshold', 20))
        active = active_item.checkState() == Qt.Checked
        is_custom = bool(name_item.data(Qt.UserRole + 1))
        path, source = vehicle_image_path(model)
        asset_signature = (str(path) if path else '', source)
        image = controls['image']
        if getattr(card, '_catalog_asset_signature', None) != asset_signature:
            image.set_source(path if path else QPixmap())
            card._catalog_asset_signature = asset_signature
        controls['enabled'].blockSignals(True)
        controls['enabled'].setChecked(active)
        controls['enabled'].blockSignals(False)
        controls['title'].setText(model)
        controls['title'].setToolTip(model)
        if category == BLACKLIST_CATEGORY:
            controls['meta'].setText('ЧОРНИЙ СПИСОК · АВТОПОКУПКА ЗАБОРОНЕНА')
        else:
            controls['meta'].setText(f'{category}  ·  Поріг знижки: −{threshold}%')
        controls['category'].blockSignals(True)
        controls['category'].setCurrentText(category if category in CATALOG_CATEGORIES else 'Звичайне')
        controls['category'].blockSignals(False)
        controls['threshold'].blockSignals(True)
        controls['threshold'].setValue(int(threshold))
        controls['threshold'].blockSignals(False)
        badge_text = {'custom': 'ВЛАСНЕ ФОТО', 'photo': 'ФОТО', 'render': 'ЗОБРАЖЕННЯ', 'approximate': 'РЕФЕРЕНС', 'none': 'НЕМАЄ ФОТО'} .get(source, 'ЗОБРАЖЕННЯ')
        badge = controls['badge']
        if badge.text() != badge_text or badge.property('sourceType') != source:
            badge.setText(badge_text)
            badge.setProperty('sourceType', source)
            badge.style().unpolish(badge); badge.style().polish(badge)
        controls['image'].setToolTip({
            'custom': 'Власне зображення користувача',
            'photo': 'Локальне фото',
            'render': 'Ілюстративне зображення моделі; воно не замінює дані сканування',
            'approximate': 'Візуальний референс схожого кузова; точна модель не підтверджена',
            'none': 'Для цієї моделі немає якісного локального зображення',
        }.get(source, 'Зображення автомобіля'))

    def _refresh_catalog_grid(self):
        """Reflow cached cards in place; never hide/recreate the whole grid on routine resizes."""
        self._catalog_grid_refresh_pending = False
        layout = getattr(self, 'catalog_grid_layout', None)
        table = getattr(self, 'catalog_table', None)
        if layout is None or table is None:
            return
        if hasattr(self, 'stack') and self.stack.currentWidget() is not self.pages.get('catalog'):
            self._catalog_grid_needs_refresh = True
            return

        viewport_width = max(1, self.catalog_grid_scroll.viewport().width())
        cols = self._catalog_columns_for_width(viewport_width)
        self._catalog_last_columns = cols
        if getattr(self, '_catalog_visible_order', None) is None:
            row_order = [r for r in range(table.rowCount()) if not table.isRowHidden(r)]
        else:
            row_order = [r for r in self._catalog_visible_order
                         if 0 <= r < table.rowCount() and not table.isRowHidden(r)]

        row_lookup = {}
        for row in range(table.rowCount()):
            name_item = table.item(row, 2)
            if name_item:
                row_lookup[str(name_item.data(Qt.UserRole) or name_item.text())] = row
        self._catalog_row_lookup = row_lookup
        cards = getattr(self, '_catalog_cards', None)
        if cards is None:
            self._catalog_cards = {}
            cards = self._catalog_cards

        # Remove widgets only when the underlying catalog entry was genuinely deleted.
        for stale_model in list(cards):
            if stale_model not in row_lookup:
                stale_card = cards.pop(stale_model)
                layout.removeWidget(stale_card)
                stale_card.hide()
                stale_card.setParent(None)
                stale_card.deleteLater()

        visible_models = []
        for row in row_order:
            name_item = table.item(row, 2)
            if name_item:
                model = str(name_item.data(Qt.UserRole) or name_item.text())
                if model not in visible_models:
                    visible_models.append(model)
        visible_set = set(visible_models)

        # Hide only filtered-out cards; visible cards retain their widget identity and hover state.
        for model, card in cards.items():
            if model not in visible_set:
                if layout.indexOf(card) >= 0:
                    layout.removeWidget(card)
                card.hide()

        empty = getattr(self, '_catalog_empty_label', None)
        if not visible_models:
            if empty is None:
                empty = QLabel('За цими фільтрами моделей не знайдено.')
                empty.setObjectName('mutedNote')
                empty.setAlignment(Qt.AlignCenter)
                self._catalog_empty_label = empty
            for card in cards.values():
                if layout.indexOf(card) >= 0:
                    layout.removeWidget(card)
                card.hide()
            if layout.indexOf(empty) < 0:
                layout.addWidget(empty, 0, 0, 1, cols)
            empty.show()
            self._catalog_grid_layout_signature = (tuple(), cols)
            self._catalog_grid_needs_refresh = False
            return

        if empty is not None:
            if layout.indexOf(empty) >= 0:
                layout.removeWidget(empty)
            empty.hide()

        signature = (tuple(visible_models), cols)
        if signature == getattr(self, '_catalog_grid_layout_signature', None):
            # No structural change: do not touch layout, visibility or controls under the pointer.
            self._catalog_grid_needs_refresh = False
            return

        self._catalog_build_token = int(getattr(self, '_catalog_build_token', 0)) + 1
        token = self._catalog_build_token
        self._catalog_grid_needs_refresh = True
        batch_size = 8

        def populate_batch(start_index=0):
            if token != self._catalog_build_token:
                return
            if self.stack.currentWidget() is not self.pages.get('catalog'):
                self._catalog_grid_needs_refresh = True
                return
            stop_index = min(len(visible_models), start_index + batch_size)
            for index in range(start_index, stop_index):
                model = visible_models[index]
                row = row_lookup.get(model, -1)
                if row < 0:
                    continue
                card = cards.get(model)
                is_new = card is None
                if card is None:
                    card = self._create_catalog_card(model)
                    card.setParent(self.catalog_grid_host)
                    cards[model] = card
                self._update_catalog_card_for_row(model, row)
                desired_row, desired_col = divmod(index, cols)
                layout_index = layout.indexOf(card)
                current_position = layout.getItemPosition(layout_index) if layout_index >= 0 else None
                if current_position is None or current_position[:2] != (desired_row, desired_col):
                    if layout_index >= 0:
                        layout.removeWidget(card)
                    layout.addWidget(card, desired_row, desired_col)
                if is_new or card.isHidden():
                    card.show()
            if stop_index < len(visible_models):
                QTimer.singleShot(0, lambda next_index=stop_index: populate_batch(next_index))
            else:
                for col in range(cols):
                    layout.setColumnStretch(col, 1)
                self._catalog_grid_layout_signature = signature
                self._catalog_grid_needs_refresh = False

        QTimer.singleShot(0, lambda: populate_batch(0))

    def _set_catalog_active_from_card(self, row, checked):
        if not hasattr(self, 'catalog_table') or row >= self.catalog_table.rowCount():
            return
        self.catalog_table.item(row, 0).setCheckState(Qt.Checked if checked else Qt.Unchecked)
        if hasattr(self, 'catalog_sort') and self.catalog_sort.currentText() == 'Спочатку активні':
            self.filter_catalog()

    def _set_catalog_category_from_card(self, row, value):
        if not hasattr(self, 'catalog_table') or row >= self.catalog_table.rowCount():
            return
        combo = self.catalog_table.cellWidget(row, 3)
        if combo and combo.currentText() != value:
            combo.setCurrentText(value)

    def _set_catalog_threshold_from_card(self, row, value):
        if not hasattr(self, 'catalog_table') or row >= self.catalog_table.rowCount():
            return
        spin = self.catalog_table.cellWidget(row, 4)
        if spin and spin.value() != value:
            spin.setValue(value)

    def _edit_catalog_row(self, row):
        if not hasattr(self, 'catalog_table') or row >= self.catalog_table.rowCount():
            return
        self.catalog_table.setCurrentCell(row, 2)
        self.edit_selected_vehicle()

    def _make_settings_page(self):
        page, lay, self.settings_state = self._page('Налаштування', 'Швидкість сканування, правила дій, швидкість натискання та область 15 карток.')
        formbox = QFrame(); formbox.setObjectName('glassPanel'); form = QFormLayout(formbox); form.setContentsMargins(18, 16, 18, 16); form.setSpacing(12)
        self.set_threshold = QComboBox(); self.set_threshold.addItems([f'-{x}%' for x in range(5, 101, 5)]); self.set_threshold.setCurrentText(f"-{int(self.settings['threshold'])}%"); form.addRow('Поріг звичайних моделей', self.set_threshold)
        self.set_interval = QComboBox(); self.set_interval.addItems(list(INTERVALS)); self.set_interval.setCurrentText(self.interval_text()); form.addRow('Частота сканування', self.set_interval)
        self.resolution_profile_combo = QComboBox(); self.resolution_profile_combo.addItems(list(RESOLUTION_PROFILES)); self.resolution_profile_combo.setCurrentText(RESOLUTION_PROFILE_LABELS.get(self.settings.get('resolution_profile', 'auto'), RESOLUTION_PROFILE_LABELS['auto']))
        self.resolution_profile_combo.setToolTip('Профіль змінює щільність інтерфейсу. Він не змінює роздільність Windows або гри; сканер і координати покупки використовують фактичний фізичний розмір екрана.')
        self.resolution_profile_combo.currentTextChanged.connect(self._on_resolution_profile_changed); form.addRow('Масштаб інтерфейсу', self.resolution_profile_combo)
        self.animations_check = QCheckBox('Плавні переходи між розділами та м’які ефекти'); self.animations_check.setChecked(bool(self.settings.get('animations_enabled', False))); form.addRow('Анімації', self.animations_check)
        self.click_speed_combo = QComboBox(); self.click_speed_combo.addItems(list(CLICK_SPEEDS)); self.click_speed_combo.setCurrentText(self.click_speed_text()); self.click_speed_combo.setToolTip('Mouse-down/up відправляються одним SendInput-пакетом. Кнопка очікується адаптивно за зеленими пікселями кожні 2 мс; загальний час залежить від гри та сервера.'); form.addRow('Швидкість натискання', self.click_speed_combo)
        self.grid_spins = {}
        for key, label in [('left', 'Ліва межа області (%)'), ('top', 'Верхня межа області (%)'), ('right', 'Права межа області (%)'), ('bottom', 'Нижня межа області (%)')]:
            spin = QDoubleSpinBox(); spin.setRange(0.0, 100.0); spin.setDecimals(1); spin.setSingleStep(0.5); spin.setSuffix(' %'); spin.setValue(float(self.settings['grid'][key])*100); form.addRow(label, spin); self.grid_spins[key] = spin
        self.auto_click_check = QCheckBox('Дозволити автоклік по картці, яка точно відповідає умовам')
        self.auto_click_check.setChecked(bool(self.settings.get('auto_click', False)))
        form.addRow('Автоматизація', self.auto_click_check)
        self.auto_confirm_check = QCheckBox('Автоматично натиснути фінальне «Купити за …»')
        self.auto_confirm_check.setChecked(bool(self.settings.get('auto_confirm', False)))
        self.auto_confirm_check.setEnabled(bool(self.settings.get('auto_click', False)))
        self.auto_click_check.setToolTip('Вмикає автоматичний перехід до знайденої вигідної картки. Працює лише після перевірки назви, ціни, знижки, координат і вікна гри.')
        form.addRow('Автоклік', self.auto_click_check)
        self.auto_confirm_check.setToolTip('Якщо вимкнено, після відкриття сторінки автомобіля фінальний крок залишається для ручного підтвердження.')
        form.addRow('Фінальне підтвердження', self.auto_confirm_check)

        behavior_title = QLabel('Поведінка безперервного сканування')
        behavior_title.setObjectName('sectionTitle')
        form.addRow(behavior_title)
        self.continue_after_purchase_check = QCheckBox('Продовжувати сканування та пошук після покупки')
        self.continue_after_purchase_check.setChecked(bool(self.settings.get('continue_after_purchase', True)))
        self.continue_after_purchase_check.setToolTip('УВІМКНЕНО: після автоматичного ланцюжка покупки сканер дочекається повернення сітки «Транспорт» і продовжить. ВИМКНЕНО: після покупки безперервне сканування зупиниться.')
        form.addRow('Після покупки', self.continue_after_purchase_check)

        self.auto_refresh_check = QCheckBox('Автоматично перезапускати ринок через планшет')
        self.auto_refresh_check.setChecked(bool(self.settings.get('auto_refresh_enabled', False)))
        self.auto_refresh_check.setToolTip('Періодично виконує ESC → стрілка вниз → клік по екрану блокування → Маркет → Транспорт. Працює лише в безперервному режимі, коли гра на передньому плані й показана сітка авторинку. Перед дією сканер перевіряє стан екрана; якщо гра/сітка не підтверджена, кліки не надсилаються.')
        form.addRow('Автооновлення ринку', self.auto_refresh_check)
        self.auto_refresh_interval_combo = QComboBox()
        self.auto_refresh_interval_combo.addItems([f'{minutes} хв' for minutes in range(1, 11)])
        self.auto_refresh_interval_combo.setCurrentText(f"{int(self.settings.get('auto_refresh_interval_min', 5) or 5)} хв")
        self.auto_refresh_interval_combo.setEnabled(bool(self.settings.get('auto_refresh_enabled', False)))
        self.auto_refresh_interval_combo.setToolTip('Інтервал між завершеними оновленнями. Під час покупки та OCR автооновлення відкладається, а не перериває поточну дію.')
        form.addRow('Інтервал автооновлення', self.auto_refresh_interval_combo)

        protection_title = QLabel('Захисти та режим розпізнавання')
        protection_title.setObjectName('sectionTitle')
        form.addRow(protection_title)
        self.full_ocr_check = QCheckBox('GREEN ONLY: OCR лише карток із зеленим бейджем')
        # GREEN ONLY is a hard lock, not a user-toggleable option. Show it as ON;
        # the previous unchecked + disabled state misleadingly looked like OFF.
        self.full_ocr_check.setChecked(True)
        self.full_ocr_check.setEnabled(False)
        self.full_ocr_check.setToolTip('GREEN ONLY УЖЕ УВІМКНЕНО та зафіксовано. Прапорець заблокований навмисно: сканер пропускає червоні, відсутні й невизначені бейджі без OCR, щоб не витрачати час перед перевіркою зеленої пропозиції. Додатково натискати не потрібно.')
        form.addRow('Режим OCR (зафіксовано)', self.full_ocr_check)
        self.blacklist_protection_check = QCheckBox('Блокувати автодії для моделей із чорного списку')
        self.blacklist_protection_check.setChecked(bool(self.settings.get('blacklist_protection_enabled', True)))
        self.blacklist_protection_check.setToolTip('Рекомендовано залишати увімкненим. Якщо вимкнути, моделі з чорного списку можуть розглядатися для автодії, якщо їх також увімкнено в каталозі й вони пройдуть інші перевірки.')
        form.addRow('Чорний список', self.blacklist_protection_check)
        self.confidence_protection_check = QCheckBox('Вимагати високу впевненість збігу назви (не менше 0,93)')
        self.confidence_protection_check.setChecked(bool(self.settings.get('confidence_protection_enabled', True)))
        self.confidence_protection_check.setToolTip('Увімкнено: автодія блокується, якщо впевненість розпізнавання назви нижча за 0,93. Якщо вимкнути, все одно потрібен збіг із моделлю каталогу з мінімальною впевненістю 0,80.')
        form.addRow('Перевірка назви', self.confidence_protection_check)
        required_safety = QLabel('Постійно активні захисти: сканувати лише в активному вікні гри; перевіряти розмір екрана та координати; дочекатися видимої зеленої кнопки перед кліком; скасувати дію при втраті фокуса. Ці перевірки не вимикаються.')
        required_safety.setObjectName('warningNote')
        required_safety.setWordWrap(True)
        form.addRow('Обов’язкові захисти', required_safety)

        blacklist_frame = QFrame(); blacklist_frame.setObjectName('glassPanel')
        blacklist_layout = QVBoxLayout(blacklist_frame); blacklist_layout.setContentsMargins(14, 12, 14, 12); blacklist_layout.setSpacing(7)
        blacklist_title = QLabel('Чорний список автомобілів'); blacklist_title.setObjectName('sectionTitle'); blacklist_layout.addWidget(blacklist_title)
        blacklist_hint = QLabel('Одна модель на рядок. Вона залишиться в каталозі та статистиці, але її автоматична покупка буде заблокована. Також можна вибрати «Чорний список» у категорії картки авто.')
        blacklist_hint.setObjectName('mutedNote'); blacklist_hint.setWordWrap(True); blacklist_layout.addWidget(blacklist_hint)
        self.blacklist_editor = QTextEdit(); self.blacklist_editor.setObjectName('blacklistEditor'); self.blacklist_editor.setAcceptRichText(False)
        self.blacklist_editor.setMinimumHeight(105); self.blacklist_editor.setMaximumHeight(170)
        self.blacklist_editor.setPlainText('\n'.join(read_lines(BLACKLIST)))
        self.blacklist_editor.setPlaceholderText('Наприклад:\nPenaud Logan\nUbermacht M3 E30')
        blacklist_layout.addWidget(self.blacklist_editor)
        lay.addWidget(blacklist_frame)
        safe = QLabel('Автодія запускається лише для моделі з каталогу, підтвердженою ціною та реальною зеленою знижкою, що проходить поріг моделі. Перед кожним натисканням сканер перевіряє цільове вікно й видимий стан кнопки; якщо перевірка не пройдена, кліку не буде. Швидкість реакції гри та сервера не гарантується.')
        safe.setObjectName('warningNote'); safe.setWordWrap(True); form.addRow('Захист покупки', safe)
        lay.addWidget(formbox)
        hint = QLabel('Профіль Full HD/2K впливає на щільність інтерфейсу після перезапуску, а не змінює Windows/гру. Координати кліків автоматично масштабуються до фактичного фізичного розміру екрана. У режимі «Ультра+» інтервал між циклами — 50 мс (теоретично до 20 циклів/с, якщо захоплення/OCR вкладаються в цей час). Одночасні OCR-потоки не запускаються: якщо цикл триває довше інтервалу, наступний починається відразу після завершення. Незмінені картки та поля обробляються через кеш. Глобальна команда СТОП — Ctrl+Alt+F8.')
        hint.setObjectName('mutedNote'); hint.setWordWrap(True); lay.addWidget(hint)
        self.auto_click_check.toggled.connect(self._on_auto_click_toggled)
        self.auto_confirm_check.toggled.connect(self._on_auto_confirm_toggled)
        self.auto_refresh_check.toggled.connect(self.auto_refresh_interval_combo.setEnabled)
        self.blacklist_protection_check.toggled.connect(self._on_runtime_protection_controls_changed)
        self.confidence_protection_check.toggled.connect(self._on_runtime_protection_controls_changed)
        buttons = QHBoxLayout(); save = QPushButton('Зберегти налаштування'); save.setObjectName('primary'); save.clicked.connect(self.save_all_settings); buttons.addWidget(save)
        reset = QPushButton('Скинути область'); reset.setObjectName('ghost'); reset.clicked.connect(self.reset_grid); buttons.addWidget(reset); lay.addLayout(buttons); lay.addStretch()
        return page

    def _on_resolution_profile_changed(self, label):
        """Keep the profile controls synchronized; layout density is applied on restart."""
        profile = RESOLUTION_PROFILES.get(str(label), 'auto')
        self._pending_resolution_profile = profile
        for name in ('scan_resolution_combo', 'resolution_profile_combo'):
            combo = getattr(self, name, None)
            if combo is not None and combo.currentText() != RESOLUTION_PROFILE_LABELS[profile]:
                combo.blockSignals(True)
                combo.setCurrentText(RESOLUTION_PROFILE_LABELS[profile])
                combo.blockSignals(False)
        status = getattr(self, 'scan_resolution_status', None)
        if status is not None:
            status.setText(self._screen_profile_status_text())

    def _sync_resolution_profile_controls(self):
        profile = str(getattr(self, '_pending_resolution_profile', self.settings.get('resolution_profile', 'auto')))
        label = RESOLUTION_PROFILE_LABELS.get(profile, RESOLUTION_PROFILE_LABELS['auto'])
        self._pending_resolution_profile = profile
        for name in ('scan_resolution_combo', 'resolution_profile_combo'):
            combo = getattr(self, name, None)
            if combo is not None:
                combo.blockSignals(True)
                combo.setCurrentText(label)
                combo.blockSignals(False)
        status = getattr(self, 'scan_resolution_status', None)
        if status is not None:
            status.setText(self._screen_profile_status_text())

    def _on_runtime_protection_controls_changed(self, *_):
        """Persist OCR/automation safety toggles immediately for the next scan cycle."""
        if hasattr(self, 'full_ocr_check'):
            self.settings['fast_color_filter_enabled'] = True
        if hasattr(self, 'blacklist_protection_check'):
            self.settings['blacklist_protection_enabled'] = self.blacklist_protection_check.isChecked()
        if hasattr(self, 'confidence_protection_check'):
            self.settings['confidence_protection_enabled'] = self.confidence_protection_check.isChecked()
        self.settings['config_version'] = 31
        try:
            self._write_settings()
            if hasattr(self, 'full_ocr_check'):
                mode = 'GREEN ONLY зафіксовано: текст червоних/невідомих карток не розпізнається'
                self.logline(f'Режим розпізнавання збережено: {mode}.')
            if hasattr(self, 'blacklist_protection_check') and not self.blacklist_protection_check.isChecked():
                self.logline('УВАГА: захист чорного списку вимкнено; такі моделі можуть розглядатися для автодії.')
            if hasattr(self, 'confidence_protection_check'):
                self.logline('Строгий поріг впевненості назви: ' + ('0,93' if self.confidence_protection_check.isChecked() else '0,80 для збігу з каталогом') + '.')
        except Exception as exc:
            self.logline(f'Не вдалося зберегти перемикачі захисту: {type(exc).__name__}: {exc}')

    def _refresh_safe_note(self):
        if not hasattr(self, 'safe_note'):
            return
        if self.settings.get('auto_click', False):
            final = 'автопідтвердження ON' if self.settings.get('auto_confirm', False) else 'фінальне підтвердження вручну'
            after = 'продовження після покупки ON' if self.settings.get('continue_after_purchase', True) else 'стоп після покупки ON'
            self.safe_note.setText(f'АВТОДІЇ УВІМКНЕНО · {final} · {after}')
        else:
            self.safe_note.setText('АНАЛІЗ БЕЗ КЛІКІВ · автоматичне відкриття картки та купівля вимкнені')

    def _on_auto_click_toggled(self, checked):
        self.settings['auto_click'] = bool(checked)
        if not checked and self.action_worker and self.action_worker.isRunning():
            self.action_worker.cancel()
            self.logline('Автоклік вимкнено під час автодії: надіслано команду скасування.')
        if not checked:
            self.settings['auto_confirm'] = False
            self.auto_confirm_check.blockSignals(True)
            self.auto_confirm_check.setChecked(False)
            self.auto_confirm_check.blockSignals(False)
        self.auto_confirm_check.setEnabled(bool(checked))
        self.settings['auto_confirm'] = bool(checked and self.auto_confirm_check.isChecked())
        try:
            self.settings['config_version'] = 31
            self._write_settings()
        except Exception as exc:
            self.logline(f'Не вдалося зберегти перемикач автокліку: {type(exc).__name__}: {exc}')
        self._refresh_safe_note()
        self.logline(f'Автоклік: {"УВІМКНЕНО" if checked else "ВИМКНЕНО"}.')

    def _on_auto_confirm_toggled(self, checked):
        if not checked and self.action_worker and self.action_worker.isRunning():
            # If the final confirmation has not happened yet, cancellation leaves it for manual review.
            self.action_worker.cancel()
            self.logline('Автопідтвердження вимкнено: поточну автодію скасовано перед наступним кроком.')
        if checked and not self.auto_click_check.isChecked():
            self.auto_confirm_check.blockSignals(True)
            self.auto_confirm_check.setChecked(False)
            self.auto_confirm_check.blockSignals(False)
            checked = False
        self.settings['auto_confirm'] = bool(checked and self.auto_click_check.isChecked())
        try:
            self.settings['config_version'] = 31
            self._write_settings()
        except Exception as exc:
            self.logline(f'Не вдалося зберегти перемикач підтвердження: {type(exc).__name__}: {exc}')
        self._refresh_safe_note()
        self.logline(f'Автопідтвердження: {"УВІМКНЕНО" if self.settings["auto_confirm"] else "ВИМКНЕНО"}.')

    def _make_stats_page(self):
        page, lay, self.stats_state = self._page('Статистика сканера', 'Реальні вимірювання швидкості, точності розпізнавання, вигідних пропозицій і підтверджених покупок за журналом.')
        filter_row = QHBoxLayout(); filter_row.addWidget(make_icon_label('stats', 18))
        filter_title = QLabel('Аналітика NG Market'); filter_title.setObjectName('sectionTitle'); filter_row.addWidget(filter_title); filter_row.addStretch()
        self.stats_period_combo = QComboBox(); self.stats_period_combo.addItems(['Сьогодні', '7 днів', '30 днів', 'Увесь час']); self.stats_period_combo.setCurrentText('7 днів'); self.stats_period_combo.currentTextChanged.connect(self.refresh_stats); filter_row.addWidget(QLabel('Період:')); filter_row.addWidget(self.stats_period_combo)
        refresh = QPushButton('Оновити'); refresh.setObjectName('ghost'); refresh.setIcon(make_ui_icon('refresh', '#DCE7F1')); refresh.clicked.connect(self.refresh_stats); filter_row.addWidget(refresh)
        export = QPushButton('Експорт CSV'); export.setObjectName('primary'); export.setIcon(make_ui_icon('save', '#0B3026')); export.clicked.connect(self.export_stats_csv); filter_row.addWidget(export)
        lay.addLayout(filter_row)

        self.stats_cards = {}
        grid = QGridLayout(); grid.setSpacing(9)
        definitions = [
            ('cards', 'Картки в останньому циклі'), ('checked_total', 'Карток перевірено всього'),
            ('recognized', 'Розпізнано в останньому циклі'), ('eligible', 'Поточні вигідні пропозиції'),
            ('offers_total', 'Вигідних пропозицій у журналі'), ('actions_sent', 'Послідовностей кліків надіслано'),
            ('confirmed', 'Підтверджені покупки'), ('failed', 'Невдалі автодії'),
            ('avg_cycle', 'Середній цикл'), ('avg_ocr', 'Середній OCR'),
            ('click_speed', 'Налаштована затримка кліку'), ('savings', 'Оціночна економія підтверджених'),
        ]
        for i, (key, title) in enumerate(definitions):
            box = QFrame(); box.setObjectName('statsMetricCard')
            v = QVBoxLayout(box); v.setContentsMargins(12, 10, 12, 10); v.setSpacing(4)
            icon = make_icon_label('stats' if i % 3 == 0 else ('clock' if 'цикл' in title.lower() or 'ocr' in title.lower() else 'check'), 18)
            v.addWidget(icon, 0, Qt.AlignLeft)
            name = QLabel(title); name.setObjectName('statsMetricTitle'); name.setWordWrap(True)
            value = QLabel('—'); value.setObjectName('statsMetricValue'); value.setWordWrap(True)
            v.addWidget(name); v.addWidget(value)
            self.stats_cards[key] = value; grid.addWidget(box, i // 4, i % 4)
        lay.addLayout(grid)

        charts = QGridLayout(); charts.setSpacing(10)
        self.stats_purchase_chart = MiniLineChart('Динаміка підтверджених покупок (за журналом)', 'шт.')
        self.stats_cycle_chart = MiniLineChart('Середній час циклу (фактичні вимірювання)', 'с')
        self.stats_ocr_chart = MiniLineChart('Час OCR (лише OCR-цикли)', 'с')
        charts.addWidget(self.stats_purchase_chart, 0, 0, 1, 2)
        charts.addWidget(self.stats_cycle_chart, 1, 0); charts.addWidget(self.stats_ocr_chart, 1, 1)
        lay.addLayout(charts)

        lower = QGridLayout(); lower.setSpacing(10)
        top_box = QFrame(); top_box.setObjectName('glassPanel'); top_lay = QVBoxLayout(top_box); top_lay.setContentsMargins(12, 10, 12, 10)
        top_title = QLabel('Топ автомобілів за вигідними пропозиціями'); top_title.setObjectName('sectionTitle'); top_lay.addWidget(top_title)
        self.stats_rank_table = QTableWidget(0, 4); self.stats_rank_table.setHorizontalHeaderLabels(['Модель', 'Вигідних', 'Автодій', 'Підтверджено'])
        self._style_table(self.stats_rank_table); self.stats_rank_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
        for c in (1, 2, 3): self.stats_rank_table.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        self.stats_rank_table.setMinimumHeight(230); self.stats_rank_table.setMaximumHeight(390); top_lay.addWidget(self.stats_rank_table)
        lower.addWidget(top_box, 0, 0)

        info_box = QFrame(); info_box.setObjectName('glassPanel'); info_lay = QVBoxLayout(info_box); info_lay.setContentsMargins(12, 10, 12, 10)
        info_title = QLabel('Додаткова інформація'); info_title.setObjectName('sectionTitle'); info_lay.addWidget(info_title)
        self.stats_summary = QTextEdit(); self.stats_summary.setReadOnly(True); self.stats_summary.setMinimumHeight(230); self.stats_summary.setPlaceholderText('Після сканування тут з’являться реальні показники.'); info_lay.addWidget(self.stats_summary, 1)
        lower.addWidget(info_box, 0, 1)
        lower.setColumnStretch(0, 3); lower.setColumnStretch(1, 2); lay.addLayout(lower, 1)
        return page

    def _make_top_page(self):
        page, lay, self.top_state = self._page('Топ автомобілів', 'Рейтинг моделей за вигідними пропозиціями та фактично зафіксованими результатами автоматичних дій.')
        cards = QGridLayout(); cards.setSpacing(10)
        self.top_summary_values = {}
        for i, (key, title) in enumerate([('offers', 'Вигідних пропозицій'), ('actions', 'Послідовностей кліків'), ('confirmed', 'Підтверджених покупок'), ('savings', 'Оціночна економія')]):
            box = QFrame(); box.setObjectName('statsMetricCard'); v = QVBoxLayout(box); v.setContentsMargins(14, 12, 14, 12)
            label = QLabel(title); label.setObjectName('statsMetricTitle'); value = QLabel('—'); value.setObjectName('statsMetricValue')
            v.addWidget(label); v.addWidget(value); self.top_summary_values[key] = value; cards.addWidget(box, 0, i)
        lay.addLayout(cards)
        title = QLabel('Рейтинг за вигідними появами та результатами автодій'); title.setObjectName('sectionTitle'); lay.addWidget(title)
        self.top_table = QTableWidget(0, 6); self.top_table.setHorizontalHeaderLabels(['№', 'Модель автомобіля', 'Вигідних появ', 'Кліків надіслано', 'Підтверджено', 'Середня знижка'])
        self._style_table(self.top_table); self.top_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.Stretch)
        for c in (0, 2, 3, 4, 5): self.top_table.horizontalHeader().setSectionResizeMode(c, QHeaderView.ResizeToContents)
        lay.addWidget(self.top_table, 1)
        note = QLabel('«Клік надіслано» означає, що Windows отримала послідовність натискань. «Підтверджено» додається лише при явному повідомленні підтвердження; натискання кнопки саме по собі не є доказом покупки.'); note.setObjectName('mutedNote'); note.setWordWrap(True); lay.addWidget(note)
        row = QHBoxLayout(); row.addStretch(); export = QPushButton('Експорт рейтингу CSV'); export.setObjectName('primary'); export.clicked.connect(self.export_stats_csv); row.addWidget(export); lay.addLayout(row)
        return page

    def _make_log_page(self):
        page, lay, self.log_state = self._page('Журнал подій', 'Хронологія сканування, причини пропуску карток, зміни пропозицій і статуси автоматичних дій.')
        self.full_log = QPlainTextEdit(); self.full_log.setReadOnly(True); self.full_log.document().setMaximumBlockCount(2000); lay.addWidget(self.full_log, 1)
        row = QHBoxLayout(); clear = QPushButton('Очистити журнал'); clear.setObjectName('ghost'); clear.clicked.connect(self.clear_log); row.addWidget(clear)
        export = QPushButton('Експортувати TXT'); export.setObjectName('primary'); export.clicked.connect(self.export_log); row.addWidget(export)
        row.addStretch(); lay.addLayout(row)
        return page

    def _make_about_page(self):
        page, lay, self.about_state = self._page('Про NG Market Scanner', 'Що сканер перевіряє, як визначає вигідні пропозиції та які обмеження діють для захисту від помилкових кліків.')
        box = QFrame(); box.setObjectName('glassPanel'); v = QVBoxLayout(box); v.setContentsMargins(18, 18, 18, 18); v.setSpacing(10)
        title = QLabel('NG MARKET SCANNER  ·  v1.2.65 FINAL RELIABILITY  ·  2K / FULL HD'); title.setObjectName('sectionTitle'); v.addWidget(title)
        for txt in [
            '• Аналізує 15 карток у сітці 3×5 на основному моніторі й показує окремий статус кожної картки.',
            '• Окремо зчитує назву, ціну та кольоровий бейдж знижки через RapidOCR.',
            '• Зелений бейдж трактується як мінус-знижка, червоний — як плюс-націнка; націнка не є вигідною пропозицією.',
            '• Каталог підтримує додавання власних моделей, фото, категорії та індивідуального порога; ці назви передаються в OCR-зіставлення.',
            '• Режим GREEN ONLY зафіксовано: текст читається лише на картках із зеленим бейджем; повне OCR червоних/невідомих карток недоступне, щоб не витрачати час на них.',
            '• Перед автоматичною дією перевіряються збіг моделі, ціна, поріг знижки та параметри захисту. Перевірка активного вікна гри й готовності кнопки покупки завжди увімкнена.',
            '• Діагностика зберігається у last_scan_diagnostics.json; у журналі для кожної картки є причина, чому її текст пропущено або автодію заблоковано.',
            '',
            'Обмеження: точність OCR залежить від масштабу гри, чіткості карток і налаштованої області. Перед практичним використанням перевір результати вручну.'
        ]:
            l = QLabel(txt); l.setObjectName('mutedNote'); l.setWordWrap(True); v.addWidget(l)
        lay.addWidget(box); lay.addStretch(); return page

    def _style_table(self, table):
        table.setAlternatingRowColors(True); table.setShowGrid(False); table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers); table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setMinimumHeight(180); table.verticalHeader().setDefaultSectionSize(34); table.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents)

    def _apply_style(self):
        # Enlarge font/spacing tokens on high-resolution screens. This affects UI only;
        # screenshots, OCR crops and all calibrated game click coordinates stay unchanged.
        theme_path = RESOURCE_DIR / 'theme' / 'style.qss'
        try:
            stylesheet = theme_path.read_text(encoding='utf-8')
            scale = float(getattr(self, 'ui_scale', 1.0))
            if scale > 1.001:
                def _scale_css_px(match):
                    value = float(match.group(1))
                    if value == 0:
                        return match.group(0)
                    return f"{max(1, int(round(value * scale)))}px"
                stylesheet = re.sub(r'(?<![\w.])(-?\d+(?:\.\d+)?)px\b', _scale_css_px, stylesheet)
            self.setStyleSheet(stylesheet)
        except Exception as exc:
            self.setStyleSheet('QWidget { background: #080e14; color: #e8edf2; }')
            try:
                self.logline(f'Не вдалося завантажити тему {theme_path.name}: {exc}')
            except Exception:
                pass

    def _set_start_button(self, state='start'):
        """Update scan action label and its vector icon together; no Unicode icon glyphs."""
        variants = {
            'start': ('Почати сканування', 'play', '#0B3026'),
            'stop': ('Зупинити сканування', 'stop', '#3D171D'),
            'analyze': ('Зупинити аналіз', 'stop', '#3D171D'),
        }
        label, icon_name, icon_color = variants.get(state, variants['start'])
        object_name = 'danger' if state in ('stop', 'analyze') else 'primary'
        if self.start_btn.objectName() != object_name:
            self.start_btn.setObjectName(object_name)
            self.start_btn.style().unpolish(self.start_btn)
            self.start_btn.style().polish(self.start_btn)
        self.start_btn.setText(label)
        self.start_btn.setIcon(make_ui_icon(icon_name, icon_color))
        self.start_btn.setIconSize(QSize(18, 18))

    def interval_text(self):
        try:
            value = int(self.settings.get('interval_ms', 50))
        except (TypeError, ValueError):
            value = 50
        return min(INTERVALS, key=lambda label: abs(INTERVALS[label] - value))

    def click_speed_text(self):
        value = int(self.settings.get('click_delay_ms', 1))
        return next((label for label, ms in CLICK_SPEEDS.items() if ms == value), 'Миттєво · 1 мс')

    def navigate(self, key):
        """Switch pages immediately; refresh non-visible page content after UI dispatch."""
        if key not in self.pages:
            return
        same_page = self.stack.currentIndex() == self.page_index[key]
        if not same_page:
            self.stack.setCurrentIndex(self.page_index[key])
        page_widget = self.pages[key]
        if self._fade is not None:
            previous_effect = self._fade.targetObject()
            self._fade.stop()
            if previous_effect is not None:
                previous_effect.setOpacity(1.0)
            self._fade = None
        if bool(self.settings.get('animations_enabled', False)) and not same_page:
            effect = self._page_fade_effects.get(page_widget)
            if effect is None:
                effect = QGraphicsOpacityEffect(page_widget)
                effect.setOpacity(1.0)
                page_widget.setGraphicsEffect(effect)
                self._page_fade_effects[page_widget] = effect
            effect.setOpacity(0.82)
            self._fade = QPropertyAnimation(effect, b'opacity', self)
            self._fade.setDuration(90)
            self._fade.setStartValue(0.82)
            self._fade.setEndValue(1.0)
            self._fade.setEasingCurve(QEasingCurve.OutCubic)
            self._fade.start()
        for name, btn in self.nav_buttons.items():
            desired = 'navActive' if name == key else 'nav'
            if btn.objectName() != desired:
                btn.setObjectName(desired)
                btn.style().unpolish(btn)
                btn.style().polish(btn)
        if not same_page:
            # The active page becomes visible before stats/log/catalog refresh work.
            # If the user switches again immediately, the stale callback simply exits.
            QTimer.singleShot(0, lambda selected=key: self._refresh_page_after_navigation(selected))

    def _refresh_page_after_navigation(self, key):
        if key not in self.pages or self.stack.currentIndex() != self.page_index.get(key):
            return
        if key == 'catalog':
            self.refresh_catalog()
        elif key in ('stats', 'top'):
            self.refresh_stats()
            self._refresh_performance_widgets()
        elif key == 'log':
            self.refresh_log_views()
        elif key == 'settings':
            self.set_threshold.setCurrentText(f"-{int(self.settings['threshold'])}%")
            self.set_interval.setCurrentText(self.interval_text())
            self.click_speed_combo.setCurrentText(self.click_speed_text())
            self._sync_resolution_profile_controls()
            if hasattr(self, 'animations_check'):
                self.animations_check.setChecked(bool(self.settings.get('animations_enabled', False)))
            # Synchronize persisted toggles without firing handlers or rebuilding the catalog.
            self.auto_click_check.blockSignals(True)
            self.auto_confirm_check.blockSignals(True)
            self.auto_click_check.setChecked(bool(self.settings.get('auto_click', False)))
            self.auto_confirm_check.setChecked(bool(self.settings.get('auto_confirm', False)))
            self.auto_confirm_check.setEnabled(bool(self.settings.get('auto_click', False)))
            self.auto_click_check.blockSignals(False)
            self.auto_confirm_check.blockSignals(False)
            self.continue_after_purchase_check.blockSignals(True)
            self.auto_refresh_check.blockSignals(True)
            self.auto_refresh_interval_combo.blockSignals(True)
            self.continue_after_purchase_check.setChecked(bool(self.settings.get('continue_after_purchase', True)))
            self.auto_refresh_check.setChecked(bool(self.settings.get('auto_refresh_enabled', False)))
            self.auto_refresh_interval_combo.setCurrentText(f"{int(self.settings.get('auto_refresh_interval_min', 5) or 5)} хв")
            self.auto_refresh_interval_combo.setEnabled(bool(self.settings.get('auto_refresh_enabled', False)))
            self.continue_after_purchase_check.blockSignals(False)
            self.auto_refresh_check.blockSignals(False)
            self.auto_refresh_interval_combo.blockSignals(False)

    def loglines(self, messages):
        """Persist log rows and append only the new text to the plain-text views."""
        messages = [str(message).strip() for message in messages if str(message).strip()]
        if not messages:
            return
        now = datetime.now()
        lines = [f'{now:%H:%M:%S}    {message}' for message in messages]
        self.event_lines.extend(lines)
        self.event_lines = self.event_lines[-2000:]
        try:
            with LOG.open('a', encoding='utf-8') as f:
                f.write('\n'.join(lines) + '\n')
        except Exception:
            pass
        self._append_log_views(lines)

    def _append_log_views(self, lines):
        """Append deltas instead of rebuilding up to 2,000 lines twice per event."""
        payload = '\n'.join(str(line) for line in lines if str(line))
        if not payload:
            return
        for widget_name, block_limit in (('log_preview', 80), ('full_log', 2000)):
            widget = getattr(self, widget_name, None)
            if widget is None:
                continue
            try:
                document = widget.document()
                if document.maximumBlockCount() != block_limit:
                    document.setMaximumBlockCount(block_limit)
                # Both log widgets are QPlainTextEdit instances; appendPlainText is
                # optimized for streaming logs and avoids setPlainText/layout of history.
                widget.appendPlainText(payload)
            except Exception:
                # Never fall back to a synchronous full render on the purchase hot path.
                if not self._log_views_refresh_pending:
                    self._log_views_refresh_pending = True
                    QTimer.singleShot(50, self._flush_log_views_refresh)

    def _flush_log_views_refresh(self):
        self._log_views_refresh_pending = False
        self.refresh_log_views()

    def logline(self, message):
        self.loglines([message])
        self._observe_stats_message(str(message))

    def refresh_log_views(self):
        for widget_name, block_limit in (('log_preview', 80), ('full_log', 2000)):
            widget = getattr(self, widget_name, None)
            if widget:
                try:
                    widget.document().setMaximumBlockCount(block_limit)
                except Exception:
                    pass
                widget.setPlainText('\n'.join(self.event_lines[-block_limit:]))
                widget.moveCursor(QTextCursor.End)

    def clear_log(self):
        self.event_lines = []
        try: LOG.write_text('', encoding='utf-8')
        except Exception as e: QMessageBox.warning(self, 'Журнал', f'Не вдалося очистити файл журналу: {e}')
        self.refresh_log_views()
        self.logline('Журнал очищено користувачем.')

    def export_log(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Експорт журналу', 'NG_Market_Scanner_log.txt', 'Текстові файли (*.txt)')
        if not path: return
        try:
            Path(path).write_text('\n'.join(self.event_lines) + '\n', encoding='utf-8')
            self.logline(f'Журнал експортовано: {path}')
        except Exception as e: QMessageBox.critical(self, 'Помилка експорту', str(e))

    def _catalog_state_signature(self):
        """Stable signature lets navigation reuse the hidden table and avoid rebuilding 100+ controls."""
        selected = self.settings.get('selected_models')
        if not isinstance(selected, list):
            selected = read_lines(SELECTED)
        payload = {
            'models': list(self.all_models),
            'threshold': int(self.settings.get('threshold', 20)),
            'selected': list(selected),
            'model_thresholds': self.settings.get('model_thresholds', {}),
            'category_overrides': self.settings.get('category_overrides', {}),
            'custom_vehicles': self.settings.get('custom_vehicles', {}),
            'vehicle_photos': self.settings.get('vehicle_photos', {}),
            'blacklist': sorted(load_blacklist_models(self.all_models)),
            'rules': self.rules,
        }
        return hashlib.sha256(json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str).encode('utf-8')).hexdigest()

    def refresh_catalog(self, force=False):
        if not hasattr(self, 'catalog_table'):
            return
        desired_signature = self._catalog_state_signature()
        if not force and desired_signature == getattr(self, '_catalog_built_signature', None):
            # Navigating back to Catalog should not recreate every row, combo, spin box,
            # or pixmap. Only bring the cached tile grid up to date if it is stale.
            if getattr(self, '_catalog_grid_needs_refresh', False):
                self._schedule_catalog_grid_rebuild()
            return
        self._catalog_manual_thresholds = set()
        configured = self.settings.get('selected_models')
        selected = set(configured) if isinstance(configured, list) else set(read_lines(SELECTED))
        selected = {'Bravado Charger Redeye' if m == 'Bravado Charger Redeve' else m for m in selected}
        if configured is None and not selected and not SELECTED.exists(): selected = set(self.all_models)
        overrides = self.settings.get('model_thresholds', {})
        blacklisted_models = load_blacklist_models(self.all_models)
        self.catalog_table.setRowCount(0)
        for model in self.all_models:
            rule = self.rules.get(model, {'category':'Звичайне', 'threshold':20})
            category = BLACKLIST_CATEGORY if model in blacklisted_models else rule['category']
            custom_meta = self.settings.get('custom_vehicles', {}).get(model, {})
            default = int(overrides.get(model, custom_meta.get('threshold', rule['threshold'] if category != 'Звичайне' else self.settings['threshold'])))
            r = self.catalog_table.rowCount(); self.catalog_table.insertRow(r)
            check = QTableWidgetItem(''); check.setFlags(Qt.ItemIsEnabled | Qt.ItemIsUserCheckable); check.setCheckState(Qt.Checked if model in selected else Qt.Unchecked)
            self.catalog_table.setItem(r, 0, check)
            # The table is a hidden data/selection model; loading 53 thumbnails here
            # duplicated the image decoding before the visible card grid was built.
            # The visible cards lazily load from the shared pixmap cache instead.
            thumb = QTableWidgetItem('')
            thumb.setTextAlignment(Qt.AlignCenter)
            thumb.setToolTip('Попередній перегляд завантажується кешовано у квадратній сітці каталогу.')
            self.catalog_table.setItem(r, 1, thumb)
            name = QTableWidgetItem(model); name.setData(Qt.UserRole, model); name.setData(Qt.UserRole + 1, model in self.settings.get('custom_vehicles', {})); name.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable); self.catalog_table.setItem(r, 2, name)
            self.catalog_table.setRowHeight(r, int(184 * self.ui_scale))
            cat_combo = QComboBox()
            cat_combo.addItems(list(CATALOG_CATEGORIES))
            # Normalize legacy/category wording so the control never appears blank.
            aliases = {'Пріоритетна': 'Пріоритетне', 'Звичайна': 'Звичайне', 'Спеціальна': 'Спеціальне'}
            category = aliases.get(str(category).strip(), str(category).strip())
            if category not in CATALOG_CATEGORIES:
                category = 'Звичайне'
            if model in load_blacklist_models(self.all_models):
                category = BLACKLIST_CATEGORY
            cat_combo.setCurrentText(category)
            cat_combo.setProperty('previous_category', category)
            cat_combo.setFixedWidth(178)
            cat_combo.setFixedHeight(30)
            cat_combo.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            cat_combo.setToolTip('Категорія визначає правило знижки для цієї моделі')
            cat_combo.currentTextChanged.connect(lambda new_value, row=r: self._on_catalog_category_changed(row, new_value))
            self.catalog_table.setCellWidget(r, 3, cat_combo)
            spin = QSpinBox()
            spin.setRange(0, 100)
            spin.setSuffix(' %')
            spin.setValue(default)
            spin.valueChanged.connect(lambda value, row=r: self._mark_catalog_threshold_manual(row))
            spin.setFixedWidth(116)
            spin.setFixedHeight(30)
            spin.setSizePolicy(QSizePolicy.Fixed, QSizePolicy.Fixed)
            spin.setToolTip('Мінімальна знижка для цієї моделі, у відсотках')
            self.catalog_table.setCellWidget(r, 4, spin)
        self.filter_catalog()
        self._catalog_built_signature = self._catalog_state_signature()
        self._schedule_catalog_grid_rebuild()

    def _selected_catalog_model(self):
        row = self.catalog_table.currentRow() if hasattr(self, 'catalog_table') else -1
        if row < 0 or self.catalog_table.item(row, 2) is None:
            QMessageBox.information(self, 'Вибери автомобіль', 'Спочатку вибери рядок автомобіля в каталозі.')
            return None, -1
        item = self.catalog_table.item(row, 2)
        return str(item.data(Qt.UserRole) or item.text()), row

    def _configured_selected_models(self):
        configured = self.settings.get('selected_models')
        if isinstance(configured, list):
            return list(configured)
        if SELECTED.exists():
            return read_lines(SELECTED)
        return list(self.all_models)

    @staticmethod
    def _slug_for_photo(model):
        stem = re.sub(r'[^A-Za-z0-9_-]+', '_', str(model or '')).strip('_')[:48] or 'vehicle'
        digest = hashlib.sha1(str(model or '').casefold().encode('utf-8')).hexdigest()[:10]
        return f'{stem}_{digest}'

    def _store_custom_photo(self, model, source_path):
        source = Path(str(source_path or '')).expanduser()
        if not source.is_file() or source.suffix.lower() not in _CUSTOM_PHOTO_EXTENSIONS:
            raise ValueError('Вибери наявний файл зображення підтримуваного формату.')
        # QPixmap validation catches truncated/renamed non-image files before persistence.
        if QPixmap(str(source)).isNull():
            raise ValueError('Файл не вдалося прочитати як зображення.')
        target_dir = DATA / 'vehicle_photos' / 'custom'
        target_dir.mkdir(parents=True, exist_ok=True)
        target = target_dir / f'{self._slug_for_photo(model)}{source.suffix.lower()}'
        if source.resolve() != target.resolve():
            shutil.copy2(source, target)
        return target.relative_to(DATA).as_posix()

    def _sync_rules_and_models(self):
        """Rebuild OCR catalog inputs from bundled rules plus persistent custom entries."""
        self.rules = load_rules()
        for model, meta in self.settings.get('custom_vehicles', {}).items():
            self.rules[model] = {
                'category': meta.get('category', 'Звичайне'),
                'threshold': int(meta.get('threshold', 20)),
            }
        for model, category in self.settings.get('category_overrides', {}).items():
            if model in self.rules and category in ('Пріоритетне', 'Звичайне', 'Спеціальне'):
                self.rules[model]['category'] = category
        bundled_models = read_lines(ALL)
        self.all_models = list(dict.fromkeys((bundled_models or list(self.rules)) + list(self.rules)))
        CUSTOM_VEHICLE_PHOTOS.clear()
        for model, relative in self.settings.get('vehicle_photos', {}).items():
            safe_relative = _safe_custom_photo_relative(relative)
            if safe_relative:
                CUSTOM_VEHICLE_PHOTOS[model] = safe_relative
        for model, meta in self.settings.get('custom_vehicles', {}).items():
            safe_relative = _safe_custom_photo_relative(meta.get('photo_file', ''))
            if safe_relative:
                CUSTOM_VEHICLE_PHOTOS[model] = safe_relative

    def add_custom_vehicle(self):
        dialog = VehicleEditorDialog(self, is_new=True)
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.values()
        model = values['name']
        if any(existing.casefold() == model.casefold() for existing in self.all_models):
            QMessageBox.warning(self, 'Модель уже є', 'Така назва вже є в каталозі. Вибери існуючий рядок або введи іншу назву.')
            return
        try:
            photo_file = self._store_custom_photo(model, values['photo_path']) if values['photo_changed'] and values['photo_path'] else ''
            meta = {'category': values['category'], 'threshold': int(values['threshold']), 'photo_file': photo_file}
            custom = dict(self.settings.get('custom_vehicles', {}))
            custom[model] = meta
            self.settings['custom_vehicles'] = custom
            thresholds = dict(self.settings.get('model_thresholds', {}))
            thresholds[model] = int(values['threshold'])
            self.settings['model_thresholds'] = thresholds
            photos = dict(self.settings.get('vehicle_photos', {}))
            if photo_file:
                photos[model] = photo_file
            self.settings['vehicle_photos'] = photos
            selected = self._configured_selected_models()
            if values['active'] and model not in selected:
                selected.append(model)
            self.settings['selected_models'] = selected
            self.settings['config_version'] = 31
            self._write_settings()
            if photo_file:
                try:
                    SELECTED.parent.mkdir(parents=True, exist_ok=True)
                except Exception:
                    pass
            SELECTED.write_text('\n'.join(selected) + ('\n' if selected else ''), encoding='utf-8')
            self._sync_rules_and_models()
            self.refresh_catalog()
            self.refresh_vehicle_gallery()
            self.refresh_stats()
            self.logline(f'Додано власну модель: {model}; категорія {meta["category"]}; поріг -{meta["threshold"]}%; активний пошук: {"так" if values["active"] else "ні"}.')
        except Exception as exc:
            self.logline(f'Не вдалося додати власну модель: {type(exc).__name__}: {exc}')
            QMessageBox.critical(self, 'Помилка додавання', f'Модель не була повністю збережена: {type(exc).__name__}: {exc}')
            self._sync_rules_and_models()
            self.refresh_catalog()

    def edit_selected_vehicle(self):
        model, row = self._selected_catalog_model()
        if not model:
            return
        custom_vehicles = dict(self.settings.get('custom_vehicles', {}))
        is_custom = model in custom_vehicles
        custom_meta = custom_vehicles.get(model, {})
        category_widget = self.catalog_table.cellWidget(row, 3)
        threshold_widget = self.catalog_table.cellWidget(row, 4)
        photo_override = (custom_meta.get('photo_file') if is_custom else '') or self.settings.get('vehicle_photos', {}).get(model, '')
        safe_photo = _safe_custom_photo_relative(photo_override)
        current_override = (DATA / Path(*safe_photo.split('/'))) if safe_photo else None
        current_image, _ = vehicle_image_path(model)
        dialog = VehicleEditorDialog(
            self,
            name=model,
            category=category_widget.currentText(),
            threshold=threshold_widget.value(),
            photo_path=current_override if current_override and current_override.is_file() else None,
            preview_path=current_image,
            name_editable=is_custom,
            is_new=False,
        )
        if dialog.exec() != QDialog.Accepted:
            return
        values = dialog.values()
        new_model = values['name']
        if new_model.casefold() != model.casefold() and any(m.casefold() == new_model.casefold() for m in self.all_models if m != model):
            QMessageBox.warning(self, 'Модель уже є', 'Інша модель з такою назвою вже є в каталозі.')
            return
        if not is_custom and new_model != model:
            QMessageBox.warning(self, 'Назва захищена', 'Назви вбудованих моделей зберігаються відповідно до ігрового каталогу, щоб OCR не втратив зіставлення.')
            return
        try:
            if new_model != model:
                self._rename_custom_vehicle(model, new_model)
                model = new_model
                custom_vehicles = dict(self.settings.get('custom_vehicles', {}))
                # Keep the edited table row in sync with the renamed model before save_catalog()
                # reads UserRole; otherwise it would persist the old name back into settings.
                name_item = self.catalog_table.item(row, 2)
                name_item.setText(model)
                name_item.setData(Qt.UserRole, model)
                name_item.setData(Qt.UserRole + 1, True)
            if values['photo_changed']:
                photos = dict(self.settings.get('vehicle_photos', {}))
                if values['photo_path']:
                    relative = self._store_custom_photo(model, values['photo_path'])
                    photos[model] = relative
                    if model in custom_vehicles:
                        custom_vehicles[model]['photo_file'] = relative
                else:
                    photos.pop(model, None)
                    if model in custom_vehicles:
                        custom_vehicles[model]['photo_file'] = ''
                self.settings['vehicle_photos'] = photos
                self.settings['custom_vehicles'] = custom_vehicles
            if model in custom_vehicles:
                custom_vehicles[model]['category'] = values['category']
                custom_vehicles[model]['threshold'] = int(values['threshold'])
                self.settings['custom_vehicles'] = custom_vehicles
            cat_combo = self.catalog_table.cellWidget(row, 3)
            spin = self.catalog_table.cellWidget(row, 4)
            cat_combo.setCurrentText(values['category'])
            spin.setValue(int(values['threshold']))
            self.settings['config_version'] = 31
            self._sync_rules_and_models()
            self._write_settings()
            self.save_catalog()
            self.refresh_vehicle_gallery()
            self.logline(f'Оновлено дані моделі {model}: категорія {values["category"]}, поріг -{values["threshold"]}%.')
        except Exception as exc:
            self.logline(f'Не вдалося відредагувати модель: {type(exc).__name__}: {exc}')
            QMessageBox.critical(self, 'Помилка редагування', f'Зміни не завершено: {type(exc).__name__}: {exc}')
            self._sync_rules_and_models()
            self.refresh_catalog()

    def _rename_custom_vehicle(self, old_name, new_name):
        custom = dict(self.settings.get('custom_vehicles', {}))
        if old_name not in custom:
            raise ValueError('Перейменовувати через цей діалог можна лише власні моделі.')
        meta = dict(custom.pop(old_name))
        if new_name in custom or any(name.casefold() == new_name.casefold() for name in self.all_models if name != old_name):
            raise ValueError('Назва вже використовується іншою моделлю.')
        custom[new_name] = meta
        self.settings['custom_vehicles'] = custom
        for key in ('model_thresholds', 'category_overrides', 'vehicle_photos'):
            mapping = dict(self.settings.get(key, {}))
            if old_name in mapping:
                mapping[new_name] = mapping.pop(old_name)
            self.settings[key] = mapping
        selected = self.settings.get('selected_models')
        if isinstance(selected, list):
            self.settings['selected_models'] = [new_name if value == old_name else value for value in selected]
        self._sync_rules_and_models()
        self.settings['config_version'] = 31

    def delete_custom_vehicle(self):
        model, _row = self._selected_catalog_model()
        if not model:
            return
        custom = dict(self.settings.get('custom_vehicles', {}))
        if model not in custom:
            QMessageBox.information(self, 'Вбудована модель', 'Вбудовані моделі не видаляються. Для них можна змінювати вибір, категорію, поріг і фото.')
            return
        answer = QMessageBox.question(self, 'Видалити власну модель?',
                                      f'Прибрати «{model}» з каталогу та активного пошуку?')
        if answer != QMessageBox.Yes:
            return
        custom.pop(model, None)
        self.settings['custom_vehicles'] = custom
        for key in ('model_thresholds', 'category_overrides', 'vehicle_photos'):
            mapping = dict(self.settings.get(key, {})); mapping.pop(model, None); self.settings[key] = mapping
        selected = self._configured_selected_models()
        self.settings['selected_models'] = [value for value in selected if value != model]
        self.settings['config_version'] = 31
        try:
            self._write_settings()
            SELECTED.write_text('\n'.join(self.settings['selected_models']) + ('\n' if self.settings['selected_models'] else ''), encoding='utf-8')
            self._sync_rules_and_models()
            self.refresh_catalog()
            self.refresh_vehicle_gallery()
            self.refresh_stats()
            self.logline(f'Власну модель видалено з каталогу: {model}. Фотофайл залишено у папці custom на випадок відновлення.')
        except Exception as exc:
            QMessageBox.critical(self, 'Помилка видалення', f'Не вдалося видалити модель: {type(exc).__name__}: {exc}')

    def filter_catalog(self, *_):
        if not hasattr(self, 'catalog_table'):
            return
        query = self.catalog_search.text().strip().casefold()
        cat = self.catalog_filter.currentText()
        sort = self.catalog_sort.currentText() if hasattr(self, 'catalog_sort') else 'За назвою'
        row_keys = []
        for r in range(self.catalog_table.rowCount()):
            name_item = self.catalog_table.item(r, 2)
            model = name_item.text() if name_item else ''
            category_widget = self.catalog_table.cellWidget(r, 3)
            category = category_widget.currentText() if category_widget else 'Звичайне'
            is_custom = bool(name_item.data(Qt.UserRole + 1)) if name_item else False
            visible = (not query or query in model.casefold()) and (cat == 'Усі категорії' or category == cat)
            if sort == 'Власні авто' and not is_custom:
                visible = False
            self.catalog_table.setRowHidden(r, not visible)
            if visible:
                active = self.catalog_table.item(r, 0).checkState() == Qt.Checked
                row_keys.append((r, model.casefold(), active, is_custom))
        if sort == 'Спочатку активні':
            row_keys.sort(key=lambda x: (not x[2], x[1]))
        elif sort == 'Власні авто':
            row_keys.sort(key=lambda x: x[1])
        else:
            row_keys.sort(key=lambda x: x[1])
        self._catalog_visible_order = [r for r, _, _, _ in row_keys]
        self._schedule_catalog_grid_rebuild()

    def set_catalog_checks(self, checked):
        for r in range(self.catalog_table.rowCount()):
            self.catalog_table.item(r, 0).setCheckState(Qt.Checked if checked else Qt.Unchecked)
        self._schedule_catalog_grid_rebuild()

    def _default_threshold_for_category(self, model, category):
        """Default threshold for a row after choosing a category; individual values override it."""
        base = load_rules().get(model, {'category': 'Звичайне', 'threshold': 20})
        if category == BLACKLIST_CATEGORY:
            category = self.settings.get('category_overrides', {}).get(model, base.get('category', 'Звичайне'))
        if category == 'Пріоритетне':
            return int(base.get('threshold', 15)) if base.get('category') == 'Пріоритетне' else 15
        if category == 'Спеціальне':
            return int(base.get('threshold', 50)) if base.get('category') == 'Спеціальне' else 50
        return int(self.settings.get('threshold', 20))

    def _mark_catalog_threshold_manual(self, row):
        self._catalog_manual_thresholds.add(int(row))

    def _on_catalog_category_changed(self, row, new_category):
        """Category changes update the row's default threshold unless the user set it manually."""
        try:
            combo = self.catalog_table.cellWidget(row, 3)
            spin = self.catalog_table.cellWidget(row, 4)
            model = self.catalog_table.item(row, 2).text()
            previous = str(combo.property('previous_category') or 'Звичайне')
            old_default = self._default_threshold_for_category(model, previous)
            new_default = self._default_threshold_for_category(model, str(new_category))
            has_explicit_model_threshold = model in self.settings.get('model_thresholds', {})
            if (not has_explicit_model_threshold and int(row) not in self._catalog_manual_thresholds
                    and int(spin.value()) == old_default):
                spin.blockSignals(True)
                spin.setValue(new_default)
                spin.blockSignals(False)
            combo.setProperty('previous_category', str(new_category))
            self.filter_catalog()
            self._schedule_catalog_grid_rebuild()
        except Exception as exc:
            self.logline(f'Не вдалося оновити поріг після зміни категорії: {type(exc).__name__}: {exc}')

    def save_catalog(self):
        chosen, overrides, category_overrides = [], {}, {}
        base_rules = load_rules()
        for custom_model, custom_meta in self.settings.get('custom_vehicles', {}).items():
            base_rules[custom_model] = {'category': custom_meta.get('category', 'Звичайне'), 'threshold': int(custom_meta.get('threshold', 20))}
        try:
            known_keys = {norm(model) for model in self.all_models if norm(model)}
            existing_blacklist = read_lines(BLACKLIST)
            # Preserve entries that are not currently in the catalog (for example a model
            # temporarily removed from the game) while rebuilding known entries from UI.
            unknown_blacklist_entries = [line for line in existing_blacklist if norm(line) not in known_keys]
            blacklisted_models = set()

            for r in range(self.catalog_table.rowCount()):
                name_item = self.catalog_table.item(r, 2)
                model = str(name_item.data(Qt.UserRole) or name_item.text())
                displayed_category = self.catalog_table.cellWidget(r, 3).currentText()
                if self.catalog_table.item(r, 0).checkState() == Qt.Checked:
                    chosen.append(model)
                if displayed_category == BLACKLIST_CATEGORY:
                    blacklisted_models.add(model)
                    underlying_category = self.settings.get('category_overrides', {}).get(
                        model, base_rules.get(model, {}).get('category', 'Звичайне'))
                    if underlying_category not in ('Пріоритетне', 'Звичайне', 'Спеціальне'):
                        underlying_category = 'Звичайне'
                else:
                    underlying_category = displayed_category

                value = int(self.catalog_table.cellWidget(r, 4).value())
                baseline = self._default_threshold_for_category(model, underlying_category)
                if value != baseline or model in DEFAULT_MODEL_THRESHOLDS or model in self.settings.get('custom_vehicles', {}):
                    overrides[model] = value
                if model in self.settings.get('custom_vehicles', {}):
                    custom_meta = dict(self.settings['custom_vehicles'][model])
                    custom_meta['category'] = underlying_category
                    custom_meta['threshold'] = value
                    self.settings['custom_vehicles'][model] = custom_meta
                if underlying_category != base_rules.get(model, {}).get('category', 'Звичайне'):
                    category_overrides[model] = underlying_category

            self.settings['selected_models'] = chosen
            self.settings['model_thresholds'] = overrides
            self.settings['category_overrides'] = category_overrides
            self.settings['config_version'] = 31
            blacklist_entries = normalize_blacklist_entries(
                unknown_blacklist_entries + [model for model in self.all_models if model in blacklisted_models],
                self.all_models,
            )
            self._write_lines_atomic(BLACKLIST, blacklist_entries)
            self._write_settings()
            SELECTED.write_text('\n'.join(chosen) + ('\n' if chosen else ''), encoding='utf-8')
            self._sync_rules_and_models()
            self._catalog_built_signature = None
            self.refresh_catalog(force=True)
            self.logline(f'Каталог збережено: активних моделей {len(chosen)}; чорний список {len(load_blacklist_models(self.all_models))}; індивідуальних порогів {len(overrides)}; змін категорій {len(category_overrides)}.')
            QMessageBox.information(self, 'Каталог збережено', f'Активних моделей: {len(chosen)}\nЧорний список: {len(load_blacklist_models(self.all_models))}\nІндивідуальних порогів: {len(overrides)}\nЗмін категорій: {len(category_overrides)}')
        except Exception as e:
            QMessageBox.critical(self, 'Помилка збереження', f'Не вдалося зберегти каталог: {e}')

    def _write_settings(self):
        payload = json.dumps(self.settings, ensure_ascii=False, indent=2) + '\n'
        temporary = CONFIG.with_suffix(CONFIG.suffix + '.tmp')
        temporary.write_text(payload, encoding='utf-8')
        temporary.replace(CONFIG)

    @staticmethod
    def _write_lines_atomic(path, lines):
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        payload = '\n'.join(str(value).strip() for value in lines if str(value).strip())
        if payload:
            payload += '\n'
        temporary = path.with_suffix(path.suffix + '.tmp')
        temporary.write_text(payload, encoding='utf-8')
        temporary.replace(path)

    def save_all_settings(self):
        try:
            self.settings['threshold'] = int(self.set_threshold.currentText().strip('-%'))
            self.settings['interval_ms'] = INTERVALS[self.set_interval.currentText()]
            self.settings['click_delay_ms'] = CLICK_SPEEDS[self.click_speed_combo.currentText()]
            profile_label = self.resolution_profile_combo.currentText()
            self.settings['resolution_profile'] = RESOLUTION_PROFILES.get(profile_label, 'auto')
            self._pending_resolution_profile = self.settings['resolution_profile']
            self.settings['animations_enabled'] = bool(self.animations_check.isChecked())
            self.settings['auto_click'] = self.auto_click_check.isChecked()
            self.settings['auto_confirm'] = bool(self.settings['auto_click'] and self.auto_confirm_check.isChecked())
            self.settings['fast_color_filter_enabled'] = True
            self.settings['blacklist_protection_enabled'] = self.blacklist_protection_check.isChecked()
            self.settings['confidence_protection_enabled'] = self.confidence_protection_check.isChecked()
            self.settings['continue_after_purchase'] = bool(self.continue_after_purchase_check.isChecked())
            self.settings['auto_refresh_enabled'] = bool(self.auto_refresh_check.isChecked())
            self.settings['auto_refresh_interval_min'] = max(1, min(10, int(self.auto_refresh_interval_combo.currentText().split()[0])))
            self.settings['config_version'] = 31
            grid = self.settings.setdefault('grid', {})
            for key, spin in self.grid_spins.items(): grid[key] = round(spin.value()/100.0, 4)
            if not (grid['left'] < grid['right'] and grid['top'] < grid['bottom']):
                raise ValueError('Ліва межа має бути меншою за праву, а верхня — за нижню.')
            blacklist_entries = normalize_blacklist_entries(
                self.blacklist_editor.toPlainText().splitlines() if hasattr(self, 'blacklist_editor') else read_lines(BLACKLIST),
                self.all_models,
            )
            self._write_lines_atomic(BLACKLIST, blacklist_entries)
            self._write_settings()
            self._sync_auto_refresh_schedule(reset=True)
            self.threshold.setCurrentText(f"-{self.settings['threshold']}%")
            self.interval.setCurrentText(self.interval_text())
            self._refresh_safe_note()
            self._sync_resolution_profile_controls()
            self._catalog_built_signature = None
            if hasattr(self, 'catalog_table'):
                self.refresh_catalog(force=True)
            self.logline(f'Налаштування збережено. Чорний список: {len(load_blacklist_models(self.all_models))} моделей; зміни застосовано. Масштаб інтерфейсу: {RESOLUTION_PROFILE_LABELS.get(self.settings["resolution_profile"], RESOLUTION_PROFILE_LABELS["auto"])}; повне масштабування нового профілю застосовується після перезапуску.')
        except Exception as e:
            QMessageBox.warning(self, 'Перевір налаштування', str(e))

    def save_settings(self):
        try:
            self.settings['threshold'] = int(self.threshold.currentText().strip('-%'))
            self.settings['interval_ms'] = INTERVALS[self.interval.currentText()]
            self.settings['resolution_profile'] = RESOLUTION_PROFILES.get(self.scan_resolution_combo.currentText(), 'auto')
            self._pending_resolution_profile = self.settings['resolution_profile']
            self.settings['animations_enabled'] = bool(self.animations_check.isChecked())
            self.settings['config_version'] = 31
            self._write_settings()
            if hasattr(self, 'set_threshold'): self.set_threshold.setCurrentText(f"-{self.settings['threshold']}%")
            if hasattr(self, 'set_interval'): self.set_interval.setCurrentText(self.interval_text())
            self._sync_resolution_profile_controls()
            self.logline(f'Налаштування збережено. Масштаб інтерфейсу: {RESOLUTION_PROFILE_LABELS.get(self.settings["resolution_profile"], RESOLUTION_PROFILE_LABELS["auto"])}; повне масштабування нового профілю застосовується після перезапуску.')
        except Exception as e:
            QMessageBox.warning(self, 'Помилка', f'Не вдалося зберегти налаштування: {e}')

    def reset_grid(self):
        defaults = DEFAULTS['grid']
        for key, spin in self.grid_spins.items(): spin.setValue(float(defaults[key])*100)

    @staticmethod
    def _foreground_window_handle():
        if os.name != 'nt':
            return None
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            user32.GetForegroundWindow.restype = wintypes.HWND
            return int(user32.GetForegroundWindow() or 0)
        except Exception:
            return 0

    def _foreground_matches_game_target(self, target_hwnd=None, foreground_hwnd=None):
        """Accept the target game HWND, owned modal/root windows, or another HWND in the same process.

        Purchase/confirmation transitions can temporarily expose an owned window with a
        different HWND. Treating only exact HWND equality as the game loses the resume gate
        even though the foreground still belongs to the same game process. This never
        treats the scanner or an unrelated application as the game.
        """
        target = target_hwnd or getattr(self, '_scan_target_hwnd', None)
        if target in (None, 0):
            return True
        if os.name != 'nt':
            return True
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            target = int(target)
            foreground = int(foreground_hwnd if foreground_hwnd is not None
                             else (user32.GetForegroundWindow() or 0))
            if foreground <= 0 or target <= 0:
                return False
            if foreground == target:
                return True
            if not user32.IsWindow(wintypes.HWND(target)) or not user32.IsWindow(wintypes.HWND(foreground)):
                return False

            user32.GetAncestor.argtypes = [wintypes.HWND, ctypes.c_uint]
            user32.GetAncestor.restype = wintypes.HWND
            # GA_ROOTOWNER=3 also handles owned dialogs attached to the game window.
            target_root = int(user32.GetAncestor(wintypes.HWND(target), 3) or 0)
            foreground_root = int(user32.GetAncestor(wintypes.HWND(foreground), 3) or 0)
            if target_root and foreground_root and target_root == foreground_root:
                return True

            user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
            user32.GetWindowThreadProcessId.restype = wintypes.DWORD
            target_pid = wintypes.DWORD()
            foreground_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(wintypes.HWND(target), ctypes.byref(target_pid))
            user32.GetWindowThreadProcessId(wintypes.HWND(foreground), ctypes.byref(foreground_pid))
            return bool(target_pid.value and target_pid.value == foreground_pid.value)
        except Exception:
            return False

    def _restore_game_focus_for_resume_if_safe(self, target_hwnd):
        """Recover the game only if the scanner itself is foreground; never steal focus from another app."""
        if os.name != 'nt' or target_hwnd in (None, 0):
            return False
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            foreground = int(user32.GetForegroundWindow() or 0)
            if foreground <= 0 or not user32.IsWindow(wintypes.HWND(int(target_hwnd))):
                return False
            foreground_pid = wintypes.DWORD()
            user32.GetWindowThreadProcessId(wintypes.HWND(foreground), ctypes.byref(foreground_pid))
            # If an unrelated application owns foreground, user intent takes priority.
            if int(foreground_pid.value or 0) != os.getpid():
                return False
            actions = load_external_action_core()
            activated = bool(actions.PurchaseWorker._activate_target_window(int(target_hwnd)))
            return activated and self._foreground_matches_game_target(int(target_hwnd))
        except Exception as exc:
            self.logline(f'RESUME FOCUS RECOVERY: безпечне відновлення фокуса не вдалося: {type(exc).__name__}: {exc}.')
            return False

    def _action_worker_is_running(self):
        """Safely test whether the click QThread is still alive, including its final unwind."""
        worker = getattr(self, 'action_worker', None)
        if worker is None:
            return False
        try:
            return bool(worker.isRunning())
        except RuntimeError:
            return False

    def _auto_refresh_interval_ms(self):
        try:
            minutes = int(self.settings.get('auto_refresh_interval_min', 5) or 5)
        except (TypeError, ValueError):
            minutes = 5
        return max(1, min(10, minutes)) * 60 * 1000

    def _sync_auto_refresh_schedule(self, reset=False, retry_ms=None):
        """Arm a single-shot timer only for an active continuous session."""
        timer = getattr(self, 'auto_refresh_timer', None)
        if timer is None:
            return
        if not self.settings.get('auto_refresh_enabled', False):
            timer.stop()
            self._auto_refresh_pending = False
            if self._auto_refresh_in_progress:
                self._abort_auto_refresh_sequence('автооновлення вимкнено в налаштуваннях')
            return
        if not self._continuous_scan_requested:
            timer.stop()
            self._auto_refresh_pending = False
            return
        if self._auto_refresh_in_progress:
            timer.stop()
            return
        if reset or retry_ms is not None or not timer.isActive():
            timer.stop()
            timer.start(max(250, int(retry_ms)) if retry_ms is not None else self._auto_refresh_interval_ms())

    def _auto_refresh_worker_active(self):
        try:
            scan_active = bool(self.worker and self.worker.isRunning())
        except RuntimeError:
            scan_active = False
        try:
            badge_active = bool(self.green_badge_worker and self.green_badge_worker.isRunning())
        except RuntimeError:
            badge_active = False
        return bool(scan_active or badge_active or self.busy or self._scan_request_active or self.pending_scan is not None)

    def _on_auto_refresh_timeout(self):
        """Defer refresh until a safe gap; never race OCR or the purchase worker."""
        if not self.settings.get('auto_refresh_enabled', False) or not self._continuous_scan_requested:
            self._auto_refresh_pending = False
            return
        if self._auto_refresh_in_progress:
            return
        if self.action_in_progress or self._action_worker_is_running():
            # The purchase worker owns the game UI. Retry after it and the return gate finish.
            self._sync_auto_refresh_schedule(retry_ms=1000)
            return
        self._auto_refresh_pending = True
        self.once_btn.setEnabled(False)
        if self._auto_refresh_worker_active():
            # _finalize_scan_worker_finished starts the refresh before scheduling another OCR cycle.
            self.once_btn.setEnabled(False)
            return
        self._try_start_pending_auto_refresh()

    def _try_start_pending_auto_refresh(self):
        if not self._auto_refresh_pending:
            return
        if not self.settings.get('auto_refresh_enabled', False) or not self._continuous_scan_requested:
            self._auto_refresh_pending = False
            return
        if self._auto_refresh_in_progress:
            return
        if self.action_in_progress or self._action_worker_is_running():
            self._sync_auto_refresh_schedule(retry_ms=1000)
            return
        if not self.running:
            # Purchase-return gate may still be restoring the listing page.
            self._sync_auto_refresh_schedule(retry_ms=1000)
            return
        if self._auto_refresh_worker_active():
            return
        if os.name != 'nt':
            self._auto_refresh_pending = False
            self.once_btn.setEnabled(True)
            self.logline('AUTO-REFRESH пропущено: автоматичне керування клавішами доступне лише у Windows.')
            self._sync_auto_refresh_schedule(reset=True)
            self.timer.start(0)
            return

        target = getattr(self, '_scan_target_hwnd', None)
        if target in (None, 0, '0'):
            reason = 'цільове вікно гри ще не визначене'
            self._defer_auto_refresh(reason, retry_ms=5000)
            return
        target = int(target)
        if not self._foreground_matches_game_target(target):
            self._defer_auto_refresh('гра не на передньому плані', retry_ms=5000)
            return

        # Require visual evidence that the 3x5 marketplace grid is currently shown.
        # A stale-but-visible market still qualifies; a tablet, details page, or modal does not.
        try:
            core = load_external_scan_core()
            probe = core.probe_market_return_state(
                dict(self.settings.get('grid') or {}), target_hwnd=target)
        except Exception as exc:
            probe = {'state': 'unknown', 'reason': f'{type(exc).__name__}: {exc}'}
        state = str((probe or {}).get('state') or 'unknown')
        if state != 'market':
            self._defer_auto_refresh(f'сітка «Транспорт» не підтверджена (state={state})', retry_ms=5000)
            return

        self._auto_refresh_wait_reason = ''
        self._auto_refresh_pending = False
        self._auto_refresh_in_progress = True
        self._auto_refresh_target_hwnd = target
        self._auto_refresh_screen_size = tuple(self._physical_screen_size())
        self._auto_refresh_sequence_id += 1
        sequence_id = self._auto_refresh_sequence_id
        self.timer.stop()
        self.once_btn.setEnabled(False)
        self.state.setText('● АВТООНОВЛЕННЯ РИНКУ…')
        self.logline(
            f'AUTO-REFRESH: починаю цикл ESC → ↓ → розблокування планшета → Маркет → Транспорт; '
            f'інтервал {self.settings.get("auto_refresh_interval_min", 5)} хв. '
            'Сканування призупинене до повторного підтвердження сітки.'
        )
        self._auto_refresh_run_step(
            sequence_id, 'ESC', lambda: self._auto_refresh_send_key(sequence_id, 0x1B), 400,
            self._auto_refresh_open_tablet)

    def _defer_auto_refresh(self, reason, retry_ms=5000):
        self._auto_refresh_pending = True
        self.once_btn.setEnabled(False)
        if reason != self._auto_refresh_wait_reason:
            self.logline(f'AUTO-REFRESH очікує: {reason}; кліки не виконуються, перевірка повториться пізніше.')
            self._auto_refresh_wait_reason = reason
        self._sync_auto_refresh_schedule(retry_ms=retry_ms)

    def _auto_refresh_context_is_safe(self, sequence_id):
        if (sequence_id != self._auto_refresh_sequence_id or not self._auto_refresh_in_progress
                or not self.running or not self._continuous_scan_requested):
            return False
        target = self._auto_refresh_target_hwnd
        if target in (None, 0) or not self._foreground_matches_game_target(target):
            return False
        size = tuple(self._physical_screen_size())
        return size == tuple(self._auto_refresh_screen_size or ()) and size[0] > 0 and size[1] > 0

    def _auto_refresh_send_key(self, sequence_id, virtual_key):
        """Send a scan-code key tap with a brief hold so games can poll it."""
        if not self._auto_refresh_context_is_safe(sequence_id):
            return False
        try:
            import ctypes
            from ctypes import wintypes

            class KEYBDINPUT(ctypes.Structure):
                _fields_ = [
                    ("wVk", wintypes.WORD), ("wScan", wintypes.WORD),
                    ("dwFlags", wintypes.DWORD), ("time", wintypes.DWORD),
                    ("dwExtraInfo", ctypes.c_size_t),
                ]

            class MOUSEINPUT(ctypes.Structure):
                _fields_ = [
                    ("dx", wintypes.LONG), ("dy", wintypes.LONG),
                    ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                    ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t),
                ]

            class HARDWAREINPUT(ctypes.Structure):
                _fields_ = [("uMsg", wintypes.DWORD), ("wParamL", wintypes.WORD), ("wParamH", wintypes.WORD)]

            class INPUTUNION(ctypes.Union):
                _fields_ = [("ki", KEYBDINPUT), ("mi", MOUSEINPUT), ("hi", HARDWAREINPUT)]

            class INPUT(ctypes.Structure):
                _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]

            user32 = ctypes.windll.user32
            user32.MapVirtualKeyW.argtypes = [wintypes.UINT, wintypes.UINT]
            user32.MapVirtualKeyW.restype = wintypes.UINT
            user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
            user32.SendInput.restype = wintypes.UINT

            vk = int(virtual_key)
            scan = int(user32.MapVirtualKeyW(vk, 0)) & 0xFF  # MAPVK_VK_TO_VSC
            if not scan:
                self.logline(f'AUTO-REFRESH: для клавіші VK=0x{vk:02X} не знайдений скан-код.')
                return False

            # KEYEVENTF_SCANCODE is preferred for games; arrow keys are extended keys.
            key_flags = 0x0008  # KEYEVENTF_SCANCODE
            if vk in (0x25, 0x26, 0x27, 0x28):
                key_flags |= 0x0001  # KEYEVENTF_EXTENDEDKEY

            def send_key_event(flags):
                event = INPUT()
                event.type = 1  # INPUT_KEYBOARD
                event.union.ki = KEYBDINPUT(0, scan, flags, 0, 0)
                return int(user32.SendInput(1, ctypes.byref(event), ctypes.sizeof(INPUT))) == 1

            if not send_key_event(key_flags):
                self.logline(f'AUTO-REFRESH: SendInput не прийняв натискання клавіші VK=0x{vk:02X}, scan=0x{scan:02X}.')
                return False
            # Keep the key down long enough for the game input poll; always attempt key-up.
            time.sleep(0.065)
            key_up_sent = send_key_event(key_flags | 0x0002)  # KEYEVENTF_KEYUP
            if not key_up_sent:
                self.logline(f'AUTO-REFRESH: SendInput не прийняв відпускання клавіші VK=0x{vk:02X}.')
                return False
            self.logline(f'AUTO-REFRESH: клавіша VK=0x{vk:02X} надіслана як scan=0x{scan:02X}, утримання 65 мс.')
            return self._auto_refresh_context_is_safe(sequence_id)
        except Exception as exc:
            self.logline(f'AUTO-REFRESH: не вдалося надіслати клавішу 0x{int(virtual_key):02X}: {type(exc).__name__}: {exc}.')
            return False

    def _auto_refresh_click_fraction(self, sequence_id, x_fraction, y_fraction):
        if not self._auto_refresh_context_is_safe(sequence_id):
            return False
        try:
            import ctypes
            width, height = self._auto_refresh_screen_size
            x = max(0, min(width - 1, int(round(width * float(x_fraction)))) )
            y = max(0, min(height - 1, int(round(height * float(y_fraction)))) )
            user32 = ctypes.windll.user32
            user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
            user32.SetCursorPos.restype = ctypes.c_bool
            if not user32.SetCursorPos(x, y):
                return False
            if not self._auto_refresh_context_is_safe(sequence_id):
                return False
            actions = load_external_action_core()
            sent = bool(actions.PurchaseWorker._send_atomic_left_click())
            return sent and self._auto_refresh_context_is_safe(sequence_id)
        except Exception as exc:
            self.logline(f'AUTO-REFRESH: помилка кліку: {type(exc).__name__}: {exc}.')
            return False

    def _auto_refresh_run_step(self, sequence_id, label, action, delay_ms, next_step):
        if not self._auto_refresh_context_is_safe(sequence_id):
            self._abort_auto_refresh_sequence('змінився фокус гри або розмір екрана; послідовність перервана для безпеки')
            return
        try:
            sent = bool(action())
        except Exception as exc:
            self.logline(f'AUTO-REFRESH: крок «{label}» завершився помилкою {type(exc).__name__}: {exc}.')
            sent = False
        if not sent:
            self._abort_auto_refresh_sequence(f'крок «{label}» не вдалося безпечно виконати; повторні кліки не надсилалися')
            return
        self.logline(f'AUTO-REFRESH: крок «{label}» виконано.')
        QTimer.singleShot(max(100, int(delay_ms)),
                          lambda seq=sequence_id, step=next_step: step(seq))

    def _auto_refresh_open_tablet(self, sequence_id):
        self._auto_refresh_run_step(
            sequence_id, 'стрілка вниз — відкрити планшет',
            lambda: self._auto_refresh_send_key(sequence_id, 0x28), 600,
            self._auto_refresh_unlock_tablet)

    def _auto_refresh_unlock_tablet(self, sequence_id):
        self._auto_refresh_run_step(
            sequence_id, 'клік по екрану блокування',
            lambda: self._auto_refresh_click_fraction(sequence_id, 0.50, 0.50), 500,
            self._auto_refresh_open_market)

    def _auto_refresh_open_market(self, sequence_id):
        # Coordinates are normalized to the active physical screen, so Full HD and 2K use the same path.
        self._auto_refresh_run_step(
            sequence_id, 'відкрити застосунок «Маркет»',
            lambda: self._auto_refresh_click_fraction(sequence_id, 0.300, 0.255), 1100,
            self._auto_refresh_select_transport)

    def _auto_refresh_select_transport(self, sequence_id):
        self._auto_refresh_run_step(
            sequence_id, 'вибрати «Транспорт» у лівому меню',
            lambda: self._auto_refresh_click_fraction(sequence_id, 0.040, 0.178), 1200,
            self._auto_refresh_begin_market_gate)

    def _auto_refresh_begin_market_gate(self, sequence_id):
        if not self._auto_refresh_context_is_safe(sequence_id):
            self._abort_auto_refresh_sequence('після навігації втрачено фокус гри або змінився екран')
            return
        self._resume_scan_after_action = True
        self._resume_scan_not_before = time.monotonic()
        self._resume_focus_recovery_attempted = False
        self._resume_market_wait_started = 0.0
        self._resume_market_good_frames = 0
        self._resume_market_good_since = None
        self._resume_market_last_frame_token = None
        self._resume_market_last_state_logged = ''
        self._resume_market_back_attempted = False
        self._resume_market_cancel_attempts = 0
        self._resume_market_cancel_last_attempt_at = 0.0
        self._resume_market_confirm_started_at = 0.0
        self._resume_market_confirm_good_frames = 0
        self._resume_market_confirm_last_frame_token = None
        self._resume_after_purchase_navigation = False
        self._resume_market_screen_size = tuple(self._auto_refresh_screen_size or self._physical_screen_size())
        self._resume_market_target_hwnd = self._auto_refresh_target_hwnd
        self.logline('AUTO-REFRESH: навігацію завершено; перевіряю свіжими кадрами, що каталог «Транспорт» повернувся. OCR поки не запускається.')
        QTimer.singleShot(500, self._resume_continuous_scan_after_action)

    def _abort_auto_refresh_sequence(self, reason):
        """Fail closed if a mid-sequence click could have left the game on an unknown screen."""
        if not self._auto_refresh_in_progress:
            return
        self._auto_refresh_sequence_id += 1
        self._auto_refresh_in_progress = False
        self._auto_refresh_pending = False
        self._auto_refresh_target_hwnd = None
        self._auto_refresh_screen_size = None
        self._auto_refresh_wait_reason = ''
        self._resume_scan_after_action = False
        self._resume_market_target_hwnd = None
        self._resume_market_wait_started = 0.0
        self._continuous_scan_requested = False
        self.running = False
        self.timer.stop()
        self.auto_refresh_timer.stop()
        self._set_start_button('start')
        self.start_btn.setEnabled(True)
        self.once_btn.setEnabled(True)
        self.state.setText('● АВТООНОВЛЕННЯ ПЕРЕРВАНО')
        if self.capture_hidden:
            self.capture_hidden = False
            self.showNormal()  # Do not raise/activate over an unrelated foreground application.
        self._refresh_live_monitor()
        self.logline(f'AUTO-REFRESH ПЕРЕРВАНО: {reason}. Сканер зупинено, щоб не читати невідомий екран; повернись у ринок «Транспорт» і натисни START.')

    def _on_scan_timer(self):
        """Dispatch only while the game remains foreground; never OCR the scanner/log window."""
        if not self.running or self._auto_refresh_in_progress:
            return
        if os.name == 'nt' and self._scan_target_hwnd is not None:
            try:
                import ctypes
                if not ctypes.windll.user32.IsWindow(int(self._scan_target_hwnd)):
                    self._scan_target_hwnd = None
            except Exception:
                self._scan_target_hwnd = None
        if (os.name == 'nt' and self._scan_target_hwnd is not None
                and not self._foreground_matches_game_target(self._scan_target_hwnd)):
            self.state.setText('● ОЧІКУЄ НА ГРУ')
            if not self._waiting_for_game_logged:
                self.logline('Сканування призупинено для безпеки: активне не вікно гри. Повернись у гру — сканер продовжить автоматично.')
                self._waiting_for_game_logged = True
            self.timer.start(max(20, int(self.settings.get('interval_ms', 20) or 20)))
            return
        self._waiting_for_game_logged = False
        # Defensive guard for stale/duplicate timer events. Do not add a log line here:
        # timer callbacks can be frequent, and a guard must remain silent.
        worker_active = False
        try:
            worker_active = bool(self.worker and self.worker.isRunning())
        except RuntimeError:
            worker_active = False
        if self.busy or self._scan_request_active or self.action_in_progress or worker_active or self._action_worker_is_running():
            return
        self.scan_once(hide_window=None)

    def _on_scan_worker_finished(self):
        """Release the single-flight latch only after OCR's QThread has actually stopped."""
        # QThread emits result before it exits; defer finalization so the queued result
        # handler can update state before another interval is scheduled.
        self._scan_finish_waits = 0
        QTimer.singleShot(0, self._finalize_scan_worker_finished)

    def _finalize_scan_worker_finished(self):
        worker = self.worker
        try:
            if worker and worker.isRunning():
                # finished signals should mean the thread has stopped; if Qt still reports
                # it active, check again shortly without creating another OCR worker.
                QTimer.singleShot(1, self._finalize_scan_worker_finished)
                return
        except RuntimeError:
            pass

        if self.busy and not self._scan_result_received and self._scan_finish_waits < 5:
            self._scan_finish_waits += 1
            QTimer.singleShot(1, self._finalize_scan_worker_finished)
            return

        self._scan_request_active = False
        self.worker = None
        if self.busy:
            # A worker that terminated without delivering its result must not leave the
            # scanner in a permanently busy state or silently start another cycle.
            self.busy = False
            self._continuous_scan_requested = False
            self.running = False
            self.timer.stop()
            self.auto_refresh_timer.stop()
            self._auto_refresh_pending = False
            self.once_btn.setEnabled(True)
            self.start_btn.setEnabled(True)
            self._set_start_button('start')
            self.state.setText('● ПОМИЛКА')
            self._restore_capture_window()
            self._scan_target_hwnd = None
            self._waiting_for_game_logged = False
            self.logline('OCR-потік завершився без результату. Безперервне сканування зупинено, щоб уникнути повторних запусків.')
            return

        if self._auto_refresh_pending and self.running and self._continuous_scan_requested and not self.action_in_progress:
            # A due refresh takes the next safe gap before another OCR cycle starts.
            QTimer.singleShot(0, self._try_start_pending_auto_refresh)
            return

        if self.running and not self.action_in_progress and not self._auto_refresh_in_progress and not self.timer.isActive():
            # Fast color-first cadence (default 20 ms). If OCR takes longer than
            # the chosen interval, the next cycle starts immediately; workers never overlap.
            cycle_started = self._scan_cycle_started_at
            target_interval_ms = max(20, int(self.settings.get('interval_ms', 20) or 20))
            if cycle_started is None:
                delay_ms = 0
            else:
                elapsed_ms = (time.perf_counter() - cycle_started) * 1000.0
                delay_ms = max(0, int(target_interval_ms - elapsed_ms))
            self.timer.start(delay_ms)

    def _poll_global_stop_hotkey(self):
        """Ctrl+Alt+F8 is a global stop that still works while the window is minimized."""
        if os.name != 'nt':
            return
        try:
            import ctypes
            user32 = ctypes.windll.user32
            ctrl = bool(user32.GetAsyncKeyState(0x11) & 0x8000)
            alt = bool(user32.GetAsyncKeyState(0x12) & 0x8000)
            f8 = bool(user32.GetAsyncKeyState(0x77) & 0x8000)
            down = ctrl and alt and f8
            if down and not self._stop_hotkey_latched:
                self.logline('Глобальна команда СТОП: Ctrl+Alt+F8.')
                self.stop_scanning()
            self._stop_hotkey_latched = down
        except Exception:
            # Keyboard polling is a convenience only; the normal Stop button remains authoritative.
            return

    def _restore_capture_window(self):
        if self.capture_hidden:
            self.capture_hidden = False
            self.showNormal()
            self.raise_()
            self.activateWindow()

    def stop_scanning(self):
        """Stop timers, OCR, and any in-progress click workflow without scheduling another cycle."""
        was_active = bool(self.running or self.busy or self.pending_scan is not None or self.action_in_progress or self._auto_refresh_in_progress)
        # Explicit STOP overrides any deferred auto-resume after purchase and invalidates every queued refresh step.
        self._auto_refresh_sequence_id += 1
        self.auto_refresh_timer.stop()
        self._auto_refresh_in_progress = False
        self._auto_refresh_pending = False
        self._auto_refresh_target_hwnd = None
        self._auto_refresh_screen_size = None
        self._auto_refresh_wait_reason = ''
        self._continuous_scan_requested = False
        self._resume_scan_after_action = False
        self._resume_focus_recovery_attempted = False
        self._resume_market_target_hwnd = None
        self.running = False
        self.timer.stop()
        self._green_watch_mode = False
        self._green_resume_pending = False
        if self.green_badge_worker is not None and self.green_badge_worker.isRunning():
            try: self.green_badge_worker.cancel()
            except Exception: pass
        if self.green_watch_worker is not None and self.green_watch_worker.isRunning():
            try: self.green_watch_worker.cancel()
            except Exception: pass
        if self.pending_scan is not None:
            self.pending_scan = None
            self.busy = False
            self._scan_request_active = False
            self.once_btn.setEnabled(True)
        if self.worker and self.worker.isRunning():
            try:
                self.worker.cancel()
            except Exception:
                pass
        if self.action_worker and self.action_worker.isRunning():
            try:
                self.action_worker.cancel()
            except Exception:
                pass
            self.state.setText('● ЗУПИНЯЄТЬСЯ')
            self._set_start_button('start')
            self.logline('Команда СТОП передана автодії; поточний клік/очікування буде скасовано.')
            return
        self._set_start_button('start')
        if self.worker and self.worker.isRunning():
            self.state.setText('● ЗУПИНЯЄТЬСЯ')
            self.logline('Команду СТОП передано OCR. Поточна операція припиниться між картками.')
            return
        self.state.setText('● ЗУПИНЕНО' if was_active else '● ГОТОВИЙ')
        self.once_btn.setEnabled(True)
        self._refresh_live_monitor()
        self._restore_capture_window()
        self._scan_target_hwnd = None
        self._waiting_for_game_logged = False
        if was_active:
            self.logline('Сканування зупинено; наступний цикл не буде запущений.')

    def toggle_scanning(self):
        active_worker = bool(self.worker and self.worker.isRunning())
        watcher_active = bool(self.green_watch_worker and self.green_watch_worker.isRunning())
        if self.running or self.action_in_progress or self._action_worker_is_running() or active_worker or watcher_active or self.pending_scan is not None:
            self.stop_scanning()
            return
        if self.busy:
            self.logline('Попередній цикл ще закривається. Дочекайся його результату перед новим запуском.')
            return
        self.save_settings()
        self._continuous_scan_requested = True
        self.running = True
        self._sync_auto_refresh_schedule(reset=True)
        self._set_start_button('stop')
        self.state.setText('● СКАНУЄ')
        self._refresh_live_monitor()
        self.timer.stop()
        if self.settings.get('auto_click', False) and self.settings.get('auto_confirm', False):
            # v1.2.66: preflight the offer while it is still on the market grid.
            # ScanWorker's GREEN fast lane reads the badge first, then only the candidate's
            # title/price; it emits only after model selection, blacklist, price, discount
            # tolerance, and per-model threshold are confirmed. The purchase worker then
            # opens the card once and deliberately skips detail-page OCR, which previously
            # caused repeated open -> reject -> back cycles and left the market stale.
            self._green_watch_mode = False
            self.logline(
                f'FAST GRID BUY {EXPECTED_MARKET_PREFLIGHT_PATCH_VERSION}: '
                'перевірка кандидата виконується до входу в картку; після входу — '
                'лише кнопки покупки/підтвердження, без повторного OCR деталей. '
                'Після FINAL_CONFIRM серверна відповідь не перевіряється; після кліків автосканування чекатиме на фактичне повернення сітки 3×5, потім перечитає актуальні координати.'
            )
            self.scan_once(hide_window=None)
            return
        self.logline(f'Безперервне сканування запущено: інтервал {int(self.settings.get("interval_ms", 20) or 20)} мс, без накладання OCR-потоків; якщо цикл довший — наступний стартує одразу після завершення. Журнал показує картки, ціни, знижки й зміни.')
        # Ordinary/manual path uses the same grid-first scanner. Auto-click mode enables
        # ScanWorker's existing fast candidate lane via fast_candidate_mode in _launch_scan_worker.
        self._green_watch_mode = False
        self.scan_once(hide_window=None)

    def scan_once(self, hide_window=None):
        worker_active = False
        try:
            worker_active = bool(self.worker and self.worker.isRunning())
        except RuntimeError:
            worker_active = False
        if (self.busy or self._scan_request_active or self.action_in_progress
                or self._action_worker_is_running() or self.pending_scan is not None or worker_active
                or self._auto_refresh_in_progress or self._auto_refresh_pending):
            return
        self.timer.stop()
        catalog_models = [m for m in self.all_models if m]
        blacklist = (load_blacklist_models(catalog_models)
                     if self.settings.get('blacklist_protection_enabled', True) else set())
        configured = self.settings.get('selected_models')
        if isinstance(configured, list):
            selected = list(configured)
        elif SELECTED.exists():
            selected = read_lines(SELECTED)
        else:
            selected = list(catalog_models)
        selected = ['Bravado Charger Redeye' if m == 'Bravado Charger Redeve' else m for m in selected]
        active_models = set(selected) - blacklist
        if hide_window is None:
            # Desktop OCR captures the whole primary monitor. If this UI is on that
            # monitor, minimize it for every scan (even with auto-click OFF), so the
            # scanner cannot OCR its own table/logs in place of the market.
            hide_window = bool(self.screen() == QApplication.primaryScreen())
        self._scan_request_active = True
        self._scan_result_received = False
        self.busy = True
        self.once_btn.setEnabled(False)
        self.start_btn.setEnabled(True)
        self._set_start_button('stop' if self.running else 'analyze')
        self.state.setText('● АНАЛІЗ' if not self.running else '● СКАНУЄ')
        self.pending_scan = (
            catalog_models,
            int(self.threshold.currentText().strip('-%')),
            dict(self.settings.get('model_thresholds', {})),
            json.loads(json.dumps(self.settings['grid'])),
            active_models,
            blacklist,
            {k: dict(v) for k, v in self.rules.items()},
        )
        # Avoid flooding the log during continuous polling; log manual one-shot scans only.
        if not self.running:
            self.logline('Запущено разове сканування 15 карток у сітці 3×5.')
        if hide_window and self.isVisible():
            already_minimized = self.isMinimized()
            self.capture_hidden = True
            self.showMinimized()
            QTimer.singleShot(0 if already_minimized else 250, self._launch_scan_worker)
        else:
            self._launch_scan_worker()

    def _defer_scan_until_game_foreground(self):
        """Release the scan latch without OCR and retry after the game regains focus."""
        self.pending_scan = None
        self.busy = False
        self._scan_request_active = False
        self._scan_result_received = False
        self.once_btn.setEnabled(True)
        self.start_btn.setEnabled(True)
        self._set_start_button('stop' if self.running else 'start')
        self.state.setText('● ОЧІКУЄ НА ГРУ')
        if not self._waiting_for_game_logged:
            self.logline('OCR пропущено: активне вікно вже не гра. Повернись у вікно гри — безперервне сканування відновиться автоматично.')
            self._waiting_for_game_logged = True
        self._scan_cycle_started_at = None
        if self.running:
            self.timer.start(max(20, int(self.settings.get('interval_ms', 20) or 20)))

    def _prepare_scan_target(self):
        """Find, validate and initially activate the fullscreen game window, as AHK does."""
        if os.name != 'nt':
            return None
        actions = load_external_action_core()
        # During continuous scan, do not steal focus back if the user Alt-Tabs away.
        # AHK's CheckDiscount simply returns while the target game is not active.
        if self._scan_target_hwnd is not None:
            if self._foreground_matches_game_target(self._scan_target_hwnd):
                return int(self._scan_target_hwnd)
            if self.running:
                return False
            self._scan_target_hwnd = None

        found = actions.PurchaseWorker._find_target_window()
        if not found:
            raise RuntimeError('Не знайдено вікно гри NG/GTA. Відкрий ринок у грі та повтори сканування.')
        hwnd, title, process_name = found
        hwnd = int(hwnd)
        screen_size = actions.PurchaseWorker._screen_size()
        if not actions.PurchaseWorker._window_covers_screen(hwnd, screen_size):
            raise RuntimeError('Вікно гри не займає весь основний екран. Увімкни fullscreen/borderless на весь екран монітора (16:9, наприклад 1920×1080 або 2560×1440).')
        if not actions.PurchaseWorker._activate_target_window(hwnd):
            raise RuntimeError(f'Не вдалося активувати вікно гри: {title or process_name}. Сканування не виконано.')
        if not self._foreground_matches_game_target(hwnd):
            raise RuntimeError(f'Активним не стало вікно гри: {title or process_name}. Сканування не виконано.')
        self._scan_target_hwnd = hwnd
        self._waiting_for_game_logged = False
        return hwnd

    def _launch_scan_worker(self):
        if not self.pending_scan:
            return
        catalog_models, threshold, model_thresholds, grid, active_models, blacklist, rules_snapshot = self.pending_scan
        self.pending_scan = None
        try:
            core = load_external_scan_core()
            core_version = str(getattr(core, 'OCR_PATCH_VERSION', 'unknown'))
            speed_version = str(getattr(core, 'OCR_SPEED_PATCH_VERSION', 'unknown'))
            capture_version = str(getattr(core, 'DETAIL_CAPTURE_CACHE_PATCH_VERSION', 'unknown'))
            detail_discount_version = str(getattr(core, 'DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION', 'unknown'))
            recognition_only_version = str(getattr(core, 'RECOGNITION_ONLY_PATCH_VERSION', 'unknown'))
            single_card_batch_version = str(getattr(core, 'SINGLE_CARD_BATCH_PATCH_VERSION', 'unknown'))
            purchase_diagnostics_version = str(getattr(core, 'PURCHASE_DIAGNOSTICS_PATCH_VERSION', 'unknown'))
            fast_badge_consensus_version = str(getattr(core, 'FAST_BADGE_CONSENSUS_PATCH_VERSION', 'unknown'))
            market_return_gate_version = str(getattr(core, 'MARKET_RETURN_GATE_PATCH_VERSION', 'unknown'))
            if (core_version != EXPECTED_OCR_CORE_VERSION or speed_version != EXPECTED_OCR_SPEED_PATCH_VERSION
                    or capture_version != EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION
                    or detail_discount_version != EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION
                    or recognition_only_version != EXPECTED_RECOGNITION_ONLY_PATCH_VERSION
                    or single_card_batch_version != EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION
                    or purchase_diagnostics_version != EXPECTED_PURCHASE_DIAGNOSTICS_PATCH_VERSION
                    or fast_badge_consensus_version != EXPECTED_FAST_BADGE_CONSENSUS_PATCH_VERSION
                    or market_return_gate_version != EXPECTED_MARKET_RETURN_GATE_PATCH_VERSION):
                self._ocr_core_compatible = False
                raise RuntimeError(f'Завантажено несумісне OCR-ядро {core_version} / {speed_version} / {capture_version} / {detail_discount_version}; потрібні '
                                   f'{EXPECTED_OCR_CORE_VERSION} / {EXPECTED_OCR_SPEED_PATCH_VERSION} / {EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION} / {EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION} / {EXPECTED_RECOGNITION_ONLY_PATCH_VERSION} / {EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION} / {EXPECTED_PURCHASE_DIAGNOSTICS_PATCH_VERSION} / {EXPECTED_FAST_BADGE_CONSENSUS_PATCH_VERSION}. Автодії не виконувались.')
            target_hwnd = self._prepare_scan_target()
            if target_hwnd is False:
                self._defer_scan_until_game_foreground()
                return
            self.worker = core.ScanWorker(
                catalog_models, rules_snapshot, threshold, model_thresholds, grid,
                active_models=active_models, blacklisted_models=blacklist,
                target_hwnd=target_hwnd,
                fast_color_filter_enabled=True,
                confidence_protection_enabled=bool(self.settings.get('confidence_protection_enabled', True)),
                fast_candidate_mode=bool(self.settings.get('auto_click', False)),
            )
            self.worker.result.connect(self.on_result)
            if hasattr(self.worker, 'candidate_found'):
                self.worker.candidate_found.connect(self._on_fast_candidate_found)
            self.worker.finished.connect(self._on_scan_worker_finished)
            if hasattr(self.worker, 'progress'):
                self.worker.progress.connect(self.on_scan_progress)
            if self.running:
                self._scan_cycle_started_at = time.perf_counter()
            self.worker.start()
        except Exception as exc:
            self.busy = False
            self._scan_request_active = False
            self._continuous_scan_requested = False
            compatible = bool(getattr(self, '_ocr_core_compatible', False))
            self.once_btn.setEnabled(compatible)
            self.start_btn.setEnabled(compatible)
            self.timer.stop()
            self.running = False
            self._set_start_button('start')
            self.state.setText('● НЕСУМІСНА ЗБІРКА' if not compatible else '● ПОМИЛКА')
            self._restore_capture_window()
            self._scan_target_hwnd = None
            self._waiting_for_game_logged = False
            self.logline(f'Не вдалося запустити сканування: {type(exc).__name__}: {exc}')

    def on_scan_progress(self, card_number, message):
        if self.state.text().startswith('● ЗУПИНЯЄТЬСЯ'):
            return
        if self.running:
            self.state.setText(f'● СКАНУЄ {min(15, int(card_number))}/15')
        else:
            self.state.setText(f'● АНАЛІЗ {min(15, int(card_number))}/15')

    def _direct_green_settings_snapshot(self, core):
        """Snapshot all purchase rules before the watcher starts; no GUI reads from worker threads."""
        try:
            global_threshold = int(self.threshold.currentText().strip('-% '))
        except Exception:
            global_threshold = int(self.settings.get('threshold', 20) or 20)
        configured = self.settings.get('selected_models')
        if isinstance(configured, list):
            selected = [str(m).strip() for m in configured if str(m).strip()]
        else:
            selected = read_lines(SELECTED) or list(self.all_models)
        selected = list(dict.fromkeys(selected))
        blacklist = (load_blacklist_models(self.all_models)
                     if self.settings.get('blacklist_protection_enabled', True) else set())
        active = [m for m in selected if m not in blacklist]
        model_thresholds = dict(self.settings.get('model_thresholds', {}) or {})
        rules = {k: dict(v) for k, v in self.rules.items()}
        thresholds = []
        for model in active:
            rule = dict(rules.get(model, {}) or {})
            category = str(rule.get('category', 'Звичайне')).strip()
            if category in ('Пріоритетне', 'Пріоритетна'):
                category_threshold = 15
            elif category in ('Спеціальне', 'Спеціальна'):
                category_threshold = 50
            else:
                category_threshold = global_threshold
            try:
                effective = core.effective_threshold(
                    category, model_thresholds.get(model), category_threshold, global_threshold)
                thresholds.append(abs(int(effective)))
            except Exception:
                thresholds.append(abs(global_threshold))
        if not active or not thresholds:
            raise RuntimeError('Немає активних моделей/порогів для GREEN WATCH. Перевір каталог та вибір автомобілів.')
        return {
            'all_models': list(self.all_models),
            'active_models': list(active),
            'blacklisted_models': set(blacklist),
            'rules': rules,
            'global_threshold': global_threshold,
            'model_thresholds': model_thresholds,
            'minimum_possible_threshold': min(thresholds),
            'confidence_floor': 0.93 if self.settings.get('confidence_protection_enabled', True) else 0.80,
        }

    def _start_direct_green_watch(self):
        """Start the independent DXGI/MSS watcher used when both auto-click and auto-confirm are enabled."""
        try:
            if os.name != 'nt':
                raise RuntimeError('DIRECT GREEN WATCH доступний лише у Windows.')
            if not getattr(self, 'ocr_ready', False) or not getattr(self, '_ocr_core_compatible', False):
                raise RuntimeError('OCR ще не готовий або версія ядра несумісна. Дочекайся стану «ГОТОВИЙ · GREEN ONLY».')
            core = load_external_scan_core()
            if (str(getattr(core, 'OCR_PATCH_VERSION', '')) != EXPECTED_OCR_CORE_VERSION
                    or str(getattr(core, 'OCR_SPEED_PATCH_VERSION', '')) != EXPECTED_OCR_SPEED_PATCH_VERSION
                    or str(getattr(core, 'DETAIL_CAPTURE_CACHE_PATCH_VERSION', '')) != EXPECTED_DETAIL_CAPTURE_CACHE_PATCH_VERSION
                    or str(getattr(core, 'DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION', '')) != EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION
                    or str(getattr(core, 'WATCH_FINGERPRINT_PATCH_VERSION', '')) != '1.2.65-perceptual-offer-dedupe'
                    or str(getattr(core, 'DETAIL_OCR_FASTPATH_PATCH_VERSION', '')) != '1.2.65-compact-detail-ocr'):
                raise RuntimeError('DIRECT GREEN WATCH заблоковано: не збігається версія скан-ядра.')
            if not all(hasattr(core, name) for name in ('GreenBadgeWatcher', 'validate_market_detail_screen', 'effective_threshold')):
                raise RuntimeError('У scanner_core.py відсутні компоненти DIRECT GREEN WATCH; збірку заблоковано.')
            actions = load_external_action_core()
            if (str(getattr(actions, 'CLICK_WORKFLOW_VERSION', '')) != EXPECTED_CLICK_WORKFLOW_VERSION
                    or str(getattr(actions, 'CLICK_LATENCY_PATCH_VERSION', '')) != EXPECTED_CLICK_LATENCY_PATCH_VERSION
                    or str(getattr(actions, 'CLICK_WAIT_TIMER_PATCH_VERSION', '')) != EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION
                    or str(getattr(actions, 'CLICK_BUTTON_PROBE_PATCH_VERSION', '')) != EXPECTED_CLICK_BUTTON_PROBE_PATCH_VERSION
                    or str(getattr(actions, 'CLICK_MARKET_RETURN_PATCH_VERSION', '')) != EXPECTED_CLICK_MARKET_RETURN_PATCH_VERSION
                    or str(getattr(actions, 'CLICK_DYNAMIC_CONFIRM_PATCH_VERSION', '')) != EXPECTED_DYNAMIC_CONFIRM_PATCH_VERSION
                    or str(getattr(actions, 'FAST_COORDINATE_FLOW_VERSION', '')) != EXPECTED_FAST_COORDINATE_FLOW_VERSION):
                raise RuntimeError('Версія click-workflow не збігається; автодію заблоковано.')
            target_hwnd = self._prepare_scan_target()
            if target_hwnd is False:
                self.state.setText('● ОЧІКУЄ НА ГРУ')
                self._set_start_button('stop')
                if not self._waiting_for_game_logged:
                    self.logline('DIRECT GREEN WATCH очікує, поки вікно гри знову стане активним. Інші вікна не скануються.')
                    self._waiting_for_game_logged = True
                QTimer.singleShot(250, self._retry_direct_green_watch_start)
                return
            screen_size = actions.PurchaseWorker._screen_size()
            if len(screen_size) != 2 or min(int(screen_size[0]), int(screen_size[1])) <= 0:
                raise RuntimeError('Не вдалося визначити фактичний розмір екрана.')
            context = self._direct_green_settings_snapshot(core)
            context.update({'core': core, 'target_hwnd': target_hwnd, 'screen_size': tuple(map(int, screen_size))})
            self._green_direct_context = context
            self._green_watch_mode = True
            self._green_resume_pending = False
            self._urgent_candidate_started = False
            self._green_badge_context = None
            self._green_batch_candidates = None
            self.timer.stop()
            self.capture_hidden = True
            self.showMinimized()
            watcher = core.GreenBadgeWatcher(dict(self.settings.get('grid', DEFAULTS['grid'])),
                                             target_hwnd, screen_size)
            self.green_watch_worker = watcher
            watcher.candidates_found.connect(self._on_green_watch_candidates)
            watcher.status.connect(self._on_green_watch_status)
            watcher.finished.connect(self._on_green_watch_finished)
            watcher.start()
            self.state.setText('● DIRECT GREEN WATCH')
            self.logline(f'DIRECT GREEN WATCH запущено: DXGI/DXcam або MSS; ціль — швидке виявлення зелених бейджів без OCR каталогу. Мінімальний можливий поріг активних моделей: -{context["minimum_possible_threshold"]}%. Перевірка назви/ціни/знижки виконується у деталях ДО кнопки «Купити».')
        except Exception as exc:
            self._green_watch_mode = False
            self._continuous_scan_requested = False
            self.running = False
            self.timer.stop()
            self._set_start_button('start')
            self.state.setText('● DIRECT WATCH ПОМИЛКА')
            self.start_btn.setEnabled(bool(self._ocr_core_compatible))
            self.once_btn.setEnabled(bool(self._ocr_core_compatible))
            self.logline(f'DIRECT GREEN WATCH не запущено; автокліків не виконано: {type(exc).__name__}: {exc}')
            self._restore_capture_window()
            self._scan_target_hwnd = None

    def _retry_direct_green_watch_start(self):
        if not self.running or self._green_watch_mode or self.action_in_progress:
            return
        self._start_direct_green_watch()

    def _on_green_watch_status(self, message):
        message = str(message or '')
        if message:
            self.logline(message)
        if message.startswith('ERROR:'):
            self._green_watch_mode = False
            self._continuous_scan_requested = False
            self.running = False
            self.timer.stop()
            try:
                if self.green_watch_worker is not None:
                    self.green_watch_worker.cancel()
            except Exception:
                pass
            self._set_start_button('start')
            self.start_btn.setEnabled(True)
            self.once_btn.setEnabled(True)
            self.state.setText('● DIRECT WATCH ПОМИЛКА')
            self._restore_capture_window()

    def _on_green_watch_finished(self):
        worker = self.sender()
        if worker is None:
            worker = self.green_watch_worker
        if worker is self.green_watch_worker:
            self.green_watch_worker = None
        if self._green_watch_mode and self.running and not self.action_in_progress:
            self._resume_green_watch_if_safe()

    def _on_green_watch_candidates(self, candidates):
        """Dispatch a sole green candidate without badge OCR; rank coalesced arrivals by badge % only."""
        if (not self._green_watch_mode or not self.running or self.action_in_progress
                or self._action_worker_is_running()):
            return
        context = self._green_direct_context
        if not context:
            self.logline('DIRECT WATCH отримав кандидата без контексту; покупки не буде.')
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        green = [dict(c) for c in (candidates or [])
                 if str(c.get('badge_color', '')).upper() == 'GREEN']
        if not green:
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return

        # The common case keeps the shortest path: a single new green badge does not
        # pay for OCR before CARD_CLICK. Ranking is needed only for simultaneous arrivals.
        if len(green) == 1:
            self._launch_direct_green_candidate(green[0], ranked_discount=None,
                                                selection_note='єдина нова зелена пропозиція')
            return

        core = context.get('core')
        if core is None or not hasattr(core, 'GreenBadgeBatchWorker'):
            self.logline('PRIORITY BY MAX DISCOUNT: немає badge-only OCR worker; кілька карток пропущено без кліку.')
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        if self.green_badge_worker is not None:
            try:
                if self.green_badge_worker.isRunning():
                    self.logline('PRIORITY BY MAX DISCOUNT: OCR попередньої групи ще працює; повторну групу не запускаю.')
                    self._green_resume_pending = True
                    return
            except RuntimeError:
                self.green_badge_worker = None

        self._green_batch_candidates = [dict(c) for c in green]
        self._green_badge_context = {
            'candidate_signatures': tuple(str(c.get('signature') or '') for c in green),
            'started_at': time.perf_counter(),
            'count': len(green),
        }
        self._green_resume_pending = False
        try:
            worker = core.GreenBadgeBatchWorker(green)
            worker.results_ready.connect(self._on_green_badge_results_ready)
            worker.finished.connect(self._on_green_badge_worker_finished)
            self.green_badge_worker = worker
            self.logline(f'PRIORITY BY MAX DISCOUNT: одночасно з’явилися {len(green)} зелені картки; читаю лише відсотки бейджів у одному OCR-проході, назви й ціни до першого кліку не OCR-ю.')
            worker.start()
        except Exception as exc:
            self.green_badge_worker = None
            self._green_batch_candidates = None
            self._green_badge_context = None
            self.logline(f'PRIORITY BY MAX DISCOUNT: запуск OCR відсотків не вдався ({type(exc).__name__}: {exc}); покупки не виконую.')
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()

    def _on_green_badge_results_ready(self, ranked, error, elapsed):
        """Select the highest confidently read discount; fail closed if any rival is unknown."""
        context = dict(self._green_direct_context or {})
        expected = list(self._green_batch_candidates or [])
        if not self._green_watch_mode or not self.running or self.action_in_progress:
            self._green_batch_candidates = None
            self._green_badge_context = None
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        if error or not ranked:
            self.logline(f'PRIORITY BY MAX DISCOUNT: OCR бейджів не завершився успішно ({error or "немає результатів"}); групу не купую. Час OCR: {float(elapsed or 0)*1000:.1f} мс.')
            self._green_batch_candidates = None
            self._green_badge_context = None
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        required = {int(c.get('card_index', c.get('card', 999))) for c in expected}
        decoded = {int(c.get('card_index', c.get('card', 999))): c for c in ranked}
        # Never guess the largest deal when a competitor's percentage is unreadable.
        uncertain = []
        for candidate in expected:
            key = int(candidate.get('card_index', candidate.get('card', 999)))
            row = decoded.get(key)
            try:
                discount = int(row.get('discount_value')) if row and row.get('discount_value') is not None else None
                confidence = float(row.get('badge_ocr_confidence') or 0.0) if row else 0.0
            except (TypeError, ValueError):
                discount, confidence = None, 0.0
            if discount is None or confidence < 0.55:
                uncertain.append((candidate.get('card'), discount, confidence))
        if len(decoded) < len(required) or uncertain:
            details = ', '.join(f'#{card}: {value if value is not None else "не прочитано"}%, conf={conf:.2f}'
                                for card, value, conf in uncertain[:5])
            self.logline(f'PRIORITY BY MAX DISCOUNT: не натискаю жодну картку — відсоток усіх {len(expected)} пропозицій треба знати, щоб не пропустити найбільшу. Невизначені: {details or "неповний набір результатів"}. OCR: {float(elapsed or 0)*1000:.1f} мс.')
            self._green_batch_candidates = None
            self._green_badge_context = None
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        best = max((decoded[int(c.get('card_index', c.get('card', 999)))] for c in expected),
                   key=lambda c: (int(c.get('discount_value') or 0),
                                  float(c.get('badge_ocr_confidence') or 0.0),
                                  -int(c.get('card_index', c.get('card', 999)) or 999)))
        self.logline(f'PRIORITY BY MAX DISCOUNT: вибрано картку {best.get("card")} зі знижкою -{best.get("discount_value")}% (conf={float(best.get("badge_ocr_confidence") or 0.0):.2f}; OCR бейджів {float(elapsed or 0)*1000:.1f} мс).')
        self._green_batch_candidates = None
        self._green_badge_context = None
        self._launch_direct_green_candidate(best, ranked_discount=int(best.get('discount_value')),
                                            selection_note='найбільша впевнено прочитана знижка')

    def _launch_direct_green_candidate(self, chosen, ranked_discount=None, selection_note=''):
        """Build and dispatch the common direct-click payload with detail-page validation."""
        context = self._green_direct_context
        if not context or not chosen:
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
            return
        direct = dict(chosen)
        # Use a fresh dispatch timestamp for click-phase timing. Keep any older candidate-age
        # diagnostics out of the pre-click path; they are queued only after the worker starts.
        dispatch_perf_counter = time.perf_counter()
        candidate_age_ms = None
        try:
            raw_detected_at = float(chosen.get('detected_at'))
            candidate_age_ms = max(0.0, (dispatch_perf_counter - raw_detected_at) * 1000.0)
        except (TypeError, ValueError):
            pass
        if ranked_discount is not None:
            direct_discount = int(ranked_discount)
            direct_display = f'-{direct_discount}% (OCR бейджа)'
        else:
            direct_discount = None
            direct_display = 'Зелений бейдж'
        direct.update({
            '_direct_green_watch': True,
            '_target_hwnd': context.get('target_hwnd'),
            '_fast_candidate_detected_at_perf_counter': dispatch_perf_counter,
            'discount_value': direct_discount,
            'discount': direct_display,
            'discount_kind': 'discount',
            'badge_color': 'GREEN',
            'eligible': True,  # Provisional: detail-page validator must approve before Buy.
            'catalog_model': '',
            'model': 'GREEN кандидат — деталі ще не перевірені',
            'model_confidence': 0.0,
            'price_value': None,
            'price': None,
            'threshold': int(context.get('minimum_possible_threshold', 20)),
        })
        # Latch the chosen signature before dispatch to avoid duplicate queued frame signals.
        if self.green_watch_worker is not None:
            try:
                self.green_watch_worker.mark_attempted(chosen.get('signature'))
            except Exception:
                pass
        direct['_candidate_age_ms'] = candidate_age_ms
        self._urgent_candidate_started = True
        self._green_resume_pending = False
        source_note = f' · {selection_note}' if selection_note else ''
        discount_note = f' · -{direct_discount}%' if direct_discount is not None else ''
        direct_message = (f'DIRECT GREEN WATCH: картка {chosen.get("card")} — зелений бейдж{discount_note}; '
                          f'відправлено на CARD_CLICK без OCR назви/ціни{source_note}. '
                          'Деталі й точний відсоток перевіряються перед «Купити».')
        if not self._start_purchase_action(direct):
            self.logline(f'{direct_message} Автодію не запущено; перевір причину вище.')
            self._urgent_candidate_started = False
            self._green_resume_pending = True
            self._resume_green_watch_if_safe()
        else:
            if candidate_age_ms is not None and candidate_age_ms >= 250.0:
                age_message = (f'DIRECT GREEN WATCH: кадр кандидата очікував передачі '
                               f'{candidate_age_ms:.1f} мс; таймер кліків відраховується від передачі в PurchaseWorker.')
                QTimer.singleShot(0, lambda message=age_message: self.logline(message))
            QTimer.singleShot(0, lambda message=direct_message: self.logline(message))

    def _on_green_badge_worker_finished(self):
        worker = self.sender()
        if worker is None:
            worker = self.green_badge_worker
        if worker is self.green_badge_worker:
            self.green_badge_worker = None
        self._resume_green_watch_if_safe()

    def _resume_green_watch_if_safe(self):
        if not self._green_resume_pending or not self._green_watch_mode or not self.running:
            return
        if self.action_in_progress or self._action_worker_is_running():
            return
        try:
            if self.green_badge_worker is not None and self.green_badge_worker.isRunning():
                return
        except RuntimeError:
            self.green_badge_worker = None
        if self.green_watch_worker is not None:
            try:
                self.green_watch_worker.resume_after_action()
                self._green_resume_pending = False
                self.state.setText('● DIRECT GREEN WATCH')
            except Exception as exc:
                self.logline(f'Не вдалося відновити green watcher: {type(exc).__name__}: {exc}')

    def _build_direct_detail_validator(self, candidate):
        """Create a worker-safe validator using immutable snapshots, not Qt/UI calls."""
        context = dict(self._green_direct_context or {})
        core = context.get('core')
        if core is None:
            raise RuntimeError('Відсутній контекст перевірки деталей.')
        detail_discount_version = str(getattr(core, 'DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION', ''))
        if detail_discount_version != EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION:
            raise RuntimeError(f'Автокупівлю заблоковано: потрібна перевірка знижки {EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION}, завантажено {detail_discount_version or "невідому версію"}.')
        all_models = list(context['all_models'])
        active_models = list(context['active_models'])
        rules = {k: dict(v) for k, v in context['rules'].items()}
        global_threshold = int(context['global_threshold'])
        model_thresholds = dict(context['model_thresholds'])
        blacklist = set(context['blacklisted_models'])
        target_hwnd = context.get('target_hwnd')
        confidence_floor = float(context.get('confidence_floor', 0.93))
        def validate(expected_discount, after_perf_counter=None):
            return core.validate_market_detail_screen(
                all_models, active_models, rules, global_threshold, model_thresholds,
                blacklist, expected_discount, target_hwnd=target_hwnd,
                confidence_floor=confidence_floor, detail_frame_not_before=after_perf_counter)
        return validate

    @staticmethod
    def _purchase_attempt_key(candidate):
        """Deduplicate one visible lot, rather than every lot with matching model/price/discount."""
        candidate = candidate if isinstance(candidate, dict) else {}
        model = str(candidate.get('catalog_model') or candidate.get('model') or '').strip()
        price = candidate.get('price_value')
        discount = candidate.get('discount_value')
        threshold = candidate.get('threshold')
        if candidate.get('_direct_green_watch'):
            signature = str(candidate.get('offer_identity_signature') or candidate.get('offer_signature') or candidate.get('signature') or '').strip()
            return ('DIRECT_GREEN', signature, discount, threshold)
        identity_signature = str(candidate.get('offer_identity_signature') or '').strip()
        if identity_signature:
            # Do not include the current cell number: after purchase the market may shift
            # a still-visible lot into the next cell. The visual identity plus its price,
            # discount and threshold prevents duplicate clicks on that moved lot.
            return ('GRID_OFFER', identity_signature, model, price, discount, threshold)
        signature = str(candidate.get('offer_signature') or candidate.get('signature') or '').strip()
        card = candidate.get('card')
        if signature:
            return ('GRID_LEGACY_OFFER', card, signature, model, price, discount, threshold)
        # Compatibility fallback for synthetic/legacy candidates without image signatures.
        return ('GRID_FALLBACK', card, model, price, discount, threshold)

    def _on_purchase_worker_progress(self, message):
        """Mirror worker progress and latch a dedupe key only after the first card click was sent."""
        text = str(message or '')
        self.logline(text)
        upper = text.upper()
        first_click_sent = (
            ('CARD_CLICK' in upper and 'SENT' in upper)
            or ('STEP 1/3' in upper and 'SENT' in upper)
            or ('КЛІК ПО КАРТЦІ' in upper and ('НАДІСЛАНО' in upper or 'ВІДПРАВЛЕНО' in upper))
        )
        if first_click_sent:
            key = getattr(self, '_active_purchase_attempt_key', None)
            if key is not None:
                self._active_purchase_click_sent = True
                self._purchase_offer_keys_attempted.add(key)

    def _log_purchase_skip_once(self, candidate, reason):
        """Explain the first reason an eligible-looking lot did not trigger another click."""
        candidate = candidate if isinstance(candidate, dict) else {}
        key = (self._purchase_attempt_key(candidate), str(reason))
        if key in self._purchase_offer_skip_logged:
            return
        self._purchase_offer_skip_logged.add(key)
        label = (f"картка {candidate.get('card', '?')} · "
                 f"{candidate.get('catalog_model') or candidate.get('model') or 'модель не визначена'} · "
                 f"{candidate.get('price') or candidate.get('price_value') or 'ціна не визначена'} · "
                 f"{candidate.get('discount') or candidate.get('discount_value') or 'знижка не визначена'}")
        self.logline(f'AUTO-BUY SKIP: {label}. Причина: {reason}. Цього разу кліки не відправлялися.')

    def _purchase_gate_reason(self, candidate, blacklisted_now, confidence_floor):
        candidate = candidate if isinstance(candidate, dict) else {}
        if not candidate.get('eligible'):
            return str(candidate.get('status') or 'кандидат не пройшов перевірку придатності')
        if str(candidate.get('badge_color', '')).upper() != 'GREEN':
            return 'бейдж не GREEN'
        if candidate.get('discount_kind') != 'discount':
            return 'тип бейджа не є підтвердженою знижкою'
        if candidate.get('price_value') is None:
            return 'ціна не прочитана'
        if candidate.get('threshold') is None:
            return 'мінімальний поріг не визначений'
        model = str(candidate.get('catalog_model') or '').strip()
        if not model:
            return 'модель не зіставлена з каталогом'
        try:
            confidence = float(candidate.get('model_confidence') or 0.0)
        except (TypeError, ValueError):
            confidence = 0.0
        if confidence < confidence_floor:
            return f'впевненість моделі {confidence:.2f} нижча за поріг {confidence_floor:.2f}'
        if model in blacklisted_now:
            return 'модель у чорному списку'
        try:
            xy = candidate.get('xy')
            size = candidate.get('screen_size')
            x, y = int(xy[0]), int(xy[1])
            width, height = int(size[0]), int(size[1])
        except (TypeError, ValueError, IndexError):
            return 'відсутні або некоректні координати картки/розмір екрана'
        if width <= 0 or height <= 0 or x < 0 or y < 0 or x >= width or y >= height:
            return f'координати ({x},{y}) поза екраном {width}×{height}'
        return 'інша умова захисту автокупівлі не пройдена; перевір статус і налаштування'

    def _on_fast_candidate_found(self, candidate):
        """Start the existing guarded purchase path on the first fully validated GREEN offer."""
        if not isinstance(candidate, dict) or not self.settings.get('auto_click', False):
            return
        if self._urgent_candidate_started or self.action_in_progress or self._action_worker_is_running():
            return
        if str(candidate.get('badge_color', '')).upper() != 'GREEN':
            return
        if not candidate.get('eligible') or candidate.get('discount_kind') != 'discount':
            return
        key = self._purchase_attempt_key(candidate)
        if key in self._purchase_offer_keys_attempted:
            self._log_purchase_skip_once(candidate, 'ця сама видима пропозиція вже отримувала спробу купівлі в цьому сеансі; повторю не роблю, бо швидкий потік не перевіряє відповідь сервера')
            return
        # Latch before launching the action: a queued result signal must not trigger a second flow.
        self._urgent_candidate_started = True
        detected_after = candidate.get('_fast_candidate_detected_after_seconds')
        try:
            latency_text = f'{float(detected_after) * 1000.0:.1f} мс від початку сканування' if detected_after is not None else 'час виявлення не виміряно'
        except (TypeError, ValueError):
            latency_text = 'час виявлення не виміряно'
        try:
            detected_at = float(candidate.get('_fast_candidate_detected_at_perf_counter'))
            signal_queue_ms = max(0.0, (time.perf_counter() - detected_at) * 1000.0)
            queue_text = f'затримка передачі сигналу {signal_queue_ms:.1f} мс'
        except (TypeError, ValueError):
            queue_text = 'затримка передачі сигналу не виміряна'
        if self._start_purchase_action(candidate):
            # _start_purchase_action has already cancelled the competing ScanWorker
            # immediately after starting PurchaseWorker, before any UI/log refresh.
            fastlane_message = (f'GREEN PRIORITY FASTLANE: придатна зелена пропозиція передана на автокупівлю; '
                                f'{latency_text}; {queue_text}; решту OCR скасовано.')
            QTimer.singleShot(0, lambda message=fastlane_message: self.logline(message))
        else:
            self._urgent_candidate_started = False

    def _start_purchase_action(self, candidate):
        """Launch the guarded sidecar action flow for one validated candidate."""
        if not self.settings.get('auto_click', False):
            return False
        if self.action_in_progress or self._action_worker_is_running():
            self.logline('Автодію заблоковано: попередній потік покупки ще завершується. Повторний потік не запускався.')
            return False
        direct_mode = bool(candidate.get('_direct_green_watch'))
        model_name = str(candidate.get('catalog_model') or candidate.get('model') or '').strip()
        if (not direct_mode and self.settings.get('blacklist_protection_enabled', True) and model_name
                and model_name in load_blacklist_models(self.all_models)):
            self.logline(f'Автодію заблоковано: «{model_name}» перебуває в чорному списку.')
            return False
        if not candidate.get('eligible') or candidate.get('discount_kind') != 'discount':
            self.logline('Автодію пропущено: результат не має підтвердженої знижки.')
            return False
        if direct_mode:
            try:
                minimum = int(candidate.get('threshold'))
                raw_discount = candidate.get('discount_value')
                badge_discount = int(raw_discount) if raw_discount not in (None, '') else None
            except (TypeError, ValueError):
                self.logline('DIRECT WATCH: мінімальний поріг некоректний; клік заблоковано.')
                return False
            if (str(candidate.get('badge_color', '')).upper() != 'GREEN'
                    or (badge_discount is not None and badge_discount < minimum)):
                self.logline('DIRECT WATCH: бейдж не зелений або відомий відсоток не проходить базовий поріг; клік заблоковано.')
                return False
            if not self.settings.get('auto_confirm', False):
                self.logline('DIRECT WATCH потребує одночасно auto-click і auto-confirm; картку не відкриваю.')
                return False
        else:
            try:
                confidence = float(candidate.get('model_confidence') or 0.0)
            except (TypeError, ValueError):
                confidence = 0.0
            confidence_floor = 0.93 if self.settings.get('confidence_protection_enabled', True) else 0.80
            if not candidate.get('catalog_model') or confidence < confidence_floor:
                self.logline(f'Автодію заблоковано: модель поза каталогом або впевненість розпізнавання нижче {confidence_floor:.2f}.')
                return False
            if candidate.get('price_value') is None or candidate.get('threshold') is None:
                self.logline('Автодію заблоковано: ціна або поріг не прочитані.')
                return False
        xy = candidate.get('xy')
        size = candidate.get('screen_size')
        try:
            x, y = int(xy[0]), int(xy[1])
            width, height = int(size[0]), int(size[1])
        except (TypeError, ValueError, IndexError):
            self.logline('Автодію заблоковано: координати картки або розмір екрана відсутні/некоректні.')
            return False
        if width <= 0 or height <= 0 or x < 0 or y < 0 or x >= width or y >= height:
            self.logline(f'Автодію заблоковано: координати картки ({x},{y}) поза екраном {width}×{height}.')
            return False
        attempt_key = self._purchase_attempt_key(candidate)
        if attempt_key in self._purchase_offer_keys_attempted:
            self._log_purchase_skip_once(candidate, 'ця сама видима пропозиція вже отримувала спробу купівлі в цьому сеансі')
            return False
        try:
            actions = load_external_action_core()
            action_version = str(getattr(actions, 'CLICK_WORKFLOW_VERSION', ''))
            latency_version = str(getattr(actions, 'CLICK_LATENCY_PATCH_VERSION', 'unknown'))
            probe_version = str(getattr(actions, 'CLICK_BUTTON_PROBE_PATCH_VERSION', 'unknown'))
            return_version = str(getattr(actions, 'CLICK_MARKET_RETURN_PATCH_VERSION', 'unknown'))
            dynamic_confirm_version = str(getattr(actions, 'CLICK_DYNAMIC_CONFIRM_PATCH_VERSION', 'unknown'))
            timer_version = str(getattr(actions, 'CLICK_WAIT_TIMER_PATCH_VERSION', 'unknown'))
            if (action_version != EXPECTED_CLICK_WORKFLOW_VERSION
                    or latency_version != EXPECTED_CLICK_LATENCY_PATCH_VERSION
                    or timer_version != EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION
                    or probe_version != EXPECTED_CLICK_BUTTON_PROBE_PATCH_VERSION
                    or return_version != EXPECTED_CLICK_MARKET_RETURN_PATCH_VERSION
                    or dynamic_confirm_version != EXPECTED_DYNAMIC_CONFIRM_PATCH_VERSION
                    or str(getattr(actions, 'FAST_COORDINATE_FLOW_VERSION', '')) != EXPECTED_FAST_COORDINATE_FLOW_VERSION):
                raise RuntimeError(f"Версія click-workflow не збігається: потрібні {EXPECTED_CLICK_WORKFLOW_VERSION} / {EXPECTED_CLICK_LATENCY_PATCH_VERSION} / {EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION} / {EXPECTED_CLICK_BUTTON_PROBE_PATCH_VERSION} / {EXPECTED_CLICK_MARKET_RETURN_PATCH_VERSION} / {EXPECTED_FAST_COORDINATE_FLOW_VERSION}, завантажено {action_version or 'невідому версію'} / {latency_version} / {timer_version} / {probe_version} / {return_version}. Автодію заблоковано без кліків.")
            self._active_purchase_candidate = dict(candidate)
            self._active_purchase_started = time.monotonic()
            self._active_purchase_attempt_key = attempt_key
            self._active_purchase_click_sent = False
            self._queue_stats_event('purchase_flow_started', model=str(candidate.get('catalog_model') or candidate.get('model') or ''),
                                    price_value=candidate.get('price_value'), discount_pct=candidate.get('discount_value'))
            auto_confirm_enabled = bool(self.settings.get('auto_confirm', False) and self.settings.get('auto_click', False))
            fast_coordinate_flow = bool(auto_confirm_enabled and not direct_mode)
            validator = self._build_direct_detail_validator(candidate) if direct_mode else None
            action_worker = actions.PurchaseWorker(
                (x, y),
                (width, height),
                click_delay_ms=self.settings.get('click_delay_ms', 1),
                auto_confirm=auto_confirm_enabled,
                target_hwnd=candidate.get('_target_hwnd'),
                candidate_detected_at=candidate.get('_fast_candidate_detected_at_perf_counter'),
                pre_buy_validator=validator,
                expected_discount=candidate.get('discount_value') if direct_mode else None,
                fast_coordinate_flow=fast_coordinate_flow,
            )
            self.action_worker = action_worker
            self._action_result_received = False
            self._action_result_handled = False
            self._last_action_success = False
            action_worker.progress.connect(self._on_purchase_worker_progress)
            action_worker.finished_result.connect(self.on_action_result)
            action_worker.finished.connect(self._on_action_worker_thread_finished_signal)
            self.action_in_progress = True
            # Capture durable user intent, not just the transient `running` flag.
            # Purchase setup intentionally clears `running`; worker cleanup must not erase
            # the fact that START requested continuous scanning.
            self._purchase_was_continuous_scan = bool(getattr(self, '_continuous_scan_requested', False) or self.running)
            continue_after_purchase = bool(self.settings.get('continue_after_purchase', True))
            self._resume_scan_after_action = bool(self._purchase_was_continuous_scan and continue_after_purchase)
            # This navigation recovery is only for an auto-confirmed purchase flow;
            # it must not alter candidate analysis or the CARD_CLICK/BUY/CONFIRM chain.
            self._resume_after_purchase_navigation = bool(self._resume_scan_after_action and auto_confirm_enabled)
            self._resume_market_screen_size = (width, height)
            self._resume_market_cancel_attempts = 0
            self._resume_market_cancel_last_attempt_at = 0.0
            self._resume_market_confirm_started_at = 0.0
            self._resume_market_confirm_good_frames = 0
            self._resume_market_confirm_last_frame_token = None
            if self._purchase_was_continuous_scan and not continue_after_purchase:
                self._continuous_scan_requested = False
                self.auto_refresh_timer.stop()
                self._auto_refresh_pending = False
                self.logline('ПАРАМЕТР ПІСЛЯ ПОКУПКИ: продовження вимкнене — після поточного ланцюжка сканер зупиниться.')
            self._resume_focus_recovery_attempted = False
            self._resume_market_wait_started = 0.0
            self._resume_market_good_frames = 0
            self._resume_market_good_since = None
            self._resume_market_last_frame_token = None
            self._resume_market_last_state_logged = ''
            self._resume_market_back_attempted = False
            self._resume_market_target_hwnd = candidate.get('_target_hwnd') or self._scan_target_hwnd
            self.running = False
            self.timer.stop()
            self._set_start_button('start')
            # Avoid a second user-triggered scan/cancel in the short action tail.
            # The buttons are re-enabled only after QThread.finished is observed.
            self.start_btn.setEnabled(False)
            self.once_btn.setEnabled(False)
            self.state.setText('● АВТОДІЯ')
            action_worker.start()
            # Stop the competing full-grid OCR worker at the earliest safe point:
            # all purchase gates passed and the action thread is already running.
            if not direct_mode:
                scan_worker = self.worker
                try:
                    if scan_worker is not None and scan_worker.isRunning():
                        scan_worker.cancel()
                except RuntimeError:
                    pass
            start_message = (f"Автодію запущено для картки {candidate.get('card')}: "
                             f"{candidate.get('model')} · {candidate.get('price')} · "
                             f"{candidate.get('discount')} · поріг -{candidate.get('threshold')}%.")
            QTimer.singleShot(0, lambda message=start_message: self.logline(message))
            return True
        except Exception as exc:
            self.action_in_progress = False
            preserve_direct_watch = bool(direct_mode and self._green_watch_mode and self.green_watch_worker is not None)
            self.running = preserve_direct_watch
            self.timer.stop()
            self.state.setText('● АВТОДІЮ ЗАБЛОКОВАНО')
            self.start_btn.setEnabled(True)
            self.once_btn.setEnabled(True)
            self.logline(f'Автодію не запущено; жодних автоматичних кліків не виконано: {type(exc).__name__}: {exc}')
            if preserve_direct_watch:
                self._green_resume_pending = True
                QTimer.singleShot(0, self._resume_green_watch_if_safe)
            else:
                self._restore_capture_window()
            try:
                existing_worker = getattr(self, 'action_worker', None)
                if existing_worker is not None and not existing_worker.isRunning():
                    self.action_worker = None
            except Exception:
                self.action_worker = None
            return False

    def _on_action_worker_thread_finished_signal(self):
        """Retain the QThread object until its native thread actually stops."""
        worker = self.sender()
        if worker is None:
            worker = getattr(self, 'action_worker', None)
        if worker is None:
            return
        # queued finished_result is emitted before QThread.finished, but defer cleanup
        # so its GUI-thread slot always gets a chance to reset action_in_progress first.
        QTimer.singleShot(10, lambda active_worker=worker: self._finalize_action_worker_reference(active_worker, 0))

    def _finalize_action_worker_reference(self, worker, retries=0):
        """Release a click worker only after QThread.finished and result handling."""
        if getattr(self, 'action_worker', None) is not worker:
            return
        try:
            if worker.isRunning():
                QTimer.singleShot(10, lambda active_worker=worker, next_retry=retries + 1: self._finalize_action_worker_reference(active_worker, next_retry))
                return
        except RuntimeError:
            # A wrapper can be invalid only after its C++ thread object is already gone.
            if getattr(self, 'action_worker', None) is worker:
                self.action_worker = None
            return

        if self.action_in_progress:
            result_emitted = bool(getattr(worker, '_result_emitted', False))
            result_handled = bool(getattr(self, '_action_result_handled', False))
            if result_emitted and not result_handled and retries < 100:
                # A queued finished_result may be waiting behind UI events. Retain both
                # the worker object and the single-flight latch until the GUI slot runs.
                QTimer.singleShot(10, lambda active_worker=worker, next_retry=retries + 1: self._finalize_action_worker_reference(active_worker, next_retry))
                return

            if result_handled:
                self.action_in_progress = False
                self._active_purchase_candidate = None
                self._active_purchase_started = None
                self._active_purchase_attempt_key = None
                self._active_purchase_click_sent = False
                self.running = bool(self._resume_scan_after_action)
                self.timer.stop()
                self.busy = False
                try:
                    self.start_btn.setEnabled(True)
                    self.once_btn.setEnabled(True)
                    self._set_start_button('stop' if self._resume_scan_after_action else 'start')
                    if self._resume_scan_after_action:
                        self.state.setText('● ПОВЕРНЕННЯ ДО КАТАЛОГУ…')
                    else:
                        self.state.setText('● КЛІКИ НАДІСЛАНО · ПЕРЕВІР ГРУ' if self._last_action_success else '● АВТОДІЮ ЗУПИНЕНО')
                    self._refresh_live_monitor()
                except Exception as exc:
                    self.logline(f'Не вдалося оновити стан після завершення потоку: {type(exc).__name__}: {exc}')
            else:
                # A thread exit without a handled terminal result is always a failure.
                # If no first card click was sent, do not leave a false dedupe lock behind.
                if self._active_purchase_attempt_key is not None and not self._active_purchase_click_sent:
                    self._purchase_offer_keys_attempted.discard(self._active_purchase_attempt_key)
                self._active_purchase_attempt_key = None
                self._active_purchase_click_sent = False
                self.action_in_progress = False
                self._continuous_scan_requested = False
                self._resume_scan_after_action = False
                self._active_purchase_candidate = None
                self._active_purchase_started = None
                self.running = False
                self.timer.stop()
                self.busy = False
                try:
                    self.start_btn.setEnabled(True)
                    self.once_btn.setEnabled(True)
                    self._set_start_button('start')
                    self.state.setText('● ПОМИЛКА АВТОДІЇ')
                    self.logline('Критична страховка: потік автодії завершився без обробленого результату. Покупка НЕ позначена як успішна; перевір гру вручну.')
                    self._restore_capture_window()
                except Exception:
                    pass
                self._scan_target_hwnd = None
                self._waiting_for_game_logged = False

        self.action_worker = None
        if self._resume_scan_after_action and self._action_result_handled:
            QTimer.singleShot(0, self._resume_continuous_scan_after_action)
        elif not self.action_in_progress:
            self._urgent_candidate_started = False

    def _resume_send_game_click(self, point, label):
        """Send one guarded post-action navigation click, never a purchase click."""
        try:
            actions = load_external_action_core()
            screen_size = tuple(self._physical_screen_size())
            expected_size = tuple(getattr(self, '_resume_market_screen_size', None) or ())
            if (len(expected_size) == 2 and all(int(v) > 0 for v in expected_size)
                    and screen_size != expected_size):
                self.logline(f'RESUME RECOVERY: {label} пропущено — роздільна здатність змінилася '
                              f'({expected_size[0]}×{expected_size[1]} → {screen_size[0]}×{screen_size[1]}).')
                return False
            if len(screen_size) != 2 or min(screen_size) <= 0:
                self.logline(f'RESUME RECOVERY: {label} пропущено — розмір екрана недоступний.')
                return False
            target = (getattr(self, '_resume_market_target_hwnd', None)
                      or getattr(self, '_scan_target_hwnd', None))
            foreground = int(self._foreground_window_handle() or 0)
            if (target in (None, 0, '0') or foreground <= 0
                    or not self._foreground_matches_game_target(target, foreground_hwnd=foreground)):
                self.logline(f'RESUME RECOVERY: {label} пропущено — гра не на передньому плані.')
                return False
            x, y = int(point[0]), int(point[1])
            if x < 0 or y < 0 or x >= screen_size[0] or y >= screen_size[1]:
                self.logline(f'RESUME RECOVERY: {label} пропущено — точка ({x},{y}) поза екраном.')
                return False
            # Use the currently foreground HWND after confirming it belongs to the same
            # game process; owned modal windows can have a different HWND than the root.
            clicker = actions.PurchaseWorker(
                (0, 0), screen_size, click_delay_ms=1, auto_confirm=False,
                target_hwnd=foreground, fast_coordinate_flow=False)
            sent = bool(clicker._click(x, y, expected_hwnd=foreground))
            if sent:
                self.logline(f'RESUME RECOVERY: {label} ({x},{y}) відправлено.')
            else:
                self.logline(f'RESUME RECOVERY: {label} не відправлено — перевірка фокуса/екрана не пройдена.')
            return sent
        except Exception as exc:
            self.logline(f'RESUME RECOVERY: {label} не вдалося виконати: {type(exc).__name__}: {exc}.')
            return False

    def _resume_continuous_scan_after_action(self):
        """Resume only after the catalog grid is visibly back; never OCR a modal/details page."""
        if not self._resume_scan_after_action:
            return
        remaining = float(getattr(self, '_resume_scan_not_before', 0.0) or 0.0) - time.monotonic()
        if remaining > 0:
            QTimer.singleShot(max(25, int(remaining * 1000)), self._resume_continuous_scan_after_action)
            return
        try:
            worker_active = bool(self.worker and self.worker.isRunning())
        except RuntimeError:
            worker_active = False
        try:
            badge_worker_active = bool(self.green_badge_worker and self.green_badge_worker.isRunning())
        except RuntimeError:
            badge_worker_active = False
        if (self.action_in_progress or self._action_worker_is_running() or worker_active
                or badge_worker_active or self.busy or self._scan_request_active):
            QTimer.singleShot(25, self._resume_continuous_scan_after_action)
            return

        now = time.monotonic()
        if not self._resume_market_wait_started:
            self._resume_market_wait_started = now
            self._resume_market_good_frames = 0
            self._resume_market_good_since = None
            self._resume_market_last_frame_token = None
            self._resume_market_last_state_logged = ''
            self._resume_market_back_attempted = False
            self._resume_market_cancel_attempts = 0
            self._resume_market_cancel_last_attempt_at = 0.0
            self._resume_market_confirm_started_at = 0.0
            self._resume_market_confirm_good_frames = 0
            self._resume_market_confirm_last_frame_token = None
            self.logline('RESUME GATE: чекаю на повернення каталогу; OCR не запускається поверх деталей або модального вікна.')

        # The probe is color/texture-only and reuses the persistent DXGI ROI. It performs
        # no OCR, sends no purchase click, and returns fresh cell evidence for 3x5 layout.
        try:
            core = load_external_scan_core()
            probe = core.probe_market_return_state(
                dict(self.settings.get('grid') or {}),
                target_hwnd=(getattr(self, '_resume_market_target_hwnd', None)
                             or getattr(self, '_scan_target_hwnd', None)))
        except Exception as exc:
            probe = {'state': 'unknown', 'reason': f'{type(exc).__name__}: {exc}',
                     'frame_timestamp': None, 'market_score': {}}
        state = str((probe or {}).get('state') or 'unknown')
        reason = str((probe or {}).get('reason') or '')
        if state == 'not_foreground' and not self._resume_focus_recovery_attempted:
            self._resume_focus_recovery_attempted = True
            target = (getattr(self, '_resume_market_target_hwnd', None)
                      or getattr(self, '_scan_target_hwnd', None))
            if self._restore_game_focus_for_resume_if_safe(target):
                self.logline('RESUME FOCUS RECOVERY: фокус був на самому сканері; повернув фокус грі й повторно перевіряю свіжий кадр каталогу.')
                QTimer.singleShot(60, self._resume_continuous_scan_after_action)
                return
        token = (probe or {}).get('frame_timestamp')

        # Log only state transitions to avoid flooding a fast log during the wait.
        if state != self._resume_market_last_state_logged:
            score = (probe or {}).get('market_score') or {}
            if state == 'market':
                detail = (f"grid evidence {score.get('image_like_cells', 0)}/15 thumbnails, "
                          f"{score.get('footer_like_cells', 0)}/15 footers")
            else:
                detail = reason
            self.logline(f'RESUME GATE: state={state}; {detail}.')
            self._resume_market_last_state_logged = state

        if state == 'market':
            # Require two newly presented frames and a small stable interval. Identical
            # timestamps do not count as new evidence when DXcam's ring buffer is reused.
            fresh = token is None or token != self._resume_market_last_frame_token
            if fresh:
                self._resume_market_last_frame_token = token
                if self._resume_market_good_frames == 0:
                    self._resume_market_good_since = now
                self._resume_market_good_frames += 1
            stable_for = (now - self._resume_market_good_since
                          if self._resume_market_good_since is not None else 0.0)
            if self._resume_market_good_frames >= 2 and stable_for >= 0.08:
                self._finish_continuous_resume_after_market_confirmed()
                return
        else:
            self._resume_market_good_frames = 0
            self._resume_market_good_since = None
            self._resume_market_last_frame_token = None

        waited = now - float(self._resume_market_wait_started or now)
        # Never navigate away when the catalog is already visible; simply wait for its
        # stability gate. A missing foreground must also reach the timeout guard below.
        if state in {'market', 'not_foreground'}:
            self._resume_market_confirm_started_at = 0.0
            self._resume_market_confirm_good_frames = 0
            self._resume_market_confirm_last_frame_token = None
        elif self._resume_after_purchase_navigation and state == 'confirm':
            # Do not compete with the just-sent FINAL_CONFIRM click or the game's UI
            # transition. Only dismiss a modal that remains visible after a grace period
            # and at least two fresh capture frames. This is navigation recovery only;
            # it never repeats any purchase click.
            if not self._resume_market_confirm_started_at:
                self._resume_market_confirm_started_at = now
                self._resume_market_confirm_good_frames = 0
                self._resume_market_confirm_last_frame_token = None
                self.logline('RESUME RECOVERY: модальне вікно ще видно; даю FINAL_CONFIRM час завершити перехід перед «Скасувати».')
            fresh_confirm_frame = (token is None or token != self._resume_market_confirm_last_frame_token)
            if fresh_confirm_frame:
                self._resume_market_confirm_last_frame_token = token
                self._resume_market_confirm_good_frames += 1
            confirm_stable_for = now - float(self._resume_market_confirm_started_at or now)
            confirm_stable = (
                confirm_stable_for >= POST_PURCHASE_CONFIRM_GRACE_SECONDS
                and self._resume_market_confirm_good_frames >= POST_PURCHASE_CONFIRM_MIN_FRESH_FRAMES
            )
            last_attempt = float(self._resume_market_cancel_last_attempt_at or 0.0)
            retry_due = (self._resume_market_cancel_attempts == 0
                         or (self._resume_market_cancel_attempts < 2 and now-last_attempt >= 0.65))
            if confirm_stable and retry_due:
                cancel_point = (probe or {}).get('cancel_button_center')
                if cancel_point is not None and len(cancel_point) >= 2:
                    self._resume_market_cancel_attempts += 1
                    self._resume_market_cancel_last_attempt_at = now
                    if self._resume_market_cancel_attempts == 1:
                        self.logline('RESUME RECOVERY: зелена кнопка підтвердження досі видима після паузи; пробую закрити діалог через «Скасувати». Результат покупки окремо не підтверджено.')
                    self._resume_send_game_click(cancel_point, 'CANCEL / «Скасувати»')
        elif self._resume_after_purchase_navigation and state in {'detail', 'unknown'}:
            # If the modal closed by itself, the detail page still needs its Back arrow.
            # Unknown-but-foreground states use a longer guard so we do not click during
            # an animation or through a modal that was not confidently identified.
            self._resume_market_confirm_started_at = 0.0
            self._resume_market_confirm_good_frames = 0
            self._resume_market_confirm_last_frame_token = None
            last_attempt = float(self._resume_market_cancel_last_attempt_at or 0.0)
            cancel_cooldown_done = not last_attempt or (now - last_attempt) >= 0.28
            minimum_wait = (POST_PURCHASE_UNKNOWN_BACK_MIN_WAIT_SECONDS if state == 'unknown'
                            else POST_PURCHASE_DETAIL_BACK_MIN_WAIT_SECONDS)
            if self._resume_market_cancel_attempts and not last_attempt:
                minimum_wait = max(minimum_wait, POST_PURCHASE_CONFIRM_GRACE_SECONDS)
            if (waited >= minimum_wait and cancel_cooldown_done
                    and not self._resume_market_back_attempted):
                try:
                    actions = load_external_action_core()
                    screen_size = tuple(self._physical_screen_size())
                    back_xy = actions.scale_reference_point(actions.BACK_MARKET, screen_size)
                    back_sent = self._resume_send_game_click(back_xy, 'BACK / стрілка «назад»')
                    if back_sent:
                        self._resume_market_back_attempted = True
                        self.logline('RESUME RECOVERY: клік «назад» відправлено після завершення попереднього кроку; очікую підтвердження каталогу перед скануванням.')
                except Exception as exc:
                    self.logline(f'RESUME RECOVERY: BACK не вдалося підготувати: {type(exc).__name__}: {exc}.')
        elif state == 'detail' and waited >= 2.5 and not self._resume_market_back_attempted:
            # Preserve the existing auto-refresh recovery behavior when the scan is
            # returning from tablet navigation rather than from a purchase.
            self._resume_market_back_attempted = True
            try:
                actions = load_external_action_core()
                screen_size = tuple(self._physical_screen_size())
                back_xy = actions.scale_reference_point(actions.BACK_MARKET, screen_size)
                self._resume_send_game_click(back_xy, 'AUTO-REFRESH BACK')
            except Exception as exc:
                self.logline(f'RESUME RECOVERY: не вдалося безпечно натиснути BACK: {type(exc).__name__}: {exc}.')

        if waited >= 12.0:
            was_auto_refresh = bool(self._auto_refresh_in_progress)
            self._resume_scan_after_action = False
            self._continuous_scan_requested = False
            self.running = False
            self.timer.stop()
            self.auto_refresh_timer.stop()
            self._auto_refresh_in_progress = False
            self._auto_refresh_pending = False
            self._auto_refresh_target_hwnd = None
            self._auto_refresh_screen_size = None
            self._set_start_button('start')
            self.start_btn.setEnabled(True)
            self.once_btn.setEnabled(True)
            self.state.setText('● КАТАЛОГ НЕ ПІДТВЕРДЖЕНО')
            self._restore_capture_window()
            score = (probe or {}).get('market_score') or {}
            timeout_prefix = ('AUTO-REFRESH TIMEOUT: після навігації вкладку «Транспорт» не підтверджено. ' if was_auto_refresh else 'RESUME GATE TIMEOUT: за 12 с каталог не підтверджено; ')
            self.logline(
                timeout_prefix + 'OCR не запускався поверх невідомого екрана. '
                'Переконайся, що ринок 3×5 відкритий, і натисни START. '
                f"Останній стан={state}, grid evidence={score.get('image_like_cells', 0)}/15 thumbnails / "
                f"{score.get('footer_like_cells', 0)}/15 footers."
            )
            self._scan_target_hwnd = None
            self._resume_market_target_hwnd = None
            self._resume_after_purchase_navigation = False
            self._resume_market_screen_size = None
            self._resume_market_confirm_started_at = 0.0
            self._resume_market_confirm_good_frames = 0
            self._resume_market_confirm_last_frame_token = None
            self._waiting_for_game_logged = False
            self._refresh_live_monitor()
            return
        QTimer.singleShot(100, self._resume_continuous_scan_after_action)

    def _finish_continuous_resume_after_market_confirmed(self):
        """Resume the pre-existing scan mode once two fresh catalog frames are confirmed."""
        if not self._resume_scan_after_action:
            return
        completed_auto_refresh = bool(self._auto_refresh_in_progress)
        self._auto_refresh_in_progress = False
        self._auto_refresh_pending = False
        self._auto_refresh_target_hwnd = None
        self._auto_refresh_screen_size = None
        self._auto_refresh_wait_reason = ''
        self._resume_scan_after_action = False
        self._resume_market_wait_started = 0.0
        self._resume_market_good_frames = 0
        self._resume_market_good_since = None
        self._resume_market_last_frame_token = None
        self._resume_market_last_state_logged = ''
        self._resume_market_back_attempted = False
        self._resume_focus_recovery_attempted = False
        self._resume_market_cancel_attempts = 0
        self._resume_market_cancel_last_attempt_at = 0.0
        self._resume_market_confirm_started_at = 0.0
        self._resume_market_confirm_good_frames = 0
        self._resume_market_confirm_last_frame_token = None
        self._resume_after_purchase_navigation = False
        self._resume_market_screen_size = None
        self._urgent_candidate_started = False
        self._continuous_scan_requested = True
        resume_target_hwnd = getattr(self, '_resume_market_target_hwnd', None)
        if resume_target_hwnd not in (None, 0, '0'):
            self._scan_target_hwnd = int(resume_target_hwnd)
        self._resume_market_target_hwnd = None
        if self._green_watch_mode and self.green_watch_worker is not None:
            self.running = True
            self.timer.stop()
            self.capture_hidden = True
            self.showMinimized()
            self.start_btn.setEnabled(True)
            self.once_btn.setEnabled(True)
            self._set_start_button('stop')
            self.state.setText('● DIRECT GREEN WATCH')
            self.logline('Каталог підтверджено на двох свіжих кадрах. DIRECT GREEN WATCH відновлено; картки та координати визначатимуться заново.')
            try:
                self.green_watch_worker.resume_after_action()
            except Exception as exc:
                self.logline(f'Не вдалося відновити DIRECT GREEN WATCH: {type(exc).__name__}: {exc}')
            self._refresh_live_monitor()
            return
        self.running = True
        self.timer.stop()
        self.start_btn.setEnabled(True)
        self.once_btn.setEnabled(True)
        self._set_start_button('stop')
        self.state.setText('● СКАНУЄ')
        if completed_auto_refresh:
            self.logline('AUTO-REFRESH УСПІШНО ЗАВЕРШЕНО: вкладку «Транспорт» підтверджено на двох свіжих кадрах; безперервний скан продовжується.')
            self._sync_auto_refresh_schedule(reset=True)
        else:
            self.logline('Каталог підтверджено на двох свіжих кадрах. Безперервний аналіз відновлено; координати 15 карток зчитуються заново, OCR-кеш зіставляє незмінені лоти за вмістом.')
            self._sync_auto_refresh_schedule(reset=True)
        self.once_btn.setEnabled(True)
        self._refresh_live_monitor()
        self.scan_once(hide_window=None)

    def on_action_result(self, success, message):
        """Handle result data but retain the action latch until the worker thread has exited."""
        # Never start grid OCR while a purchase dialog/details page may still be open.
        # Only resume after a successful flow or an explicitly confirmed BACK recovery.
        message_text = str(message)
        safe_recovery = '[RECOVERED_TO_MARKET]' in str(message)
        manual_confirm_pending = 'Фінальне підтвердження залишено вручну' in message_text
        fast_no_postcheck = '[FAST_FLOW_NO_POSTCHECK]' in message_text
        # A success/no-postcheck result means the click chain was sent even if the UI queued
        # the progress text later. Failures before CARD_CLICK must not poison dedupe for this offer.
        if success or fast_no_postcheck or ('CARD_CLICK' in message_text.upper() and 'SENT' in message_text.upper()):
            self._active_purchase_click_sent = True
            if self._active_purchase_attempt_key is not None:
                self._purchase_offer_keys_attempted.add(self._active_purchase_attempt_key)
        elif self._active_purchase_attempt_key is not None and not self._active_purchase_click_sent:
            self._purchase_offer_keys_attempted.discard(self._active_purchase_attempt_key)
            self.logline('AUTO-BUY RETRY ALLOWED: потік завершився до відправлення CARD_CLICK; пропозицію не позначено як спробувану.')
        if manual_confirm_pending:
            self._resume_scan_after_action = False
            self._continuous_scan_requested = False
            self.logline('Автосканування призупинено: фінальне підтвердження залишене вручну; після підтвердження повернись на ринок і запускай START.')
        elif fast_no_postcheck:
            # Keep continuous mode alive after the fast click chain, but allow a short UI
            # transition cooldown before starting the next scan. This does NOT verify purchase.
            self._resume_scan_not_before = time.monotonic() + 0.25
            if self._resume_scan_after_action:
                self.logline('Швидкі кліки відправлено. Через 250 мс почнеться OCR-free перевірка стану гри; повний аналіз відновиться лише після підтвердження каталогу, серверне підтвердження покупки цим не замінюється.')
            elif self._purchase_was_continuous_scan and not self.settings.get('continue_after_purchase', True):
                self.logline('Швидкі кліки відправлено. За налаштуванням «Продовжувати сканування після покупки» = ВИМКНЕНО сканер залишається зупиненим.')
            else:
                self.logline('Швидкі кліки відправлено в одноразовому режимі. Серверне підтвердження покупки не перевірялося; сканування автоматично не перезапускається.')
        elif not success and not safe_recovery:
            self._resume_scan_after_action = False
            self._continuous_scan_requested = False
            self.logline('Автосканування призупинено після невдалої автодії: не запускаю OCR поверх діалогу/сторінки деталей. Перевір гру та натисни START після повернення на ринок.')
            self.logline('Автосканування призупинено: фінальне підтвердження залишене вручну; після підтвердження повернись на ринок і запускай START.')
        self._sync_auto_refresh_schedule(reset=False)
        self._action_result_received = True
        self._action_result_handled = False
        candidate = dict(self._active_purchase_candidate or {})
        try:
            action_details = getattr(self.action_worker, 'validated_details', None)
            if isinstance(action_details, dict) and action_details.get('ok'):
                candidate.update(action_details)
                if isinstance(self._active_purchase_candidate, dict):
                    self._active_purchase_candidate.update(action_details)
        except Exception:
            pass
        elapsed_action = (time.monotonic() - self._active_purchase_started) if self._active_purchase_started is not None else None
        try:
            event_type = 'purchase_flow_sent' if success else 'purchase_flow_failed'
            self._queue_stats_event(event_type,
                                    model=str(candidate.get('catalog_model') or candidate.get('model') or ''),
                                    price_value=candidate.get('price_value'), discount_pct=candidate.get('discount_value'),
                                    workflow_seconds=round(elapsed_action, 6) if elapsed_action is not None else None,
                                    message=str(message)[:400])
            self._last_action_success = bool(success)
            self.logline(message)
        except Exception as exc:
            self._last_action_success = False
            try:
                self.logline(f'Помилка обробки результату автодії: {type(exc).__name__}: {exc}. Покупка не позначена як підтверджена.')
            except Exception:
                pass
        finally:
            # Do not clear action_in_progress or re-enable scan buttons here. QThread
            # emits finished_result from run() before its finally block completes; the
            # previous release could destroy the still-running QThread and crash Python.
            self._active_purchase_started = None
            self.running = bool(self._resume_scan_after_action)
            self.timer.stop()
            self.busy = False
            self._action_result_handled = True
            try:
                self.start_btn.setEnabled(False)
                self.once_btn.setEnabled(False)
                self._set_start_button('stop' if self._resume_scan_after_action else 'start')
                self.state.setText('● ПОВЕРНЕННЯ ДО КАТАЛОГУ…' if self._resume_scan_after_action else '● ЗАВЕРШЕННЯ АВТОДІЇ…')
                if not self._green_watch_mode and not self._resume_scan_after_action:
                    self._restore_capture_window()
                elif self._resume_scan_after_action:
                    self.capture_hidden = True
                    self.showMinimized()
            except Exception as exc:
                try:
                    self.logline(f'Помилка відновлення інтерфейсу після автодії: {type(exc).__name__}: {exc}')
                except Exception:
                    pass
            self._scan_target_hwnd = None
            if not self._resume_scan_after_action:
                self._resume_market_target_hwnd = None
            self._waiting_for_game_logged = False

    @staticmethod
    def _vehicle_snapshot_state(item):
        """Stable visible state for deciding when a card deserves a journal update."""
        def norm(value):
            return ' '.join(str(value if value is not None else '').split()).casefold()
        return (
            norm(item.get('model')), norm(item.get('catalog_model')),
            item.get('price_value'), norm(item.get('price')),
            item.get('discount_value'), norm(item.get('discount')),
            norm(item.get('discount_kind')), item.get('threshold'),
            norm(item.get('badge_color')), norm(item.get('status')),
            bool(item.get('eligible')), norm(item.get('name_text')),
            norm(item.get('price_text')), norm(item.get('badge_text')),
        )

    def _log_vehicle_snapshots(self, rows):
        """Log all 15 card results initially, then log a card again only when its data change."""
        messages = []
        current = {}
        for item in sorted(rows or [], key=lambda row: int(row.get('card', 999) or 999)):
            try:
                card_number = int(item.get('card', 0) or 0)
            except (TypeError, ValueError):
                continue
            if card_number <= 0:
                continue
            state = self._vehicle_snapshot_state(item)
            previous = self._last_logged_vehicle_snapshots.get(card_number)
            current[card_number] = state
            if previous == state:
                continue

            model = str(item.get('model') or '—')
            price = str(item.get('price') or 'Не прочитано')
            discount = str(item.get('discount') or '—')
            threshold = item.get('threshold')
            threshold_text = f'-{int(threshold)}%' if threshold is not None else '—'
            status = str(item.get('status') or 'Статус не задан')
            badge = str(item.get('badge_color') or 'UNKNOWN')
            prefix = 'КАРТКА' if previous is None else 'ОНОВЛЕННЯ КАРТКИ'
            messages.append(
                f'{prefix} {card_number:02d}/15: {model} · ціна {price} · знижка {discount} · '
                f'поріг {threshold_text} · бейдж {badge} · статус: {status}.'
            )

        # Keep positions that were present in a prior scan. If a row becomes empty, its
        # state change is logged once; the next listing in that slot will then be logged.
        self._last_logged_vehicle_snapshots = current
        self.loglines(messages)
        return len(messages)

    @staticmethod
    def _offer_log_key(item):
        """Stable identity for deduplicating the same visible listing across scan cycles."""
        def as_int(value):
            try:
                return int(value) if value is not None else None
            except (TypeError, ValueError):
                return None
        return (
            as_int(item.get('card')), str(item.get('catalog_model') or item.get('model') or ''),
            as_int(item.get('price_value')), as_int(item.get('discount_value')),
            as_int(item.get('threshold')),
        )

    def _log_offer_observations(self, rows):
        """Log newly visible eligible/blocked offers once until their state changes or disappears."""
        current_eligible = set()
        current_blocked = set()
        messages = []
        for item in rows:
            color = str(item.get('badge_color', 'UNKNOWN'))
            kind = str(item.get('discount_kind', 'none'))
            model = str(item.get('model') or '—')
            price = str(item.get('price') or 'Не прочитано')
            discount = str(item.get('discount') or '—')
            status = str(item.get('status') or 'Статус не задан')
            key = self._offer_log_key(item)

            if color == 'GREEN' and kind == 'discount' and item.get('discount_value') is not None:
                if bool(item.get('eligible')):
                    current_eligible.add(key)
                    if key not in self._seen_eligible_offer_keys:
                        messages.append(
                            f"ВИГІДНО: картка {item.get('card')} · {model} · {price} · {discount} · "
                            f"поріг -{item.get('threshold')}%."
                        )
                        self._queue_stats_event('offer_found', model=str(item.get('catalog_model') or model),
                                                price=str(price), price_value=item.get('price_value'),
                                                discount=str(discount), discount_pct=item.get('discount_value'),
                                                card=item.get('card'), threshold=item.get('threshold'))
                else:
                    current_blocked.add(key)
                    if key not in self._seen_blocked_discount_keys:
                        messages.append(
                            f"ЗНИЖКУ РОЗПІЗНАНО, АЛЕ АВТОКУПІВЛЮ НЕ ДОЗВОЛЕНО: "
                            f"картка {item.get('card')} · {model} · {price} · {discount}. "
                            f"Причина: {status}. Назва OCR='{item.get('name_text', '')}', "
                            f"ціна OCR='{item.get('price_text', '')}', бейдж OCR='{item.get('badge_text', '')}'."
                        )
            elif color == 'GREEN' and item.get('discount_value') is None:
                key = ('unreadable-green',) + key + (str(item.get('badge_text', '')),)
                current_blocked.add(key)
                if key not in self._seen_blocked_discount_keys:
                    messages.append(
                        f"УВАГА: зелений бейдж на картці {item.get('card')}, але відсоток не прочитано. "
                        f"Модель='{model}', бейдж OCR='{item.get('badge_text', '')}', статус: {status}."
                    )

        self._seen_eligible_offer_keys = current_eligible
        self._seen_blocked_discount_keys = current_blocked
        self.loglines(messages)

    def on_result(self, rows, error, elapsed):
        self._scan_result_received = True
        if self._urgent_candidate_started and self.action_in_progress:
            # The fast-lane handler already owns this transaction. Do not re-enable UI or
            # run the ordinary end-of-scan purchase selector while its click worker is active.
            self.busy = False
            return
        self.busy = False
        self.once_btn.setEnabled(True)
        self.start_btn.setEnabled(True)
        cancelled = (error == '__CANCELLED__')
        if error == '__FOCUS_LOST__':
            self.busy = False
            self.once_btn.setEnabled(True)
            self.start_btn.setEnabled(True)
            if self.running:
                self.state.setText('● ОЧІКУЄ НА ГРУ')
                if hasattr(self, 'live_status_label'):
                    self.live_status_label.setText('Очікує гру')
                    self.live_dot.setStyleSheet('color: #F1C875;')
                if not self._waiting_for_game_logged:
                    self.logline('Захоплення пропущено: фокус змінився на інше вікно. Повернись у гру — сканування продовжиться.')
                    self._waiting_for_game_logged = True
            else:
                self.state.setText('● ГОТОВИЙ')
                self._restore_capture_window()
                self._scan_target_hwnd = None
                self._waiting_for_game_logged = False
                self.logline('Разове сканування пропущено: активне вікно змінилося; дані не оновлювалися.')
            return
        if error and not cancelled:
            self.running = False
            self._continuous_scan_requested = False
            self.timer.stop()
            self._set_start_button('start')
            self.state.setText('● ПОМИЛКА')
            self._restore_capture_window()
            self._scan_target_hwnd = None
            self._waiting_for_game_logged = False
            self.logline('Помилка сканування; безперервний режим зупинено: ' + error.splitlines()[0])
            self.logline('Деталі: ' + error.replace('\n', ' | ')[:900])
            self._refresh_live_monitor()
            self.live_status_label.setText('Помилка')
            self.live_dot.setStyleSheet('color: #F18C96;')
            return

        rows = list(rows or [])
        if not cancelled:
            self._log_vehicle_snapshots(rows)
            self._log_offer_observations(rows)
        # On an unchanged market frame, the OCR core returns exact cached rows.
        # Avoid destroying/rebuilding 15 table rows and appending another log entry
        # every 100 ms; candidate handling below still runs on these validated rows.
        cache_only = bool(rows and len(rows) == 15 and all(x.get('_cache_hit') for x in rows)
                          and len(self.last) == 15)
        self.last = rows
        worker = self.worker
        if not cancelled:
            self._record_performance_measurement(elapsed, worker)
        recognized = sum(1 for x in self.last if x.get('model') not in ('', '—', None))
        eligible = sum(1 for x in self.last if bool(x.get('eligible')))
        self._queue_stats_event(
            'scan_cycle', cards=len(self.last), recognized=recognized, eligible=eligible,
            unknown=max(0, len(self.last)-recognized), elapsed=float(elapsed),
            ocr_seconds=float(getattr(worker, '_ocr_elapsed_seconds', 0.0) or 0.0) if worker is not None else 0.0,
            ocr_calls=int(getattr(worker, '_ocr_call_count', 0) or 0) if worker is not None else 0,
            cache_hits=int(getattr(worker, '_cache_hits', 0) or 0) if worker is not None else 0,
        )
        green_count = sum(1 for x in self.last if str(x.get('badge_color', '')).upper() == 'GREEN')
        self._last_green_count = green_count
        self.kpi_values[0].setText(str(len(self.last)))
        self.kpi_values[1].setText(str(recognized))
        self.kpi_values[2].setText(str(green_count))
        self.kpi_values[3].setText(str(eligible))
        self.kpi_values[4].setText(f'{elapsed:.2f} с')
        self._refresh_live_monitor()
        if not cache_only:
            self.refresh_vehicle_gallery()
        self.found_badge.setText(f'Знайдено: {recognized}')
        self.match_badge.setText(f'Відповідають: {eligible}')
        if not cache_only:
            self.results_table.setRowCount(0)
        from PySide6.QtGui import QColor
        for item in ([] if cache_only else self.last):
            r = self.results_table.rowCount()
            self.results_table.insertRow(r)
            threshold = item.get('threshold')
            threshold_text = f"-{int(threshold)}%" if threshold is not None else '—'
            vals = [str(item.get('card', r + 1)), '', item.get('model', '—'),
                    item.get('price', 'Не прочитано'), item.get('discount', '—'),
                    threshold_text, item.get('status', 'Перевірка')]
            for c, value in enumerate(vals):
                cell = QTableWidgetItem(value)
                cell.setFlags(cell.flags() & ~Qt.ItemIsEditable)
                if c == 1:
                    cell.setTextAlignment(Qt.AlignCenter)
                    render_model = item.get('catalog_model') or ''
                    render_path, image_source = vehicle_image_path(render_model) if render_model else (None, 'none')
                    if render_path:
                        cell.setIcon(QIcon(QPixmap(str(render_path)).scaled(56, 34, Qt.KeepAspectRatio, Qt.SmoothTransformation)))
                        cell.setToolTip('Власне фото користувача' if image_source == 'custom' else ('Локальне ліцензійне фото' if image_source == 'photo' else ('Референс схожого кузова; не точна модель' if image_source == 'approximate' else ('Ілюстративне зображення моделі' if render_path and Path(render_path).suffix.lower() == '.png' else 'Зображення моделі'))))
                    else:
                        cell.setText('—')
                        cell.setForeground(QColor('#7c8c99'))
                elif c == 4:
                    kind = item.get('discount_kind')
                    if kind == 'discount':
                        cell.setForeground(QColor('#31f59a'))
                    elif kind == 'markup':
                        cell.setForeground(QColor('#ff647c'))
                elif c == 6:
                    if item.get('eligible'):
                        cell.setForeground(QColor('#31f59a'))
                    elif item.get('discount_kind') == 'markup':
                        cell.setForeground(QColor('#ff647c'))
                    elif any(word in str(value).lower() for word in ('не прочит', 'не розпізн', 'не визнач', 'поза каталогом')):
                        cell.setForeground(QColor('#f4c76b'))
                if c == 2:
                    cell.setToolTip(
                        f"OCR: {item.get('name_text', '')}\n"
                        f"Зіставлення з каталогом: {item.get('catalog_model') or 'немає'}\n"
                        f"Впевненість збігу: {item.get('model_confidence', 0)}"
                    )
                elif c == 3:
                    cell.setToolTip(f"Текст ціни OCR: {item.get('price_text', '')}")
                elif c == 4:
                    cell.setToolTip(
                        f"Колір бейджа: {item.get('badge_color', 'UNKNOWN')}\n"
                        f"Текст бейджа OCR: {item.get('badge_text', '')}"
                    )
                self.results_table.setItem(r, c, cell)
            self.results_table.setRowHeight(r, 48)

        if cancelled:
            self.running = False
            self.timer.stop()
            self._set_start_button('start')
            self.state.setText('● ЗУПИНЕНО')
            self.logline(f'Сканування зупинено. Показано оброблених карток: {len(self.last)}/15.')
            self._restore_capture_window()
            self._scan_target_hwnd = None
            self._waiting_for_game_logged = False
            self.refresh_stats()
            self._refresh_live_monitor()
            return

        if not cancelled:
            self._scan_cycle_number += 1
            worker = self.worker
            cache_debug = getattr(worker, '_cache_debug', {}) if worker is not None else {}
            cache_hits = getattr(worker, '_cache_hits', 0) if worker is not None else 0
            changed_cards = getattr(worker, '_changed_cards', 15) if worker is not None else 15
            ocr_calls = getattr(worker, '_ocr_call_count', 0) if worker is not None else 0
            changed_fields = getattr(worker, '_changed_field_counts', {}) if worker is not None else {}
            green_discounts = sum(
                1 for row in self.last
                if row.get('badge_color') == 'GREEN' and row.get('discount_kind') == 'discount'
                and row.get('discount_value') is not None
            )
            cache_valid = cache_debug.get('valid', 'unknown') if isinstance(cache_debug, dict) else 'unknown'
            cycle_label = 'ПОВІЛЬНИЙ ЦИКЛ' if elapsed >= 1.0 else 'ЦИКЛ'
            self.logline(
                f'{cycle_label} #{self._scan_cycle_number}: аналіз {elapsed:.2f} с · '
                f'карток {len(self.last)}/15 · моделей {recognized}/15 · знижок {green_discounts} · '
                f'вигідних {eligible} · OCR-пакетів {ocr_calls} · кеш {cache_hits}/15 · '
                f'змінено карток {changed_cards} · кеш valid={cache_valid} · полів {changed_fields}.'
            )
            if elapsed >= 1.0 and worker is not None:
                stage_map = getattr(worker, '_last_stage_seconds', {}) or {}
                slow_stages = sorted(
                    ((str(k), float(v)) for k, v in stage_map.items()
                     if isinstance(v, (int, float)) and k != 'total' and not str(k).endswith('_calls')),
                    key=lambda pair: pair[1], reverse=True
                )[:4]
                stage_text = ', '.join(f'{name}={seconds:.2f}s' for name, seconds in slow_stages) or 'етапи не збережені'
                stage_info = getattr(worker, '_last_stage_info', {}) or {}
                backend = stage_info.get('capture_backend', 'невідомо')
                providers = ','.join(getattr(worker, '_last_ocr_active_providers', []) or []) or 'не визначено'
                init_s = float(getattr(worker, '_last_ocr_engine_init_seconds', 0.0) or 0.0)
                warm_s = float(getattr(worker, '_last_ocr_engine_warmup_seconds', 0.0) or 0.0)
                self.logline(f'ПРОФІЛЬ ПОВІЛЬНОГО ЦИКЛУ: {stage_text}; capture={backend}; OCR init={init_s:.2f}s; warmup={warm_s:.2f}s; providers={providers}.')
            self.refresh_stats()

        # Auto-actions are considered only for high-confidence matches and strictly
        # positive discounts; price/threshold/model selection were checked by OCR core.
        blacklisted_now = (load_blacklist_models(self.all_models)
                           if self.settings.get('blacklist_protection_enabled', True) else set())
        confidence_floor = 0.93 if self.settings.get('confidence_protection_enabled', True) else 0.80
        candidates = []
        for item in self.last:
            try:
                confidence = float(item.get('model_confidence') or 0.0)
                model_name = str(item.get('catalog_model') or '')
                if (item.get('eligible') and item.get('discount_kind') == 'discount'
                        and item.get('badge_color') == 'GREEN'
                        and item.get('price_value') is not None and item.get('threshold') is not None
                        and model_name and confidence >= confidence_floor and model_name not in blacklisted_now
                        and item.get('xy') is not None and item.get('screen_size') is not None):
                    candidates.append(item)
            except (AttributeError, TypeError, ValueError, IndexError) as exc:
                self.logline(f'Автодію пропущено через некоректні поля OCR-картки: {type(exc).__name__}: {exc}.')
        def _candidate_card_order(item):
            try:
                return int(item.get('card', 99) or 99)
            except (TypeError, ValueError):
                return 99
        candidates.sort(key=_candidate_card_order)
        auto_click_enabled = bool(self.settings.get('auto_click', False))
        interesting_rows = [
            item for item in self.last
            if str(item.get('badge_color', '')).upper() == 'GREEN'
            and item.get('discount_kind') == 'discount'
            and item.get('discount_value') is not None
        ]
        if not auto_click_enabled:
            for item in interesting_rows:
                if item.get('eligible'):
                    self._log_purchase_skip_once(item, 'автокупівлю вимкнено в налаштуваннях (auto-click)')
        elif not candidates:
            for item in interesting_rows:
                reason = self._purchase_gate_reason(item, blacklisted_now, confidence_floor)
                self._log_purchase_skip_once(item, reason)
        if auto_click_enabled and candidates:
            fresh_candidates = []
            for candidate in candidates:
                key = self._purchase_attempt_key(candidate)
                if key not in self._purchase_offer_keys_attempted:
                    fresh_candidates.append(candidate)
                else:
                    self._log_purchase_skip_once(candidate, 'ця сама видима пропозиція вже отримувала спробу купівлі в цьому сеансі; повторний клік заблоковано')
            candidates = fresh_candidates
        if self.settings.get('auto_click', False) and candidates:
            # Stop the poll loop before performing one transaction; same price/discount
            # offer is attempted only once per app session to prevent accidental duplicate purchases.
            self.running = False
            self.timer.stop()
            self._set_start_button('start')
            self._refresh_live_monitor()
            if not self._start_purchase_action(candidates[0]):
                self._continuous_scan_requested = False
                self._resume_scan_after_action = False
                self.running = False
                self.timer.stop()
                self.action_in_progress = False
                self._set_start_button('start')
                self.state.setText('● АВТОДІЮ ЗАБЛОКОВАНО')
                self._restore_capture_window()
                self._scan_target_hwnd = None
                self._waiting_for_game_logged = False
                self._refresh_live_monitor()
            return

        self._set_start_button('stop' if self.running else 'start')
        self.state.setText('● СКАНУЄ' if self.running else '● ГОТОВИЙ')
        self._refresh_live_monitor()
        # Keep the scanner hidden for every continuous scan on the primary monitor,
        # regardless of auto-click state. Ctrl+Alt+F8 stops scanning and restores the UI.
        if not self.running:
            self._restore_capture_window()
            self._scan_target_hwnd = None
            self._waiting_for_game_logged = False
        # The next cycle is scheduled only in _finalize_scan_worker_finished().

    def _stats_events_for_period(self):
        all_events = list(getattr(self, '_stats_events', []))
        period = self.stats_period_combo.currentText() if hasattr(self, 'stats_period_combo') else '7 днів'
        now = datetime.now()
        if period == 'Сьогодні':
            cutoff = now.replace(hour=0, minute=0, second=0, microsecond=0)
        elif period == '30 днів':
            cutoff = now - __import__('datetime').timedelta(days=30)
        elif period == 'Увесь час':
            cutoff = None
        else:
            cutoff = now - __import__('datetime').timedelta(days=7)
        selected = []
        for event in all_events:
            try:
                stamp = datetime.fromisoformat(str(event.get('ts', '')))
            except Exception:
                continue
            if cutoff is None or stamp >= cutoff:
                selected.append(event)
        return selected, period

    @staticmethod
    def _stats_average(values):
        values = [float(v) for v in values if v is not None]
        return (sum(values) / len(values)) if values else None

    def _update_rank_tables(self, events):
        offers, actions, confirmed, discounts = {}, {}, {}, {}
        for event in events:
            model = str(event.get('model') or '').strip()
            if not model:
                continue
            typ = event.get('type')
            if typ == 'offer_found':
                offers[model] = offers.get(model, 0) + 1
                try:
                    d = float(event.get('discount_pct') or 0)
                    discounts.setdefault(model, []).append(abs(d))
                except (TypeError, ValueError):
                    pass
            elif typ == 'purchase_flow_sent':
                actions[model] = actions.get(model, 0) + 1
            elif typ == 'purchase_confirmed':
                confirmed[model] = confirmed.get(model, 0) + 1
        models = set(offers) | set(actions) | set(confirmed)
        ranking = sorted(models, key=lambda m: (offers.get(m, 0), confirmed.get(m, 0), actions.get(m, 0), m.casefold()), reverse=True)
        if hasattr(self, 'stats_rank_table'):
            table = self.stats_rank_table; table.setRowCount(0)
            for model in ranking[:12]:
                r = table.rowCount(); table.insertRow(r)
                for c, value in enumerate([model, str(offers.get(model, 0)), str(actions.get(model, 0)), str(confirmed.get(model, 0))]):
                    table.setItem(r, c, QTableWidgetItem(value))
        if hasattr(self, 'top_table'):
            table = self.top_table; table.setRowCount(0)
            for idx, model in enumerate(ranking[:30], start=1):
                r = table.rowCount(); table.insertRow(r)
                avg_discount = self._stats_average(discounts.get(model, []))
                values = [str(idx), model, str(offers.get(model, 0)), str(actions.get(model, 0)), str(confirmed.get(model, 0)), f'{avg_discount:.1f}%' if avg_discount is not None else '—']
                for c, value in enumerate(values):
                    cell = QTableWidgetItem(value); cell.setFlags(cell.flags() & ~Qt.ItemIsEditable); table.setItem(r, c, cell)
                table.setRowHeight(r, 32)
        return offers, actions, confirmed

    def _fill_purchase_dynamics(self, events, period):
        if not hasattr(self, 'stats_purchase_chart'):
            return
        # All-time now aggregates the entire retained event history rather than silently
        # showing only the last 30 days. The helper caps chart density at 60 points.
        self.stats_purchase_chart.title = f'Динаміка підтверджених покупок · {period}'
        self.stats_purchase_chart.set_values(purchase_dynamics_series(events, period))

    def refresh_stats(self):
        if not hasattr(self, 'stats_cards'):
            return
        self._refresh_performance_widgets()
        recognized = sum(1 for x in self.last if x.get('model') not in ('', '—', None))
        eligible = sum(1 for x in self.last if bool(x.get('eligible')))
        unknown = max(0, len(self.last) - recognized)
        events, period = self._stats_events_for_period()
        scan_events = [e for e in events if e.get('type') == 'scan_cycle']
        offers_events = [e for e in events if e.get('type') == 'offer_found']
        action_events = [e for e in events if e.get('type') == 'purchase_flow_sent']
        failed_events = [e for e in events if e.get('type') == 'purchase_flow_failed']
        confirmed_events = [e for e in events if e.get('type') == 'purchase_confirmed']
        total_checked = sum(int(e.get('cards') or 0) for e in scan_events)
        avg_cycle = self._stats_average([e.get('elapsed') for e in scan_events])
        avg_ocr = self._stats_average([e.get('ocr_seconds') for e in scan_events if float(e.get('ocr_seconds') or 0) > 0])
        total_savings = sum(float(e.get('estimated_savings') or 0) for e in confirmed_events)
        click_ms = int(self.settings.get('click_delay_ms', 1) or 1)
        values = {
            'cards': str(len(self.last)), 'recognized': str(recognized), 'eligible': str(eligible), 'unknown': str(unknown),
            'checked_total': f'{total_checked:,}'.replace(',', ' '), 'offers_total': f'{len(offers_events):,}'.replace(',', ' '),
            'actions_sent': str(len(action_events)), 'confirmed': str(len(confirmed_events)), 'failed': str(len(failed_events)),
            'avg_cycle': f'{avg_cycle:.3f} с' if avg_cycle is not None else 'Немає даних',
            'avg_ocr': f'{avg_ocr:.3f} с' if avg_ocr is not None else 'Немає даних',
            'click_speed': f'{click_ms} мс', 'savings': f'${total_savings:,.0f}'.replace(',', ' ') if confirmed_events else 'Не визначено',
        }
        for key, value in values.items():
            label = self.stats_cards.get(key)
            if label is not None: label.setText(value)
        offers, actions, confirmed = self._update_rank_tables(events)
        self._fill_purchase_dynamics(events, period)
        if hasattr(self, 'top_summary_values'):
            self.top_summary_values['offers'].setText(str(len(offers_events)))
            self.top_summary_values['actions'].setText(str(len(action_events)))
            self.top_summary_values['confirmed'].setText(str(len(confirmed_events)))
            self.top_summary_values['savings'].setText(f'${total_savings:,.0f}'.replace(',', ' ') if confirmed_events else '—')

        total_recognized = sum(int(e.get('recognized') or 0) for e in scan_events)
        total_possible = sum(int(e.get('cards') or 0) for e in scan_events)
        recognition_rate = (100.0 * total_recognized / total_possible) if total_possible else None
        cache_hits = sum(int(e.get('cache_hits') or 0) for e in scan_events)
        ocr_calls = sum(int(e.get('ocr_calls') or 0) for e in scan_events)
        click_time_values = [float(e.get('workflow_seconds')) for e in action_events if e.get('workflow_seconds') is not None]
        avg_action = self._stats_average(click_time_values)
        category_counts = {}
        for item in self.last:
            if item.get('model') not in ('', '—', None):
                category = str(item.get('category') or 'Без категорії')
                category_counts[category] = category_counts.get(category, 0) + 1
        top_three = sorted(offers.items(), key=lambda kv: kv[1], reverse=True)[:3]
        lines = [
            f'Період: {period}. Історичних подій у вибраному періоді: {len(events)}.',
            f'Циклів сканування: {len(scan_events)}; разом перевірено карток: {total_checked:,}'.replace(',', ' '),
            f'Розпізнавання за історією: {recognition_rate:.1f}%' if recognition_rate is not None else 'Розпізнавання за історією: ще немає циклів.',
            f'Незмінені картки взято з кешу: {cache_hits}; OCR-виклики: {ocr_calls}.',
            f'Середній час циклу: {avg_cycle:.4f} с' if avg_cycle is not None else 'Середній час циклу: немає вимірів.',
            f'Середній час OCR: {avg_ocr:.4f} с (лише цикли з реальним OCR)' if avg_ocr is not None else 'Середній час OCR: немає реальних вимірів.',
            f'Середня тривалість відправлення кліків: {avg_action:.4f} с' if avg_action is not None else 'Середня тривалість автодії: поки немає завершених послідовностей.',
            f'Автоклік: {"увімкнений" if self.settings.get("auto_click") else "вимкнений"}; фінальне підтвердження: {"увімкнене" if self.settings.get("auto_confirm") else "вимкнене"}; затримка між натисканнями: {click_ms} мс.',
            f'OCR backend: {self._last_backend}; останній вимір OCR: {self._last_actual_ocr_seconds:.4f} с' if self._last_actual_ocr_seconds is not None else f'OCR backend: {self._last_backend}; час OCR ще не виміряно.',
            f'Дій кліку надіслано: {len(action_events)}; невдалих послідовностей: {len(failed_events)}; серверно/явно підтверджених покупок: {len(confirmed_events)}.',
            f'Оціночна економія: ${total_savings:,.0f}'.replace(',', ' ') if confirmed_events else 'Оціночна економія рахується лише для записів із ціною та відсотком знижки з явного підтвердження.',
            '', 'Найчастіші моделі у вигідних пропозиціях:'
        ]
        lines += [f'• {model}: {count} появ' for model, count in top_three] or ['• У вибраному періоді ще не зафіксовано вигідних появ.']
        lines += ['', 'Категорії в останньому циклі:']
        lines += [f'• {category}: {count}' for category, count in sorted(category_counts.items())] or ['• Немає розпізнаних моделей.']
        if hasattr(self, 'stats_summary'):
            self.stats_summary.setPlainText('\n'.join(lines))

    def export_stats_csv(self):
        path, _ = QFileDialog.getSaveFileName(self, 'Експорт історії статистики', 'NG_Market_Scanner_statistics.csv', 'CSV файли (*.csv)')
        if not path:
            return
        try:
            import csv
            fields = ['ts', 'type', 'model', 'price_value', 'discount_pct', 'estimated_savings', 'cards', 'recognized', 'eligible', 'elapsed', 'ocr_seconds', 'ocr_calls', 'cache_hits', 'workflow_seconds', 'message']
            with Path(path).open('w', encoding='utf-8-sig', newline='') as handle:
                writer = csv.DictWriter(handle, fieldnames=fields, extrasaction='ignore')
                writer.writeheader()
                writer.writerows(self._stats_events)
            self.logline(f'Історію статистики експортовано: {Path(path).name}.')
        except Exception as exc:
            QMessageBox.critical(self, 'Експорт статистики', f'Не вдалося експортувати CSV: {type(exc).__name__}: {exc}')

    def closeEvent(self, event):
        self.timer.stop()
        if hasattr(self, 'auto_refresh_timer'):
            self.auto_refresh_timer.stop()
        self._auto_refresh_sequence_id += 1
        self._auto_refresh_in_progress = False
        self._auto_refresh_pending = False
        if hasattr(self, 'hotkey_timer'):
            self.hotkey_timer.stop()
        self.running = False
        self._continuous_scan_requested = False
        self._resume_scan_after_action = False
        self._green_watch_mode = False
        if self.green_badge_worker and self.green_badge_worker.isRunning():
            try: self.green_badge_worker.cancel()
            except Exception: pass
            self.green_badge_worker.wait(1500)
        if self.green_watch_worker and self.green_watch_worker.isRunning():
            try: self.green_watch_worker.cancel()
            except Exception: pass
            if not self.green_watch_worker.wait(2000):
                event.ignore(); self.showNormal(); self.raise_()
                self.logline('Закриття відкладено: потік DIRECT GREEN WATCH ще завершує захоплення кадрів.')
                return
        if self.ocr_warmup_worker and self.ocr_warmup_worker.isRunning():
            self.ocr_warmup_worker.wait()
        if self.worker and self.worker.isRunning():
            try:
                self.worker.cancel()
            except Exception:
                pass
            self.worker.wait(5000)
        if self.action_worker and self.action_worker.isRunning():
            active_action = self.action_worker
            try:
                active_action.cancel()
            except Exception:
                pass
            if not active_action.wait(3000):
                event.ignore()
                self.showNormal()
                self.raise_()
                self.logline('Закриття відкладено: потік автодії ще завершується. Натискання/очікування скасовано; дочекайся повідомлення та закрий вікно повторно.')
                return
        self._flush_stats_history()
        event.accept()





if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setFont(QFont('Segoe UI', 10))
    if ICON_PATH.is_file():
        app.setWindowIcon(QIcon(str(ICON_PATH)))
    win = Main(); win.showMaximized()
    sys.exit(app.exec())
