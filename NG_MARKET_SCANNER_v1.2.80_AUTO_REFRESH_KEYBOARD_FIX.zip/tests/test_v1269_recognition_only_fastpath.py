import sys
import time
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

# Keep the unit tests runnable in the Linux packaging sandbox, which does not
# ship PySide6. Production still uses the real PySide6 classes on Windows.
try:
    import PySide6.QtCore  # noqa: F401
except ImportError:
    import types as _types
    import sys as _sys
    class _Signal:
        def __init__(self, *args, **kwargs): self._callbacks=[]
        def connect(self, callback): self._callbacks.append(callback)
        def emit(self, *args):
            for callback in tuple(self._callbacks): callback(*args)
    class _QThread:
        def __init__(self, *args, **kwargs): pass
        def start(self): self.run()
        def wait(self, *args, **kwargs): return True
        def isRunning(self): return False
    _qtcore = _types.ModuleType("PySide6.QtCore")
    _qtcore.QThread = _QThread
    _qtcore.Signal = _Signal
    _pyside = _types.ModuleType("PySide6")
    _pyside.QtCore = _qtcore
    _sys.modules.setdefault("PySide6", _pyside)
    _sys.modules.setdefault("PySide6.QtCore", _qtcore)
import scanner_core

ROOT = Path(__file__).resolve().parents[1]


class _RecOutput:
    def __init__(self, texts, scores):
        self.txts = tuple(texts)
        self.scores = tuple(scores)


class _UnderlyingRecognitionEngine:
    def __init__(self, texts, scores):
        self._texts = list(texts)
        self._scores = list(scores)
        self.loaded = False
        self.input_shapes = None

    def _load_rec_model(self):
        self.loaded = True

    def recognize_txt(self, images):
        self.input_shapes = [tuple(image.shape) for image in images]
        return _RecOutput(self._texts, self._scores)


class RecognitionOnlyFastpathV1269Tests(unittest.TestCase):
    def test_adapter_batches_known_rois_without_calling_detector(self):
        underlying = _UnderlyingRecognitionEngine(["-27%", "$8 500"], [0.98, 0.97])
        adapter = scanner_core._RapidOCRAdapter(underlying)
        images = [np.full((32, 100, 3), 20, np.uint8), np.full((40, 120, 3), 20, np.uint8)]
        result, elapsed = adapter.recognize_crops(images)
        self.assertTrue(underlying.loaded)
        self.assertEqual(result, [("-27%", 0.98), ("$8 500", 0.97)])
        self.assertEqual(len(underlying.input_shapes), 2)
        self.assertGreaterEqual(elapsed, 0.0)

    def test_known_crop_prep_trims_empty_background_and_normalizes_height(self):
        image = np.full((60, 420, 3), (18, 20, 22), np.uint8)
        image[15:45, 40:170] = (245, 245, 245)
        prepared = scanner_core._prepare_known_text_crop(image, "name", target_height=48)
        self.assertIsNotNone(prepared)
        self.assertEqual(prepared.shape[0], 48)
        self.assertLess(prepared.shape[1], image.shape[1])
        self.assertTrue(prepared.flags.c_contiguous)

    def test_unsupported_engine_uses_safe_detector_fallback_signal(self):
        image = np.full((40, 120, 3), 20, np.uint8)
        result, elapsed = scanner_core._recognize_known_roi_batch(lambda _image: ([], 0.0), [image], "badge")
        self.assertIsNone(result)
        self.assertGreaterEqual(elapsed, 0.0)

    def test_detail_validator_uses_recognition_only_when_three_lines_are_confident(self):
        core = scanner_core
        with core._WATCH_DETAIL_FRAME_LOCK:
            old_frame, old_meta, old_last = core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT
        now = time.perf_counter()
        try:
            frame = np.zeros((907, 1665, 3), dtype=np.uint8)
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME = frame
                core._WATCH_DETAIL_FRAME_META = {"captured_at": now, "screen_size": (1920, 1080),
                                                 "origin": (255, 81), "target_hwnd": None}
                core._WATCH_DETAIL_FRAME_LAST_COPY_AT = now
            class DirectEngine:
                def __call__(self, _image):
                    raise AssertionError("detector fallback should not be called for confident line ROIs")
                def recognize_crops(self, _images):
                    return [
                        ("Karin Land Cruiser 100", .99),
                        ("Ціна: $8 500", .99),
                        ("Хороша ціна: -27% до ринку ($11 651)", .99),
                    ], .003
            fake_mss = types.SimpleNamespace(mss=lambda: (_ for _ in ()).throw(AssertionError("MSS should not be used")))
            with patch.dict(sys.modules, {"mss": fake_mss}), \
                 patch.object(core, "_foreground_matches_target", return_value=True), \
                 patch.object(core, "_get_ocr_engine", return_value=DirectEngine()):
                result = core.validate_market_detail_screen(
                    ["Karin Land Cruiser 100"], ["Karin Land Cruiser 100"],
                    {"Karin Land Cruiser 100": {"category": "Звичайне"}}, 20, {}, set(), 27,
                    target_hwnd=None, confidence_floor=.93, detail_frame_not_before=now-.01)
            self.assertTrue(result["ok"], result["reason"])
            self.assertEqual(result["detail_ocr_mode"], "recognition-only-batch")
            self.assertEqual(result["discount_value"], 27)
            self.assertEqual(result["market_reference_price_value"], 11651)
        finally:
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT = old_frame, old_meta, old_last

    def test_badge_evidence_conflict_fails_closed_but_consistent_batch_keeps_discount(self):
        candidate = {"card_index": 1, "badge_crop": np.full((24, 80, 3), 20, np.uint8)}
        conflict = scanner_core._resolve_discount_ocr_evidence(candidate, [
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .98},
            {"discount_value": 22, "badge_ocr_text": "-22%", "badge_ocr_confidence": .87},
        ])
        self.assertIsNone(conflict["discount_value"])
        self.assertTrue(conflict["badge_ocr_conflict"])
        consistent = scanner_core._resolve_discount_ocr_evidence(candidate, [
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .65},
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .94},
        ])
        self.assertEqual(consistent["discount_value"], 27)
        self.assertEqual(consistent["badge_ocr_confidence"], .94)

    def test_three_badge_reads_use_clear_two_of_three_consensus_only(self):
        candidate = {"card_index": 3, "badge_crop": np.full((22, 65, 3), 25, np.uint8)}
        consensus = scanner_core._resolve_discount_ocr_evidence(candidate, [
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .95, "badge_ocr_source": "direct"},
            {"discount_value": 22, "badge_ocr_text": "-22%", "badge_ocr_confidence": .92, "badge_ocr_source": "enhanced"},
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .88, "badge_ocr_source": "detector"},
        ])
        self.assertEqual(consensus["discount_value"], 27)
        self.assertFalse(consensus["badge_ocr_conflict"])
        tied = scanner_core._resolve_discount_ocr_evidence(candidate, [
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .98},
            {"discount_value": 22, "badge_ocr_text": "-22%", "badge_ocr_confidence": .99},
        ])
        self.assertIsNone(tied["discount_value"])
        self.assertTrue(tied["badge_ocr_conflict"])
        four_reads = scanner_core._resolve_discount_ocr_evidence(candidate, [
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .98},
            {"discount_value": 27, "badge_ocr_text": "-27%", "badge_ocr_confidence": .95},
            {"discount_value": 22, "badge_ocr_text": "-22%", "badge_ocr_confidence": .92},
            {"discount_value": 21, "badge_ocr_text": "-21%", "badge_ocr_confidence": .88},
        ])
        self.assertIsNone(four_reads["discount_value"], "2-of-4 is not sufficient consensus")
        self.assertTrue(four_reads["badge_ocr_conflict"])

    def test_batch_badge_worker_uses_recognition_only_for_confident_badges(self):
        candidates = [
            {"card_index": 0, "badge_crop": np.full((22, 65, 3), 25, np.uint8)},
            {"card_index": 1, "badge_crop": np.full((22, 65, 3), 25, np.uint8)},
        ]
        class DirectEngine:
            def __call__(self, _image):
                raise AssertionError("high-confidence known badges should skip detector OCR")
            def recognize_crops(self, images):
                self.seen = len(images)
                return [("-18%", .96), ("-31%", .97)], .002
        engine = DirectEngine()
        captured = {}
        worker = scanner_core.GreenBadgeBatchWorker(candidates)
        class LocalSignal:
            def __init__(self): self._callback = None
            def connect(self, callback): self._callback = callback
            def emit(self, *args):
                if self._callback:
                    self._callback(*args)
        # Isolate this test from a minimal Qt shim imported by another test module.
        worker.results_ready = LocalSignal()
        worker.results_ready.connect(lambda rows, error, elapsed: captured.update(rows=rows, error=error, elapsed=elapsed))
        with patch.object(scanner_core, "_get_ocr_engine", return_value=engine):
            worker.run()
        self.assertEqual(captured["error"], "")
        self.assertEqual(engine.seen, 2)
        self.assertEqual(captured["rows"][0]["discount_value"], 31)
        self.assertEqual(captured["rows"][1]["discount_value"], 18)


if __name__ == "__main__":
    unittest.main(verbosity=2)
