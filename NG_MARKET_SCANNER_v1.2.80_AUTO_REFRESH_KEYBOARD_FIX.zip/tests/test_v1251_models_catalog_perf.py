import json
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
NEW_MODELS = {
    'Karin Land Cruiser 100',
    'Shitzu Matiz',
    'Vapid F-150 Raptor',
    'BF Surfer',
    'Grotti Roma',
    'Vapid Transit V347',
    'BF T6.1',
}
EXCLUDED_MODELS = {'Vapid Model T', 'Gallivanter L322'}


def read_names(filename):
    return {
        line.strip() for line in (ROOT / filename).read_text(encoding='utf-8-sig').splitlines()
        if line.strip() and not line.lstrip().startswith('#')
    }


class V1251ModelAndCatalogTests(unittest.TestCase):
    def test_requested_models_are_in_all_lists_and_excluded_models_are_absent(self):
        all_models = read_names('all_vehicles.txt')
        selected = read_names('selected_vehicles.txt')
        rules = {line.split('|', 1)[0] for line in read_names('vehicle_rules.txt')}
        self.assertTrue(NEW_MODELS.issubset(all_models))
        self.assertTrue(NEW_MODELS.issubset(selected))
        self.assertTrue(NEW_MODELS.issubset(rules))
        for forbidden in EXCLUDED_MODELS:
            self.assertNotIn(forbidden, all_models)
            self.assertNotIn(forbidden, selected)
            self.assertNotIn(forbidden, rules)
        self.assertEqual(len(all_models), 53)

    def test_shitzu_matiz_minimum_discount_is_twenty_percent(self):
        rules = {}
        for line in (ROOT / 'vehicle_rules.txt').read_text(encoding='utf-8-sig').splitlines():
            if not line.strip() or line.lstrip().startswith('#'):
                continue
            parts = line.split('|')
            if len(parts) == 3:
                rules[parts[0]] = int(parts[2])
        settings = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertEqual(rules['Shitzu Matiz'], 20)
        self.assertEqual(settings.get('model_thresholds', {}).get('Shitzu Matiz'), 20)
        self.assertRegex(main, r"'Shitzu Matiz'\s*:\s*20")

    def test_new_model_render_mappings_resolve_to_existing_high_resolution_assets(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        mapping_block = main.split('VEHICLE_RENDER_ALIASES = {', 1)[1].split('\n}', 1)[0]
        mappings = dict(re.findall(r"'([^']+)':\s*'([^']+)'", mapping_block))
        for model in NEW_MODELS - {'BF Surfer', 'Vapid Transit V347'}:
            self.assertIn(model, mappings, model)
            asset = ROOT / 'vehicle_renders' / mappings[model]
            self.assertTrue(asset.is_file(), f'{model}: {asset.name} missing')
            with Image.open(asset) as image:
                self.assertEqual(image.size, (1200, 620), model)
                self.assertEqual(image.mode, 'RGBA', model)
                self.assertEqual(image.getchannel('A').getextrema()[0], 0, model)
        # BF Surfer and Vapid Transit V347 use their dedicated, bundled render files.
        for asset_name in ('BF_Surfer.png', 'Vapid_Transit_V347.png'):
            with Image.open(ROOT / 'vehicle_renders' / asset_name) as image:
                self.assertEqual(image.size, (1200, 620))
                self.assertEqual(image.mode, 'RGBA')
                self.assertEqual(image.getchannel('A').getextrema()[0], 0)

    def test_approximate_vehicle_mappings_are_explicitly_disclosed_in_ui_and_provenance(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        provenance = (ROOT / 'VEHICLE_CUTOUTS_PROVENANCE_UA.txt').read_text(encoding='utf-8')
        self.assertIn("'approximate': 'РЕФЕРЕНС'", main)
        for phrase in ('не точне фото', 'Shitzu Matiz', 'Karin Land Cruiser 100', 'Vapid F-150 Raptor', 'Grotti Roma', 'BF T6.1'):
            self.assertIn(phrase, provenance)

    def test_catalog_image_cache_avoids_redecoding_same_asset(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn('_PREVIEW_VALIDATION_CACHE = {}', main)
        self.assertIn('_PIXMAP_CACHE = {}', main)
        self.assertIn('int(stat.st_mtime_ns)', main)
        self.assertIn('int(stat.st_size)', main)
        self.assertIn('cached = _PIXMAP_CACHE.get(key)', main)

    def test_hidden_catalog_model_does_not_load_duplicate_thumbnails(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        refresh = main.split('    def refresh_catalog(self, force=False):', 1)[1].split('    def _selected_catalog_model', 1)[0]
        self.assertIn('loading 53 thumbnails here', refresh)
        self.assertIn("thumb = QTableWidgetItem('')", refresh)
        self.assertNotIn('thumb.setIcon(QIcon(QPixmap(str(render_path))', refresh)

    def test_visible_catalog_cards_are_reused_and_created_in_small_batches(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        grid = main.split('    def _refresh_catalog_grid(self):', 1)[1].split('    def _set_catalog_active_from_card', 1)[0]
        self.assertIn('self._catalog_cards', main)
        self.assertIn('batch_size = 8', grid)
        self.assertIn('QTimer.singleShot(0, lambda: populate_batch(0))', grid)
        self.assertIn("if signature == getattr(self, '_catalog_grid_layout_signature', None):", grid)
        self.assertNotIn('widget.deleteLater()', grid)

    def test_release_builder_checks_version_and_runs_tests_before_pyinstaller(self):
        builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        self.assertIn('NG Market Scanner v1.2.71', builder)
        self.assertIn('python -m unittest discover -s tests -v', builder)
        self.assertLess(builder.index('python -m unittest discover -s tests -v'), builder.index('python -m PyInstaller'))
        self.assertTrue((ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_FINAL_v1.2.54.bat.fixture.txt').is_file())
        outer = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'build_exe.bat.fixture.txt').read_text(encoding='utf-8')
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', outer)

if __name__ == '__main__':
    unittest.main(verbosity=2)
