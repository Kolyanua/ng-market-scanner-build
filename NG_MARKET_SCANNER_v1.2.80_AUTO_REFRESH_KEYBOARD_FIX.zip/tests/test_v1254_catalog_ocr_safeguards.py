import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class V1254CatalogOcrSafeguardTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "scanner_core.py").read_text(encoding="utf-8")
        cls.settings = json.loads((ROOT / "settings.json").read_text(encoding="utf-8"))

    def test_catalog_reflow_preserves_widgets_and_has_enough_vertical_space(self):
        self.assertIn("Qt.ScrollBarAlwaysOn", self.main)
        self.assertIn("card.setMinimumHeight(max(500, int(510 * self.ui_scale)))", self.main)
        self.assertIn("QSizePolicy.Expanding, QSizePolicy.Preferred", self.main)
        block = self.main.split("    def _refresh_catalog_grid(self):", 1)[1].split("    def _set_catalog_active_from_card", 1)[0]
        self.assertIn("if signature == getattr(self, '_catalog_grid_layout_signature', None):", block)
        self.assertIn("visible cards retain their widget identity and hover state", block)
        self.assertNotIn("while layout.count():", block)

    def test_full_ocr_and_safeguards_are_visible_and_persisted(self):
        for key in ("fast_color_filter_enabled", "blacklist_protection_enabled", "confidence_protection_enabled"):
            self.assertIn(key, self.settings)
        for label in (
            "GREEN ONLY: OCR лише карток із зеленим бейджем",
            "Блокувати автодії для моделей із чорного списку",
            "Вимагати високу впевненість збігу назви (не менше 0,93)",
            "Постійно активні захисти",
        ):
            self.assertIn(label, self.main)
        self.assertIn("def _on_runtime_protection_controls_changed", self.main)
        self.assertIn("self.settings['fast_color_filter_enabled'] = True", self.main)
        self.assertIn("self.full_ocr_check.setEnabled(False)", self.main)
        self.assertIn("self.full_ocr_check.setChecked(True)", self.main)
        self.assertIn("GREEN ONLY УЖЕ УВІМКНЕНО", self.main)
        self.assertIn("fast_color_filter_enabled=True,", self.main)

    def test_full_ocr_disables_color_skip_and_is_recorded_in_diagnostics(self):
        self.assertIn("if (self.fast_color_filter_enabled", self.core)
        self.assertIn("full-card OCR: read text on all 15 cards regardless of badge color", self.core)
        self.assertIn("'full_card_ocr_enabled': not bool(self.fast_color_filter_enabled)", self.core)
        self.assertIn("if not self.fast_color_filter_enabled:", self.core)
        self.assertIn("self.fast_color_filter_enabled", self.core.split("def _config_cache_key", 1)[1].split("def _threshold_for", 1)[0])

    def test_functional_ui_does_not_expose_format_labels_as_feature_names(self):
        self.assertNotIn("PNG · ПРОЗОРИЙ ФОН", self.main)
        self.assertNotIn("Автомобільний PNG із прозорістю", self.main)
        self.assertIn("Галерея автомобілів · результати сканування", self.main)
        self.assertIn("ЗОБРАЖЕННЯ КАТАЛОГУ", self.main)


if __name__ == "__main__":
    unittest.main()
