import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TwoKUIContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.qss = (ROOT / 'theme' / 'style.qss').read_text(encoding='utf-8')
        cls.actions = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        cls.settings = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))

    def test_2k_settings_and_adaptive_layout_are_present(self):
        self.assertIn('2560', self.main)
        self.assertIn('1440', self.main)
        self.assertIn('TransparentVehiclePreview', self.main)
        self.assertIn('catalog_grid_layout', self.main)
        self.assertIn('_is_high_resolution_preview', self.main)
        self.assertIn('self.catalog_grid_scroll', self.main)
        self.assertIn('setWindowIcon', self.main)

    def test_fast_click_configuration_is_one_ms_and_polling_is_adaptive(self):
        self.assertEqual(self.settings['click_delay_ms'], 1)
        self.assertEqual(self.settings['interval_ms'], 20)
        self.assertIn('Ультра++ · 20 мс', self.main)
        self.assertIn('Ультра+ · 50 мс', self.main)
        self.assertIn('self.timer.setTimerType(Qt.PreciseTimer)', self.main)
        self.assertIn('BUTTON_POLL_INTERVAL_MS = 1', self.actions)
        self.assertIn('gdi32.GetPixel', self.actions)
        self.assertIn('SendInput(2, events', self.actions)
        self.assertNotRegex(self.actions, r'time\.sleep\(0\.(?:7|85)\)')
        self.assertNotIn('time.sleep(0.700)', self.actions)
        self.assertNotIn('time.sleep(0.850)', self.actions)

    def test_buttons_and_tiles_have_neon_focus_styles(self):
        self.assertIn('QPushButton#primary:hover', self.qss)
        self.assertIn('QFrame#catalogVehicleCard:hover', self.qss)
        self.assertIn('#54E5B6', self.qss)
        self.assertIn('QLabel#catalogSourceBadge[sourceType="approximate"]', self.qss)

if __name__ == '__main__': unittest.main()
