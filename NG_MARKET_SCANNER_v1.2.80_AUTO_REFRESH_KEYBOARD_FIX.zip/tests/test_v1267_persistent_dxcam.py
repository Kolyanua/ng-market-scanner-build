import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import cv2
import numpy as np
import scanner_core
from scanner_core import ScanWorker

ROOT = Path(__file__).resolve().parents[1]
GRID = {'left': .153, 'top': .095, 'right': .985, 'bottom': .895, 'cols': 5, 'rows': 3}
SCREEN = (2560, 1440)


class PersistentDXcamV1267Tests(unittest.TestCase):
    def test_worker_cache_tests_force_fake_capture_instead_of_real_windows_desktop(self):
        # Regression for Windows build hosts where installing DXcam caused unit tests
        # with FakeMSS fixtures to capture the real desktop. This made synthetic green
        # badges disappear and produced false OCR/cache failures before PyInstaller.
        test_source = (ROOT / 'tests' / 'test_scanner_core_speed.py').read_text(encoding='utf-8')
        self.assertIn("class FastScanCacheTests(unittest.TestCase):", test_source)
        self.assertIn("patch('scanner_core._primary_screen_size', return_value=None)", test_source)

    def tearDown(self):
        scanner_core.close_market_capture()

    def test_market_roi_is_clipped_and_covers_all_2k_grid_cards(self):
        region = scanner_core._market_capture_region(GRID, SCREEN)
        left, top, right, bottom = region
        self.assertGreaterEqual(left, 0)
        self.assertGreaterEqual(top, 0)
        self.assertLessEqual(right, SCREEN[0])
        self.assertLessEqual(bottom, SCREEN[1])
        self.assertLess(left, int(GRID['left'] * SCREEN[0]))
        self.assertLess(top, int(GRID['top'] * SCREEN[1]))
        self.assertGreater(right, int(GRID['right'] * SCREEN[0]) - 1)
        self.assertGreater(bottom, int(GRID['bottom'] * SCREEN[1]) - 1)

    def test_roi_extraction_is_pixel_and_coordinate_equivalent_to_full_2k_capture(self):
        rng = np.random.default_rng(1267)
        full = rng.integers(0, 256, size=(SCREEN[1], SCREEN[0], 3), dtype=np.uint8)
        region = scanner_core._market_capture_region(GRID, SCREEN)
        rx0, ry0, rx1, ry1 = region
        roi = full[ry0:ry1, rx0:rx1].copy()
        full_bounds = (int(GRID['left'] * SCREEN[0]), int(GRID['right'] * SCREEN[0]),
                       int(GRID['top'] * SCREEN[1]), int(GRID['bottom'] * SCREEN[1]))
        x0, x1, y0, y1 = full_bounds
        worker = ScanWorker([], {}, 20, {}, GRID)
        full_cards = worker._extract_card_contexts(
            full, x0, x1, y0, y1, 5, 3, 0, 0, SCREEN, cv2, np, capture_origin=(0, 0)
        )
        roi_bounds = (x0-rx0, x1-rx0, y0-ry0, y1-ry0)
        rx0g, rx1g, ry0g, ry1g = roi_bounds
        roi_cards = worker._extract_card_contexts(
            roi, rx0g, rx1g, ry0g, ry1g, 5, 3, 0, 0, SCREEN, cv2, np, capture_origin=(rx0, ry0)
        )
        self.assertEqual(len(full_cards), 15)
        self.assertEqual(len(roi_cards), 15)
        for idx, (full_card, roi_card) in enumerate(zip(full_cards, roi_cards), start=1):
            self.assertEqual(full_card['card'], idx)
            self.assertEqual(full_card['xy'], roi_card['xy'], f'card {idx} click coordinates changed')
            self.assertEqual(full_card['badge_color'], roi_card['badge_color'], f'card {idx} badge color changed')
            for field in ('name_crop', 'price_crop', 'badge_crop', 'footer_crop'):
                self.assertTrue(np.array_equal(full_card[field], roi_card[field]), f'card {idx} {field} changed')
            self.assertEqual(full_card['signature'], roi_card['signature'], f'card {idx} signature changed')

    def test_dxcam_camera_is_reused_for_successive_scan_cycles(self):
        scanner_core.close_market_capture()
        region = scanner_core._market_capture_region(GRID, SCREEN)
        rx0, ry0, rx1, ry1 = region
        fake_camera = MagicMock()
        frame = np.zeros((ry1-ry0, rx1-rx0, 4), dtype=np.uint8)
        fake_camera.get_latest_frame.return_value = (frame, 123.456)
        fake_dxcam = types.SimpleNamespace(create=MagicMock(return_value=fake_camera))
        with patch.dict(sys.modules, {'dxcam': fake_dxcam}):
            first = scanner_core._capture_market_frame(GRID, np, screen_size_override=SCREEN)
            second = scanner_core._capture_market_frame(GRID, np, screen_size_override=SCREEN)
        self.assertEqual(fake_dxcam.create.call_count, 1)
        self.assertEqual(fake_camera.start.call_count, 1)
        self.assertEqual(fake_camera.get_latest_frame.call_count, 2)
        for value in (first, second):
            captured, origin, desktop_origin, size, backend, elapsed, timestamp = value
            self.assertEqual(captured.shape, frame.shape[:2] + (3,))
            self.assertFalse(np.shares_memory(captured, frame))
            self.assertEqual(origin, region[:2])
            self.assertEqual(desktop_origin, (0, 0))
            self.assertEqual(size, SCREEN)
            self.assertIn('DXGI/DXcam persistent ROI', backend)
            self.assertIn('BGRA fast path', backend)
            self.assertEqual(timestamp, 123.456)
            self.assertGreaterEqual(elapsed, 0)
        kwargs = fake_camera.start.call_args.kwargs
        self.assertEqual(tuple(kwargs['region']), region)
        self.assertEqual(kwargs['target_fps'], 120)
        self.assertFalse(kwargs['video_mode'])
        self.assertEqual(fake_dxcam.create.call_args.kwargs['output_color'], 'BGRA')

    def test_first_dxcam_frame_wait_is_bounded_and_only_used_at_startup(self):
        fresh_camera = MagicMock()
        frame = np.zeros((40, 60, 3), dtype=np.uint8)
        fresh_camera.get_latest_frame.side_effect = [(None, None), (frame, 1.25)]
        with patch.object(scanner_core.time, 'sleep') as sleep:
            got_frame, timestamp = scanner_core._read_latest_dxcam_frame(fresh_camera, wait_timeout_seconds=0.040)
        self.assertTrue(np.array_equal(got_frame, frame))
        self.assertFalse(np.shares_memory(got_frame, frame))
        self.assertEqual(timestamp, 1.25)
        self.assertEqual(fresh_camera.get_latest_frame.call_count, 2)
        sleep.assert_called_once_with(0.001)

        stale_camera = MagicMock()
        stale_camera.get_latest_frame.return_value = (None, None)
        with patch.object(scanner_core.time, 'sleep') as sleep:
            with self.assertRaisesRegex(RuntimeError, 'fresh frame'):
                scanner_core._read_latest_dxcam_frame(stale_camera, wait_timeout_seconds=0.0)
        self.assertEqual(stale_camera.get_latest_frame.call_count, 1)
        sleep.assert_not_called()

    def test_failed_dxcam_start_is_released_and_persistent_mss_fallback_is_used(self):
        scanner_core.close_market_capture()
        failed_camera = MagicMock()
        failed_camera.start.side_effect = RuntimeError('simulated DXcam startup failure')
        fake_dxcam = types.SimpleNamespace(create=MagicMock(return_value=failed_camera))
        fake_mss_capture = MagicMock()
        fake_mss_capture.monitors = [{}, {'left': 0, 'top': 0, 'width': SCREEN[0], 'height': SCREEN[1]}]
        fake_mss_capture.grab.return_value = np.zeros((SCREEN[1], SCREEN[0], 4), dtype=np.uint8)
        with patch.dict(sys.modules, {'dxcam': fake_dxcam, 'mss': types.ModuleType('mss')}):
            with patch.object(scanner_core, '_get_detail_capture', return_value=fake_mss_capture):
                captured = scanner_core._capture_market_frame(GRID, np, screen_size_override=SCREEN)
        self.assertEqual(captured[0].shape, (SCREEN[1], SCREEN[0], 3))
        self.assertIn('MSS persistent full-screen fallback', captured[4])
        failed_camera.stop.assert_called_once()
        failed_camera.release.assert_called_once()
        self.assertIn('simulated DXcam startup failure', scanner_core._MARKET_CAPTURE_LAST_ERROR)

    def test_scanworker_uses_shared_capture_instead_of_creating_mss_every_cycle(self):
        source = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        worker_source = source.split('class ScanWorker(QThread):', 1)[1]
        run_source = worker_source.split('    def run(self):', 1)[1].split('\nclass ', 1)[0]
        self.assertIn('_capture_market_frame(grid, np)', run_source)
        self.assertNotIn('with mss.mss() as sct', run_source)
        self.assertIn("stage['capture_backend'] = capture_backend", run_source)
        self.assertIn("'stage_info':", source)
        self.assertIn('MARKET_CAPTURE_PATCH_VERSION = "1.2.67-persistent-dxcam-market-roi"', source)

    def test_20ms_polling_remains_single_flight_and_settings_migrate_once(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        settings = __import__('json').loads((ROOT / 'settings.json').read_text(encoding='utf-8'))
        self.assertEqual(settings['interval_ms'], 20)
        self.assertEqual(settings['config_version'], 31)
        self.assertIn("'Ультра++ · 20 мс': 20", main)
        self.assertIn("if old_version < 31 and configured_interval == 50:", main)
        self.assertIn('self.busy or self._scan_request_active or self.action_in_progress or worker_active or self._action_worker_is_running()', main)
        self.assertIn("self.timer.start(max(20, int(self.settings.get('interval_ms', 20) or 20)))", main)

    def test_release_builder_requires_capture_and_20ms_markers(self):
        builder = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        internal = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        self.assertIn('1.2.67-persistent-dxcam-market-roi', builder)
        self.assertIn('1.2.68-dxcam-bgra-fastpath', builder)
        self.assertIn('1.2.67-persistent-dxcam-market-roi', internal)
        self.assertLess(internal.index('python -m unittest discover -s tests -v'), internal.index('python -m PyInstaller'))


if __name__ == '__main__':
    unittest.main()
