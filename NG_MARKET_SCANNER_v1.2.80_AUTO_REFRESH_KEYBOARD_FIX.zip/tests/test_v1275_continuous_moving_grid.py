import unittest
from pathlib import Path

import cv2
import numpy as np
import scanner_core

ROOT = Path(__file__).resolve().parents[1]


class ContinuousMovingGridV1275Tests(unittest.TestCase):
    def test_unique_moved_cards_reuse_ocr_rows_but_new_card_is_not_falsely_cached(self):
        previous_signatures = ['lot-a', 'lot-b', 'lot-c', 'lot-d']
        previous_rows = [{'model': value, 'card': i + 1} for i, value in enumerate(previous_signatures)]
        previous_fields = [{'name': f'name-{value}', 'price': f'price-{value}', 'badge': f'badge-{value}'}
                           for value in previous_signatures]
        current_signatures = ['lot-b', 'lot-c', 'lot-d', 'new-lot']

        rows, fields, mapping = scanner_core._remap_cached_rows_by_signature(
            current_signatures, previous_signatures, previous_rows, previous_fields)

        self.assertEqual(mapping, {0: 1, 1: 2, 2: 3})
        self.assertEqual([rows[i]['model'] for i in range(3)], ['lot-b', 'lot-c', 'lot-d'])
        self.assertEqual(fields[0]['name'], 'name-lot-b')
        self.assertIsNone(rows[3])
        self.assertIsNone(fields[3])
        # No source row is copied twice when the whole line of cards moves left.
        self.assertEqual(len({id(rows[i]) for i in range(3)}), 3)

    def test_changed_same_cell_keeps_field_level_fallback_for_only_changed_fields(self):
        previous_signatures = ['old-lot', 'steady-lot']
        previous_rows = [{'model': 'Old Model'}, {'model': 'Steady Model'}]
        previous_fields = [
            {'name': 'old-name-mask', 'price': 'same-price-mask', 'badge': 'same-badge-mask'},
            {'name': 'steady-name-mask', 'price': 'steady-price-mask', 'badge': 'steady-badge-mask'},
        ]
        rows, fields, mapping = scanner_core._remap_cached_rows_by_signature(
            ['new-lot', 'steady-lot'], previous_signatures, previous_rows, previous_fields)
        self.assertEqual(rows[0]['model'], 'Old Model')
        self.assertEqual(fields[0]['price'], 'same-price-mask')
        self.assertEqual(mapping, {0: 0, 1: 1})
        self.assertEqual(rows[1]['model'], 'Steady Model')

    def test_duplicate_fingerprints_do_not_trigger_cross_cell_guessing(self):
        previous_signatures = ['same-lot', 'same-lot', 'same-lot']
        previous_rows = [{'model': 'Same A'}, {'model': 'Same B'}, {'model': 'Same C'}]
        previous_fields = [{'name': f'name-{i}', 'price': f'price-{i}', 'badge': f'badge-{i}'}
                           for i in range(3)]
        rows, _, mapping = scanner_core._remap_cached_rows_by_signature(
            ['new-lot', 'same-lot', 'same-lot'], previous_signatures, previous_rows, previous_fields)
        self.assertEqual(mapping, {1: 1, 2: 2, 0: 0})
        self.assertEqual([rows[i]['model'] for i in range(3)], ['Same A', 'Same B', 'Same C'])

    def _synthetic_market(self):
        width, height = 2560, 1440
        rng = np.random.default_rng(1275)
        frame = np.full((height, width, 3), 30, dtype=np.uint8)
        lefts = (.155, .322, .489, .655, .822)
        rights = (.315, .481, .647, .813, .981)
        row_offsets = (0.0, .270, .540)
        for row in range(3):
            for col in range(5):
                x0, x1 = int(lefts[col] * width), int(rights[col] * width)
                y0 = int((.095 + row_offsets[row]) * height)
                y1 = int((.095 + row_offsets[row] + .265) * height)
                frame[y0:y1, x0:x1] = (42, 42, 42)
                th, tw = int((y1-y0)*.65), int((x1-x0)*.72)
                thumb = rng.integers(0, 256, (th, tw, 3), dtype=np.uint8)
                frame[y0+5:y0+5+th, x0+5:x0+5+tw] = thumb
                fy = y0 + int(.72 * (y1-y0))
                cv2.line(frame, (x0+5, fy), (x0+int(.70*(x1-x0)), fy), (240, 240, 240), 3)
                cv2.line(frame, (x0+5, fy+9), (x0+int(.40*(x1-x0)), fy+9), (160, 160, 160), 2)
        return frame

    def test_market_grid_probe_accepts_fifteen_cards(self):
        grid = {'left': .153, 'right': .985, 'top': .095, 'bottom': .895, 'cols': 5, 'rows': 3}
        result = scanner_core._market_grid_presence_score(self._synthetic_market(), grid, (2560, 1440))
        self.assertTrue(result['market_grid_visible'], result)
        self.assertGreaterEqual(result['image_like_cells'], 8)
        self.assertGreaterEqual(result['footer_like_cells'], 8)
        self.assertGreaterEqual(result['distinct_thumbnail_cells'], 6)

    def test_details_layout_is_not_mistaken_for_market_grid(self):
        width, height = 2560, 1440
        rng = np.random.default_rng(88)
        frame = np.full((height, width, 3), 30, dtype=np.uint8)
        cv2.rectangle(frame, (500, 200), (1600, 1000), (55, 70, 80), -1)
        frame[220:850, 520:1300] = rng.integers(0, 256, (630, 780, 3), dtype=np.uint8)
        for i in range(8):
            cv2.line(frame, (1650, 230+i*65), (2100, 230+i*65), (220, 220, 220), 3)
        grid = {'left': .153, 'right': .985, 'top': .095, 'bottom': .895, 'cols': 5, 'rows': 3}
        result = scanner_core._market_grid_presence_score(frame, grid, (width, height))
        self.assertFalse(result['market_grid_visible'], result)

    def test_return_gate_requires_two_frames_and_preserves_target_window(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        resume = main.split('    def _resume_continuous_scan_after_action(self):', 1)[1].split(
            '    def _finish_continuous_resume_after_market_confirmed(self):', 1)[0]
        finish = main.split('    def _finish_continuous_resume_after_market_confirmed(self):', 1)[1].split(
            '    def on_action_result(', 1)[0]
        self.assertIn("target_hwnd=(getattr(self, '_resume_market_target_hwnd', None)", resume)
        self.assertIn("state == 'market'", resume)
        self.assertIn('self._resume_market_good_frames >= 2', resume)
        self.assertIn("row['xy']", (ROOT / 'scanner_core.py').read_text(encoding='utf-8'))
        self.assertIn("self._scan_target_hwnd = int(resume_target_hwnd)", finish)
        self.assertIn('RESUME GATE TIMEOUT:', resume)
        self.assertIn("self._resume_market_target_hwnd = candidate.get('_target_hwnd') or self._scan_target_hwnd", main)

    def test_resume_flow_keeps_continuous_intent_and_does_not_steal_other_app_focus(self):
        main = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("getattr(self, '_continuous_scan_requested', False) or self.running", main)
        self.assertIn("if int(foreground_pid.value or 0) != os.getpid():", main)
        self.assertIn("self._continuous_scan_requested = False", main)
        core = (ROOT / "scanner_core.py").read_text(encoding="utf-8")
        self.assertIn("def _same_target_window_or_process", core)
        self.assertIn("GetWindowThreadProcessId", core)

    def test_purchase_click_sequence_is_still_the_stable_three_click_flow(self):
        actions = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', actions)
        self.assertIn('CARD_CLICK', actions)
        self.assertIn('DETAIL_BUY', actions)
        self.assertIn('FINAL_CONFIRM', actions)
        self.assertIn('SendInput(2, events', actions)


if __name__ == '__main__':
    unittest.main(verbosity=2)
