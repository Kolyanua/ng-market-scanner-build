import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class ReleaseContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.action = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        cls.builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        cls.settings = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))

    def test_release_version_and_click_workflow_are_aligned(self):
        self.assertIn('NG Market Scanner v1.2.71', self.main)
        self.assertIn('1.2.60-position-independent-discount', self.main)
        self.assertIn('1.2.67-persistent-dxcam-market-roi', self.main)
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', self.action)
        self.assertEqual(self.settings['config_version'], 31)
        self.assertFalse(self.settings.get('animations_enabled', True))
        self.assertIn('if old_version < 29:', self.main)

    def test_user_requested_fast_auto_buy_defaults_are_saved(self):
        self.assertEqual(self.settings['click_delay_ms'], 1)
        self.assertTrue(self.settings.get('auto_click'))
        self.assertTrue(self.settings.get('auto_confirm'))
        self.assertIn('click_delay_ms', self.main)
        self.assertIn("self.settings.get('click_delay_ms', 1)", self.main)
        self.assertIn('click_delay_ms=1', self.action)

    def test_builder_bundles_icon_grid_assets_and_persistent_stats(self):
        for token in ('--icon "assets\\ng_market_scanner.ico"', '--add-data "assets;assets"', 'stats_history.json', '--add-data "vehicle_renders;vehicle_renders"'):
            self.assertIn(token, self.builder)
        self.assertTrue((ROOT / 'assets' / 'ng_market_scanner.ico').is_file())


    def test_all_legacy_build_entrypoints_forward_to_current_onefile_release(self):
        current = 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat'
        wrappers = [
            'BUILD_2K_FINAL_CONFIRM_FIX_v1.2.65.1.bat.fixture.txt',
            'BUILD_2K_MARKET_PREFLIGHT_v1.2.66.bat.fixture.txt',
            'BUILD_2K_PERSONAL_v1.2.65.bat.fixture.txt',
            'BUILD_2K_REC_ONLY_FAST_v1.2.69.bat.fixture.txt',
            'BUILD_FINAL_v1.2.54.bat.fixture.txt',
            'BUILD_FINAL_v1.2.55_GREEN_ONLY_OCR.bat.fixture.txt',
            'BUILD_FINAL_v1.2.56_GREEN_FASTLANE.bat.fixture.txt',
            'BUILD_FINAL_v1.2.57_DIRECT_GREEN_WATCH.bat.fixture.txt',
            'BUILD_FINAL_v1.2.58_LARGEST_DISCOUNT_WATCH.bat.fixture.txt',
            'BUILD_FINAL_v1.2.59_PARALLEL_DETAIL_FASTPATH.bat.fixture.txt',
            'BUILD_FINAL_v1.2.60_POSITION_INDEPENDENT_DISCOUNT.bat.fixture.txt',
            'build_exe.bat.fixture.txt', 'build_exe_internal.bat.fixture.txt', 'RUN_CLEAN_INSTALL_AND_START.bat.fixture.txt',
        ]
        for name in wrappers:
            text = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / name).read_text(encoding='utf-8')
            self.assertIn(current, text, name)
        canonical = (ROOT / current).read_text(encoding='utf-8')
        self.assertIn('1.2.67-persistent-dxcam-market-roi', canonical)
        self.assertIn('1.2.69-known-roi-batched-recognition-only', canonical)
        self.assertIn('1.2.75-market-return-state-gate', canonical)
        self.assertIn('1.2.70-single-card-batched-recognition-only', canonical)
        self.assertIn('1.2.70-dynamic-cta-and-lot-not-found-guard', canonical)
        self.assertIn('NGMS_PRESERVE_AUTOBUY=1', canonical)
        self.assertIn('call build_single_exe_internal.bat', canonical)

    def test_recognition_only_fastpath_marker_is_required_by_current_release(self):
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        self.assertIn('RECOGNITION_ONLY_PATCH_VERSION = "1.2.69-known-roi-batched-recognition-only"', core)
        self.assertIn('EXPECTED_RECOGNITION_ONLY_PATCH_VERSION = "1.2.69-known-roi-batched-recognition-only"', self.main)
        self.assertIn('EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION = "1.2.70-single-card-batched-recognition-only"', self.main)
        self.assertIn('1.2.69-known-roi-batched-recognition-only', self.builder)
        self.assertIn('1.2.70-single-card-batched-recognition-only', self.builder)
        self.assertIn('1.2.70-dynamic-cta-and-lot-not-found-guard', self.builder)
        outer = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        self.assertIn('1.2.69-known-roi-batched-recognition-only', outer)
        self.assertIn('1.2.75-market-return-state-gate', outer)
        benchmark = (ROOT / 'tools' / 'benchmark_ocr_providers.py').read_text(encoding='utf-8')
        self.assertIn('known_roi_rec_only_detail_3lines', benchmark)
        self.assertIn('known_roi_rec_only_badges_3', benchmark)

    def test_latest_named_build_entrypoint_forwards_to_current_single_exe_builder(self):
        entry = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_2K_COORDINATE_FAST_v1.2.71.bat.fixture.txt').read_text(encoding='ascii')
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', entry)
        self.assertIn('call', entry.lower())
        readme = (ROOT / 'docs' / 'release' / 'README_FINAL_v1.2.75_UA.txt').read_text(encoding='utf-8')
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', readme)
        self.assertNotIn('BUILD_2K_COORDINATE_FAST_v1.2.71.bat.fixture.txt', readme)

    def test_v1272_vectorized_badge_sampler_marker_is_required(self):
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        logic = (ROOT / 'scanner_core_logic.py').read_text(encoding='utf-8')
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        builder = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        self.assertIn('BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"', core)
        self.assertIn('BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"', logic)
        self.assertIn('EXPECTED_BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"', main)
        self.assertIn('1.2.72-vectorized-badge-sampling', builder)

    def test_v1270_batch_ocr_and_dynamic_confirm_markers_are_required(self):
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        action = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        self.assertIn('SINGLE_CARD_BATCH_PATCH_VERSION = "1.2.70-single-card-batched-recognition-only"', core)
        self.assertIn('CLICK_DYNAMIC_CONFIRM_PATCH_VERSION = "1.2.70-dynamic-cta-and-lot-not-found-guard"', action)
        self.assertIn('single_card_batch_version != EXPECTED_SINGLE_CARD_BATCH_PATCH_VERSION', self.main)
        self.assertIn("dynamic_confirm_version != EXPECTED_DYNAMIC_CONFIRM_PATCH_VERSION", self.main)

    def test_same_offer_is_not_retried_repeatedly_in_a_single_session(self):
        self.assertIn('_purchase_offer_keys_attempted', self.main)
        self.assertIn('same price/discount', self.main)

if __name__ == '__main__': unittest.main()
