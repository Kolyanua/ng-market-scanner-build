import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class TwoKFinalConfirmFixTests(unittest.TestCase):
    def test_migration_enables_personal_automation_once_for_v29_configs(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        settings = json.loads((ROOT / 'settings.json').read_text(encoding='utf-8'))
        self.assertIn('if old_version < 30:', main)
        migration = main.split('if old_version < 30:', 1)[1].split("settings['config_version'] = 31", 1)[0]
        self.assertIn("settings['auto_click'] = True", migration)
        self.assertIn("settings['auto_confirm'] = True", migration)
        self.assertIn("settings['resolution_profile'] = '2560x1440'", migration)
        self.assertEqual(settings['config_version'], 31)
        self.assertTrue(settings['auto_click'])
        self.assertTrue(settings['auto_confirm'])
        self.assertEqual(settings['resolution_profile'], '2560x1440')

    def test_compact_and_wide_buttons_use_distinct_probe_profiles_in_both_directions(self):
        source = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        self.assertIn("button_kind='detail_buy'", source)
        self.assertIn("button_kind='confirm'", source)
        self.assertIn('button_probe_offsets(self.scan_screen_size, button_kind)', source)
        self.assertIn("button_kind='confirm'):", source)
        self.assertIn('CLICK_BUTTON_PROBE_PATCH_VERSION', source)

    def test_final_confirm_verification_uses_the_same_probe_profile_as_detection(self):
        source = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        self.assertIn("_wait_for_green_button_gone(*confirm_xy, timeout_ms=1800, expected_hwnd=hwnd, button_kind='confirm')", source)
        self.assertIn("_wait_for_green_button(*detail_xy, timeout_ms=700, expected_hwnd=hwnd, button_kind='detail_buy')", source)

    def test_builder_refuses_to_package_an_old_button_probe_module(self):
        builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        wrapper = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_2K_MARKET_PREFLIGHT_v1.2.66.bat.fixture.txt').read_text(encoding='utf-8')
        self.assertIn('1.2.65.1-2k-offtext-probes', builder)
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', wrapper)
        canonical = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        self.assertIn('NGMS_PRESERVE_AUTOBUY=1', canonical)
        self.assertIn('1.2.66-return-market-recover', builder)

if __name__ == '__main__':
    unittest.main()
