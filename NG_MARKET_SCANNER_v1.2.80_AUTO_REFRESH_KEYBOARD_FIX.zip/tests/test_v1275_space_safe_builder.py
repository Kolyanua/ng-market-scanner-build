import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class SpaceSafeBuilderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.outer = (ROOT / "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat").read_text(encoding="ascii")

    def test_selects_a_writable_local_drive_with_at_least_10_gb_free(self):
        helper = (ROOT / "tools" / "select_build_workspace.ps1").read_text(encoding="ascii")
        self.assertIn("Win32_LogicalDisk", helper)
        self.assertIn("$minimumFreeBytes = 10GB", helper)
        self.assertIn("NGMS_NO_SPACE", helper)
        self.assertIn("No writable local drive has at least 10 GB free", self.outer)
        self.assertIn("select_build_workspace.ps1", self.outer)

    def test_redirects_temp_pip_and_pyinstaller_cache_away_from_full_c_drive(self):
        for value in ("set \"TEMP=%NGMS_WORK_ROOT%Temp\"", "set \"TMP=%NGMS_WORK_ROOT%Temp\"", "set \"PIP_CACHE_DIR=%NGMS_WORK_ROOT%pip-cache\"", "set \"PYINSTALLER_CONFIG_DIR=%NGMS_WORK_ROOT%PyInstallerConfig\""):
            self.assertIn(value, self.outer)

    def test_publishes_exe_to_the_selected_drive_output_folder(self):
        self.assertIn("$outDir=$env:NGMS_OUTPUT_DIR", self.outer)
        self.assertIn("Join-Path $outDir 'NG Market Scanner.exe'", self.outer)
        self.assertIn('start \"\" explorer.exe \"%NGMS_OUTPUT_DIR%\"', self.outer)

    def test_cleans_large_build_intermediates_after_build_failure(self):
        self.assertIn("foreach($n in @('build','dist'))", self.outer)


if __name__ == "__main__":
    unittest.main()
