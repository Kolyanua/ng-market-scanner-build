import sys
import types
import unittest
from pathlib import Path
from unittest.mock import MagicMock, patch

import numpy as np
import scanner_core

ROOT = Path(__file__).resolve().parents[1]
GRID = {'left': .153, 'top': .095, 'right': .985, 'bottom': .895, 'cols': 5, 'rows': 3}
SCREEN = (2560, 1440)


class BgraFastPathTests(unittest.TestCase):
    def tearDown(self):
        scanner_core.close_market_capture()

    def test_release_marker_and_dxcam_native_bgra_path_are_present(self):
        self.assertEqual(scanner_core.CAPTURE_COLOR_FASTPATH_PATCH_VERSION, '1.2.68-dxcam-bgra-fastpath')
        source = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        self.assertIn('output_color="BGRA"', source)
        self.assertIn('get_latest_frame(copy=False, with_timestamp=True)', source)

    def test_bgra_capture_returns_stable_three_channel_frame_from_ring_buffer_view(self):
        scanner_core.close_market_capture()
        region = scanner_core._market_capture_region(GRID, SCREEN)
        rx0, ry0, rx1, ry1 = region
        backing = np.zeros((ry1 - ry0, rx1 - rx0, 4), dtype=np.uint8)
        backing[:, :, 1] = 120
        camera = MagicMock()
        camera.get_latest_frame.side_effect = lambda **kwargs: (backing, 42.0)
        fake_dxcam = types.SimpleNamespace(create=MagicMock(return_value=camera))
        with patch.dict(sys.modules, {'dxcam': fake_dxcam}):
            captured = scanner_core._capture_market_frame(GRID, np, screen_size_override=SCREEN)
        frame, origin, _, screen_size, backend, _, timestamp = captured
        self.assertEqual(fake_dxcam.create.call_args.kwargs['output_color'], 'BGRA')
        self.assertEqual(camera.get_latest_frame.call_args.kwargs, {'copy': False, 'with_timestamp': True})
        self.assertEqual(frame.shape, backing.shape[:2] + (3,))
        self.assertEqual(origin, region[:2])
        self.assertEqual(screen_size, SCREEN)
        self.assertIn('BGRA fast path', backend)
        self.assertEqual(timestamp, 42.0)
        self.assertFalse(np.shares_memory(frame, backing))
        backing[:, :, 1] = 0
        self.assertTrue(np.all(frame[:, :, 1] == 120), 'captured frame must not change when DXcam ring buffer advances')

    def test_unsupported_bgra_creation_falls_back_to_bgr(self):
        scanner_core.close_market_capture()
        region = scanner_core._market_capture_region(GRID, SCREEN)
        rx0, ry0, rx1, ry1 = region
        frame = np.zeros((ry1 - ry0, rx1 - rx0, 3), dtype=np.uint8)
        camera = MagicMock()
        camera.get_latest_frame.return_value = (frame, 77.0)
        create = MagicMock(side_effect=[ValueError('BGRA unavailable'), camera])
        fake_dxcam = types.SimpleNamespace(create=create)
        with patch.dict(sys.modules, {'dxcam': fake_dxcam}):
            captured = scanner_core._capture_market_frame(GRID, np, screen_size_override=SCREEN)
        self.assertEqual(create.call_count, 2)
        self.assertEqual(create.call_args_list[0].kwargs['output_color'], 'BGRA')
        self.assertEqual(create.call_args_list[1].kwargs['output_color'], 'BGR')
        self.assertIn('BGR compatibility fallback', captured[4])
        self.assertEqual(captured[0].shape, frame.shape)

    def test_build_scripts_clean_stale_stage_before_copying_current_sources(self):
        inner = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'build_single_exe.bat.fixture.txt').read_text(encoding='utf-8')
        outer = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        self.assertIn('NGMS271_CoordFast_OneFile', inner)
        self.assertIn("Where-Object { $_.Name -ne '.venv' } | Remove-Item -Recurse -Force", inner)
        selector = (ROOT / 'tools' / 'select_build_workspace.ps1').read_text(encoding='ascii')
        self.assertIn('NGMS1274_FinalFastOCR_Source', selector)
        self.assertIn('select_build_workspace.ps1', outer)
        self.assertIn("1.2.68-dxcam-bgra-fastpath", outer)

    def test_latest_release_docs_warn_exe_must_be_built_on_windows(self):
        readme = (ROOT / 'START_HERE_UA.txt').read_text(encoding='utf-8')
        self.assertIn('1.2.71', readme)
        self.assertIn('готовий нативний EXE у нього не включено', readme)


if __name__ == '__main__':
    unittest.main()
