import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class UltraIntervalV1253Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.settings = json.loads((ROOT / "settings.json").read_text(encoding="utf-8"))
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "tests" / "fixtures" / "build_exe_internal_v1.2.65_legacy.bat.fixture.txt").read_text(encoding="utf-8")

    def test_default_interval_is_20ms_and_config_schema_is_current(self):
        self.assertEqual(self.settings["interval_ms"], 20)
        self.assertEqual(self.settings["config_version"], 31)
        self.assertIn("'interval_ms': 20", self.main)
        self.assertIn("'Ультра+ · 50 мс': 50", self.main)
        self.assertIn("(20, 50, 100, 250, 500, 1000)", self.main)

    def test_precise_timer_and_resume_polling_honor_20ms_floor(self):
        self.assertIn("self.timer.setTimerType(Qt.PreciseTimer)", self.main)
        self.assertGreaterEqual(self.main.count("self.timer.start(max(20, int(self.settings.get('interval_ms', 20) or 20)))"), 2)
        self.assertIn("target_interval_ms = max(20, int(self.settings.get('interval_ms', 20) or 20))", self.main)

    def test_single_flight_guard_remains_when_interval_is_reduced(self):
        scan_timer = self.main.split("    def _on_scan_timer(self):", 1)[1].split("    def _on_scan_worker_finished", 1)[0]
        self.assertIn("self.busy or self._scan_request_active or self.action_in_progress or worker_active or self._action_worker_is_running()", scan_timer)
        self.assertIn("elapsed_ms = (time.perf_counter() - cycle_started) * 1000.0", self.main)
        self.assertIn("CLICK_WORKFLOW_VERSION = \"1.2.65-stable-offer-dedupe\"", self.actions)

    def test_config_schema_does_not_downgrade_during_save(self):
        self.assertNotIn("settings['config_version'] = 26", self.main)
        self.assertNotIn("self.settings['config_version'] = 26", self.main)
        self.assertGreaterEqual(self.main.count("config_version'] = 31"), 5)

    def test_builder_validates_tests_before_pyinstaller_for_current_release(self):
        self.assertIn("NG Market Scanner v1.2.65", self.builder)
        self.assertIn("1.2.65-stable-offer-dedupe", self.builder)
        self.assertLess(self.builder.index("python -m unittest discover -s tests -v"), self.builder.index("python -m PyInstaller"))

if __name__ == "__main__":
    unittest.main()
