import unittest
from pathlib import Path
import scanner_core
import scanner_actions

ROOT = Path(__file__).resolve().parents[1]

class SharedFrameFastDetailValidationV1263Tests(unittest.TestCase):
    def test_persistent_capture_marker_is_exposed(self):
        self.assertEqual(scanner_core.DETAIL_CAPTURE_CACHE_PATCH_VERSION, "1.2.63-shared-watch-frame-detail-capture")
        self.assertIn("_get_detail_capture", (ROOT / "scanner_core.py").read_text(encoding="utf-8"))
        self.assertIn("_get_detail_capture(_mss_module)", (ROOT / "scanner_core.py").read_text(encoding="utf-8"))

    def test_capture_cache_is_used_before_mss_fallback(self):
        source=(ROOT / "scanner_core.py").read_text(encoding="utf-8")
        validator=source.split("def validate_market_detail_screen", 1)[1].split("class ScanWorker", 1)[0]
        self.assertIn("_latest_watch_detail_panel(target_hwnd, detail_frame_not_before)", validator)
        self.assertIn("with _DETAIL_CAPTURE_LOCK:", validator)
        self.assertIn("capture=_get_detail_capture(mss)", validator)
        self.assertIn("capture_backend = 'persistent-mss-fallback'", validator)

    def test_detail_ocr_runs_parallel_with_cta_polling(self):
        source=(ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        run=source.split("    def run(self):", 1)[1]
        validation=run.index("validation_task = self._start_parallel_detail_validation() if self.pre_buy_validator is not None else None")
        poll=run.index("button_ready = self._wait_for_green_button(*detail_xy")
        join=run.index("validation_done.wait()", poll)
        click=run.index("if not self._click(*detail_xy", join)
        self.assertLess(validation, poll)
        self.assertLess(poll, join)
        self.assertLess(join, click)
        self.assertIn("DETAIL_OCR_START_DELAY_MS = 220", source)
        self.assertIn("CLICK_LATENCY_PATCH_VERSION = \"1.2.65-fast-coalesce-compact-detail-ocr\"", source)


    def test_shared_watcher_frame_is_fresh_post_click_and_same_window(self):
        import numpy as np
        core = scanner_core
        with core._WATCH_DETAIL_FRAME_LOCK:
            old_frame, old_meta, old_last = core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT
        try:
            # The watcher's ROI covers x≈13.3%..100%, y≈7.5%..91.5% of a Full HD screen.
            frame = np.zeros((907, 1665, 3), dtype=np.uint8)
            now = __import__('time').perf_counter()
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME = frame
                core._WATCH_DETAIL_FRAME_META = {'captured_at': now, 'screen_size': (1920,1080),
                                                 'origin': (255,81), 'target_hwnd': 123}
                core._WATCH_DETAIL_FRAME_LAST_COPY_AT = now
            cached = core._latest_watch_detail_panel(123, now - .01)
            self.assertIsNotNone(cached)
            panel, meta = cached
            self.assertEqual(panel.shape[:2], (int(.295*1080)-int(.135*1080), int(.990*1920)-int(.690*1920)))
            self.assertEqual(meta['capture_backend'], 'shared-direct-watch-frame')
            self.assertIsNone(core._latest_watch_detail_panel(124, now - .01))
            self.assertIsNone(core._latest_watch_detail_panel(123, now + .01))
        finally:
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT = old_frame, old_meta, old_last


    def test_detail_validator_prefers_watch_frame_without_mss_regrab(self):
        import sys, time, types, numpy as np
        from unittest.mock import patch
        core = scanner_core
        with core._WATCH_DETAIL_FRAME_LOCK:
            old_frame, old_meta, old_last = core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT
        now = time.perf_counter()
        try:
            frame = np.zeros((907, 1665, 3), dtype=np.uint8)
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME = frame
                core._WATCH_DETAIL_FRAME_META = {'captured_at': now, 'screen_size': (1920,1080),
                                                 'origin': (255,81), 'target_hwnd': None}
                core._WATCH_DETAIL_FRAME_LAST_COPY_AT = now
            def forbidden_mss():
                raise AssertionError('MSS fallback should not be used when a fresh watcher frame exists')
            fake_mss = types.SimpleNamespace(mss=forbidden_mss)
            def fake_engine(image):
                def box(y):
                    return [[0,y],[200,y],[200,y+25],[0,y+25]]
                return [
                    (box(38), 'Karin Land Cruiser 100', .99),
                    (box(123), 'Ціна: $8 500', .99),
                    (box(204), 'Хороша ціна: -27% до ринку ($11 651)', .99),
                ], .001
            with patch.dict(sys.modules, {'mss': fake_mss}), \
                 patch.object(core, '_foreground_matches_target', return_value=True), \
                 patch.object(core, '_get_ocr_engine', return_value=fake_engine):
                result = core.validate_market_detail_screen(
                    ['Karin Land Cruiser 100'], ['Karin Land Cruiser 100'],
                    {'Karin Land Cruiser 100': {'category': 'Звичайне'}}, 20, {}, set(), 27,
                    target_hwnd=None, confidence_floor=.93, detail_frame_not_before=now-.01)
            self.assertTrue(result['ok'], result['reason'])
            self.assertEqual(result['discount_value'], 27)
            self.assertEqual(result['market_reference_price_value'], 11651)
            self.assertEqual(result['capture_backend'], 'shared-direct-watch-frame')
            self.assertLess(result['capture_seconds'], .050)
        finally:
            with core._WATCH_DETAIL_FRAME_LOCK:
                core._WATCH_DETAIL_FRAME, core._WATCH_DETAIL_FRAME_META, core._WATCH_DETAIL_FRAME_LAST_COPY_AT = old_frame, old_meta, old_last

    def test_internal_detail_retry_prevents_a_third_redundant_ocr_attempt(self):
        source=(ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        self.assertIn("and not bool(self.validated_details.get('detail_retry_attempted'))", source)
        self.assertIn("_retry_discount_mismatch=False", (ROOT / "scanner_core.py").read_text(encoding="utf-8"))

    def test_legacy_safety_guards_remain(self):
        source=(ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        self.assertIn("if not bool(self.validated_details.get('ok')):", source)
        self.assertIn("if self._screen_size() != self.scan_screen_size", source)
        self.assertIn("if self._wait_for_green_button_gone(*confirm_xy", source)

if __name__ == "__main__":
    unittest.main(verbosity=2)
