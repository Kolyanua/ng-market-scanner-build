import json
import re
import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]

class VehicleAssetsAndIconTests(unittest.TestCase):
    def test_new_cutouts_have_true_alpha_and_large_canvas(self):
        names = ['Obey_A8_D5.png','Coil_Semi.png','BF_Surfer.png','Karin_Tundra.png','Progen_Senna.png',
                 'Vapid_Transit_V347.png','Benefactor_CLS_Class_C257.png','Ubermacht_M4_F82.png','Canis_Track_Hawk.png',
                 'Ubermacht_X5_E70.png','Vapid_Mustang_GT_S550.png','Benefactor_G_Class_W463.png','Pfister_Macan_95B.png',
                 'BF_Golf_VIII.png','Ubermacht_M4_G82.png','Dinka_Civic_FK2.png','Dinka_S2000.png','Annis_GT_R_R35_Japan_Spec.png',
                 'Obey_RS6_C8.png','Benefactor_S_Class_W223.png','Coil_Model_3.png','Karin_Supra_A80.png','Karin_WRX_STI_GDB.png',
                 'Annis_RX8_SE3P.png','Lampadati_Giulia.png','Bollokan_Creta.png','Bollokan_Rio_QB.png']
        for name in names:
            path = ROOT / 'vehicle_renders' / name
            self.assertTrue(path.is_file(), name)
            im = Image.open(path).convert('RGBA')
            self.assertGreaterEqual(im.width, 1000, name)
            self.assertEqual(im.size, (1200, 620), name)
            alpha = im.getchannel('A')
            self.assertEqual(alpha.getextrema()[0], 0, name)
            self.assertGreaterEqual(alpha.getextrema()[1], 250, name)

    def test_every_supported_vehicle_resolves_to_a_high_resolution_preview(self):
        import ast
        source = (ROOT / 'main.py').read_text(encoding='utf-8')
        tree = ast.parse(source)
        aliases = {}
        for node in tree.body:
            if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'VEHICLE_RENDER_ALIASES' for t in node.targets):
                aliases = ast.literal_eval(node.value)
                break
        self.assertTrue(aliases)
        models = [x.strip() for x in (ROOT / 'all_vehicles.txt').read_text(encoding='utf-8').splitlines() if x.strip() and not x.lstrip().startswith('#')]
        for model in models:
            if model in aliases:
                path = ROOT / 'vehicle_renders' / aliases[model]
            else:
                import re
                stem = re.sub(r'[^A-Za-z0-9]+', '_', model).strip('_')
                path = ROOT / 'vehicle_renders' / (stem + '.png')
                if not path.is_file():
                    path = ROOT / 'vehicle_renders' / (stem + '.jpg')
            self.assertTrue(path.is_file(), model)
            with Image.open(path) as image:
                self.assertGreaterEqual(image.width, 1000, f'{model}: {path.name} is too small ({image.size})')
                self.assertGreaterEqual(image.height, 500, f'{model}: {path.name} is too short ({image.size})')
                if image.format == 'PNG':
                    self.assertIn('A', image.getbands(), f'{model}: {path.name} should support transparency')
                    alpha = image.getchannel('A')
                    self.assertEqual(alpha.getextrema()[0], 0, f'{model}: {path.name} should have transparent pixels')
                    self.assertGreaterEqual(alpha.getextrema()[1], 250, f'{model}: {path.name} should have opaque vehicle pixels')

    def test_icon_is_a_real_multiresolution_windows_ico(self):
        icon = ROOT / 'assets' / 'ng_market_scanner.ico'
        self.assertTrue(icon.is_file())
        self.assertTrue((ROOT / 'assets' / 'ng_market_scanner.png').is_file())
        with Image.open(icon) as im:
            self.assertEqual(im.format, 'ICO')
            self.assertGreaterEqual(im.size[0], 128)

    def test_runtime_rejects_legacy_pixelated_render_assets(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn('MIN_PREVIEW_WIDTH = 1000', main)
        self.assertIn('MIN_PREVIEW_HEIGHT = 500', main)
        self.assertIn('reader.size()', main)
        self.assertIn('if _is_high_resolution_preview(candidate):', main)

    def test_aliases_are_explicitly_marked_as_references(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn('APPROXIMATE_RENDER_MODELS = set(VEHICLE_RENDER_ALIASES)', main)
        self.assertIn("'approximate': 'Візуальний референс схожого кузова; точна модель не підтверджена'", main)
        self.assertTrue((ROOT/'VEHICLE_CUTOUTS_PROVENANCE_UA.txt').is_file())

if __name__ == '__main__': unittest.main()
