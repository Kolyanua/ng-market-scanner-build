import importlib
import sys
import types
import unittest

# The test environment used to validate coordinate math may not have Qt installed.
# Add a tiny import-only stub; no thread or UI actions are executed by these tests.
try:
    from PySide6.QtCore import QThread, Signal  # noqa: F401
except Exception:
    pyside = types.ModuleType('PySide6')
    qtcore = types.ModuleType('PySide6.QtCore')
    class QThread:  # pragma: no cover - only an import stub
        pass
    class _Signal:  # pragma: no cover - only an import stub
        def __init__(self, *args, **kwargs):
            pass
    qtcore.QThread = QThread
    qtcore.Signal = _Signal
    pyside.QtCore = qtcore
    sys.modules.setdefault('PySide6', pyside)
    sys.modules.setdefault('PySide6.QtCore', qtcore)

from scanner_actions import (scale_reference_point, DETAIL_BUY, FINAL_CONFIRM,
                              CLICK_WORKFLOW_VERSION, DETAIL_TRANSITION_MS, CONFIRM_TRANSITION_MS, BUTTON_POLL_INTERVAL_MS, _looks_like_green_button, button_probe_offsets, CLICK_BUTTON_PROBE_PATCH_VERSION, locate_green_button_center_bgr, CLICK_DYNAMIC_CONFIRM_PATCH_VERSION)

class ScannerActionMathTests(unittest.TestCase):
    def test_reference_coordinates_1920_by_1080(self):
        self.assertEqual(scale_reference_point((1485, 1042), (1920, 1080)), (1485, 1042))

    def test_reference_coordinates_scaled_16_9(self):
        self.assertEqual(scale_reference_point((1485, 1042), (1280, 720)), (990, 695))

    def test_actual_purchase_buttons_scale_to_2560_by_1440_2k(self):
        self.assertEqual(scale_reference_point(DETAIL_BUY, (2560, 1440)), (1979, 1340))
        self.assertEqual(scale_reference_point(FINAL_CONFIRM, (2560, 1440)), (1427, 956))

    def test_non_16_9_screen_fails_closed(self):
        with self.assertRaises(ValueError):
            scale_reference_point((1485, 1042), (1600, 1000))

    def test_actual_purchase_buttons_keep_reference_coordinates(self):
        self.assertEqual(scale_reference_point(DETAIL_BUY, (1920, 1080)), (1484, 1005))
        self.assertEqual(scale_reference_point(FINAL_CONFIRM, (1920, 1080)), (1070, 717))

    def test_actual_purchase_buttons_scale_to_1280_by_720(self):
        self.assertEqual(scale_reference_point(DETAIL_BUY, (1280, 720)), (989, 670))
        self.assertEqual(scale_reference_point(FINAL_CONFIRM, (1280, 720)), (713, 478))
        
    def test_latest_workflow_marker_and_render_transition_guards(self):
        self.assertEqual(CLICK_WORKFLOW_VERSION, "1.2.65-stable-offer-dedupe")
        self.assertEqual(DETAIL_TRANSITION_MS, 1400)
        self.assertEqual(CONFIRM_TRANSITION_MS, 1400)
        self.assertEqual(BUTTON_POLL_INTERVAL_MS, 1)


    def test_green_button_signature_detects_mint_purchase_pixel(self):
        # COLORREF for RGB(43,255,183) from the supplied green CTA screenshot.
        colorref = 43 | (255 << 8) | (183 << 16)
        self.assertTrue(_looks_like_green_button(colorref))

    def test_green_button_signature_rejects_red_discount_pixel(self):
        colorref = 220 | (55 << 8) | (65 << 16)
        self.assertFalse(_looks_like_green_button(colorref))

    def test_2k_detail_buy_probes_avoid_text_glyphs_and_stay_inside_compact_button(self):
        self.assertEqual(CLICK_BUTTON_PROBE_PATCH_VERSION, "1.2.65.1-2k-offtext-probes")
        probes = button_probe_offsets((2560, 1440), "detail_buy")
        self.assertEqual(probes, ((-51, -20), (51, -20), (-51, 20), (51, 20), (-51, 0), (51, 0)))
        self.assertTrue(all(abs(x) < 58 and abs(y) < 28 for x, y in probes))

    def test_2k_final_confirm_probes_sample_background_outside_wide_label(self):
        probes = button_probe_offsets((2560, 1440), "confirm")
        self.assertEqual(probes, ((-144, -23), (144, -23), (-144, 23), (144, 23), (-144, 0), (144, 0)))
        # Expected screenshot geometry: the modal CTA is ~374 px wide and ~72 px tall;
        # these points avoid the centered white text but stay on its green background.
        self.assertTrue(all(abs(x) < 187 and abs(y) < 36 for x, y in probes))

    def test_v1270_dynamic_confirm_finds_green_button_shifted_by_lot_not_found_banner(self):
        import numpy as np
        self.assertEqual(CLICK_DYNAMIC_CONFIRM_PATCH_VERSION, "1.2.70-dynamic-cta-and-lot-not-found-guard")
        # Synthetic ROI captured around the 2K modal. Green CTA has shifted down
        # 25 px from its nominal location after the yellow "Лот не знайдено" alert.
        frame = np.zeros((250, 500, 3), dtype=np.uint8)
        frame[120:170, 210:490] = (183, 255, 43)  # BGR for mint-green button
        found = locate_green_button_center_bgr(
            frame, 800, 500, (1100, 620), (2560, 1440), 'confirm'
        )
        self.assertIsNotNone(found)
        self.assertTrue(abs(found[0] - 1150) <= 8, found)
        self.assertTrue(abs(found[1] - 645) <= 8, found)

    def test_v1270_dynamic_confirm_fails_closed_without_green_cta(self):
        import numpy as np
        frame = np.zeros((250, 500, 3), dtype=np.uint8)
        frame[120:170, 210:490] = (65, 55, 220)  # red / non-green area
        self.assertIsNone(locate_green_button_center_bgr(
            frame, 800, 500, (1100, 620), (2560, 1440), 'confirm'
        ))

    def test_fast_purchase_reuses_verified_window_and_reports_elapsed_time(self):
        from pathlib import Path
        source = (Path(__file__).resolve().parents[1] / 'scanner_actions.py').read_text(encoding='utf-8')
        self.assertIn('target_hwnd=None, candidate_detected_at=None', source)
        self.assertIn('self.target_hwnd = int(target_hwnd)', source)
        self.assertIn('if not user32.IsWindow(hwnd) or user32.GetForegroundWindow() != hwnd', source)
        self.assertIn('def _detection_elapsed_ms(self):', source)
        self.assertIn('t+{elapsed:.1f} мс від передачі кандидата', source)

    def test_click_is_sent_as_atomic_down_up_without_hold_sleep(self):
        from pathlib import Path
        source = (Path(__file__).resolve().parents[1] / 'scanner_actions.py').read_text(encoding='utf-8')
        method = source.split('def _send_atomic_left_click', 1)[1].split('def _click', 1)[0]
        click = source.split('def _click(', 1)[1].split('def run(', 1)[0]
        self.assertIn('SendInput(2, events', method)
        self.assertIn('left_down', method)
        self.assertIn('left_up', method)
        self.assertNotIn('mouse_event', click)
        self.assertNotIn('time.sleep(0.001)', click)

if __name__ == '__main__':
    unittest.main(verbosity=2)
