from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class CoordinateFastFlowV1271Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "build_single_exe_internal.bat").read_text(encoding="utf-8")

    def test_nominal_coordinate_chain_is_within_250ms(self):
        self.assertIn('FAST_COORDINATE_HOVER_MS = 10', self.actions)
        self.assertIn('FAST_COORDINATE_GAP_MS = 50', self.actions)
        self.assertIn('FAST_COORDINATE_TARGET_MS = 250', self.actions)
        nominal_ms = 3 * 10 + 2 * 50
        self.assertEqual(nominal_ms, 130)
        self.assertLessEqual(nominal_ms, 250)

    def test_fast_chain_sends_three_distinct_coordinate_clicks(self):
        method = self.actions.split('def _run_fast_coordinate_flow(', 1)[1].split('def run(self):', 1)[0]
        self.assertEqual(method.count('hover_dwell_ms=FAST_COORDINATE_HOVER_MS'), 3)
        self.assertEqual(method.count('self._wait_precise_ms(FAST_COORDINATE_GAP_MS)'), 2)
        self.assertIn('self._click(*self.card_xy', method)
        self.assertIn('self._click(*detail_xy', method)
        self.assertIn('self._click(*confirm_xy', method)

    def test_fast_path_skips_detail_ocr_and_post_confirm_result_polling(self):
        method = self.actions.split('def _run_fast_coordinate_flow(', 1)[1].split('def run(self):', 1)[0]
        self.assertNotIn('_wait_for_green_button(', method)
        self.assertNotIn('_wait_for_green_button_gone(', method)
        self.assertNotIn('_call_pre_buy_validator(', method)
        self.assertIn('[FAST_FLOW_NO_POSTCHECK]', method)
        self.assertIn('Результат сервера навмисно не перевірявся', method)

    def test_fast_flow_remains_limited_to_preflight_candidates_with_auto_confirm(self):
        self.assertIn('fast_coordinate_flow = bool(auto_confirm_enabled and not direct_mode)', self.main)
        self.assertIn('fast_coordinate_flow=fast_coordinate_flow', self.main)
        self.assertIn('EXPECTED_FAST_COORDINATE_FLOW_VERSION', self.main)

    def test_builder_requires_fast_flow_marker_before_packaging(self):
        self.assertIn('1.2.71-fixed-coordinate-fast-chain-no-postcheck', self.builder)
        self.assertIn('NG Market Scanner v1.2.71', self.builder)
        outer = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='ascii')
        self.assertIn('NGMS_STAGE_DIR', outer)
        self.assertIn('powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command', outer)
        self.assertIn('call build_single_exe_internal.bat', outer)
        self.assertIn('NG Market Scanner.exe.new', outer)
        self.assertIn('final EXE was not published', outer)
        self.assertNotIn('call build_single_exe.bat', outer)
        self.assertNotIn('findstr /C:', outer)
        self.assertTrue(all(ord(ch) < 128 for ch in outer))

    def test_action_result_is_recorded_as_clicks_sent_not_purchase_confirmed(self):
        on_result = self.main.split('    def on_action_result(', 1)[1].split('    def ', 1)[0]
        self.assertIn("fast_no_postcheck = '[FAST_FLOW_NO_POSTCHECK]' in message_text", on_result)
        self.assertIn("event_type = 'purchase_flow_sent' if success else 'purchase_flow_failed'", on_result)
        self.assertIn('Результат сервера навмисно не перевірявся', self.actions)

if __name__ == '__main__':
    unittest.main()
