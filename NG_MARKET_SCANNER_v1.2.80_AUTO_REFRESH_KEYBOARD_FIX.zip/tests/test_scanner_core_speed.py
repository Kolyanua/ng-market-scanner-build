import sys
import types
import unittest
import time
from pathlib import Path
from unittest.mock import patch

# Test cache helpers without requiring the GUI runtime installed on the build host.
try:
    from PySide6.QtCore import QThread, Signal  # noqa: F401
except Exception:
    pyside = types.ModuleType('PySide6')
    qtcore = types.ModuleType('PySide6.QtCore')
    class QThread:
        pass
    class _Signal:
        def __init__(self, *args, **kwargs):
            pass
    qtcore.QThread = QThread
    qtcore.Signal = _Signal
    pyside.QtCore = qtcore
    sys.modules.setdefault('PySide6', pyside)
    sys.modules.setdefault('PySide6.QtCore', qtcore)

import cv2
import numpy as np
import scanner_core
from scanner_core import ScanWorker


class ForegroundCaptureGuardTests(unittest.TestCase):
    def test_capture_guard_accepts_expected_game_hwnd(self):
        self.assertTrue(scanner_core._foreground_matches_target(1234, 1234))

    def test_capture_guard_rejects_terminal_or_other_window(self):
        self.assertFalse(scanner_core._foreground_matches_target(1234, 5678))

    def test_capture_guard_is_permissive_when_no_target_was_supplied(self):
        self.assertTrue(scanner_core._foreground_matches_target(None, 5678))


    def test_capture_guard_accepts_owned_or_same_process_foreground_window(self):
        self.assertTrue(scanner_core._same_target_window_or_process(
            1234, 5678, target_root=100, foreground_root=100,
            target_pid=7, foreground_pid=9))
        self.assertTrue(scanner_core._same_target_window_or_process(
            1234, 5678, target_pid=77, foreground_pid=77))
        self.assertFalse(scanner_core._same_target_window_or_process(
            1234, 5678, target_root=100, foreground_root=200,
            target_pid=77, foreground_pid=88))


class FastScanCacheTests(unittest.TestCase):
    def setUp(self):
        # These worker-level cache tests use deterministic FakeMSS frames. On Windows,
        # DXcam may be installed and _primary_screen_size() would select the real desktop
        # before the fake MSS backend, making tests read the user's live screen instead
        # of the synthetic frame. Force the fallback path for this test class only; the
        # persistent DXcam backend has its own dedicated tests elsewhere in the suite.
        self._screen_size_patcher = patch('scanner_core._primary_screen_size', return_value=None)
        self._screen_size_patcher.start()
        self.addCleanup(self._screen_size_patcher.stop)

    def test_rapidocr_3_output_adapter_preserves_boxes_text_scores_and_elapsed(self):
        from scanner_core import _RapidOCRAdapter
        class ModernResult:
            boxes = np.asarray([[[1, 2], [11, 2], [11, 8], [1, 8]]], dtype=np.int32)
            txts = ("-11%",)
            scores = (0.97,)
            elapse = 0.042
        class FakeModernEngine:
            def __call__(self, image):
                return ModernResult()
        rows, elapsed = _RapidOCRAdapter(FakeModernEngine())(np.zeros((10, 20, 3), dtype=np.uint8))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0][1], "-11%")
        self.assertAlmostEqual(rows[0][2], 0.97)
        self.assertEqual(rows[0][0], [[1, 2], [11, 2], [11, 8], [1, 8]])
        self.assertAlmostEqual(elapsed, 0.042)

    def test_directml_gpu_provider_is_prioritized_when_available(self):
        attempts = scanner_core._engine_config_attempts(
            ["DmlExecutionProvider", "CPUExecutionProvider"]
        )
        self.assertEqual(attempts[0][0], "directml-fast")
        self.assertTrue(attempts[0][1]["EngineConfig.onnxruntime.use_dml"])
        self.assertFalse(attempts[0][1]["EngineConfig.onnxruntime.use_cuda"])
        self.assertIn("fast-cpu-fallback", [label for label, _ in attempts])

    def test_cpu_only_runtime_keeps_safe_fallback(self):
        attempts = scanner_core._engine_config_attempts(["CPUExecutionProvider"])
        labels = [label for label, _ in attempts]
        self.assertEqual(labels[0], "fast-cpu-fallback")
        self.assertNotIn("directml-fast", labels)
        self.assertNotIn("cuda-fast", labels)
        self.assertFalse(attempts[0][1]["EngineConfig.onnxruntime.use_dml"])
        self.assertFalse(attempts[0][1]["EngineConfig.onnxruntime.use_cuda"])

    def test_signature_stable_and_changes_with_listing_text(self):
        name = np.zeros((42, 240, 3), dtype=np.uint8)
        price = np.zeros((34, 120, 3), dtype=np.uint8)
        badge = np.zeros((34, 80, 3), dtype=np.uint8)
        cv2.putText(name, 'Dinka Civic EK6', (3, 27), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(price, '$15 499', (2, 23), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(badge, '-6%', (3, 23), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (30, 220, 60), 1, cv2.LINE_AA)
        first = ScanWorker._signature_for_crops(name, price, badge, 'GREEN', cv2, np)
        same = ScanWorker._signature_for_crops(name.copy(), price.copy(), badge.copy(), 'GREEN', cv2, np)
        self.assertEqual(first, same)

        # Small luminance jitter from display capture should not force a full OCR pass.
        mildly_changed = name.copy()
        mildly_changed = cv2.convertScaleAbs(mildly_changed, alpha=1.0, beta=2)
        stable_under_noise = ScanWorker._signature_for_crops(
            mildly_changed, price, badge, 'GREEN', cv2, np
        )
        self.assertEqual(first, stable_under_noise)

        # A one-canonical-pixel capture shift should not mark stable text as new.
        field_sig = ScanWorker._signature_for_crop(name, (128, 22), cv2)
        field_mask = np.unpackbits(
            np.frombuffer(field_sig, dtype=np.uint8), count=128 * 22
        ).reshape(22, 128)
        shifted_mask = np.zeros_like(field_mask)
        shifted_mask[1:, 1:] = field_mask[:-1, :-1]
        shifted_sig = np.packbits(shifted_mask.reshape(-1).astype(np.uint8)).tobytes()
        self.assertFalse(ScanWorker._field_signature_changed(
            field_sig, shifted_sig, 'name', cv2, np
        ))

        changed_price = price.copy()
        cv2.rectangle(changed_price, (0, 0), (119, 33), (255, 255, 255), -1)
        changed = ScanWorker._signature_for_crops(name, changed_price, badge, 'GREEN', cv2, np)
        self.assertNotEqual(first, changed)

        # A real digit change must never be mistaken for harmless capture noise.
        six = np.zeros((34, 80, 3), dtype=np.uint8)
        eight = np.zeros((34, 80, 3), dtype=np.uint8)
        cv2.putText(six, '6%', (3, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(eight, '8%', (3, 23), cv2.FONT_HERSHEY_SIMPLEX, 0.5,
                    (255, 255, 255), 1, cv2.LINE_AA)
        six_mask = ScanWorker._signature_for_crop(six, (64, 22), cv2)
        eight_mask = ScanWorker._signature_for_crop(eight, (64, 22), cv2)
        self.assertTrue(ScanWorker._field_signature_changed(
            {'mask': six_mask, 'color': 'GREEN'},
            {'mask': eight_mask, 'color': 'GREEN'}, 'badge', cv2, np
        ))
        price_a = np.zeros((34, 120, 3), dtype=np.uint8)
        price_b = np.zeros((34, 120, 3), dtype=np.uint8)
        cv2.putText(price_a, '$10 000', (2, 23), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)
        cv2.putText(price_b, '$10 008', (2, 23), cv2.FONT_HERSHEY_SIMPLEX,
                    0.5, (255, 255, 255), 1, cv2.LINE_AA)
        price_sig_a = ScanWorker._signature_for_crop(price_a, (96, 22), cv2)
        price_sig_b = ScanWorker._signature_for_crop(price_b, (96, 22), cv2)
        self.assertTrue(ScanWorker._field_signature_changed(
            price_sig_a, price_sig_b, 'price', cv2, np
        ))

        # The real cache now fingerprints native-resolution crops, so 1–2 raw-pixel
        # renderer jitter can be aligned without hiding a real changed digit.
        native_name = ScanWorker._native_field_signature(name, cv2)
        shifted_name_image = np.zeros_like(name)
        shifted_name_image[:, 1:] = name[:, :-1]
        native_name_shifted = ScanWorker._native_field_signature(shifted_name_image, cv2)
        self.assertFalse(ScanWorker._field_signature_changed(
            native_name, native_name_shifted, 'name', cv2, np
        ))
        changed_name_image = np.zeros_like(name)
        cv2.putText(changed_name_image, 'Dinka Civic EK8', (3, 27), cv2.FONT_HERSHEY_SIMPLEX,
                    0.6, (255, 255, 255), 1, cv2.LINE_AA)
        native_name_changed = ScanWorker._native_field_signature(changed_name_image, cv2)
        self.assertTrue(ScanWorker._field_signature_changed(
            native_name, native_name_changed, 'name', cv2, np
        ))

        native_price_a = ScanWorker._native_field_signature(price_a, cv2)
        native_price_b = ScanWorker._native_field_signature(price_b, cv2)
        self.assertTrue(ScanWorker._field_signature_changed(
            native_price_a, native_price_b, 'price', cv2, np
        ))
        native_badge_six = ScanWorker._native_field_signature(six, cv2)
        native_badge_eight = ScanWorker._native_field_signature(eight, cv2)
        self.assertTrue(ScanWorker._field_signature_changed(
            {**native_badge_six, 'color': 'GREEN'},
            {**native_badge_eight, 'color': 'GREEN'}, 'badge', cv2, np
        ))

    def test_static_screen_uses_cache_without_calling_ocr_engine(self):
        # A full worker-level test proving unchanged text zones bypass OCR entirely.
        import json
        screenshot_bgra = np.zeros((600, 1000, 4), dtype=np.uint8)
        screenshot_bgra[:, :, 3] = 255

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screenshot_bgra.copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss

        names = [f'Model {i}' for i in range(15)]
        grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
        worker = ScanWorker(names, {}, 20, {}, grid, active_models=set(names))
        class FakeSignal:
            def emit(self, *args, **kwargs):
                self.last = args
        worker.result = FakeSignal()
        worker.progress = FakeSignal()
        width, height = 1000, 600
        x0, x1, y0, y1 = int(.10 * width), int(.95 * width), int(.10 * height), int(.90 * height)
        bgr = screenshot_bgra[:, :, :3].copy()
        contexts = worker._extract_card_contexts(bgr, x0, x1, y0, y1, 5, 3, 0, 0,
                                                  (width, height), cv2, np)
        config_key, screen_key = worker._config_cache_key((width, height), 0, 0, x0, x1, y0, y1, 5, 3)
        previous_globals = (
            scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
            scanner_core._CARD_CACHE_FIELD_SIGNATURES,
            scanner_core._CARD_CACHE_CONFIG_KEY, scanner_core._CARD_CACHE_SCREEN_KEY,
            dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT),
        )
        scanner_core._CARD_CACHE_SIGNATURES = [c['signature'] for c in contexts]
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = [c['field_signatures'] for c in contexts]
        scanner_core._CARD_CACHE_RESULTS = [
            {'card': i + 1, 'model': names[i], 'catalog_model': names[i], 'price': '$10 000',
             'price_value': 10000, 'discount': '—', 'discount_value': None, 'discount_kind': 'none',
             'threshold': 20, 'category': 'Звичайне', 'status': 'Без бейджа знижки',
             'eligible': False, 'model_confidence': 1.0, 'badge_color': 'NONE',
             'xy': contexts[i]['xy'], 'screen_size': (width, height), '_cacheable': True, '_cache_hit': False}
            for i in range(15)
        ]
        scanner_core._CARD_CACHE_CONFIG_KEY = config_key
        scanner_core._CARD_CACHE_SCREEN_KEY = screen_key
        # Simulate a small capture brightness shift after the cache baseline was made.
        screenshot_bgra[:, :, :3] = 2
        diag_path = Path(scanner_core.__file__).resolve().parent / 'last_scan_diagnostics.json'
        existed = diag_path.exists()
        old_diag = diag_path.read_bytes() if existed else None
        try:
            start = time.perf_counter()
            worker.run()
            elapsed = time.perf_counter() - start
            self.assertEqual(worker._ocr_call_count, 0)
            self.assertEqual(worker._cache_hits, 15)
            self.assertEqual(worker._changed_cards, 0)
            self.assertLess(elapsed, 1.0)
        finally:
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES,
             scanner_core._CARD_CACHE_CONFIG_KEY, scanner_core._CARD_CACHE_SCREEN_KEY,
             retry_timestamps) = previous_globals
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss
            if existed:
                diag_path.write_bytes(old_diag)
            else:
                diag_path.unlink(missing_ok=True)


    def test_one_changed_card_triggers_one_batch_and_updates_discount_result(self):
        screen_ref = {'value': np.zeros((600, 1000, 4), dtype=np.uint8)}
        screen_ref['value'][:, :, 3] = 255

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screen_ref['value'].copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss

        model = 'Dinka Civic EK6'
        grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
        rules = {model: {'category': 'Звичайне', 'threshold': 6}}
        worker = ScanWorker([model], rules, 6, {model: 6}, grid, active_models={model})
        class FakeSignal:
            def emit(self, *args, **kwargs): self.last = args
        worker.result = FakeSignal()
        worker.progress = FakeSignal()
        width, height = 1000, 600
        x0, x1, y0, y1 = 100, 950, 60, 540
        baseline = screen_ref['value'][:, :, :3].copy()
        baseline_contexts = worker._extract_card_contexts(
            baseline, x0, x1, y0, y1, 5, 3, 0, 0, (width, height), cv2, np
        )
        config_key, screen_key = worker._config_cache_key((width, height), 0, 0, x0, x1, y0, y1, 5, 3)
        saved = (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
                 scanner_core._CARD_CACHE_FIELD_SIGNATURES,
                 scanner_core._CARD_CACHE_CONFIG_KEY, scanner_core._CARD_CACHE_SCREEN_KEY,
                 dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT))
        scanner_core._CARD_CACHE_SIGNATURES = [c['signature'] for c in baseline_contexts]
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = [c['field_signatures'] for c in baseline_contexts]
        scanner_core._CARD_CACHE_RESULTS = [
            {'card': i + 1, 'model': model, 'catalog_model': model,
             'name_text': model, 'price_text': '$10 000', 'badge_text': '',
             'name_confidence': 0.99, 'price_confidence': 0.99, 'badge_confidence': 0.0,
             'price': '$10 000', 'price_value': 10000, 'discount': '—', 'discount_value': None, 'discount_kind': 'none',
             'threshold': 6, 'category': 'Звичайне', 'status': 'Без бейджа знижки',
             'eligible': False, 'model_confidence': 1.0, 'badge_color': 'NONE',
             'xy': baseline_contexts[i]['xy'], 'screen_size': (width, height),
             '_cacheable': True, '_cache_hit': False}
            for i in range(15)
        ]
        scanner_core._CARD_CACHE_CONFIG_KEY = config_key
        scanner_core._CARD_CACHE_SCREEN_KEY = screen_key

        # Add one green discount badge in card 1, leaving all other card text zones intact.
        changed = screen_ref['value'].copy()
        cv2.rectangle(changed, (236, 197), (266, 211), (25, 48, 25, 255), -1)
        screen_ref['value'] = changed

        class FakeOCR:
            def __init__(self): self.calls = 0
            def __call__(self, image):
                self.calls += 1
                def box(a, b, c, d): return [[a,b],[c,b],[c,d],[a,d]]
                # Only the badge changed, so the montage contains the badge crop alone.
                return [[box(7, 10, 34, 32), '6%', 0.99]], None

        fake_ocr = FakeOCR()
        diag_path = Path(scanner_core.__file__).resolve().parent / 'last_scan_diagnostics.json'
        existed = diag_path.exists()
        old_diag = diag_path.read_bytes() if existed else None
        try:
            with patch('scanner_core._get_ocr_engine', return_value=fake_ocr):
                worker.run()
            self.assertEqual(fake_ocr.calls, 1)
            self.assertEqual(worker._ocr_call_count, 1)
            self.assertEqual(worker._changed_cards, 1)
            self.assertEqual(worker._cache_hits, 14)
            result_rows = worker.result.last[0]
            self.assertEqual(result_rows[0]['model'], model)
            # Price did not change in the synthetic screenshot; it should be reused from cache.
            self.assertEqual(result_rows[0]['price_value'], 10000)
            self.assertEqual(result_rows[0]['discount'], '-6%')
            self.assertTrue(result_rows[0]['eligible'])

            # Even a fail-closed/uncertain row should be reused while its pixels
            # are unchanged; it must not trigger OCR on every polling cycle.
            scanner_core._CARD_CACHE_RESULTS[0]['eligible'] = False
            scanner_core._CARD_CACHE_RESULTS[0]['_cacheable'] = False
            cached_worker = ScanWorker([model], rules, 6, {model: 6}, grid, active_models={model})
            cached_worker.result = FakeSignal()
            cached_worker.progress = FakeSignal()
            with patch('scanner_core._get_ocr_engine', side_effect=AssertionError('OCR should be skipped for unchanged pixels')):
                cached_worker.run()
            self.assertEqual(cached_worker._changed_cards, 0)
            self.assertEqual(cached_worker._cache_hits, 15)
            self.assertEqual(cached_worker._ocr_call_count, 0)
            self.assertFalse(cached_worker.result.last[0][0]['eligible'])
        finally:
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES,
             scanner_core._CARD_CACHE_CONFIG_KEY, scanner_core._CARD_CACHE_SCREEN_KEY,
             retry_timestamps) = saved
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss
            if existed:
                diag_path.write_bytes(old_diag)
            else:
                diag_path.unlink(missing_ok=True)



    def test_default_1920_layout_uses_exact_ahk_badge_rect_and_dark_rgb(self):
        # Match the screen geometry and dark RGB threshold in ng_discount_ocr.ps1.
        screen = np.zeros((1080, 1920, 3), dtype=np.uint8)
        lefts = (0.155, 0.322, 0.489, 0.655, 0.822)
        rights = (0.315, 0.481, 0.647, 0.813, 0.981)
        card_left = int(lefts[0] * 1920)
        card_right = int(rights[0] * 1920)
        card_w = card_right - card_left
        bx = card_left + int(0.775 * card_w)
        by = int(0.321 * 1080)
        bw = int(0.205 * card_w)
        bh = int(0.027 * 1080)
        screen[by:by + bh, bx:bx + bw] = (25, 48, 25)  # BGR, AHK green
        worker = ScanWorker(['Dinka Civic EK6'], {}, 20, {},
                            {'left': .153, 'top': .095, 'right': .985, 'bottom': .895,
                             'cols': 5, 'rows': 3})
        contexts = worker._extract_card_contexts(
            screen, int(.153 * 1920), int(.985 * 1920), int(.095 * 1080), int(.895 * 1080),
            5, 3, 0, 0, (1920, 1080), cv2, np
        )
        self.assertEqual(contexts[0]['badge_color'], 'GREEN')
        self.assertEqual(contexts[0]['badge_color_method'], 'ahk-central-rgb-sampler')
        self.assertEqual(contexts[0]['badge_color_sample_size'], (bh, bw))
        self.assertEqual(contexts[0]['xy'], (450, 245))
        self.assertTrue(all(c['badge_color'] == 'NONE' for c in contexts[1:]))

    def test_color_first_scan_ocr_only_for_green_cards_then_uses_cache(self):
        # Integration test: OCR only the one GREEN card; fourteen non-GREEN cards
        # are color-gated, and the next identical frame reuses the committed cache.
        screen_ref = {'value': np.zeros((600, 1000, 4), dtype=np.uint8)}
        screen_ref['value'][:, :, 3] = 255
        # First card badge crop for this test layout: grid x=100..950, y=60..540;
        # card 1 x=100..270,y=60..220; badge crop is approximately x=234..269,y=194..217.
        screen_ref['value'][197:214, 238:265, :3] = [25, 48, 25]  # BGR dark green matched by the AHK RGB sampler

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screen_ref['value'].copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss
        saved = (
            scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
            scanner_core._CARD_CACHE_FIELD_SIGNATURES,
            scanner_core._CARD_CACHE_CONFIG_KEY, scanner_core._CARD_CACHE_SCREEN_KEY,
            dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT),
        )
        old_engine = scanner_core._OCR_ENGINE
        scanner_core._CARD_CACHE_SIGNATURES = None
        scanner_core._CARD_CACHE_RESULTS = None
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = None
        scanner_core._CARD_CACHE_CONFIG_KEY = None
        scanner_core._CARD_CACHE_SCREEN_KEY = None

        model = 'Dinka Civic EK6'
        models = [model] * 15
        grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
        layout_ref = {}
        original_build = ScanWorker._build_ocr_montage

        def capture_layout(worker, contexts, cv2_module, np_module, selected_fields=None):
            montage, layout = original_build(worker, contexts, cv2_module, np_module, selected_fields)
            layout_ref['layout'] = layout
            return montage, layout

        class FakeOCR:
            def __init__(self): self.calls = 0
            def __call__(self, image):
                self.calls += 1
                layout = layout_ref['layout']
                zones = layout['field_zones']
                rows = []
                for idx in range(15):
                    cy = idx * layout['row_height'] + layout['row_height'] / 2
                    for field, value in (('name', model), ('price', '$10 000'), ('badge', '-30%')):
                        zone = next(z for z in zones if z['field'] == field)
                        cx = (zone['left'] + zone['right']) / 2
                        box = [[cx - 20, cy - 8], [cx + 20, cy - 8],
                               [cx + 20, cy + 8], [cx - 20, cy + 8]]
                        rows.append([box, value, 0.99])
                return rows, None

        class FakeSignal:
            def emit(self, *args, **kwargs): self.last = args

        engine = FakeOCR()
        try:
            with patch.object(ScanWorker, '_build_ocr_montage', capture_layout):
                first = ScanWorker(models, {}, 20, {}, grid, active_models=set(models))
                first.result = FakeSignal(); first.progress = FakeSignal()
                with patch('scanner_core._get_ocr_engine', return_value=engine):
                    first.run()
                self.assertEqual(len(first.result.last[0]), 15)
                self.assertEqual(first._ocr_call_count, 1)
                self.assertEqual(first._changed_cards, 15)
                self.assertEqual(first._green_badge_count, 1)
                self.assertEqual(first._fast_color_skipped_indices, list(range(1, 15)))
                self.assertEqual(len(first._changed_field_map), 1)

                second = ScanWorker(models, {}, 20, {}, grid, active_models=set(models))
                second.result = FakeSignal(); second.progress = FakeSignal()
                with patch('scanner_core._get_ocr_engine', return_value=engine):
                    second.run()
                self.assertEqual(len(second.result.last[0]), 15)
                self.assertEqual(second._ocr_call_count, 0)
                self.assertEqual(second._changed_cards, 0)
                self.assertEqual(second._cache_hits, 15)
                self.assertLess(second.result.last[2], 1.0)
                self.assertEqual(engine.calls, 1)
        finally:
            scanner_core._OCR_ENGINE = old_engine
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
             scanner_core._CARD_CACHE_SCREEN_KEY, retry_timestamps) = saved
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss



    def test_full_ocr_mode_reads_non_green_cards_instead_of_color_skipping(self):
        # The new opt-in mode must send every card to OCR even if all sampled badges are NONE.
        screen = np.zeros((600, 1000, 4), dtype=np.uint8)
        screen[:, :, 3] = 255

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screen.copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss
        saved = (
            scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
            scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
            scanner_core._CARD_CACHE_SCREEN_KEY, dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT),
        )
        diag_path = Path(scanner_core.__file__).resolve().parent / 'last_scan_diagnostics.json'
        existed = diag_path.exists()
        old_diag = diag_path.read_bytes() if existed else None
        scanner_core._CARD_CACHE_SIGNATURES = None
        scanner_core._CARD_CACHE_RESULTS = None
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = None
        scanner_core._CARD_CACHE_CONFIG_KEY = None
        scanner_core._CARD_CACHE_SCREEN_KEY = None

        class FakeSignal:
            def emit(self, *args, **kwargs): self.last = args
        class FakeOCR:
            def __init__(self): self.calls = 0
            def __call__(self, image):
                self.calls += 1
                return [], None

        try:
            names = ['Dinka Civic EK6'] * 15
            grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
            worker = ScanWorker(names, {}, 20, {}, grid, active_models=set(names),
                                fast_color_filter_enabled=False)
            worker.result = FakeSignal(); worker.progress = FakeSignal()
            engine = FakeOCR()
            with patch('scanner_core._get_ocr_engine', return_value=engine):
                worker.run()
            self.assertEqual(len(worker.result.last[0]), 15)
            self.assertEqual(engine.calls, 1)
            self.assertEqual(worker._ocr_call_count, 1)
            self.assertEqual(worker._changed_cards, 15)
            self.assertEqual(worker._fast_color_skipped_indices, [])
            self.assertEqual(len(worker._changed_field_map), 15)
            self.assertTrue(all(row.get('eligible') is False for row in worker.result.last[0]))
        finally:
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
             scanner_core._CARD_CACHE_SCREEN_KEY, retry_timestamps) = saved
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss
            if existed:
                diag_path.write_bytes(old_diag)
            else:
                diag_path.unlink(missing_ok=True)

    def test_initial_no_green_screen_skips_ocr_and_returns_15_fail_closed_rows(self):
        import json
        screen = np.zeros((600, 1000, 4), dtype=np.uint8)
        screen[:, :, 3] = 255

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screen.copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss
        saved = (
            scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
            scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
            scanner_core._CARD_CACHE_SCREEN_KEY, dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT),
        )
        diag_path = Path(scanner_core.__file__).resolve().parent / 'last_scan_diagnostics.json'
        existed = diag_path.exists()
        old_diag = diag_path.read_bytes() if existed else None
        scanner_core._CARD_CACHE_SIGNATURES = None
        scanner_core._CARD_CACHE_RESULTS = None
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = None
        scanner_core._CARD_CACHE_CONFIG_KEY = None
        scanner_core._CARD_CACHE_SCREEN_KEY = None
        class FakeSignal:
            def emit(self, *args, **kwargs): self.last = args
        try:
            models = ['Dinka Civic EK6'] * 15
            grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
            first = ScanWorker(models, {}, 20, {}, grid, active_models=set(models))
            first.result = FakeSignal(); first.progress = FakeSignal()
            with patch('scanner_core._get_ocr_engine', side_effect=AssertionError('OCR must not initialize when no badge is GREEN')):
                first.run()
            rows = first.result.last[0]
            self.assertEqual(len(rows), 15)
            self.assertEqual(first._ocr_call_count, 0)
            self.assertLess(first.result.last[2], 1.0)
            self.assertEqual(first._green_badge_count, 0)
            self.assertEqual(len(first._fast_color_skipped_indices), 15)
            self.assertTrue(all(row.get('eligible') is False for row in rows))
            self.assertTrue(all(row.get('badge_color') in ('NONE', 'RED', 'UNKNOWN') for row in rows))
            self.assertTrue(all(row.get('model') == '—' for row in rows))

            second = ScanWorker(models, {}, 20, {}, grid, active_models=set(models))
            second.result = FakeSignal(); second.progress = FakeSignal()
            with patch('scanner_core._get_ocr_engine', side_effect=AssertionError('OCR must remain skipped for unchanged non-GREEN cards')):
                second.run()
            self.assertEqual(second._ocr_call_count, 0)
            self.assertEqual(second._changed_cards, 0)
            self.assertEqual(second._cache_hits, 15)
        finally:
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
             scanner_core._CARD_CACHE_SCREEN_KEY, retry_timestamps) = saved
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss
            if existed:
                diag_path.write_bytes(old_diag)
            else:
                diag_path.unlink(missing_ok=True)

    def test_green_badge_uses_footer_fallback_when_focused_badge_ocr_misses_percent(self):
        worker = ScanWorker(['Dinka Civic EK6'], {}, 20, {}, {}, active_models={'Dinka Civic EK6'})
        class FakeFooterOCR:
            def __call__(self, image):
                return [
                    [[[0, 0], [30, 0], [30, 6], [0, 6]], '$10 000', 0.99],
                    [[[0, 10], [20, 10], [20, 16], [0, 16]], '-30%', 0.99],
                ], 0.01
        ctx = {
            'card': 1, 'card_index': 0, 'badge_color': 'GREEN',
            'footer_crop': np.zeros((20, 80, 3), dtype=np.uint8),
            'xy': (451, 200), 'screen_size': (1920, 1080),
        }
        fields = {
            'name': 'Dinka Civic EK6', 'price': '$10 000', 'badge': '',
            'name_confidence': 0.99, 'price_confidence': 0.99,
            'badge_confidence': 0.0, 'ocr_confidence': 0.66,
        }
        row = worker._parse_changed_card(ctx, fields, FakeFooterOCR())
        self.assertEqual(row['discount_value'], 30)
        self.assertEqual(row['discount_kind'], 'discount')
        self.assertEqual(row['discount_source'], 'footer-fallback')
        self.assertTrue(row['eligible'])
        self.assertEqual(worker._ocr_call_count, 1)

    def test_uncertain_retry_cooldown_is_12_seconds(self):
        self.assertFalse(ScanWorker._uncertain_retry_due(100.0, now=111.0))
        self.assertTrue(ScanWorker._uncertain_retry_due(100.0, now=112.0))
        self.assertTrue(ScanWorker._uncertain_retry_due(100.0, now=120.0))

    def test_compact_montage_does_not_upscale_unchanged_field_crops(self):
        worker = ScanWorker([], {}, 20, {}, {})
        contexts = []
        for idx in range(8):
            contexts.append({
                'card_index': idx, 'empty': False,
                'name_crop': np.zeros((50, 280, 3), dtype=np.uint8),
                'price_crop': np.zeros((47, 140, 3), dtype=np.uint8),
                'badge_crop': np.zeros((49, 70, 3), dtype=np.uint8),
                '_fields_to_ocr': ['name', 'price', 'badge'],
            })
        montage, layout = worker._build_ocr_montage(contexts, cv2, np)
        self.assertEqual(layout['scale'], 1.0)
        self.assertLessEqual(montage.shape[1], 540)
        self.assertLessEqual(montage.shape[0], 480)


    def test_initial_non_green_grid_skips_ocr_entirely(self):
        """Color-first fast mode must not OCR titles/prices on non-GREEN cards."""
        import json
        screenshot_bgra = np.zeros((600, 1000, 4), dtype=np.uint8)
        screenshot_bgra[:, :, 3] = 255

        class FakeMSS:
            monitors = [None, {'left': 0, 'top': 0, 'width': 1000, 'height': 600}]
            def __enter__(self): return self
            def __exit__(self, *args): return False
            def grab(self, monitor): return screenshot_bgra.copy()

        fake_mss = types.ModuleType('mss')
        fake_mss.mss = FakeMSS
        old_mss = sys.modules.get('mss')
        sys.modules['mss'] = fake_mss

        names = [f'Model {i}' for i in range(15)]
        grid = {'left': .10, 'top': .10, 'right': .95, 'bottom': .90, 'cols': 5, 'rows': 3}
        worker = ScanWorker(names, {}, 20, {}, grid, active_models=set(names))
        class FakeSignal:
            def emit(self, *args, **kwargs): self.last = args
        worker.result = FakeSignal()
        worker.progress = FakeSignal()

        saved = (
            scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
            scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
            scanner_core._CARD_CACHE_SCREEN_KEY, dict(scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT),
        )
        scanner_core._CARD_CACHE_SIGNATURES = None
        scanner_core._CARD_CACHE_RESULTS = None
        scanner_core._CARD_CACHE_FIELD_SIGNATURES = None
        scanner_core._CARD_CACHE_CONFIG_KEY = None
        scanner_core._CARD_CACHE_SCREEN_KEY = None
        scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()

        diag_path = Path(scanner_core.__file__).resolve().parent / 'last_scan_diagnostics.json'
        existed = diag_path.exists()
        old_diag = diag_path.read_bytes() if existed else None
        try:
            with patch('scanner_core._get_ocr_engine', side_effect=AssertionError('OCR must not start')):
                worker.run()
            self.assertEqual(worker._ocr_call_count, 0)
            self.assertEqual(len(worker.result.last[0]), 15)
            self.assertEqual(worker._green_badge_count, 0)
            self.assertEqual(len(worker._fast_color_skipped_indices), 15)
        finally:
            (scanner_core._CARD_CACHE_SIGNATURES, scanner_core._CARD_CACHE_RESULTS,
             scanner_core._CARD_CACHE_FIELD_SIGNATURES, scanner_core._CARD_CACHE_CONFIG_KEY,
             scanner_core._CARD_CACHE_SCREEN_KEY, retry_timestamps) = saved
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.clear()
            scanner_core._CARD_CACHE_FIELD_LAST_OCR_AT.update(retry_timestamps)
            if old_mss is None:
                sys.modules.pop('mss', None)
            else:
                sys.modules['mss'] = old_mss
            if existed:
                diag_path.write_bytes(old_diag)
            else:
                diag_path.unlink(missing_ok=True)

if __name__ == '__main__':
    unittest.main(verbosity=2)
