import unittest
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]

class CatalogVisualStabilityTests(unittest.TestCase):
    def test_preview_has_no_checkerboard_paint_or_opaque_panel(self):
        main = (ROOT / "main.py").read_text(encoding="utf-8")
        qss = (ROOT / "theme" / "style.qss").read_text(encoding="utf-8")
        start = main.index("class TransparentVehiclePreview(QLabel):")
        end = main.index("class HeroImage(QLabel):", start)
        preview = main[start:end]
        self.assertNotIn("colors = (QColor('#111923')", preview)
        self.assertNotIn("painter.fillRect(self.rect()", preview)
        self.assertIn("background: transparent;", qss)
        self.assertIn("painter.drawPixmap(x, y, fitted)", preview)
        self.assertIn("setAttribute(Qt.WA_TranslucentBackground, True)", preview)

    def test_png_cutouts_fill_most_of_the_canvas_after_crop(self):
        paths = list((ROOT / "vehicle_renders").glob("*.png"))
        self.assertGreaterEqual(len(paths), 25)
        for path in paths:
            with Image.open(path) as image:
                self.assertEqual(image.size, (1200, 620), path.name)
                rgba = image.convert("RGBA")
                mask = rgba.getchannel("A").point(lambda v: 255 if v > 12 else 0)
                bbox = mask.getbbox()
                self.assertIsNotNone(bbox, path.name)
                fill_w = (bbox[2] - bbox[0]) / image.width
                fill_h = (bbox[3] - bbox[1]) / image.height
                self.assertGreaterEqual(fill_w, 0.52, f"{path.name}: vehicle remains too small horizontally ({fill_w:.2f})")
                self.assertGreaterEqual(fill_h, 0.64, f"{path.name}: vehicle remains too small vertically ({fill_h:.2f})")
                self.assertEqual(rgba.getchannel("A").getextrema()[0], 0, path.name)

    def test_catalog_reuses_cards_and_debounces_resize_instead_of_destroying_every_card(self):
        main = (ROOT / "main.py").read_text(encoding="utf-8")
        start = main.index("    def _refresh_catalog_grid(self):")
        end = main.index("    def _set_catalog_active_from_card", start)
        block = main[start:end]
        self.assertIn("self._catalog_cards", main)
        self.assertIn("_catalog_grid_layout_signature", block)
        self.assertIn("if signature == getattr(self, '_catalog_grid_layout_signature', None):", block)
        self.assertNotIn("widget.deleteLater()", block)
        self.assertIn("QTimer.singleShot(45, self._refresh_catalog_grid)", main)
        self.assertIn("card.setMinimumHeight", main)

    def test_catalog_image_preview_is_large_and_card_text_is_outside_it(self):
        main = (ROOT / "main.py").read_text(encoding="utf-8")
        self.assertIn("int(230 * self.ui_scale)", main)
        self.assertIn("max(190, int(230 * self.ui_scale))", main)
        self.assertIn("controls['title'].setText(model)", main)
        self.assertIn("controls['meta'].setText", main)
        self.assertIn("controls['category']", main)
        self.assertIn("controls['threshold']", main)

if __name__ == '__main__':
    unittest.main()
