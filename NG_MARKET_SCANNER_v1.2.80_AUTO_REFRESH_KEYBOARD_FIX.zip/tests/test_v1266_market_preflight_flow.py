from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class MarketPreflightFlowTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "build_single_exe_internal.bat").read_text(encoding="utf-8")

    def test_autobuy_uses_market_grid_preflight_not_direct_green_watch(self):
        toggle = self.main.split("    def toggle_scanning(self):", 1)[1].split("    def scan_once(self, hide_window=None):", 1)[0]
        self.assertIn("FAST GRID BUY", toggle)
        self.assertIn("self.scan_once(hide_window=None)", toggle)
        self.assertNotIn("self._start_direct_green_watch()", toggle)

    def test_grid_scan_enables_existing_fast_candidate_lane(self):
        launch = self.main.split("    def _launch_scan_worker(self):", 1)[1].split("    def _defer_scan_until_game_foreground", 1)[0]
        self.assertIn("fast_candidate_mode=bool(self.settings.get('auto_click', False))", launch)
        self.assertIn("self.worker.candidate_found.connect(self._on_fast_candidate_found)", launch)

    def test_detail_ocr_validator_is_only_wired_for_legacy_direct_mode(self):
        start = self.main.split("    def _start_purchase_action(self, candidate):", 1)[1].split("    def _on_action_worker_thread_finished_signal", 1)[0]
        self.assertIn("validator = self._build_direct_detail_validator(candidate) if direct_mode else None", start)
        self.assertIn("pre_buy_validator=validator", start)

    def test_new_version_marker_is_required_by_builder(self):
        self.assertIn("1.2.67-persistent-dxcam-market-roi", self.main)
        self.assertIn("1.2.67-persistent-dxcam-market-roi", self.builder)

    def test_button_timeout_attempts_back_recovery_and_marks_market_recovered(self):
        self.assertIn('def _try_return_to_market(self, hwnd, current_size, reason=', self.actions)
        self.assertIn("reason='DETAIL_BUY_TIMEOUT'", self.actions)
        self.assertIn('[RECOVERED_TO_MARKET]', self.actions)
        self.assertIn('self.cancel_event.wait(0.18)', self.actions)

    def test_confirm_close_wait_uses_adaptive_ceilings_for_slow_2k_ui(self):
        self.assertIn("timeout_ms=1800, expected_hwnd=hwnd, button_kind='confirm'", self.actions)
        self.assertIn("timeout_ms=700, expected_hwnd=hwnd, button_kind='detail_buy'", self.actions)

    def test_ambiguous_failure_pauses_scan_instead_of_ocr_over_modal(self):
        self.assertIn("if not success and not safe_recovery:", self.main)
        self.assertIn('Автосканування призупинено після невдалої автодії', self.main)
        self.assertIn("safe_recovery = '[RECOVERED_TO_MARKET]' in str(message)", self.main)

if __name__ == "__main__":
    unittest.main()
