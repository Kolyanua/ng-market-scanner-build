"""Release-contract tests for v1.2.52 crash prevention and blacklist behavior.

These tests inspect deterministic logic and callback wiring without claiming to
emulate Windows input or the live game/server.
"""
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

from scanner_core_logic import build_candidate_status, normalize_vehicle_key


class V1252AutoActionSafetyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        cls.logic = (ROOT / 'scanner_core_logic.py').read_text(encoding='utf-8')
        cls.actions = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        cls.builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        cls.outer_builder = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'build_exe.bat.fixture.txt').read_text(encoding='utf-8')

    def _method(self, source, signature, next_signature):
        return source.split(signature, 1)[1].split(next_signature, 1)[0]

    def test_qthread_reference_is_not_cleared_from_result_slot(self):
        result_slot = self._method(
            self.main,
            '    def on_action_result(self, success, message):',
            '    @staticmethod\n    def _vehicle_snapshot_state',
        )
        self.assertNotIn('self.action_worker = None', result_slot)
        self.assertNotIn('self.action_in_progress = False', result_slot)
        self.assertIn('self._action_result_handled = True', result_slot)
        self.assertIn('QThread', self.main)
        self.assertIn('action_worker.finished.connect(self._on_action_worker_thread_finished_signal)', self.main)

    def test_worker_reference_and_single_flight_latch_wait_for_thread_exit(self):
        finalizer = self._method(
            self.main,
            '    def _finalize_action_worker_reference(self, worker, retries=0):',
            '    def on_action_result(self, success, message):',
        )
        self.assertIn('if worker.isRunning():', finalizer)
        self.assertIn('result_emitted and not result_handled', finalizer)
        self.assertIn('self.action_worker = None', finalizer)
        for signature, next_signature in (
            ('    def _on_scan_timer(self):', '    def _on_scan_worker_finished(self):'),
            ('    def toggle_scanning(self):', '    def scan_once(self, hide_window=None):'),
            ('    def scan_once(self, hide_window=None):', '    def _defer_scan_until_game_foreground(self):'),
        ):
            method = self._method(self.main, signature, next_signature)
            self.assertIn('_action_worker_is_running()', method, signature)

    def test_worker_emits_only_one_terminal_result(self):
        self.assertIn('def _emit_result(self, success: bool, message: str):', self.actions)
        self.assertEqual(self.actions.count('self.finished_result.emit('), 1)
        run_body = self.actions.split('    def run(self):', 1)[1]
        self.assertIn('except Exception as exc:', run_body)
        self.assertIn('self._emit_result(False, f\'Автодію перервано безпечним способом:', run_body)

    def test_blacklist_is_checked_before_click_worker_construction(self):
        action_start = self.main.split('    def _start_purchase_action(self, candidate):', 1)[1].split('    def _on_action_worker_thread_finished_signal', 1)[0]
        self.assertIn('load_blacklist_models(self.all_models)', action_start)
        self.assertLess(action_start.index('load_blacklist_models(self.all_models)'), action_start.index('actions.PurchaseWorker('))
        self.assertIn('active_models = set(selected) - blacklist', self.main)
        self.assertIn('normalize_vehicle_key', self.core)
        self.assertIn('if blacklisted:', self.logic)
        self.assertIn("return 'Чорний список · ігнорувати', False", self.logic)

    def test_blacklist_editor_is_persisted_and_catalog_updates_immediately(self):
        self.assertIn("BLACKLIST_CATEGORY = 'Чорний список'", self.main)
        self.assertIn('self.blacklist_editor = QTextEdit()', self.main)
        save_settings = self._method(self.main, '    def save_all_settings(self):', '    def save_settings(self):')
        self.assertIn('self._write_lines_atomic(BLACKLIST, blacklist_entries)', save_settings)
        self.assertIn('self.refresh_catalog(force=True)', save_settings)
        save_catalog = self._method(self.main, '    def save_catalog(self):', '    def _write_settings(self):')
        self.assertIn('unknown_blacklist_entries', save_catalog)
        self.assertIn('BLACKLIST_CATEGORY', save_catalog)

    def test_bad_or_missing_card_coordinates_fail_closed(self):
        action_start = self.main.split('    def _start_purchase_action(self, candidate):', 1)[1].split('    def _on_action_worker_thread_finished_signal', 1)[0]
        self.assertIn('координати', action_start.lower())
        self.assertIn('width <= 0 or height <= 0 or x < 0 or y < 0 or x >= width or y >= height', action_start)
        self.assertIn('scale_reference_point(DETAIL_BUY, current_size)', self.actions)
        self.assertIn('scale_reference_point(FINAL_CONFIRM, current_size)', self.actions)
        self.assertIn('if current_size != self.scan_screen_size:', self.actions)

    def test_gdi_pixel_read_and_adaptive_wait_are_guarded(self):
        wait = self.actions.split('    def _wait_for_green_button', 1)[1].split('    @staticmethod\n    def _send_atomic_left_click', 1)[0]
        self.assertIn('ctypes.windll.gdi32', wait)
        self.assertIn('gdi32.GetPixel(hdc', wait)
        self.assertIn('BUTTON_POLL_INTERVAL_MS / 1000.0', wait)
        self.assertIn('сліпий клік заблоковано', wait)
        self.assertIn('if green_count >= 4:', wait)


    def test_purchase_sequence_is_card_then_buy_then_confirm(self):
        run = self.actions.split('    def run(self):', 1)[1]
        card_click = run.index('if not self._click(*self.card_xy')
        validator_start = run.index('validation_task = self._start_parallel_detail_validation()')
        cta_poll = run.index('button_ready = self._wait_for_green_button(*detail_xy')
        validator_join = run.index('validation_done.wait()', cta_poll)
        detail_validation_gate = run.index("if not bool(self.validated_details.get('ok')):", cta_poll)
        buy_click = run.index('if not self._click(*detail_xy')
        confirm_wait = run.index('if not self._wait_for_green_button(*confirm_xy')
        confirm_click = run.index('if not self._click(*confirm_xy')
        self.assertLess(card_click, validator_start)
        self.assertLess(validator_start, cta_poll)
        self.assertLess(cta_poll, validator_join)
        self.assertLess(validator_join, detail_validation_gate)
        self.assertLess(detail_validation_gate, buy_click)
        self.assertLess(buy_click, confirm_wait)
        self.assertLess(confirm_wait, confirm_click)
        self.assertIn('if not self.auto_confirm:', run)
        self.assertIn('сліпого кліку не виконано', run)

    def test_result_slot_keeps_scan_controls_locked_until_worker_finalizer(self):
        result_slot = self._method(
            self.main,
            '    def on_action_result(self, success, message):',
            '    @staticmethod\n    def _vehicle_snapshot_state',
        )
        self.assertIn('self.start_btn.setEnabled(False)', result_slot)
        self.assertIn('self.once_btn.setEnabled(False)', result_slot)
        self.assertIn('self._action_result_handled = True', result_slot)
        self.assertNotIn('self.start_btn.setEnabled(True)', result_slot)
        self.assertNotIn('self.once_btn.setEnabled(True)', result_slot)

    def test_blacklisted_offer_is_never_eligible_even_with_large_green_discount(self):
        status, eligible = build_candidate_status(
            'Shitzu Matiz', 'Shitzu Matiz', 10000, 'GREEN', 75, 20, True, True
        )
        self.assertFalse(eligible)
        self.assertIn('Чорний список', status)

    def test_blacklist_model_normalization_is_case_and_punctuation_insensitive(self):
        self.assertEqual(
            normalize_vehicle_key('Shitzu Matiz'),
            normalize_vehicle_key('SHITZU-MATIZ'),
        )

    def test_builders_use_matching_version_and_run_tests_before_packaging(self):
        self.assertIn('NG Market Scanner v1.2.71', self.builder)
        self.assertIn('1.2.60-position-independent-discount', self.builder)
        self.assertLess(self.builder.index('python -m unittest discover -s tests -v'), self.builder.index('python -m PyInstaller'))
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', self.outer_builder)


if __name__ == '__main__':
    unittest.main(verbosity=2)
