import unittest
from datetime import datetime, timedelta
from scanner_stats_logic import purchase_dynamics_series


class PurchaseDynamicsTests(unittest.TestCase):
    def test_today_has_eight_three_hour_buckets(self):
        now = datetime(2026, 11, 13, 14, 20, 0)
        events = [
            {"type": "purchase_confirmed", "ts": "2026-11-13T01:00:00"},
            {"type": "purchase_confirmed", "ts": "2026-11-13T13:30:00"},
        ]
        values = purchase_dynamics_series(events, "Сьогодні", now)
        self.assertEqual(len(values), 8)
        self.assertEqual(sum(values), 2)

    def test_7_and_30_day_periods_have_expected_daily_buckets(self):
        now = datetime(2026, 11, 13, 12, 0, 0)
        events = [{"type": "purchase_confirmed", "ts": "2026-11-12T12:00:00"}]
        self.assertEqual(len(purchase_dynamics_series(events, "7 днів", now)), 7)
        self.assertEqual(len(purchase_dynamics_series(events, "30 днів", now)), 30)
        self.assertEqual(sum(purchase_dynamics_series(events, "7 днів", now)), 1)

    def test_all_time_includes_confirmations_older_than_30_days(self):
        now = datetime(2026, 11, 13, 12, 0, 0)
        old = (now - timedelta(days=75)).replace(hour=12, minute=0, second=0)
        events = [
            {"type": "purchase_confirmed", "ts": old.isoformat()},
            {"type": "purchase_confirmed", "ts": "2026-11-12T12:00:00"},
            {"type": "purchase_flow_sent", "ts": "2026-11-13T11:00:00"},
        ]
        values = purchase_dynamics_series(events, "Увесь час", now)
        self.assertLessEqual(len(values), 60)
        self.assertEqual(sum(values), 2)

    def test_empty_history_does_not_invent_purchases(self):
        self.assertEqual(sum(purchase_dynamics_series([], "Увесь час", datetime(2026, 11, 13))), 0)


if __name__ == '__main__':
    unittest.main(verbosity=2)
