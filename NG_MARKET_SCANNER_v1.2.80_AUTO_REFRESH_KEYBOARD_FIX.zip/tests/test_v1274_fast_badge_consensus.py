import unittest
from pathlib import Path

import scanner_core

ROOT = Path(__file__).resolve().parents[1]


class FastBadgeConsensusV1274Tests(unittest.TestCase):
    def _row(self, source, value, confidence):
        return {
            'badge_ocr_source': source,
            'discount_value': value,
            'badge_ocr_text': f'-{value}%' if value is not None else '',
            'badge_ocr_confidence': confidence,
        }

    def test_matching_credible_original_and_enhanced_reads_skip_detector_rescue(self):
        evidence = [
            self._row('recognition-only', 26, 0.49),
            self._row('recognition-only-enhanced', 26, 0.52),
        ]
        self.assertTrue(scanner_core._has_credible_recognition_only_badge_consensus(evidence))
        self.assertFalse(scanner_core._badge_requires_detector_rescue({'badge_color': 'GREEN'}, evidence))

    def test_single_low_confidence_read_still_uses_detector_rescue(self):
        evidence = [self._row('recognition-only', 26, 0.48)]
        self.assertFalse(scanner_core._has_credible_recognition_only_badge_consensus(evidence))
        self.assertTrue(scanner_core._badge_requires_detector_rescue({'badge_color': 'GREEN'}, evidence))

    def test_disagreeing_reads_still_use_detector_rescue(self):
        evidence = [
            self._row('recognition-only', 26, 0.62),
            self._row('recognition-only-enhanced', 28, 0.61),
        ]
        self.assertFalse(scanner_core._has_credible_recognition_only_badge_consensus(evidence))
        self.assertTrue(scanner_core._badge_requires_detector_rescue({'badge_color': 'GREEN'}, evidence))

    def test_low_score_agreement_does_not_bypass_detector_rescue(self):
        evidence = [
            self._row('recognition-only', 26, 0.41),
            self._row('recognition-only-enhanced', 26, 0.52),
        ]
        self.assertFalse(scanner_core._has_credible_recognition_only_badge_consensus(evidence))
        self.assertTrue(scanner_core._badge_requires_detector_rescue({'badge_color': 'GREEN'}, evidence))

    def test_only_canonical_launcher_and_internal_builder_are_executable_bat_files(self):
        # Only BAT files shipped at the project root are project launchers.
        # The build creates .venv before tests run, and Python's virtualenv
        # legitimately contains Scripts/activate.bat and deactivate.bat.
        # Those generated environment scripts are not extra project launchers.
        bat_files = {path.name for path in ROOT.glob('*.bat')}
        self.assertEqual(bat_files, {
            'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat',
            'build_single_exe_internal.bat',
        })

    def test_patch_version_and_stage_diagnostic_are_bound_to_release(self):
        self.assertEqual(scanner_core.FAST_BADGE_CONSENSUS_PATCH_VERSION,
                         '1.2.74-fast-badge-consensus-no-detector-fallback')
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn('_badge_requires_detector_rescue(candidate_ctx, evidence)', core)
        self.assertIn('fast_lane_badge_detector_fallback_skipped_consensus_calls', core)
        self.assertIn('EXPECTED_FAST_BADGE_CONSENSUS_PATCH_VERSION', main)


if __name__ == '__main__':
    unittest.main()

