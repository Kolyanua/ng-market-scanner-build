from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class OfferSignatureAndScanProfileV1273Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "scanner_core.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "build_single_exe_internal.bat").read_text(encoding="utf-8")

    def test_offer_signature_is_preserved_in_each_row_builder(self):
        self.assertGreaterEqual(self.core.count("'offer_signature': str(ctx.get('signature') or '')"), 3)

    def test_fast_path_and_result_path_share_offer_specific_attempt_key(self):
        self.assertIn("def _purchase_attempt_key(candidate):", self.main)
        self.assertGreaterEqual(self.main.count("self._purchase_attempt_key(candidate)"), 3)
        self.assertIn("_purchase_offer_skip_logged", self.main)
        self.assertIn("AUTO-BUY SKIP:", self.main)

    def test_attempt_is_latched_only_after_card_click_progress(self):
        self.assertIn("def _on_purchase_worker_progress(self, message):", self.main)
        self.assertIn("self._purchase_offer_keys_attempted.add(key)", self.main)
        start_action = self.main.split("    def _start_purchase_action(self, candidate):", 1)[1].split("    def _on_action_worker_thread_finished_signal", 1)[0]
        self.assertNotIn("self._purchase_offer_keys_attempted.add(attempt_key)", start_action)
        self.assertIn("AUTO-BUY RETRY ALLOWED:", self.main)

    def test_slow_cycle_emits_stage_profile(self):
        self.assertIn("ПРОФІЛЬ ПОВІЛЬНОГО ЦИКЛУ:", self.main)
        self.assertIn("_last_stage_seconds", self.core)
        self.assertIn("stage_seconds", self.core)

    def test_sidecar_and_builder_version_contract(self):
        marker = "1.2.73-offer-signature-dedupe-and-scan-profile"
        self.assertIn(marker, self.core)
        self.assertIn(marker, self.main)
        self.assertIn(marker, self.builder)
        self.assertIn(marker, (ROOT / "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat").read_text(encoding="ascii"))

if __name__ == "__main__":
    unittest.main()
