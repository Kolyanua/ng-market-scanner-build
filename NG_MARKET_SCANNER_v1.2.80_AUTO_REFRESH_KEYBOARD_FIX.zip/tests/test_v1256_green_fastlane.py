import sys
import types
import time
import unittest
from pathlib import Path
from unittest.mock import patch

try:
    from PySide6.QtCore import QThread, Signal  # noqa: F401
except Exception:
    pyside = types.ModuleType('PySide6')
    qtcore = types.ModuleType('PySide6.QtCore')
    class QThread:
        pass
    class _Signal:
        def __init__(self, *args, **kwargs):
            pass
    qtcore.QThread = QThread
    qtcore.Signal = _Signal
    pyside.QtCore = qtcore
    sys.modules.setdefault('PySide6', pyside)
    sys.modules.setdefault('PySide6.QtCore', qtcore)

import cv2
import numpy as np
import scanner_core
from scanner_core import ScanWorker

ROOT = Path(__file__).resolve().parents[1]


class CollectorSignal:
    def __init__(self, on_emit=None):
        self.values = []
        self.on_emit = on_emit

    def emit(self, *values):
        value = values[0] if len(values) == 1 else values
        self.values.append(value)
        if self.on_emit is not None:
            self.on_emit(value)


class GreenFastLaneV1256Tests(unittest.TestCase):
    def setUp(self):
        self.model = 'Dinka Civic EK6'
        self.worker = ScanWorker(
            [self.model], {self.model: {'threshold': 20, 'category': 'Звичайне'}},
            20, {self.model: 20}, {'left': .1, 'top': .1, 'right': .95, 'bottom': .9, 'cols': 5, 'rows': 3},
            active_models={self.model}, confidence_protection_enabled=True,
        )
        self.signal = CollectorSignal()
        self.worker.candidate_found = self.signal

    def candidate(self, **overrides):
        result = {
            'card': 1, 'model': self.model, 'catalog_model': self.model,
            'badge_color': 'GREEN', 'discount_kind': 'discount',
            'eligible': True, 'price_value': 10000, 'price': '$10 000',
            'discount_value': 89, 'discount': '-89%', 'threshold': 20,
            'model_confidence': 0.99, 'xy': (500, 300), 'screen_size': (1920, 1080),
        }
        result.update(overrides)
        return result

    def test_valid_green_offer_is_emitted_to_fast_lane(self):
        self.assertTrue(self.worker._emit_fast_candidate(self.candidate(), 0.0))
        self.assertEqual(len(self.signal.values), 1)
        self.assertGreaterEqual(self.signal.values[0]['_fast_candidate_detected_after_seconds'], 0.0)
        self.assertEqual(self.worker._candidate_signal_count, 1)

    def test_red_offer_never_enters_fast_purchase_lane(self):
        self.assertFalse(self.worker._emit_fast_candidate(self.candidate(badge_color='RED'), 0.0))
        self.assertFalse(self.worker._emit_fast_candidate(self.candidate(discount_kind='markup'), 0.0))
        self.assertFalse(self.worker._emit_fast_candidate(self.candidate(model_confidence=0.75), 0.0))
        self.assertEqual(self.signal.values, [])

    def test_current_app_refuses_legacy_or_unlocked_ocr_sidecars(self):
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        self.assertEqual(scanner_core.OCR_PATCH_VERSION, '1.2.60-position-independent-discount-watch')
        self.assertIn('EXPECTED_DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION = "1.2.65-retry-confirm-detail-discount"', main)
        self.assertIn("DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION", main)
        self.assertEqual(scanner_core.OCR_SPEED_PATCH_VERSION, '1.2.60-responsive-ui-fast-detail')
        self.assertIn('EXPECTED_OCR_CORE_VERSION', main)
        self.assertIn('EXPECTED_OCR_SPEED_PATCH_VERSION', main)
        self.assertIn('self.worker.candidate_found.connect(self._on_fast_candidate_found)', main)
        self.assertIn('self._urgent_candidate_started and self.action_in_progress', main)
        self.assertIn('1.2.60-position-independent-discount-watch', builder)
        self.assertIn('1.2.60-responsive-ui-fast-detail', builder)
        final_wrapper = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_FINAL_v1.2.59_PARALLEL_DETAIL_FASTPATH.bat.fixture.txt').read_text(encoding='utf-8')
        personal_wrapper = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_2K_FINAL_CONFIRM_FIX_v1.2.65.1.bat.fixture.txt').read_text(encoding='utf-8')
        legacy_personal_wrapper = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_FINAL_v1.2.60_POSITION_INDEPENDENT_DISCOUNT.bat.fixture.txt').read_text(encoding='utf-8')
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', personal_wrapper)
        new_wrapper = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'BUILD_2K_MARKET_PREFLIGHT_v1.2.66.bat.fixture.txt').read_text(encoding='utf-8')
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', new_wrapper)
        canonical = (ROOT / 'BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat').read_text(encoding='utf-8')
        self.assertIn('NGMS_PRESERVE_AUTOBUY=1', canonical)
        self.assertIn('call build_single_exe_internal.bat', canonical)
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', legacy_personal_wrapper)
        for old_wrapper in ('BUILD_FINAL_v1.2.54.bat.fixture.txt', 'BUILD_FINAL_v1.2.55_GREEN_ONLY_OCR.bat.fixture.txt', 'BUILD_FINAL_v1.2.56_GREEN_FASTLANE.bat.fixture.txt'):
            self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / old_wrapper).read_text(encoding='utf-8'))
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'RUN_CLEAN_INSTALL_AND_START.bat.fixture.txt').read_text(encoding='utf-8'))


    def test_fast_lane_prioritizes_largest_discount_before_grid_order(self):
        models = ['Dinka Civic EK6', 'Benefactor Sprinter W906']
        rules = {name: {'threshold': 20, 'category': 'Звичайне'} for name in models}
        worker = ScanWorker(models, rules, 20, {name: 20 for name in models},
                            {'left': .1, 'top': .1, 'right': .95, 'bottom': .9, 'cols': 5, 'rows': 3},
                            active_models=set(models), fast_candidate_mode=True)
        candidate_signal = CollectorSignal(on_emit=lambda _candidate: worker.cancel())
        worker.candidate_found = candidate_signal
        worker.progress = CollectorSignal()
        contexts = []
        for idx in range(2):
            contexts.append({
                'card_index': idx, 'card': idx + 1,
                'xy': (400 + idx * 300, 300), 'screen_size': (1920, 1080),
                'badge_color': 'GREEN', 'badge_color_method': 'test',
                'badge_color_sample_size': (10, 20), 'empty': False,
                '_fields_to_ocr': ['name', 'price', 'badge'],
                'name_crop': np.full((18, 100, 3), 255, np.uint8),
                'price_crop': np.full((18, 80, 3), 255, np.uint8),
                'badge_crop': np.full((18, 40, 3), 255, np.uint8),
                'footer_crop': np.full((18, 220, 3), 255, np.uint8),
                'field_signatures': {'name': f'n{idx}', 'price': f'p{idx}', 'badge': f'b{idx}'},
                'signature': f'sig{idx}',
            })
        layout_state = {'layout': None, 'contexts': None, 'fields': None}
        original_builder = worker._build_ocr_montage
        def tracked_builder(card_contexts, cv2_module, np_module, selected_fields=None):
            montage, layout = original_builder(card_contexts, cv2_module, np_module, selected_fields)
            layout_state['layout'] = layout
            layout_state['contexts'] = list(card_contexts)
            layout_state['fields'] = list(layout['fields'])
            return montage, layout
        worker._build_ocr_montage = tracked_builder
        engine_calls = []
        def fake_engine(image):
            layout = layout_state['layout']
            selected = layout_state['fields']
            batch_contexts = layout_state['contexts']
            output = []
            for row_index, context in enumerate(batch_contexts):
                for field_name in selected:
                    if field_name == 'badge':
                        value = '-20%' if context['card_index'] == 0 else '-89%'
                    elif field_name == 'name':
                        value = models[context['card_index']]
                    elif field_name == 'price':
                        value = '$10 000'
                    else:
                        continue
                    zone = next(z for z in layout['field_zones'] if z['field'] == field_name)
                    cx = (float(zone['left']) + float(zone['right'])) / 2.0
                    cy = row_index * float(layout['row_height']) + float(layout['row_height']) / 2.0
                    box = [[cx - 2, cy - 3], [cx + 2, cy - 3], [cx + 2, cy + 3], [cx - 2, cy + 3]]
                    output.append([box, value, 0.99])
            engine_calls.append((tuple(selected), tuple(c['card_index'] for c in batch_contexts)))
            return output, None

        cache_names = ('_CARD_CACHE_SIGNATURES', '_CARD_CACHE_RESULTS', '_CARD_CACHE_FIELD_SIGNATURES',
                       '_CARD_CACHE_CONFIG_KEY', '_CARD_CACHE_SCREEN_KEY')
        old_cache = tuple(getattr(scanner_core, name) for name in cache_names)
        try:
            with patch('scanner_core._get_ocr_engine', return_value=fake_engine):
                result, error, elapsed = worker._run_green_fast_lane(
                    contexts, contexts, [None, None], [None, None], [0, 1], [],
                    ['sig0', 'sig1'], (1920, 1080), 'cfg', 'screen', 1, 2,
                    cv2, np, time.perf_counter(), {}, ('name', 'price', 'badge'))
            self.assertEqual(error, '__CANCELLED__')
            self.assertEqual(len(candidate_signal.values), 1)
            self.assertEqual([payload['discount_value'] for payload in candidate_signal.values], [89])
            self.assertEqual(engine_calls[0], (('badge',), (0, 1)))
            self.assertEqual(engine_calls[1], (('name', 'price'), (1,)))
            self.assertEqual(len(engine_calls), 2, 'after the highest-ranked valid offer is emitted, scanning must cancel before OCRing lower-ranked green cards')
            self.assertLessEqual(elapsed, 1.0)
        finally:
            for name, value in zip(cache_names, old_cache):
                setattr(scanner_core, name, value)

    def test_unchanged_green_badge_uses_cached_discount_without_badge_ocr(self):
        worker = ScanWorker(
            [self.model], {self.model: {'threshold': 20, 'category': 'Звичайне'}},
            20, {self.model: 20},
            {'left': .1, 'top': .1, 'right': .95, 'bottom': .9, 'cols': 5, 'rows': 3},
            active_models={self.model}, fast_candidate_mode=True,
        )
        signal = CollectorSignal()
        worker.candidate_found = signal
        worker.progress = CollectorSignal()
        ctx = {
            'card_index': 0, 'card': 1, 'xy': (400, 300), 'screen_size': (1920, 1080),
            'badge_color': 'GREEN', 'badge_color_method': 'test', 'empty': False,
            '_fields_to_ocr': ['name', 'price'],
            'name_crop': np.full((18, 100, 3), 255, np.uint8),
            'price_crop': np.full((18, 80, 3), 255, np.uint8),
            'badge_crop': np.full((18, 40, 3), 255, np.uint8),
            'footer_crop': np.full((18, 220, 3), 255, np.uint8),
            'field_signatures': {'name': 'n-new', 'price': 'p-new', 'badge': 'b-same'},
            'signature': 'sig-new',
        }
        previous = {
            'card': 1, 'model': self.model, 'catalog_model': self.model,
            'price': '$9 000', 'price_value': 9000, 'discount': '-89%', 'discount_value': 89,
            'discount_kind': 'discount', 'threshold': 20, 'category': 'Звичайне',
            'status': 'cached', 'eligible': False, 'model_confidence': .99,
            'name_confidence': .99, 'price_confidence': .99, 'badge_confidence': .99,
            'badge_color': 'GREEN', 'badge_text': '-89%', 'name_text': self.model,
            'price_text': '$9 000', 'xy': (400, 300), 'screen_size': (1920, 1080),
            '_cacheable': True,
        }
        state = {'layout': None, 'contexts': None, 'fields': None}
        original_builder = worker._build_ocr_montage
        def tracked_builder(card_contexts, cv2_module, np_module, selected_fields=None):
            montage, layout = original_builder(card_contexts, cv2_module, np_module, selected_fields)
            state.update(layout=layout, contexts=list(card_contexts), fields=list(layout['fields']))
            return montage, layout
        worker._build_ocr_montage = tracked_builder
        calls = []
        def fake_engine(image):
            layout, selected, batch = state['layout'], state['fields'], state['contexts']
            calls.append((tuple(selected), tuple(c['card_index'] for c in batch)))
            output = []
            for field in selected:
                value = self.model if field == 'name' else '$10 000'
                zone = next(z for z in layout['field_zones'] if z['field'] == field)
                cx = (float(zone['left']) + float(zone['right'])) / 2.0
                cy = float(layout['row_height']) / 2.0
                box = [[cx - 2, cy - 3], [cx + 2, cy - 3], [cx + 2, cy + 3], [cx - 2, cy + 3]]
                output.append([box, value, .99])
            return output, None

        cache_names = ('_CARD_CACHE_SIGNATURES', '_CARD_CACHE_RESULTS', '_CARD_CACHE_FIELD_SIGNATURES',
                       '_CARD_CACHE_CONFIG_KEY', '_CARD_CACHE_SCREEN_KEY')
        old_cache = tuple(getattr(scanner_core, name) for name in cache_names)
        try:
            with patch('scanner_core._get_ocr_engine', return_value=fake_engine):
                result, error, elapsed = worker._run_green_fast_lane(
                    [ctx], [ctx], [previous], [{'name': 'n-old', 'price': 'p-old', 'badge': 'b-same'}],
                    [0], [], ['sig-new'], (1920, 1080), 'cfg', 'screen', 1, 1,
                    cv2, np, time.perf_counter(), {}, ('name', 'price', 'badge')
                )
            self.assertEqual(error, '')
            self.assertEqual(calls, [(('name', 'price'), (0,))])
            self.assertEqual(worker._ocr_call_count, 1)
            self.assertEqual(len(signal.values), 1)
            self.assertEqual(signal.values[0]['discount_value'], 89)
            self.assertEqual(result[0]['price_value'], 10000)
        finally:
            for name, value in zip(cache_names, old_cache):
                setattr(scanner_core, name, value)

    def test_green_discount_below_all_enabled_thresholds_skips_name_price_ocr(self):
        worker = ScanWorker(
            [self.model], {self.model: {'threshold': 20, 'category': 'Звичайне'}},
            20, {self.model: 20},
            {'left': .1, 'top': .1, 'right': .95, 'bottom': .9, 'cols': 5, 'rows': 3},
            active_models={self.model}, fast_candidate_mode=True,
        )
        signal = CollectorSignal()
        worker.candidate_found = signal
        worker.progress = CollectorSignal()
        ctx = {
            'card_index': 0, 'card': 1, 'xy': (400, 300), 'screen_size': (1920, 1080),
            'badge_color': 'GREEN', 'badge_color_method': 'test', 'empty': False,
            '_fields_to_ocr': ['name', 'price', 'badge'],
            'name_crop': np.full((18, 100, 3), 255, np.uint8),
            'price_crop': np.full((18, 80, 3), 255, np.uint8),
            'badge_crop': np.full((18, 40, 3), 255, np.uint8),
            'footer_crop': np.full((18, 220, 3), 255, np.uint8),
            'field_signatures': {'name': 'n0', 'price': 'p0', 'badge': 'b0'},
            'signature': 'sig0',
        }
        state = {'layout': None, 'contexts': None, 'fields': None}
        original_builder = worker._build_ocr_montage
        def tracked_builder(card_contexts, cv2_module, np_module, selected_fields=None):
            montage, layout = original_builder(card_contexts, cv2_module, np_module, selected_fields)
            state.update(layout=layout, contexts=list(card_contexts), fields=list(layout['fields']))
            return montage, layout
        worker._build_ocr_montage = tracked_builder
        calls = []
        def fake_engine(image):
            layout, selected, batch = state['layout'], state['fields'], state['contexts']
            calls.append((tuple(selected), tuple(c['card_index'] for c in batch)))
            if tuple(selected) != ('badge',):
                raise AssertionError('name/price OCR must be skipped for a discount below every active threshold')
            zone = next(z for z in layout['field_zones'] if z['field'] == 'badge')
            cx = (float(zone['left']) + float(zone['right'])) / 2.0
            cy = float(layout['row_height']) / 2.0
            box = [[cx - 2, cy - 3], [cx + 2, cy - 3], [cx + 2, cy + 3], [cx - 2, cy + 3]]
            return [[box, '-10%', 0.99]], None

        cache_names = ('_CARD_CACHE_SIGNATURES', '_CARD_CACHE_RESULTS', '_CARD_CACHE_FIELD_SIGNATURES',
                       '_CARD_CACHE_CONFIG_KEY', '_CARD_CACHE_SCREEN_KEY')
        old_cache = tuple(getattr(scanner_core, name) for name in cache_names)
        try:
            with patch('scanner_core._get_ocr_engine', return_value=fake_engine):
                result, error, elapsed = worker._run_green_fast_lane(
                    [ctx], [ctx], [None], [None], [0], [], ['sig0'], (1920, 1080),
                    'cfg', 'screen', 1, 1, cv2, np, time.perf_counter(), {}, ('name', 'price', 'badge')
                )
            self.assertEqual(error, '')
            self.assertEqual(calls, [(('badge',), (0,))])
            self.assertEqual(signal.values, [])
            self.assertEqual(result[0]['discount_value'], 10)
            self.assertFalse(result[0]['eligible'])
            self.assertIn('OCR назви й ціни пропущено', result[0]['status'])
            self.assertEqual(worker._fast_lane_below_threshold_skipped, 1)
        finally:
            for name, value in zip(cache_names, old_cache):
                setattr(scanner_core, name, value)

    def test_green_only_does_not_ocr_red_cards(self):
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        self.assertIn("str(ctx.get('badge_color', 'UNKNOWN')).upper() != 'GREEN'", core)
        self.assertIn("status = 'Швидкий режим: червоний бейдж · OCR тексту пропущено'", core)
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn("fast_color_filter_enabled=True", main)
        self.assertIn('Режим GREEN ONLY зафіксовано', main)
        self.assertNotIn('У налаштуваннях можна ввімкнути повне OCR усіх 15 карток', main)


if __name__ == '__main__':
    unittest.main()
