import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class FinalV1251RegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "tests" / "fixtures" / "build_exe_internal_v1.2.65_legacy.bat.fixture.txt").read_text(encoding="utf-8")
        cls.settings = json.loads((ROOT / "settings.json").read_text(encoding="utf-8"))

    def test_reported_getpixel_attributeerror_is_fixed_at_the_source(self):
        block = self.actions.split("def _wait_for_green_button", 1)[1].split("def _send_atomic_left_click", 1)[0]
        self.assertIn("ctypes.windll.gdi32", block)
        self.assertIn("gdi32.GetPixel.argtypes", block)
        self.assertIn("gdi32.GetPixel(hdc", block)
        self.assertNotIn("user32.GetPixel", block)
        self.assertIn("GetPixel(gdi32)", block)

    def test_full_hd_and_2k_profiles_are_selectable_and_saved(self):
        self.assertIn("'Full HD · 1920×1080': '1920x1080'", self.main)
        self.assertIn("'2K · 2560×1440': '2560x1440'", self.main)
        self.assertIn("'resolution_profile'", self.main)
        self.assertIn("self.settings['resolution_profile']", self.main)
        self.assertIn("CLICK_WORKFLOW_VERSION = \"1.2.65-stable-offer-dedupe\"", self.actions)
        self.assertEqual(self.settings['resolution_profile'], '2560x1440')
        self.assertEqual(self.settings['config_version'], 31)

    def test_real_screen_resolution_still_drives_game_coordinates(self):
        self.assertIn("current_size = self._screen_size()", self.actions)
        self.assertIn("scale_reference_point(DETAIL_BUY, current_size)", self.actions)
        self.assertIn("scale_reference_point(FINAL_CONFIRM, current_size)", self.actions)
        self.assertIn("_physical_screen_size", self.main)

    def test_transitions_can_be_enabled_or_disabled(self):
        self.assertIn("'animations_enabled': False", self.main)
        self.assertIn("self.animations_check", self.main)
        self.assertIn("self.settings.get('animations_enabled', False)", self.main)
        self.assertIn("self._fade.setDuration(90)", self.main)

    def test_interrupted_page_fade_restores_old_opacity(self):
        block = self.main.split("    def navigate(self, key):", 1)[1].split("    def loglines(", 1)[0]
        self.assertIn("previous_effect = self._fade.targetObject()", block)
        self.assertIn("previous_effect.setOpacity(1.0)", block)
        self.assertIn("self._fade = None", block)

    def test_builder_checks_matching_main_and_click_workflow_versions(self):
        self.assertIn('NG Market Scanner v1.2.65', self.builder)
        self.assertIn('1.2.60-position-independent-discount', self.builder)

if __name__ == '__main__':
    unittest.main(verbosity=2)
