import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class ResponsiveNavigationV1260Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.navigate = cls.main.split('    def navigate(self, key):', 1)[1].split('    def loglines(self, messages):', 1)[0]

    def test_navigation_defers_page_refresh_until_after_switch(self):
        self.assertIn('QTimer.singleShot(0, lambda selected=key: self._refresh_page_after_navigation(selected))', self.navigate)
        self.assertIn('self.stack.currentIndex() != self.page_index.get(key)', self.navigate)

    def test_settings_navigation_does_not_rebuild_catalog_or_log_false_save(self):
        self.assertNotIn('self._catalog_built_signature = None', self.navigate)
        self.assertNotIn('Налаштування збережено', self.navigate)
        self.assertIn('self.refresh_catalog()', self.navigate)

    def test_animations_are_disabled_by_default_and_short_if_enabled(self):
        self.assertIn("'animations_enabled': False", self.main)
        self.assertIn("if bool(self.settings.get('animations_enabled', False)) and not same_page:", self.navigate)
        self.assertIn('self._fade.setDuration(90)', self.navigate)


if __name__ == '__main__':
    unittest.main(verbosity=2)
