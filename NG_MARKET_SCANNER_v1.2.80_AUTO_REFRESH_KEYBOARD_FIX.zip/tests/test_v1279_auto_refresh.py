import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class AutoRefreshV1279Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.settings = json.loads((ROOT / "settings.json").read_text(encoding="utf-8"))

    def test_auto_refresh_defaults_are_safe_and_configurable(self):
        self.assertFalse(self.settings["auto_refresh_enabled"])
        self.assertEqual(self.settings["auto_refresh_interval_min"], 5)
        self.assertTrue(self.settings["continue_after_purchase"])
        self.assertIn("max(1, min(10, int(settings.get('auto_refresh_interval_min'", self.main)

    def test_auto_refresh_ui_has_toggle_and_all_one_to_ten_minute_options(self):
        self.assertIn("self.auto_refresh_check = QCheckBox('Автоматично перезапускати ринок через планшет')", self.main)
        self.assertIn("[f'{minutes} хв' for minutes in range(1, 11)]", self.main)
        self.assertIn("self.auto_refresh_check.toggled.connect(self.auto_refresh_interval_combo.setEnabled)", self.main)
        self.assertIn("self.settings['auto_refresh_enabled'] = bool(self.auto_refresh_check.isChecked())", self.main)

    def test_refresh_path_checks_market_focus_and_resolution_before_each_action(self):
        self.assertIn("core.probe_market_return_state(", self.main)
        self.assertIn("if state != 'market':", self.main)
        self.assertIn("def _auto_refresh_context_is_safe(self, sequence_id):", self.main)
        self.assertIn("return size == tuple(self._auto_refresh_screen_size or ())", self.main)
        for token in ("_auto_refresh_send_key(sequence_id, 0x1B)", "_auto_refresh_send_key(sequence_id, 0x28)",
                      "_auto_refresh_click_fraction(sequence_id, 0.50, 0.50)",
                      "_auto_refresh_click_fraction(sequence_id, 0.300, 0.255)",
                      "_auto_refresh_click_fraction(sequence_id, 0.040, 0.178)"):
            self.assertIn(token, self.main)

    def test_auto_refresh_yields_to_ocr_and_purchase_workers(self):
        self.assertIn("self._auto_refresh_worker_active()", self.main)
        self.assertIn("_finalize_scan_worker_finished starts the refresh before scheduling another OCR cycle", self.main)
        self.assertIn("if self._auto_refresh_pending and self.running and self._continuous_scan_requested", self.main)
        self.assertIn("if self.action_in_progress or self._action_worker_is_running():", self.main)

    def test_after_purchase_behavior_is_user_configurable(self):
        self.assertIn("self.continue_after_purchase_check = QCheckBox('Продовжувати сканування та пошук після покупки')", self.main)
        self.assertIn("self._resume_scan_after_action = bool(self._purchase_was_continuous_scan and continue_after_purchase)", self.main)
        self.assertIn("if self._purchase_was_continuous_scan and not continue_after_purchase:", self.main)
        self.assertIn("self.settings['continue_after_purchase'] = bool(self.continue_after_purchase_check.isChecked())", self.main)

if __name__ == "__main__":
    unittest.main(verbosity=2)
