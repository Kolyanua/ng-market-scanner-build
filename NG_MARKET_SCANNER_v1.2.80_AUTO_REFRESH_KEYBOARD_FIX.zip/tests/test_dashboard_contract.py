import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class DashboardContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        cls.logic = (ROOT / 'scanner_core_logic.py').read_text(encoding='utf-8')
        cls.actions = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')

    def test_navigation_contains_stats_and_top_vehicles(self):
        self.assertIn("('Топ авто', 'top', 'stats')", self.main)
        self.assertIn("self.pages['top'] = self._make_top_page()", self.main)
        self.assertIn('def _make_stats_page(self):', self.main)
        self.assertIn('def _make_top_page(self):', self.main)

    def test_stats_are_persisted_and_distinguish_clicks_from_confirmation(self):
        for token in ('stats_history.json', '_queue_stats_event', 'purchase_flow_sent', 'purchase_confirmed', 'export_stats_csv', 'Динаміка підтверджених покупок'):
            self.assertIn(token, self.main)
        self.assertIn('explicit, distinct confirmation messages', self.main)

    def test_primary_ui_controls_are_wired_to_real_handlers(self):
        # Source-level wiring contract: the controls below must remain connected
        # to implemented methods rather than becoming decorative UI elements.
        for token in (
            "self.start_btn.clicked.connect(self.toggle_scanning)",
            "self.once_btn.clicked.connect(lambda: self.scan_once())",
            "self.export_results_btn.clicked.connect(self.export_results_csv)",
            "reload_btn.clicked.connect(lambda checked=False: self.refresh_catalog(force=True))",
            "save.clicked.connect(self.save_catalog)",
            "select_all.clicked.connect(lambda: self.set_catalog_checks(True))",
            "add_custom.clicked.connect(self.add_custom_vehicle)",
            "edit_vehicle.clicked.connect(self.edit_selected_vehicle)",
            "delete_vehicle.clicked.connect(self.delete_custom_vehicle)",
            "export.clicked.connect(self.export_stats_csv)",
            "clear.clicked.connect(self.clear_log)",
            "export.clicked.connect(self.export_log)",
            "self.resolution_profile_combo.currentTextChanged.connect(self._on_resolution_profile_changed)",
            "self.animations_check",
        ):
            self.assertIn(token, self.main, token)

    def test_scan_core_keeps_expected_fast_capture_and_logic_helpers(self):
        self.assertIn('OCRWarmupWorker', self.core)
        self.assertIn('changed_card_indices', self.logic)
        self.assertIn('match_catalog_model', self.logic)

    def test_clicks_poll_for_visible_green_cta_before_clicking(self):
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', self.actions)
        self.assertIn('BUTTON_POLL_INTERVAL_MS = 1', self.actions)
        self.assertIn('_wait_for_green_button', self.actions)
        self.assertIn('gdi32.GetPixel', self.actions)
        self.assertNotIn('user32.GetPixel', self.actions)
        self.assertIn('DETAIL_BUY = (1484, 1005)', self.actions)
        self.assertIn('FINAL_CONFIRM = (1070, 717)', self.actions)

if __name__ == '__main__': unittest.main()
