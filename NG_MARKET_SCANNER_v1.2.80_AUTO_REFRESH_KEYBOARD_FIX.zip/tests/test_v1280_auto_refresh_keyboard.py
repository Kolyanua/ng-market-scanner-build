import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class AutoRefreshKeyboardV1280Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")

    def test_keyboard_uses_sendinput_scan_code_instead_of_keybd_event(self):
        method = self.main.split("    def _auto_refresh_send_key(", 1)[1].split("    def _auto_refresh_click_fraction(", 1)[0]
        self.assertIn("user32.SendInput", method)
        self.assertIn("KEYEVENTF_SCANCODE", method)
        self.assertNotIn("user32.keybd_event", method)

    def test_arrow_keys_are_extended_and_held_long_enough(self):
        method = self.main.split("    def _auto_refresh_send_key(", 1)[1].split("    def _auto_refresh_click_fraction(", 1)[0]
        self.assertIn("if vk in (0x25, 0x26, 0x27, 0x28)", method)
        self.assertIn("time.sleep(0.065)", method)
        self.assertIn("key_flags | 0x0002", method)

    def test_purchase_fast_path_is_not_replaced_by_refresh_input(self):
        actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        self.assertIn("def _send_atomic_left_click()", actions)
        self.assertIn("user32.SendInput", actions)

if __name__ == "__main__":
    unittest.main(verbosity=2)
