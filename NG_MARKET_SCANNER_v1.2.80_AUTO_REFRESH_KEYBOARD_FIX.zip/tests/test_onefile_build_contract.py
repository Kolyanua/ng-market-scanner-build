import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class OneFileBuildContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "scanner_core.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "build_single_exe_internal.bat").read_text(encoding="utf-8")
        cls.outer = (ROOT / "tests" / "fixtures" / "legacy_builds" / "build_single_exe.bat.fixture.txt").read_text(encoding="utf-8")

    def test_onefile_uses_bundle_resources_and_appdata_for_mutable_state(self):
        self.assertIn("getattr(sys, '_MEIPASS'", self.main)
        self.assertIn("_LOCAL_ROOT / 'NGMarketScanner'", self.main)
        self.assertIn("RESOURCE_DIR / 'vehicle_renders'", self.main)
        self.assertIn("RESOURCE_DIR / 'theme' / 'style.qss'", self.main)
        self.assertIn("RESOURCE_DIR / 'scanner_core.py'", self.main)
        self.assertIn("LOCALAPPDATA", self.core)

    def test_builder_really_uses_pyinstaller_onefile_and_embeds_dynamic_modules(self):
        self.assertIn("--onefile", self.builder)
        self.assertNotIn("--onedir", self.builder)
        for token in (
            '--add-data "scanner_core.py;."',
            '--add-data "scanner_core_logic.py;."',
            '--add-data "scanner_actions.py;."',
            '--add-data "vehicle_renders;vehicle_renders"',
            '--add-data "theme;theme"',
            '--add-data "assets;assets"',
            '--add-data "vehicle_photos;vehicle_photos"',
        ):
            self.assertIn(token, self.builder)

    def test_builder_runs_tests_before_packaging_and_copies_one_exe_only(self):
        self.assertLess(self.builder.index("python -m unittest discover -s tests -v"), self.builder.index("python -m PyInstaller"))
        self.assertIn("--onefile", self.builder)
        self.assertIn('NG Market Scanner.exe', self.outer)
        self.assertIn('move /Y "%STAGE_EXE%" "%SOURCE_EXE%"', self.outer)

    def test_ocr_models_are_warmed_and_validated_before_singlefile_packaging(self):
        prepare = ROOT / "tools" / "prepare_ocr_models.py"
        self.assertTrue(prepare.is_file())
        self.assertLess(self.builder.index("python tools\\prepare_ocr_models.py"), self.builder.index("python -m PyInstaller"))
        prepare_text = prepare.read_text(encoding="utf-8")
        self.assertIn("Expected detector and recognizer ONNX weights", prepare_text)
        self.assertIn("PROJECT_ROOT = Path(__file__).resolve().parents[1]", prepare_text)
        self.assertIn("sys.path.insert(0, str(PROJECT_ROOT))", prepare_text)
        self.assertLess(prepare_text.index("sys.path.insert(0, str(PROJECT_ROOT))"), prepare_text.index("import scanner_core"))

    def test_shared_onefile_build_defaults_do_not_purchase_automatically(self):
        self.assertIn("d['auto_click']=False", self.builder)
        self.assertIn("d['auto_confirm']=False", self.builder)
        self.assertIn("stats_history.json').write_text('[]", self.builder)

    def test_first_run_copy_preserves_existing_user_settings(self):
        self.assertIn("if _seed_source.is_file() and not _seed_target.exists()", self.main)
        self.assertIn("if _custom_seed_file.is_file() and not (_custom_seed_target / _custom_seed_file.name).exists()", self.main)

if __name__ == "__main__":
    unittest.main()
