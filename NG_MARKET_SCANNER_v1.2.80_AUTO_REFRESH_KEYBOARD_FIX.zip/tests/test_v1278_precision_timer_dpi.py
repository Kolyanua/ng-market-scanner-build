from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]


class PrecisionWaitAndDpiV1278Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.builder = (ROOT / "build_single_exe_internal.bat").read_text(encoding="utf-8")
        cls.outer = (ROOT / "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat").read_text(encoding="utf-8")

    def test_fast_chain_keeps_page_transition_gap_and_slightly_reduces_hover(self):
        self.assertIn('FAST_COORDINATE_HOVER_MS = 10', self.actions)
        self.assertIn('FAST_COORDINATE_GAP_MS = 50', self.actions)
        self.assertEqual(3 * 10 + 2 * 50, 130)
        self.assertEqual(self.actions.count('self._wait_precise_ms(FAST_COORDINATE_GAP_MS)'), 2)

    def test_native_wait_is_cancellable_and_has_fallbacks(self):
        self.assertIn('CreateWaitableTimerExW', self.actions)
        self.assertIn('CREATE_WAITABLE_TIMER_HIGH_RESOLUTION', self.actions)
        self.assertIn('CreateWaitableTimerW', self.actions)
        self.assertIn('WaitForMultipleObjects', self.actions)
        self.assertIn('native wait failed', self.actions)
        self.assertIn('kernel32.SetEvent(handle)', self.actions)
        self.assertIn('threading.Event.wait fallback', self.actions)
        self.assertIn('CLICK_WAIT_TIMER_PATCH_VERSION = "1.2.75-cancellable-highres-wait"', self.actions)
        self.assertIn('EXPECTED_CLICK_WAIT_TIMER_PATCH_VERSION', self.main)
        self.assertIn('1.2.75-cancellable-highres-wait', self.builder)
        self.assertIn('1.2.75-cancellable-highres-wait', self.outer)

    def test_actual_wait_overrun_is_reported_after_the_click_chain(self):
        fast_flow = self.actions.split('def _run_fast_coordinate_flow(', 1)[1].split('def run(self):', 1)[0]
        self.assertIn('wait_overrun_ms = max(0.0, self._wait_actual_ms - self._wait_planned_ms)', fast_flow)
        self.assertIn('таймер={self._wait_backend}', fast_flow)

    def test_resolution_uses_same_win32_pixel_space_as_click_coordinates(self):
        self.assertIn('user32.GetSystemMetrics(0)', self.main)
        self.assertIn('user32.GetSystemMetrics(1)', self.main)
        self.assertIn('Main._physical_screen_size()', self.main)
        self.assertNotIn('--manifest', self.builder)
        self.assertNotIn('ngms_windows.manifest', self.builder)
        self.assertNotIn('ngms_windows.manifest', self.outer)

    def test_runtime_dpi_awareness_is_set_before_qt_imports(self):
        self.assertIn('SetProcessDpiAwarenessContext', self.main)
        self.assertIn('DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2', self.main)
        self.assertIn('set_awareness(2)', self.main)
        self.assertIn('_WINDOWS_DPI_AWARENESS = _enable_windows_dpi_awareness()', self.main)
        dpi_call = self.main.index('_WINDOWS_DPI_AWARENESS = _enable_windows_dpi_awareness()')
        qt_import = self.main.index('from PySide6.QtCore')
        self.assertLess(dpi_call, qt_import, 'DPI awareness must be set before importing Qt')

    def test_action_core_is_preloaded_before_the_user_can_start(self):
        warmup = self.main.split('    def _start_ocr_warmup(', 1)[1].split('    def _prewarm_action_core(', 1)[0]
        self.assertLess(warmup.index('self._prewarm_action_core()'), warmup.index('self.ocr_warmup_worker.start()'))
        self.assertIn('CLICK CORE PREWARM', self.main)


if __name__ == '__main__':
    unittest.main(verbosity=2)
