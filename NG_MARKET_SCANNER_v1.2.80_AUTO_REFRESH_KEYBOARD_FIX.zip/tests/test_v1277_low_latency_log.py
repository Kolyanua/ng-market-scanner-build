from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]

class LowLatencyLogContractTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.theme = (ROOT / "theme" / "style.qss").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")

    def test_log_views_are_plain_text_with_bounded_blocks(self):
        self.assertIn("self.log_preview = QPlainTextEdit()", self.main)
        self.assertIn("self.full_log = QPlainTextEdit()", self.main)
        self.assertIn("setMaximumBlockCount(80)", self.main)
        self.assertIn("setMaximumBlockCount(2000)", self.main)

    def test_log_append_is_incremental_not_full_rebuild(self):
        method = self.main.split("    def loglines(", 1)[1].split("    def _flush_log_views_refresh", 1)[0]
        self.assertIn("self._append_log_views(lines)", method)
        append = self.main.split("    def _append_log_views(", 1)[1].split("    def _flush_log_views_refresh", 1)[0]
        self.assertIn("appendPlainText(payload)", append)
        self.assertNotIn("setPlainText(content)", append)

    def test_scan_worker_is_cancelled_immediately_after_purchase_worker_starts(self):
        method = self.main.split("    def _start_purchase_action(", 1)[1].split("    def _on_action_worker_thread_finished_signal(", 1)[0]
        self.assertLess(method.index("action_worker.start()"), method.index("scan_worker.cancel()"))
        self.assertLess(method.index("scan_worker.cancel()"), method.index("QTimer.singleShot(0, lambda message=start_message"))

    def test_only_hover_dwell_is_reduced(self):
        self.assertIn("FAST_COORDINATE_HOVER_MS = 10", self.actions)
        self.assertIn("FAST_COORDINATE_GAP_MS = 50", self.actions)

if __name__ == "__main__":
    unittest.main()
