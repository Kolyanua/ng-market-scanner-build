import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class PathSafeBuilderTests(unittest.TestCase):
    def test_canonical_builder_uses_powershell_for_unicode_and_spaced_paths(self):
        text = (ROOT / "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat").read_text(encoding="ascii")
        self.assertIn("NGMS_STAGE_DIR", text)
        self.assertIn("powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command", text)
        self.assertIn("NGMS_PRESERVE_AUTOBUY=1", text)
        self.assertIn("1.2.67-persistent-dxcam-market-roi", text)
        self.assertIn("self.timer.start(max(20", text)
        self.assertIn("call build_single_exe_internal.bat", text)
        self.assertNotIn("findstr /C:", text)
        self.assertTrue(all(ord(ch) < 128 for ch in text), "CMD entrypoint must be ASCII-only")

    def test_entrypoints_avoid_parenthesized_if_command_groups(self):
        names = [
            "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat", "RUN_CLEAN_INSTALL_AND_START.bat.fixture.txt",
            "build_exe.bat.fixture.txt", "build_exe_internal.bat.fixture.txt", "BUILD_FINAL_v1.2.60_POSITION_INDEPENDENT_DISCOUNT.bat.fixture.txt",
        ]
        for name in names:
            path = (ROOT / name) if name == "BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat" else (ROOT / "tests" / "fixtures" / "legacy_builds" / name)
            text = path.read_text(encoding="utf-8")
            self.assertNotRegex(text, r"(?im)^\s*if\b[^\r\n]*\(\s*$", name)
            self.assertIn("%~dp0", text, name)

if __name__ == "__main__":
    unittest.main()
