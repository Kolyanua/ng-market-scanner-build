import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class ContinuousResumeRegressionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")

    def test_continuous_session_intent_is_persistent_across_purchase_worker(self):
        self.assertIn("self._continuous_scan_requested = True", self.main)
        self.assertIn("self._resume_scan_after_action = bool(", self.main)
        self.assertIn("getattr(self, '_continuous_scan_requested', False) or self.running", self.main)
        self.assertIn("self.running = bool(self._resume_scan_after_action)", self.main)
        self.assertIn("self._resume_scan_after_action = False", self.main)

    def test_explicit_stop_clears_persistent_continuous_intent(self):
        stop = self.main.split("    def stop_scanning(self):", 1)[1].split("    def toggle_scanning(self):", 1)[0]
        self.assertIn("self._continuous_scan_requested = False", stop)
        toggle = self.main.split("    def toggle_scanning(self):", 1)[1].split("    def scan_once(self, hide_window=None):", 1)[0]
        self.assertIn("self._continuous_scan_requested = True", toggle)

    def test_explicit_stop_cancels_deferred_resume(self):
        stop = self.main.split("    def stop_scanning(self):", 1)[1].split("    def toggle_scanning(self):", 1)[0]
        self.assertIn("self._resume_scan_after_action = False", stop)

    def test_resume_waits_until_action_and_scan_workers_exit(self):
        resume = self.main.split("    def _resume_continuous_scan_after_action(self):", 1)[1].split("    def on_action_result", 1)[0]
        self.assertIn("self._action_worker_is_running()", resume)
        self.assertIn("worker_active", resume)
        self.assertIn("self._scan_request_active", resume)
        self.assertIn("self.scan_once(hide_window=None)", resume)


    def test_fast_click_chain_keeps_continuous_mode_and_sets_cooldown(self):
        result = self.main.split("    def on_action_result(", 1)[1].split("    def ", 1)[0]
        self.assertIn("self._resume_scan_not_before = time.monotonic() + 0.25", result)
        fast_branch = result.split("if fast_no_postcheck:", 1)[1].split("elif not success", 1)[0]
        self.assertNotIn("self._resume_scan_after_action = False", fast_branch)
        self.assertIn("OCR-free перевірка стану гри", fast_branch)
        self.assertIn("серверне підтвердження покупки цим не замінюється", fast_branch)

    def test_resume_waits_for_ui_cooldown(self):
        resume = self.main.split("    def _resume_continuous_scan_after_action(", 1)[1].split("    def on_action_result", 1)[0]
        self.assertIn("_resume_scan_not_before", resume)
        self.assertIn("QTimer.singleShot(max(25, int(remaining * 1000))", resume)

    def test_resume_accepts_same_game_process_and_attempts_focus_recovery_only_safely(self):
        self.assertIn("def _foreground_matches_game_target", self.main)
        self.assertIn("GetWindowThreadProcessId", self.main)
        self.assertIn("def _restore_game_focus_for_resume_if_safe", self.main)
        self.assertIn("if state == 'not_foreground' and not self._resume_focus_recovery_attempted", self.main)
        self.assertIn("self._foreground_matches_game_target(self._scan_target_hwnd)", self.main)

    def test_fullscreen_warning_accepts_both_full_hd_and_2k_examples(self):
        self.assertIn("1920×1080 або 2560×1440", self.main)

    def test_purchase_click_implementation_is_not_modified(self):
        self.assertIn("CLICK_WORKFLOW_VERSION = \"1.2.65-stable-offer-dedupe\"", self.actions)
        self.assertIn("SendInput(2, events", self.actions)

if __name__ == "__main__":
    unittest.main(verbosity=2)
