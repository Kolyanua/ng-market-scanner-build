import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch
try:
    from PySide6.QtCore import QThread, Signal  # noqa: F401
except Exception:
    pyside = types.ModuleType('PySide6')
    qtcore = types.ModuleType('PySide6.QtCore')
    class QThread:
        def __init__(self, *args, **kwargs): pass
        def start(self): pass
        def isRunning(self): return False
        def wait(self, *args): return True
    class _Signal:
        def __init__(self, *args, **kwargs): pass
        def connect(self, *args, **kwargs): pass
        def emit(self, *args, **kwargs): pass
    qtcore.QThread = QThread
    qtcore.Signal = _Signal
    pyside.QtCore = qtcore
    sys.modules.setdefault('PySide6', pyside)
    sys.modules.setdefault('PySide6.QtCore', qtcore)

import numpy as np
import cv2
import scanner_core


class DirectGreenWatchTests(unittest.TestCase):
    def _frame_with_badges(self, index=0):
        frame=np.full((1080,1920,3),110,dtype=np.uint8)
        # Exact default-layout badge-color ROI for a selected 0-based card index.
        lefts=(.155,.322,.489,.655,.822); rights=(.315,.481,.647,.813,.981)
        row,col=divmod(index,5)
        card_x=int(lefts[col]*1920); card_w=int(rights[col]*1920)-card_x
        x0=card_x+int(.775*card_w); y0=int((.321+row*.270)*1080)
        x1=card_x+int(.980*card_w); y1=y0+int(.027*1080)
        frame[y0:y1,x0:x1]=(20,50,24)  # BGR dark green accepted by AHK-equivalent classifier.
        return frame

    def test_direct_detector_is_ocr_free_and_emits_only_green_cards(self):
        frame=self._frame_with_badges()
        candidates=scanner_core._direct_watch_card_candidates(
            frame, {'left':.153,'top':.095,'right':.985,'bottom':.895,'cols':5,'rows':3}, (1920,1080), 1234)
        self.assertEqual(len(candidates),1)
        self.assertEqual(candidates[0]['card_index'],0)
        self.assertEqual(candidates[0]['badge_color'],'GREEN')
        self.assertEqual(candidates[0]['target_hwnd'],1234)
        self.assertTrue(candidates[0]['signature'])

    def test_region_capture_preserves_card_identity_and_absolute_click_coordinates(self):
        full=self._frame_with_badges()
        full_candidate=scanner_core._direct_watch_card_candidates(
            full, {'left':.153,'top':.095,'right':.985,'bottom':.895,'cols':5,'rows':3},
            (1920,1080), 1234)[0]
        origin_x=int(.153*1920)-int(.02*1920)
        origin_y=int(.095*1080)-int(.02*1080)
        cropped=full[origin_y:,origin_x:]
        crop_candidate=scanner_core._direct_watch_card_candidates(
            cropped, {'left':.153,'top':.095,'right':.985,'bottom':.895,'cols':5,'rows':3},
            (1920,1080), 1234, monitor_left=origin_x, monitor_top=origin_y)[0]
        self.assertEqual(crop_candidate['card_index'],full_candidate['card_index'])
        self.assertEqual(crop_candidate['badge_color'],'GREEN')
        self.assertEqual(crop_candidate['xy'],full_candidate['xy'])
        self.assertEqual(crop_candidate['screen_size'],(1920,1080))

    def test_detail_button_detection_works_with_region_capture(self):
        full=np.zeros((1080,1920,3),dtype=np.uint8)
        cx,cy=int(.773*1920),int(.930*1080)
        full[cy-22:cy+23,cx-30:cx+31]=(100,200,20)
        self.assertTrue(scanner_core._direct_watch_has_detail_buy_button(full))
        ox=int(.153*1920)-int(.02*1920)
        oy=int(.095*1080)-int(.02*1080)
        cropped=full[oy:,ox:]
        self.assertTrue(scanner_core._direct_watch_has_detail_buy_button(
            cropped,ox,oy,(1920,1080)))

    def test_capture_uses_new_frames_and_a_region_instead_of_reprocessing_fullscreen(self):
        source=Path('scanner_core.py').read_text(encoding='utf-8')
        self.assertIn('camera.start(region=region, target_fps=120, video_mode=False)',source)
        self.assertIn("monitor={'left':region_left,'top':region_top,",source)
        self.assertNotIn('video_mode=True',source[source.index('class GreenBadgeWatcher'):source.index('class GreenBadgeBatchWorker')])

    def test_short_candidate_window_batches_near_simultaneous_green_offers(self):
        a={'card_index':0,'card':1,'signature':'0:one','badge_color':'GREEN'}
        b={'card_index':1,'card':2,'signature':'1:two','badge_color':'GREEN'}
        pending=scanner_core._merge_green_candidate_window({},[a],[a],set())
        self.assertEqual(set(pending),{'0:one'})
        pending=scanner_core._merge_green_candidate_window(pending,[a,b],[b],set())
        self.assertEqual(set(pending),{'0:one','1:two'})
        # A card that loses its green badge during the brief collection window must be dropped.
        pending=scanner_core._merge_green_candidate_window(pending,[b],[],set())
        self.assertEqual(set(pending),{'1:two'})
        self.assertAlmostEqual(scanner_core.DIRECT_GREEN_CANDIDATE_COALESCE_SECONDS,0.004)

    def test_watcher_triggers_only_when_card_becomes_green_or_listing_changes(self):
        baseline=[
            {'card_index':0,'signature':'NON_GREEN:NONE','badge_color':'NONE'},
            {'card_index':1,'signature':'stable-green','badge_color':'GREEN'},
        ]
        changed,current=scanner_core._changed_green_watch_candidates(baseline,{})
        self.assertEqual([c['card_index'] for c in changed],[1])
        # A running watcher primes this state as its baseline, so these existing cards are ignored.
        changed_again,current2=scanner_core._changed_green_watch_candidates(baseline,current)
        self.assertEqual(changed_again,[])
        update=[
            {'card_index':0,'signature':'new-green','badge_color':'GREEN'},
            {'card_index':1,'signature':'stable-green','badge_color':'GREEN'},
        ]
        changed_again,_=scanner_core._changed_green_watch_candidates(update,current2)
        self.assertEqual([c['card_index'] for c in changed_again],[0])

    def test_card_signature_is_independent_of_grid_position(self):
        grid={'left':.153,'top':.095,'right':.985,'bottom':.895,'cols':5,'rows':3}
        first=scanner_core._direct_watch_card_candidates(self._frame_with_badges(0),grid,(1920,1080),include_all_states=True)[0]
        second=scanner_core._direct_watch_card_candidates(self._frame_with_badges(1),grid,(1920,1080),include_all_states=True)[1]
        self.assertEqual(first['identity_signature'],second['identity_signature'])
        self.assertEqual(first['discount_signature'],second['discount_signature'])
        self.assertEqual(first['signature'],second['signature'])
        self.assertFalse(first['signature'].startswith('0:'))
        self.assertFalse(second['signature'].startswith('1:'))

    def test_moving_old_green_card_to_another_cell_does_not_trigger_again(self):
        old={'card_index':0,'signature':'id:A|disc:20','identity_signature':'id:A',
             'discount_signature':'disc:20','badge_color':'GREEN'}
        changed,current=scanner_core._changed_green_watch_candidates([old],{})
        self.assertEqual(changed,[old])
        moved=dict(old,card_index=7,card=8)
        changed,_=scanner_core._changed_green_watch_candidates([moved],current)
        self.assertEqual(changed,[])

    def test_discount_change_for_same_card_remains_a_candidate(self):
        old={'card_index':0,'signature':'id:A|disc:20','identity_signature':'id:A',
             'discount_signature':'disc:20','badge_color':'GREEN'}
        _,current=scanner_core._changed_green_watch_candidates([old],{})
        updated=dict(old,card_index=4,signature='id:A|disc:35',discount_signature='disc:35')
        changed,_=scanner_core._changed_green_watch_candidates([updated],current)
        self.assertEqual(changed,[updated])

    @staticmethod
    def _perceptual_candidate(card_index=0, visual=0x123456789abcdef0,
                              text=0x0fedcba987654321, badge=0x0000ffff0000ffff,
                              mask=None):
        if mask is None:
            mask = '00' * 96
        identity = f'idp:{visual:016x}:{text:016x}'
        discount = f'dpm:{badge:016x}:{mask}'
        return {
            'card_index': card_index, 'card': card_index + 1,
            'identity_signature': identity, 'discount_signature': discount,
            'signature': f'{identity}|{discount}', 'badge_color': 'GREEN',
            'detected_at': 1.0 + card_index, 'xy': (100 + card_index, 200),
        }

    def test_perceptual_frame_noise_does_not_reenter_the_same_card(self):
        old = self._perceptual_candidate()
        # Up to 3 whole-card bits, 1 title/price bit, 1 badge hash bit and 1 mask bit
        # differ due to anti-aliasing / capture noise; this is still the same offer.
        mask = ('00' * 95) + '01'
        noisy = self._perceptual_candidate(
            card_index=7,
            visual=0x123456789abcdef3,
            text=0x0fedcba987654320,
            badge=0x0000ffff0000fffe,
            mask=mask,
        )
        self.assertTrue(scanner_core._candidate_signatures_similar(old, noisy))
        self.assertTrue(scanner_core._offer_signature_was_attempted(noisy['signature'], {old['signature']}))
        pending = scanner_core._merge_green_candidate_window({}, [noisy], [noisy], {old['signature']})
        self.assertEqual(pending, {}, 'Small render noise must not launch the same offer again.')

    def test_real_discount_change_is_not_hidden_by_perceptual_dedupe(self):
        old = self._perceptual_candidate()
        # Four DCT bits differ and the badge mask changes significantly: this is not
        # considered render noise, so the same listing at a truly new discount can retry.
        mask = ('00' * 95) + '0f'
        updated = self._perceptual_candidate(
            card_index=0,
            visual=0x123456789abcdef0,
            text=0x0fedcba987654321,
            badge=0x0000ffff0000fff0,
            mask=mask,
        )
        self.assertFalse(scanner_core._discount_signatures_similar(
            old['discount_signature'], updated['discount_signature']))
        self.assertFalse(scanner_core._offer_signature_was_attempted(
            updated['signature'], {old['signature']}))
        changed, current = scanner_core._changed_green_watch_candidates([old], {})
        self.assertEqual(changed, [old])
        changed, _ = scanner_core._changed_green_watch_candidates([updated], current)
        self.assertEqual(changed, [updated], 'A real discount change must remain eligible for validation.')

    def test_real_badge_pixels_tolerate_render_noise_but_detect_discount_change(self):
        def badge_signature(label, noise=0, seed=42):
            # Approximate the small green percentage badge captured by the watcher.
            image = np.full((28, 64, 3), (20, 50, 24), dtype=np.uint8)
            cv2.putText(image, label, (1, 20), cv2.FONT_HERSHEY_SIMPLEX,
                        0.48, (235, 245, 235), 1, cv2.LINE_AA)
            if noise:
                rng = np.random.default_rng(seed)
                noisy = image.astype(np.int16) + rng.integers(
                    -noise, noise + 1, size=image.shape)
                image = np.clip(noisy, 0, 255).astype(np.uint8)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            mask = (gray >= 120).astype(np.uint8)
            mask = cv2.resize(mask, (48, 16), interpolation=cv2.INTER_NEAREST)
            mask_hex = np.packbits(mask.reshape(-1)).tobytes().hex()
            perceptual = scanner_core._perceptual_hash_hex(image, cv2, np)
            return f'dpm:{perceptual}:{mask_hex}'

        clean = badge_signature('-27%')
        noisy_same_offer = badge_signature('-27%', noise=2, seed=7)
        genuinely_changed = badge_signature('-22%')
        self.assertTrue(scanner_core._discount_signatures_similar(clean, noisy_same_offer))
        self.assertFalse(scanner_core._discount_signatures_similar(clean, genuinely_changed))

    def test_same_card_coordinates_refresh_without_changing_offer_identity(self):
        first = self._perceptual_candidate(card_index=0)
        moved = self._perceptual_candidate(card_index=6, visual=0x123456789abcdef2)
        pending = scanner_core._merge_green_candidate_window({}, [first], [first], set())
        pending = scanner_core._merge_green_candidate_window(pending, [moved], [moved], set())
        self.assertEqual(len(pending), 1)
        refreshed = next(iter(pending.values()))
        self.assertEqual(refreshed['card_index'], 6)
        self.assertEqual(refreshed['xy'], moved['xy'])

    def test_pending_candidate_follows_offer_signature_after_position_shift(self):
        original={'card_index':0,'xy':(100,100),'signature':'id:A|disc:30','badge_color':'GREEN'}
        moved={'card_index':2,'xy':(700,100),'signature':'id:A|disc:30','badge_color':'GREEN'}
        pending=scanner_core._merge_green_candidate_window({},[original],[original],set())
        pending=scanner_core._merge_green_candidate_window(pending,[moved],[],set())
        self.assertEqual(set(pending),{'id:A|disc:30'})
        self.assertEqual(pending['id:A|disc:30']['card_index'],2)
        self.assertEqual(pending['id:A|disc:30']['xy'],(700,100))

    def test_direct_detector_can_prime_all_card_states_without_ocr(self):
        frame=np.full((1080,1920,3),110,dtype=np.uint8)
        card_x=int(.155*1920); card_w=int(.315*1920)-card_x
        x0=card_x+int(.775*card_w); y0=int(.321*1080)
        x1=card_x+int(.980*card_w); y1=y0+int(.027*1080)
        frame[y0:y1,x0:x1]=(20,50,24)
        states=scanner_core._direct_watch_card_candidates(frame,{},(1920,1080),include_all_states=True)
        self.assertEqual(len(states),15)
        self.assertEqual(states[0]['badge_color'],'GREEN')
        self.assertIsNotNone(states[0]['badge_crop'])
        self.assertIsNone(states[1]['badge_crop'])
        self.assertTrue(states[1]['signature'].startswith('1:NON_GREEN:'))

    def test_direct_detector_ignores_red_badges(self):
        frame=np.full((1080,1920,3),110,dtype=np.uint8)
        card_x=int(.155*1920); card_w=int(.315*1920)-card_x
        x0=card_x+int(.775*card_w); y0=int(.321*1080)
        x1=card_x+int(.980*card_w); y1=y0+int(.027*1080)
        frame[y0:y1,x0:x1]=(20,24,50)  # BGR dark red, must not trigger fast lane.
        self.assertEqual(scanner_core._direct_watch_card_candidates(frame,{},(1920,1080)),[])

    def test_batch_worker_sorts_green_badges_by_discount(self):
        candidates=[
            {'card':1,'signature':'a','badge_crop':np.full((30,65,3),20,dtype=np.uint8)},
            {'card':2,'signature':'b','badge_crop':np.full((30,65,3),25,dtype=np.uint8)},
        ]
        def fake_engine(image):
            # The worker lays out 3 badge tiles per row (170x80 each).
            def box(x,y): return [[x-62,y-5],[x+62,y-5],[x+62,y+5],[x-62,y+5]]
            return [(box(85,40),'-45%',0.98),(box(255,40),'-89%',0.99)],0.001
        got=[]
        class Collector:
            def emit(self,*values): got.append(values)
        worker=scanner_core.GreenBadgeBatchWorker(candidates)
        worker.results_ready=Collector()
        with patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            worker.run()
        self.assertEqual(len(got),1)
        rows,error,_=got[0]
        self.assertEqual(error,'')
        self.assertEqual([r['discount_value'] for r in rows],[89,45])
        self.assertEqual([r['card'] for r in rows],[2,1])

    def test_batch_worker_retries_unclear_badge_and_ranks_after_second_pass(self):
        candidates=[
            {'card_index':0,'card':1,'signature':'a','badge_crop':np.full((30,65,3),20,dtype=np.uint8)},
            {'card_index':1,'card':2,'signature':'b','badge_crop':np.full((30,65,3),25,dtype=np.uint8)},
        ]
        calls=[]
        def fake_engine(image):
            calls.append(image.copy())
            def box(x,y): return [[x-62,y-5],[x+62,y-5],[x+62,y+5],[x-62,y+5]]
            # First pass misses card 2, forcing the contrast-normalized fallback pass.
            if len(calls)==1:
                return [(box(85,40),'-45%',0.98)],0.001
            return [(box(85,40),'-45%',0.98),(box(255,40),'-89%',0.99)],0.001
        got=[]
        class Collector:
            def emit(self,*values): got.append(values)
        worker=scanner_core.GreenBadgeBatchWorker(candidates)
        worker.results_ready=Collector()
        with patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            worker.run()
        self.assertEqual(len(calls),2)
        self.assertEqual(len(got),1)
        rows,error,_=got[0]
        self.assertEqual(error,'')
        self.assertEqual([r['discount_value'] for r in rows],[89,45])

    def test_batch_worker_fails_closed_when_ocr_passes_disagree(self):
        candidates=[
            {'card_index':0,'card':1,'signature':'a','badge_crop':np.full((30,65,3),20,dtype=np.uint8)},
            {'card_index':1,'card':2,'signature':'b','badge_crop':np.full((30,65,3),25,dtype=np.uint8)},
        ]
        calls=[]
        def fake_engine(image):
            calls.append(image.copy())
            def box(x,y): return [[x-62,y-5],[x+62,y-5],[x+62,y+5],[x-62,y+5]]
            if len(calls)==1:
                return [(box(85,40),'-45%',0.98),(box(255,40),'?',0.10)],0.001
            return [(box(85,40),'-89%',0.99),(box(255,40),'-40%',0.96)],0.001
        got=[]
        class Collector:
            def emit(self,*values): got.append(values)
        worker=scanner_core.GreenBadgeBatchWorker(candidates)
        worker.results_ready=Collector()
        with patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            worker.run()
        self.assertEqual(len(calls),2)
        rows,error,_=got[0]
        self.assertEqual(error,'')
        decoded={r['card_index']:r for r in rows}
        self.assertIsNone(decoded[0]['discount_value'], 'Conflicting readings must not be used for max-discount selection.')
        self.assertEqual(decoded[1]['discount_value'],40)

    def test_detail_validator_requires_active_model_price_discount_and_threshold(self):
        def box(y): return [[600,y-5],[900,y-5],[900,y+5],[600,y+5]]
        detections=[
            (box(38),'Benefactor Sprinter W906',0.99),
            (box(123),'Ціна: $65 000',0.99),
            (box(204),'Добра ціна: -89% до ринку ($16 000)',0.99),
        ]
        def fake_engine(image): return detections,0.001
        class FakeCapture:
            monitors=[{'left':0,'top':0,'width':1920,'height':1080},{'left':0,'top':0,'width':1920,'height':1080}]
            def __enter__(self): return self
            def __exit__(self,*args): return False
            def grab(self,monitor):
                if isinstance(monitor,dict): return np.zeros((int(monitor['height']),int(monitor['width']),4),dtype=np.uint8)
                return np.zeros((1080,1920,4),dtype=np.uint8)
        fake_mss=types.SimpleNamespace(mss=lambda:FakeCapture())
        with patch.dict(sys.modules,{'mss':fake_mss}), patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            result=scanner_core.validate_market_detail_screen(
                ['Benefactor Sprinter W906'],['Benefactor Sprinter W906'],
                {'Benefactor Sprinter W906':{'category':'Звичайне'}},20,{},set(),89,
                target_hwnd=None,confidence_floor=.93)
        self.assertTrue(result['ok'],result['reason'])
        self.assertEqual(result['catalog_model'],'Benefactor Sprinter W906')
        self.assertEqual(result['price_value'],65000)
        self.assertEqual(result['discount_value'],89)
        with patch.dict(sys.modules,{'mss':fake_mss}), patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            rejected=scanner_core.validate_market_detail_screen(
                ['Benefactor Sprinter W906'],[],{'Benefactor Sprinter W906':{'category':'Звичайне'}},20,{},set(),89,
                target_hwnd=None,confidence_floor=.93)
        self.assertFalse(rejected['ok'])
        self.assertIn('активного каталогу',rejected['reason'])


    def test_main_direct_mode_is_wired_end_to_end(self):
        from pathlib import Path
        source=Path('main.py').read_text(encoding='utf-8')
        required=(
            'def _start_direct_green_watch(self):',
            'def _on_green_watch_candidates(self, candidates):',
            'DIRECT GREEN WATCH: картка',
            'def _on_green_badge_results_ready(self, ranked, error, elapsed):',
            "def _launch_direct_green_candidate(self, chosen, ranked_discount=None, selection_note=''):",
            'def _build_direct_detail_validator(self, candidate):',
            'pre_buy_validator=validator',
            "self._start_direct_green_watch()",
        )
        for token in required:
            self.assertIn(token,source, f'Missing DIRECT GREEN WATCH integration: {token}')
        fast_handler=source[source.index('def _on_green_watch_candidates(self, candidates):'):
                            source.index('def _on_green_badge_worker_finished(self):')]
        self.assertIn('if len(green) == 1:', fast_handler,
                      'A single green candidate must keep the immediate-click fast path.')
        self.assertIn('ranked_discount=None', fast_handler,
                      'A single candidate must not wait for badge OCR.')
        self.assertIn('core.GreenBadgeBatchWorker(green)', fast_handler,
                      'Multiple simultaneous green candidates must be ranked by badge OCR.')
        self.assertLess(fast_handler.index('if len(green) == 1:'),
                        fast_handler.index('core.GreenBadgeBatchWorker(green)'))
        toggle=source.index('def toggle_scanning(self):')
        scan_once=source.index('def scan_once(self, hide_window=None):', toggle)
        toggle_block=source[toggle:scan_once]
        self.assertNotIn('self._start_direct_green_watch()', toggle_block,
                         'Auto-buy must not open every green card before checking it.')
        self.assertIn('FAST GRID BUY', toggle_block)
        self.assertIn('self.scan_once(hide_window=None)', toggle_block)

    def test_detail_validator_accepts_authoritative_detail_discount_without_badge_ocr(self):
        def box(y): return [[600,y-5],[900,y-5],[900,y+5],[600,y+5]]
        detections=[
            (box(38),'Benefactor Sprinter W906',0.99),
            (box(123),'Ціна: $65 000',0.99),
            (box(204),'Добра ціна: -89% до ринку ($16 000)',0.99),
        ]
        def fake_engine(image): return detections,0.001
        class FakeCapture:
            monitors=[{'left':0,'top':0,'width':1920,'height':1080},{'left':0,'top':0,'width':1920,'height':1080}]
            def __enter__(self): return self
            def __exit__(self,*args): return False
            def grab(self,monitor):
                if isinstance(monitor,dict): return np.zeros((int(monitor['height']),int(monitor['width']),4),dtype=np.uint8)
                return np.zeros((1080,1920,4),dtype=np.uint8)
        fake_mss=types.SimpleNamespace(mss=lambda:FakeCapture())
        with patch.dict(sys.modules,{'mss':fake_mss}), patch.object(scanner_core,'_get_ocr_engine',return_value=fake_engine):
            result=scanner_core.validate_market_detail_screen(
                ['Benefactor Sprinter W906'],['Benefactor Sprinter W906'],
                {'Benefactor Sprinter W906':{'category':'Звичайне'}},20,{},set(),None,
                target_hwnd=None,confidence_floor=.93)
        self.assertTrue(result['ok'],result['reason'])
        self.assertEqual(result['discount_value'],89)

    def test_click_worker_has_fail_closed_detail_validator_before_buy(self):
        source=Path('scanner_actions.py').read_text(encoding='utf-8')
        validator=source.index('if validation_task is not None:')
        buy=source.index("self.progress.emit(f'STEP 2/3 CLICK: DETAIL_BUY",validator)
        self.assertLess(validator,buy)
        self.assertIn('if not bool(self.validated_details.get(\'ok\')):',source[validator:buy])
        self.assertIn('«Купити» та підтвердження не натискалися',source[validator:buy])

if __name__=='__main__':
    unittest.main()
