import unittest
import numpy as np
from scanner_core_logic import (
    clean_model_text, match_catalog_model, match_informational_model,
    parse_price, format_price, classify_badge_color, resolve_discount,
    build_candidate_status, effective_threshold, group_montage_ocr, changed_card_indices,
)

MODELS = [
    'Penaud Logan', 'Dinka Civic FK2', 'Ubermacht M4 F82',
    'BF Golf VIII', 'BF Golf VII R', 'Benefactor Sprinter W906',
    'Maibatsu Lancer EVO IX', 'Buckingham 429', 'Obey 80 B4',
]

class ScannerLogicTests(unittest.TestCase):
    def test_price_formats(self):
        self.assertEqual(parse_price('$5 008'), 5008)
        self.assertEqual(parse_price('$15 000'), 15000)
        self.assertEqual(parse_price('$4925'), 4925)
        self.assertEqual(parse_price('$1 300 000'), 1300000)
        self.assertEqual(parse_price('$41 000 +17%'), 41000)
        self.assertEqual(resolve_discount('$41 000 +17%', 'RED'), (17, '+17%', 'markup'))
        self.assertEqual(parse_price('$850 ooo'), 850000)
        self.assertEqual(parse_price('no amount'), None)
        self.assertEqual(format_price(850000), '$850 000')

    def test_model_alias_and_mileage_noise(self):
        self.assertEqual(clean_model_text('Penaud Logan O KM'), 'Penaud Logan')
        self.assertEqual(match_catalog_model('Penaud Logan 0 KM', MODELS)[0], 'Penaud Logan')
        self.assertEqual(match_catalog_model('BF Golf Vill 434 km', MODELS)[0], 'BF Golf VIII')
        self.assertIsNone(match_catalog_model('Uncatalogued Model 0 KM', MODELS)[0])
        # The title can be reordered and contaminated by mileage OCR.
        self.assertEqual(match_catalog_model('EVO IX Maibatsu Lancer 8601', MODELS)[0], 'Maibatsu Lancer EVO IX')
        self.assertEqual(match_informational_model('EVO IX Maibatsu Lancer 8601')[0], 'Maibatsu Lancer EVO IX')

    def test_green_is_discount_red_is_markup(self):
        self.assertEqual(resolve_discount('-9%', 'GREEN'), (9, '-9%', 'discount'))
        self.assertEqual(resolve_discount('+254%', 'RED'), (254, '+254%', 'markup'))
        self.assertEqual(resolve_discount('254%', 'RED'), (254, '+254%', 'markup'))
        self.assertEqual(resolve_discount('anything', 'NONE'), (None, '—', 'none'))
        self.assertEqual(resolve_discount('?', 'UNKNOWN'), (None, 'Не визначено', 'unknown'))

    def test_badge_color_masks(self):
        # Use dark badge RGB ranges from ng_discount_ocr.ps1 (input arrays are BGR).
        green = np.zeros((29, 63, 3), dtype=np.uint8)
        green[:] = (25, 48, 25)  # RGB (25,48,25): expected AHK dark green
        red = np.zeros((29, 63, 3), dtype=np.uint8)
        red[:] = (25, 25, 45)    # RGB (45,25,25): expected AHK dark red
        empty = np.zeros((29, 63, 3), dtype=np.uint8)
        noisy = np.zeros((29, 63, 3), dtype=np.uint8)
        noisy[:] = (0, 0, 0)
        noisy[0:4, :, :] = (25, 48, 25)  # color outside central AHK sample must not pass
        self.assertEqual(classify_badge_color(green), 'GREEN')
        self.assertEqual(classify_badge_color(red), 'RED')
        self.assertEqual(classify_badge_color(empty), 'NONE')
        self.assertEqual(classify_badge_color(noisy), 'NONE')

    def test_vectorized_badge_classifier_matches_legacy_sampler(self):
        # Randomized parity guard: optimization must not change any color decision.
        def legacy(crop):
            if crop is None or getattr(crop, 'size', 0) == 0:
                return 'UNKNOWN'
            arr = np.asarray(crop)
            if arr.ndim != 3 or arr.shape[2] < 3:
                return 'UNKNOWN'
            height, width = arr.shape[:2]
            cx, cy = int(width / 2.0 + 0.5), int(height / 2.0 + 0.5)
            green_count = red_count = 0
            for yy in range(max(0, cy - 8), min(height - 1, cy + 8) + 1, 2):
                for xx in range(max(0, cx - 18), min(width - 1, cx + 18) + 1, 2):
                    b, g, r = (int(v) for v in arr[yy, xx, :3])
                    if (30 <= r <= 75 and 12 <= g <= 36 and 12 <= b <= 42
                            and r > g + 6 and r > b + 3):
                        red_count += 1
                    elif (12 <= r <= 42 and 32 <= g <= 68 and 12 <= b <= 42
                            and g > r + 7 and g > b + 6):
                        green_count += 1
            if green_count >= 5 and green_count >= red_count * 1.4:
                return 'GREEN'
            if red_count >= 5 and red_count >= green_count * 1.4:
                return 'RED'
            if green_count == 0 and red_count == 0:
                return 'NONE'
            return 'UNKNOWN'

        rng = np.random.default_rng(721)
        shapes = [(29, 63, 3), (17, 37, 3), (1, 1, 3), (18, 38, 4), (31, 55, 3)]
        for shape in shapes:
            for _ in range(80):
                crop = rng.integers(0, 256, size=shape, dtype=np.uint8)
                self.assertEqual(classify_badge_color(crop), legacy(crop), msg=f'shape={shape}')

    def test_bool_selection_bug_is_fixed_and_fail_closed(self):
        status, eligible = build_candidate_status(
            'Penaud Logan', 'Penaud Logan', 5000, 'GREEN', 50, 50, True, False)
        self.assertTrue(eligible)
        self.assertIn('ВИГІДНА', status)
        status, eligible = build_candidate_status(
            'Penaud Logan', 'Penaud Logan', 5000, 'GREEN', 50, 50, False, False)
        self.assertFalse(eligible)
        self.assertIn('Вимкнено', status)
        status, eligible = build_candidate_status(
            'Penaud Logan', 'Penaud Logan', 5000, 'RED', 99, 20, True, False)
        self.assertFalse(eligible)
        self.assertIn('Націнка', status)
        status, eligible = build_candidate_status(
            'Penaud Logan', 'Penaud Logan', None, 'GREEN', 50, 50, True, False)
        self.assertFalse(eligible)
        self.assertIn('Ціну не прочитано', status)

    def test_threshold_precedence_after_category_or_discount_edit(self):
        # Per-car slider is authoritative after category/global threshold changes.
        self.assertEqual(effective_threshold('Звичайне', 30, 20, 20), 30)
        self.assertEqual(effective_threshold('Пріоритетне', None, 15, 20), 15)
        self.assertEqual(effective_threshold('Спеціальне', None, 50, 20), 50)
        self.assertEqual(effective_threshold('Звичайне', None, 20, 25), 25)
        self.assertTrue(build_candidate_status('Penaud Logan', 'Penaud Logan', 5000, 'GREEN', 30,
                                              effective_threshold('Звичайне', 30, 20, 20), True, False)[1])


    def test_custom_vehicle_can_be_matched_and_use_its_own_discount_threshold(self):
        custom_catalog = ['Maverick Sentinel SX']
        model, confidence = match_catalog_model('Maverick Sentinel SX 553 KM', custom_catalog)
        self.assertEqual(model, 'Maverick Sentinel SX')
        self.assertGreaterEqual(confidence, 0.93)
        threshold = effective_threshold('Звичайне', 35, 20, 20)
        self.assertEqual(threshold, 35)
        status, eligible = build_candidate_status(
            'Maverick Sentinel SX', model, 15500, 'GREEN', 40, threshold, True, False)
        self.assertTrue(eligible)
        self.assertIn('ВИГІДНА', status)
        self.assertFalse(build_candidate_status(
            'Maverick Sentinel SX', model, 15500, 'GREEN', 20, threshold, True, False)[1])

    def test_fast_cache_only_rechecks_changed_or_uncertain_cards(self):
        self.assertEqual(changed_card_indices(['a', 'b', 'c'], ['a', 'old', 'c']), [1])
        self.assertEqual(changed_card_indices(['a', 'b', 'c'], ['a', None, 'c']), [1])
        self.assertEqual(changed_card_indices(['a', 'b'], ['a'], cache_ready=True), [0, 1])
        self.assertEqual(changed_card_indices(['a', 'b'], None, cache_ready=False), [0, 1])

    def test_montage_grouping_keeps_name_price_badge_scores_separate(self):
        def box(x1, y1, x2, y2):
            return [[x1, y1], [x2, y1], [x2, y2], [x1, y2]]
        rows = [
            [box(20, 20, 150, 50), 'Dinka Civic EK6', 0.96],
            [box(230, 20, 310, 50), '$15 499', 0.91],
            [box(430, 20, 485, 50), '-6%', 0.94],
        ]
        grouped = group_montage_ocr(rows, {'row_height': 100, 'name_boundary': 200,
                                           'price_boundary': 400}, count=1)
        self.assertEqual(grouped[0]['name'], 'Dinka Civic EK6')
        self.assertEqual(grouped[0]['price'], '$15 499')
        self.assertEqual(grouped[0]['badge'], '-6%')
        self.assertAlmostEqual(grouped[0]['name_confidence'], 0.96)
        self.assertAlmostEqual(grouped[0]['price_confidence'], 0.91)
        self.assertAlmostEqual(grouped[0]['badge_confidence'], 0.94)

if __name__ == '__main__':
    unittest.main(verbosity=2)
