import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

class UISkinContractTests(unittest.TestCase):
    def test_neon_theme_and_glass_cards_are_present(self):
        qss = (ROOT / 'theme' / 'style.qss').read_text(encoding='utf-8')
        for token in ('QFrame#catalogVehicleCard', 'QFrame#statsMetricCard', 'QPushButton#primary:hover', 'QLabel#vehiclePreview', '#54E5B6'):
            self.assertIn(token, qss)

    def test_application_icon_is_bundled(self):
        self.assertTrue((ROOT / 'assets' / 'ng_market_scanner.ico').is_file())
        self.assertTrue((ROOT / 'assets' / 'ng_market_scanner.png').is_file())
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        self.assertIn("RESOURCE_DIR / 'assets' / 'ng_market_scanner.ico'", main)

if __name__ == '__main__': unittest.main()
