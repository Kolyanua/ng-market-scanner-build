import sys
import types
import unittest
from unittest.mock import patch

import numpy as np
import cv2

# PySide6 is only needed for the application's Qt event loop, not for the
# deterministic pure validation tests. Provide an import-time stub on Linux CI.
try:
    import scanner_core
except ModuleNotFoundError as exc:
    if exc.name != 'PySide6':
        raise
    qtcore = types.ModuleType('PySide6.QtCore')
    class _FakeQThread:
        pass
    qtcore.QThread = _FakeQThread
    qtcore.Signal = lambda *_args, **_kwargs: object()
    pyside = types.ModuleType('PySide6')
    pyside.QtCore = qtcore
    sys.modules['PySide6'] = pyside
    sys.modules['PySide6.QtCore'] = qtcore
    import scanner_core


class FakeMSSCapture:
    def __init__(self):
        self.monitors = [
            {'left': 0, 'top': 0, 'width': 1920, 'height': 1080},
            {'left': 0, 'top': 0, 'width': 1920, 'height': 1080},
        ]

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def grab(self, region):
        return np.zeros((int(region['height']), int(region['width']), 4), dtype=np.uint8)


class FakeDetailOCR:
    def __init__(self, status, price_text='Ціна: $8 500'):
        self.statuses = list(status) if isinstance(status, (list, tuple)) else [status]
        self.price_text = price_text
        self.calls = 0

    @staticmethod
    def item(cx, cy, text, width=300, height=20):
        return ([[cx-width/2, cy-height/2], [cx+width/2, cy-height/2],
                 [cx+width/2, cy+height/2], [cx-width/2, cy+height/2]], text, 0.99)

    def __call__(self, _image):
        status = self.statuses[min(self.calls, len(self.statuses) - 1)]
        self.calls += 1
        return [[
            self.item(210, 38, 'Karin Land Cruiser 100', 350),
            self.item(210, 123, self.price_text, 250),
            self.item(360, 204, status, 650),
        ]]


class DetailDiscountHotfixTests(unittest.TestCase):
    MODEL = 'Karin Land Cruiser 100'

    def test_hotfix_version_marker_is_present(self):
        self.assertEqual(scanner_core.DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION,
                         '1.2.65-retry-confirm-detail-discount')

    def validate(self, status, expected=27, threshold=20, price_text='Ціна: $8 500'):
        capture = FakeMSSCapture()
        fake_mss = types.SimpleNamespace(mss=lambda: capture)
        fake_cv2 = cv2
        engine = FakeDetailOCR(status, price_text=price_text)
        with patch.dict(sys.modules, {'mss': fake_mss, 'cv2': fake_cv2}), \
             patch.object(scanner_core, '_latest_watch_detail_panel', return_value=None), \
             patch.object(scanner_core, '_foreground_matches_target', return_value=True), \
             patch.object(scanner_core, '_get_ocr_engine', return_value=engine):
            result = scanner_core.validate_market_detail_screen(
                all_models=[self.MODEL],
                active_models=[self.MODEL],
                rules={self.MODEL: {'category': 'Звичайне', 'threshold': threshold}},
                global_threshold=threshold,
                model_thresholds={},
                blacklisted_models=set(),
                expected_discount=expected,
            )
        return result

    def test_fuzzy_ocr_word_boundary_and_latin_cyrillic_confusables_are_recognized(self):
        good, bad, normalized = scanner_core._detail_price_label_flags('Стан Хорова ціна: -27% до pинку ($11 651)')
        self.assertTrue(good, normalized)
        self.assertFalse(bad, normalized)
        self.assertIn('до ринку', normalized)

    def test_realistic_ocr_confusables_do_not_block_valid_27_percent_offer(self):
        # OCR misspells "Хороша" and returns Latin p in Ukrainian "ринку".
        result = self.validate('Стан Хорова ціна: -27% до pинку ($11 651)')
        self.assertTrue(result['ok'], result['reason'])
        self.assertTrue(result['eligible'])
        self.assertEqual(result['price_value'], 8500)
        self.assertEqual(result['discount_value'], 27)
        self.assertEqual(result['threshold'], 20)
        self.assertEqual(result['market_reference_price_value'], 11651)
        self.assertEqual(result['calculated_discount_value'], 27)
        self.assertEqual(result['detail_discount_validation_patch'],
                         '1.2.65-retry-confirm-detail-discount')

    def test_market_price_ratio_can_recover_a_missed_percent_ocr(self):
        result = self.validate('Стан Хорова ціна: до pинку ($11 651)', expected=27)
        self.assertTrue(result['ok'], result['reason'])
        self.assertEqual(result['discount_value'], 27)
        self.assertEqual(result['detail_discount_validation_method'], 'арифметична звірка з ринковою ціною')

    def test_card_and_detail_discount_allow_plus_or_minus_two_points(self):
        for badge_discount in (25, 26, 27, 28, 29):
            with self.subTest(badge_discount=badge_discount):
                result = self.validate('Стан Хороша ціна: -27% до ринку ($11 651)', expected=badge_discount)
                self.assertTrue(result['ok'], result['reason'])

    def test_difference_greater_than_two_points_is_retried_and_accepted_only_if_confirmed(self):
        # A repeated detail read that agrees with the independent price ratio may
        # override a stale card badge, but only after a second fresh OCR read.
        for badge_discount in (24, 30):
            with self.subTest(badge_discount=badge_discount):
                result = self.validate('Стан Хороша ціна: -27% до ринку ($11 651)', expected=badge_discount)
                self.assertTrue(result['ok'], result['reason'])
                self.assertTrue(result['detail_retry_attempted'])
                self.assertTrue(result['badge_mismatch_retry_confirmed'])
                self.assertEqual(result['discount_value'], 27)
                self.assertEqual(result['badge_discount_value'], badge_discount)

    def test_card_detail_mismatch_is_rejected_when_second_read_disagrees(self):
        result = self.validate([
            'Стан Хороша ціна: -27% до ринку ($11 651)',
            'Стан Хороша ціна: -17% до ринку ($11 651)',
        ], expected=24)
        self.assertFalse(result['ok'])
        self.assertTrue(result['detail_retry_attempted'])
        self.assertIn('повторне зчитування не підтвердило', result['reason'])

    def test_arithmetic_mismatch_gets_one_retry_before_rejection(self):
        result = self.validate([
            'Стан Хороша ціна: -17% до ринку ($11 651)',
            'Стан Хороша ціна: -27% до ринку ($11 651)',
        ], expected=27)
        self.assertTrue(result['ok'], result['reason'])
        self.assertTrue(result['detail_retry_attempted'])
        self.assertEqual(result['discount_value'], 27)

    def test_reference_price_arithmetic_catches_contradictory_ocr_discount(self):
        # $8,500 vs $11,651 implies ~27%; OCR claiming 17% is inconsistent.
        result = self.validate('Стан Хороша ціна: -17% до ринку ($11 651)', expected=17)
        self.assertFalse(result['ok'])
        self.assertIn('суперечить ціні лота/ринковій ціні', result['reason'])

    def test_corrected_second_read_can_confirm_details_when_first_percent_was_ocr_error(self):
        result = self.validate([
            'Стан Хороша ціна: -17% до ринку ($11 651)',
            'Стан Хороша ціна: -27% до ринку ($11 651)',
        ], expected=24)
        self.assertTrue(result['ok'], result['reason'])
        self.assertTrue(result['detail_retry_attempted'])
        self.assertTrue(result['badge_mismatch_retry_confirmed'])
        self.assertEqual(result['discount_value'], 27)

    def test_explicit_bad_price_label_never_passes(self):
        result = self.validate('Стан Погана ціна: -27% до ринку ($11 651)', expected=27)
        self.assertFalse(result['ok'])
        self.assertIn('невигідну', result['reason'])

    def test_threshold_still_applies_after_ocr_hotfix(self):
        result = self.validate('Стан Хороша ціна: -19% до ринку ($10 494)', expected=19, threshold=20)
        self.assertFalse(result['ok'])
        self.assertIn('нижча за поріг', result['reason'])


if __name__ == '__main__':
    unittest.main(verbosity=2)
