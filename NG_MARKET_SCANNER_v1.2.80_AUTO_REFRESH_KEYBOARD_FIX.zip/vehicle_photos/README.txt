Vehicle photos are downloaded from Wikimedia Commons by tools/download_vehicle_photos.ps1 during clean setup.
