from pathlib import Path
import cv2
import numpy as np

root = Path('/mnt/data/ng_scanner_review/work/NG_MARKET_SCANNER_FINAL_DASHBOARD_v1.2.38/vehicle_renders')
files = sorted(root.glob('*.jpg'))
written = 0
for path in files:
    image = cv2.imread(str(path), cv2.IMREAD_COLOR)
    if image is None:
        print('SKIP unreadable', path.name)
        continue
    h, w = image.shape[:2]
    # These bundled game renders use a near-uniform dark matte. Learn the matte
    # from the border per image, then flood only border-connected pixels similar
    # to it so dark vehicle details enclosed by the silhouette are retained.
    border = np.concatenate((
        image[:4, :, :].reshape(-1, 3), image[-4:, :, :].reshape(-1, 3),
        image[:, :4, :].reshape(-1, 3), image[:, -4:, :].reshape(-1, 3),
    ), axis=0)
    matte = np.median(border.astype(np.float32), axis=0)
    distance = np.linalg.norm(image.astype(np.float32) - matte, axis=2)
    near_matte = (distance < 9.5).astype(np.uint8)
    _, bg_labels, _, _ = cv2.connectedComponentsWithStats(near_matte, connectivity=8)
    border_labels = np.unique(np.concatenate((
        bg_labels[0, :], bg_labels[-1, :], bg_labels[:, 0], bg_labels[:, -1]
    )))
    outside = np.isin(bg_labels, border_labels)
    foreground = (~outside).astype(np.uint8)

    # Remove the heart/favourite overlay present in these source captures. It is
    # always in the upper-right panel corner, separate from the vehicle.
    ui_x = int(w * 0.765)
    ui_y = int(h * 0.305)
    foreground[:ui_y, ui_x:] = 0

    num, labels, stats, centers = cv2.connectedComponentsWithStats(foreground, connectivity=8)
    if num <= 1:
        print('SKIP no foreground', path.name)
        continue
    component_areas = stats[1:, cv2.CC_STAT_AREA]
    main_label = int(np.argmax(component_areas)) + 1
    main_area = int(stats[main_label, cv2.CC_STAT_AREA])
    x, y, bw, bh, _ = stats[main_label]
    # Keep the main vehicle, plus substantial detached pieces (e.g. truck wheels
    # and shadows) that touch or sit close to its silhouette. Drop tiny JPEG specks.
    expand = max(14, int(max(bw, bh) * 0.06))
    x0, y0 = max(0, x - expand), max(0, y - expand)
    x1, y1 = min(w, x + bw + expand), min(h, y + bh + expand)
    keep = np.zeros((h, w), dtype=np.uint8)
    keep[labels == main_label] = 255
    for label in range(1, num):
        if label == main_label:
            continue
        area = int(stats[label, cv2.CC_STAT_AREA])
        if area < max(28, int(main_area * 0.004)):
            continue
        cx, cy = centers[label]
        # A detached component is plausible car/shadow detail if it is within
        # the expanded main-car bounds. The top-right HUD is already removed.
        if x0 <= cx < x1 and y0 <= cy < y1:
            keep[labels == label] = 255

    # Include the matte-derived pixels enclosed by the silhouette, then retain
    # connected enclosed dark regions. Avoid a hard crop around the full capture.
    roi = keep > 0
    if not np.any(roi):
        print('SKIP empty mask', path.name)
        continue
    # Slight softening anti-aliases the cut edge without inventing object detail.
    alpha = cv2.GaussianBlur(keep, (3, 3), 0.55)
    yy, xx = np.where(alpha > 3)
    pad = 7
    cx0, cy0 = max(0, int(xx.min()) - pad), max(0, int(yy.min()) - pad)
    cx1, cy1 = min(w, int(xx.max()) + 1 + pad), min(h, int(yy.max()) + 1 + pad)
    crop = image[cy0:cy1, cx0:cx1]
    crop_alpha = alpha[cy0:cy1, cx0:cx1]
    rgba = cv2.cvtColor(crop, cv2.COLOR_BGR2BGRA)
    rgba[:, :, 3] = crop_alpha
    out = path.with_suffix('.png')
    if not cv2.imwrite(str(out), rgba, [cv2.IMWRITE_PNG_COMPRESSION, 7]):
        print('SKIP failed write', path.name)
        continue
    written += 1
print(f'Converted {written}/{len(files)} game renders to transparent RGBA PNG cutouts; original JPGs preserved as fallbacks.')
