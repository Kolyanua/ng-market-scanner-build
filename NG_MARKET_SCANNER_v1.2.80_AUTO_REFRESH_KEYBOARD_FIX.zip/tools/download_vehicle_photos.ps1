$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$outDir = Join-Path $root 'vehicle_photos'
New-Item -ItemType Directory -Force -Path $outDir | Out-Null
$headers = @{ 'User-Agent' = 'NG-Market-Scanner/1.2.38 (desktop UI asset downloader)' }

# Freely licensed real-world car photos from Wikimedia Commons.
# File title, author, source URL and license are also recorded in REAL_CAR_PHOTO_CREDITS_UA.txt.
$assets = @(
    @{ Name='Dinka_Civic_EK6.jpg'; Title='Honda Civic EK hatch (20221211).jpg' },
    @{ Name='Ubermacht_M4_F82.jpg'; Title='BMW M4 Coupé (F82) front.JPG' },
    @{ Name='Ubermacht_M4_G82.jpg'; Title='BMW M4 2021.jpg' },
    @{ Name='Benefactor_CLS_Class_C257.jpg'; Title='Mercedes-Benz C 257 CLS220 IAA 2019 JM 0283.jpg' },
    @{ Name='Maibatsu_Lancer_EVO_IX.jpg'; Title='Lancer Evo IX.jpg' },
    @{ Name='Coil_Model_3.jpg'; Title='Tesla Model 3.jpg' },
    @{ Name='Obey_A8_D5.jpg'; Title='Audi A8 D5 black (1).jpg' },
    @{ Name='Bravado_Charger_Redeye.jpg'; Title='22 Dodge Charger SRT Hellcat Redeye Jailbreak Widebody.jpg' },
    @{ Name='Progen_Senna.jpg'; Title='McLaren Senna.jpg' },
    @{ Name='Ubermacht_M5_F10.jpg'; Title='BMW M5 F10.jpg' },
    @{ Name='BF_Golf_VIII.jpg'; Title='Volkswagen Golf VIII IMG 3135.jpg' },
    @{ Name='Vapid_Mustang_GT_S550.jpg'; Title='2015 Ford Mustang.jpg' }
)

$ok = 0; $failed = 0
foreach ($asset in $assets) {
    $target = Join-Path $outDir $asset.Name
    if ((Test-Path $target) -and (Get-Item $target).Length -gt 4096) {
        Write-Host "[OK] exists: $($asset.Name)"
        $ok++
        continue
    }
    $tmp = Join-Path $env:TEMP ('ng-photo-' + [Guid]::NewGuid().ToString('N') + '.bin')
    try {
        $escaped = [Uri]::EscapeDataString($asset.Title)
        $uri = "https://commons.wikimedia.org/wiki/Special:FilePath/$escaped?width=1280"
        Invoke-WebRequest -Uri $uri -Headers $headers -OutFile $tmp -TimeoutSec 30 -MaximumRedirection 10 -UseBasicParsing
        if (-not (Test-Path $tmp) -or (Get-Item $tmp).Length -lt 4096) { throw 'Downloaded file is too small.' }
        Add-Type -AssemblyName System.Drawing
        $source = [System.Drawing.Image]::FromFile($tmp)
        try {
            if ($source.Width -lt 180 -or $source.Height -lt 100) { throw "Unexpected image dimensions: $($source.Width)x$($source.Height)" }
            $scale = [Math]::Min(1.0, 1400.0 / [double]$source.Width)
            $width = [Math]::Max(1, [int][Math]::Round($source.Width * $scale))
            $height = [Math]::Max(1, [int][Math]::Round($source.Height * $scale))
            $bitmap = New-Object System.Drawing.Bitmap($width, $height)
            try {
                $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
                try {
                    $graphics.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
                    $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::HighQuality
                    $graphics.DrawImage($source, 0, 0, $width, $height)
                } finally { $graphics.Dispose() }
                $bitmap.Save($target, [System.Drawing.Imaging.ImageFormat]::Jpeg)
            } finally { $bitmap.Dispose() }
        } finally { $source.Dispose() }
        if ((Get-Item $target).Length -lt 4096) { throw 'Converted JPEG is too small.' }
        Write-Host "[OK] downloaded: $($asset.Name)"
        $ok++
    } catch {
        Write-Warning "Photo download failed for $($asset.Name): $($_.Exception.Message)"
        if (Test-Path $target) { Remove-Item $target -Force -ErrorAction SilentlyContinue }
        $failed++
    } finally {
        if (Test-Path $tmp) { Remove-Item $tmp -Force -ErrorAction SilentlyContinue }
    }
}
Write-Host "Photo asset result: $ok available, $failed not downloaded. The application will label and use local render fallbacks for missing photos."
if ($ok -eq 0) { exit 1 }
exit 0
