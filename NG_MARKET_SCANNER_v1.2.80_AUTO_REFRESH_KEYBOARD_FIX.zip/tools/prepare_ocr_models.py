"""Download and warm the exact OCR models before building the single-file EXE.

Run only in the Windows build virtual environment. This stops the build if the OCR
engine cannot initialize or if its ONNX model weights are not present for bundling.
"""
from pathlib import Path
import sys

# When Python executes a file under tools\, sys.path[0] is the tools folder,
# not the project root. Add the project root explicitly so scanner_core.py and
# scanner_core_logic.py are importable in a clean Windows build.
PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

import cv2
import numpy as np
import rapidocr
import scanner_core

worker = scanner_core.OCRWarmupWorker()
worker.run()  # synchronous warm-up; it also exercises the CPU fallback if DirectML fails.

if scanner_core._OCR_ENGINE is None:
    print("[ERROR] OCR model warm-up did not create an engine.")
    print("[ERROR] Last initialization errors:", scanner_core._OCR_LAST_INIT_ERRORS)
    raise SystemExit(2)

# Verify a real inference call independently of signal delivery semantics.
sample = np.full((96, 420, 3), (15, 19, 22), dtype=np.uint8)
cv2.putText(sample, "Dinka Civic EK6  -20%", (8, 56), cv2.FONT_HERSHEY_SIMPLEX,
            0.75, (240, 240, 240), 2, cv2.LINE_AA)
try:
    scanner_core._OCR_ENGINE(sample)
except Exception as exc:
    print(f"[ERROR] OCR engine failed its packaging smoke test: {type(exc).__name__}: {exc}")
    raise SystemExit(2)

package_root = Path(rapidocr.__file__).resolve().parent
model_root = package_root / "models"
models = sorted(p for p in model_root.rglob("*") if p.is_file() and p.suffix.lower() in {".onnx", ".onnx_data"}) if model_root.is_dir() else []
large_models = [p for p in models if p.stat().st_size >= 100_000]
print("OCR warm-up: successful")
print("RapidOCR package:", package_root)
print("Bundlable model files:", len(large_models))
for path in large_models:
    print(f"  {path.name}: {path.stat().st_size} bytes")

# The current fast path needs detector and recognizer weights at minimum.
if len(large_models) < 2:
    print("[ERROR] Expected detector and recognizer ONNX weights were not found inside rapidocr/models.")
    print("[ERROR] Refusing to build an EXE that might download models on the friend's first launch.")
    raise SystemExit(3)

print("[OK] OCR model weights are pre-downloaded and ready for PyInstaller --collect-all rapidocr.")
