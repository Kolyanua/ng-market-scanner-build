"""Measure screen-capture latency on this Windows PC without changing app settings.

Run from the extracted build kit while the GTA/market window is visible:
    py tools\\benchmark_capture_backends.py --seconds 3 --fps 120

Tests DXcam DXGI and WinRT with BGRA vs BGR output (if installed/supported), plus an MSS ROI fallback.
Only use the report to compare this PC; it never modifies the scanner configuration.
"""
from __future__ import annotations

import argparse
import math
import statistics
import sys
import time
from typing import Iterable


def percentile(values: Iterable[float], pct: float) -> float | None:
    data = sorted(float(v) for v in values if math.isfinite(float(v)))
    if not data:
        return None
    index = max(0, min(len(data) - 1, round((len(data) - 1) * pct / 100.0)))
    return data[index]


def fmt(value: float | None) -> str:
    return "n/a" if value is None else f"{value:.3f}"


def region_for(width: int, height: int) -> tuple[int, int, int, int]:
    # Mirror GreenBadgeWatcher: grid plus a small safety margin, not full-screen capture.
    left = max(0, int(.153 * width) - int(.02 * width))
    top = max(0, int(.095 * height) - int(.02 * height))
    right = min(width, int(.985 * width) + int(.02 * width))
    bottom = min(height, int(.895 * height) + int(.02 * height))
    return left, top, right, bottom


def bench_dxcam(backend: str, color_mode: str, seconds: float, fps: int) -> dict:
    import dxcam
    import numpy as np

    camera = None
    try:
        camera = dxcam.create(
            output_idx=0,
            output_color=color_mode,
            backend=backend,
            max_buffer_len=2,
        )
        width, height = int(camera.width), int(camera.height)
        region = region_for(width, height)
        camera.start(region=region, target_fps=fps, video_mode=False)
        wall_start = time.perf_counter()
        cpu_start = time.process_time()
        deadline = wall_start + seconds
        last_timestamp = None
        intervals_ms: list[float] = []
        calls_ms: list[float] = []
        stable_bgr_copy_ms: list[float] = []
        unique_frames = 0
        duplicates = 0
        read_errors = 0
        while time.perf_counter() < deadline:
            call_start = time.perf_counter()
            try:
                output = camera.get_latest_frame(copy=False, with_timestamp=True)
            except TypeError:
                output = camera.get_latest_frame(with_timestamp=True)
            calls_ms.append((time.perf_counter() - call_start) * 1000.0)
            if isinstance(output, tuple) and len(output) == 2:
                frame, timestamp = output
            else:
                frame, timestamp = output, None
            if frame is None:
                read_errors += 1
                time.sleep(.0005)
                continue
            copy_start = time.perf_counter()
            try:
                _stable_bgr = np.asarray(frame)[:, :, :3].copy()
                stable_bgr_copy_ms.append((time.perf_counter() - copy_start) * 1000.0)
            except Exception:
                read_errors += 1
                time.sleep(.0005)
                continue
            copy_start = time.perf_counter()
            try:
                _stable_bgr = np.asarray(frame)[:, :, :3].copy()
                stable_bgr_copy_ms.append((time.perf_counter() - copy_start) * 1000.0)
            except Exception:
                read_errors += 1
                time.sleep(.0005)
                continue
            if timestamp is None:
                # Older versions cannot reliably distinguish a new presentation from
                # a repeated latest-buffer frame, so don't claim a unique-frame rate.
                time.sleep(.0005)
                continue
            try:
                timestamp = float(timestamp)
            except (TypeError, ValueError):
                read_errors += 1
                time.sleep(.0005)
                continue
            if last_timestamp is not None:
                if timestamp == last_timestamp:
                    duplicates += 1
                    time.sleep(.0005)
                    continue
                interval = (timestamp - last_timestamp) * 1000.0
                if interval > 0:
                    intervals_ms.append(interval)
            last_timestamp = timestamp
            unique_frames += 1
            time.sleep(.0005)
        wall = time.perf_counter() - wall_start
        cpu = time.process_time() - cpu_start
        return {
            "backend": f"{backend.upper()} / {color_mode}", "status": "OK", "region": region,
            "wall_seconds": wall, "cpu_percent": cpu / max(wall, .001) * 100.0,
            "unique_frames": unique_frames, "unique_fps": unique_frames / max(wall, .001),
            "duplicates": duplicates, "read_errors": read_errors,
            "frame_p50_ms": percentile(intervals_ms, 50),
            "frame_p95_ms": percentile(intervals_ms, 95),
            "call_p50_ms": percentile(calls_ms, 50),
            "call_p95_ms": percentile(calls_ms, 95),
            "stable_bgr_copy_p50_ms": percentile(stable_bgr_copy_ms, 50),
            "stable_bgr_copy_p95_ms": percentile(stable_bgr_copy_ms, 95),
        }
    except Exception as exc:
        return {"backend": backend.upper(), "status": f"SKIPPED: {type(exc).__name__}: {exc}"}
    finally:
        if camera is not None:
            try:
                camera.stop()
            except Exception:
                pass
            try:
                camera.release()
            except Exception:
                pass


def bench_mss(seconds: float) -> dict:
    try:
        import mss
        import numpy as np

        with mss.mss() as capture:
            monitor = capture.monitors[1] if len(capture.monitors) > 1 else capture.monitors[0]
            width, height = int(monitor["width"]), int(monitor["height"])
            x0, y0, x1, y1 = region_for(width, height)
            region = {
                "left": int(monitor.get("left", 0)) + x0,
                "top": int(monitor.get("top", 0)) + y0,
                "width": x1 - x0,
                "height": y1 - y0,
            }
            call_ms: list[float] = []
            wall_start = time.perf_counter()
            cpu_start = time.process_time()
            deadline = wall_start + seconds
            grabs = 0
            while time.perf_counter() < deadline:
                start = time.perf_counter()
                raw = np.asarray(capture.grab(region))
                if raw.size:
                    grabs += 1
                call_ms.append((time.perf_counter() - start) * 1000.0)
            wall = time.perf_counter() - wall_start
            cpu = time.process_time() - cpu_start
            return {
                "backend": "MSS ROI", "status": "OK", "region": (x0, y0, x1, y1),
                "wall_seconds": wall, "cpu_percent": cpu / max(wall, .001) * 100.0,
                "grabs": grabs, "grabs_per_second": grabs / max(wall, .001),
                "call_p50_ms": percentile(call_ms, 50),
                "call_p95_ms": percentile(call_ms, 95),
            }
    except Exception as exc:
        return {"backend": "MSS ROI", "status": f"SKIPPED: {type(exc).__name__}: {exc}"}


def main() -> int:
    parser = argparse.ArgumentParser(description="Benchmark DXcam DXGI/WinRT with BGRA vs BGR plus MSS ROI capture.")
    parser.add_argument("--seconds", type=float, default=3.0, help="Seconds per backend (default: 3).")
    parser.add_argument("--fps", type=int, default=120, help="DXcam target FPS (default: 120; >120 is resource-heavy).")
    args = parser.parse_args()
    seconds = max(1.0, min(10.0, float(args.seconds)))
    fps = max(30, min(120, int(args.fps)))

    if sys.platform != "win32":
        print("ПОМИЛКА: цей діагностичний тест призначений для Windows 10/11.")
        return 2

    print("NG Market Scanner — capture latency benchmark")
    print(f"Duration/backend: {seconds:.1f}s · target_fps: {fps} · region: market grid ROI")
    print("Залиш гру/ринок на передньому плані. Тест не клікає, не купує й не змінює налаштування.\n")

    results = []
    for backend in ("dxgi", "winrt"):
        for color_mode in ("BGRA", "BGR"):
            result = bench_dxcam(backend, color_mode, seconds, fps)
            results.append(result)
            print_result(result)
    mss_result = bench_mss(seconds)
    results.append(mss_result)
    print_result(mss_result)

    valid = [r for r in results if r.get("status") == "OK" and r.get("frame_p50_ms") is not None]
    if len(valid) >= 2:
        best = min(valid, key=lambda r: (r["frame_p50_ms"], r.get("frame_p95_ms") or float("inf")))
        print(f"\nНайменший median-інтервал нових кадрів у цьому запуску: {best['backend']} ({best['frame_p50_ms']:.3f} ms).")
        print("Змінювати робочий backend варто лише якщо перевага повторюється в кількох запусках і без помилок.")
    print("MSS показує час захоплення ROI, DXcam — інтервал нових кадрів і час читання буфера; це різні метрики, не порівнюй їх як одну величину.")
    print("\nЦе локальний мікробенчмарк, а не гарантія часу покупки або серверної відповіді гри.")
    return 0


def print_result(result: dict) -> None:
    print(f"[{result.get('backend')}] {result.get('status')}")
    if result.get("status") != "OK":
        return
    if "frame_p50_ms" in result:
        print(
            f"  unique frames: {result['unique_frames']} ({result['unique_fps']:.1f} FPS), "
            f"duplicate polls: {result['duplicates']}, read errors: {result['read_errors']}"
        )
        print(f"  new-frame interval p50/p95: {fmt(result['frame_p50_ms'])}/{fmt(result['frame_p95_ms'])} ms")
    else:
        print(f"  successful ROI grabs: {result['grabs']} ({result['grabs_per_second']:.1f}/s)")
    print(f"  capture call p50/p95: {fmt(result.get('call_p50_ms'))}/{fmt(result.get('call_p95_ms'))} ms")
    print(f"  process CPU estimate: {result['cpu_percent']:.1f}% · region: {result['region']}")


if __name__ == "__main__":
    raise SystemExit(main())
