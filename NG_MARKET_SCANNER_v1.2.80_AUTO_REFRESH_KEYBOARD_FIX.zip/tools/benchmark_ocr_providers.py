"""Benchmark RapidOCR provider choices using the same scanner parameters.

Run with the app closed after the build kit has prepared the OCR models:
    py tools\\benchmark_ocr_providers.py --repeats 8

This uses synthetic images with the app's fixed detail-panel and badge-montage sizes.
It compares inference latency only; it does not alter the scanner's provider settings.
"""
from __future__ import annotations

import argparse
import gc
import math
import statistics
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))


def percentile(values, pct):
    data = sorted(float(v) for v in values if math.isfinite(float(v)))
    if not data:
        return None
    index = max(0, min(len(data) - 1, round((len(data) - 1) * pct / 100.0)))
    return data[index]


def image_samples(cv2, np):
    detail = np.full((346, 1152, 3), (15, 19, 22), dtype=np.uint8)
    cv2.putText(detail, "Dinka Civic EK6", (18, 58), cv2.FONT_HERSHEY_SIMPLEX,
                .85, (240, 240, 240), 2, cv2.LINE_AA)
    cv2.putText(detail, "Price: $65 000", (18, 180), cv2.FONT_HERSHEY_SIMPLEX,
                .8, (240, 240, 240), 2, cv2.LINE_AA)
    cv2.putText(detail, "Good price: -89%", (18, 284), cv2.FONT_HERSHEY_SIMPLEX,
                .8, (75, 240, 130), 2, cv2.LINE_AA)

    badges = np.full((80, 510, 3), 255, dtype=np.uint8)
    for x, label in ((10, "-45%"), (180, "-69%"), (350, "-89%")):
        cv2.putText(badges, label, (x, 52), cv2.FONT_HERSHEY_SIMPLEX,
                    .95, (40, 175, 45), 2, cv2.LINE_AA)
    return (("detail_1152x346", detail), ("badge_montage_510x80", badges))



def known_roi_batches(cv2, np, samples):
    """Return known line crops from the same synthetic market samples for a fair local comparison."""
    result = []
    for sample_name, image in samples:
        if sample_name == "detail_1152x346":
            crops = [image[20:100, :], image[130:210, :], image[220:310, :]]
            fields = ["detail", "detail", "detail"]
            result.append(("known_roi_rec_only_detail_3lines", crops, fields))
        elif sample_name == "badge_montage_510x80":
            crops = [image[:, 0:165], image[:, 172:337], image[:, 344:509]]
            fields = ["badge", "badge", "badge"]
            result.append(("known_roi_rec_only_badges_3", crops, fields))
    return result

def provider_configs(scanner_core, available):
    # Use the same parameter factory and type conversion as the production scanner.
    configs = []
    for label, params in scanner_core._engine_config_attempts(available):
        if label in ("cuda-fast", "directml-fast", "fast-cpu-fallback", "common-fast-cpu"):
            configs.append((label, dict(params)))
    return configs


def run_config(label, params, cv2, np, samples, repeats, scanner_core):
    from rapidocr import RapidOCR

    started = time.perf_counter()
    active = []
    try:
        engine = scanner_core._RapidOCRAdapter(
            RapidOCR(params=scanner_core._rapidocr_typed_params(params))
        )
        active = scanner_core._active_engine_providers(engine)
        init_ms = (time.perf_counter() - started) * 1000.0
        result = {"label": label, "active": active, "init_ms": init_ms, "measurements": {}}
        for sample_name, image in samples:
            # Warm both detector and recognizer on the exact shapes before timing.
            engine(image)
            engine(image)
            elapsed_ms = []
            for _ in range(repeats):
                t0 = time.perf_counter()
                rows, _engine_elapsed = engine(image)
                elapsed_ms.append((time.perf_counter() - t0) * 1000.0)
                if rows is None:
                    raise RuntimeError("OCR adapter returned None instead of a row list")
            result["measurements"][sample_name] = {
                "p50_ms": percentile(elapsed_ms, 50),
                "p95_ms": percentile(elapsed_ms, 95),
                "mean_ms": statistics.fmean(elapsed_ms),
                "runs": len(elapsed_ms),
            }
        # A direct line-recognition batch bypasses detector/classifier stages only because
        # these crops are already localized. Measure it with the same engine/provider.
        known_roi = getattr(engine, "recognize_crops", None)
        if callable(known_roi):
            for direct_name, crops, fields in known_roi_batches(cv2, np, samples):
                # Use production crop normalization so the benchmark has representative shapes.
                prepared = [scanner_core._prepare_known_text_crop(c, fields[i], 48) for i, c in enumerate(crops)]
                prepared = [c for c in prepared if c is not None and getattr(c, "size", 0)]
                if len(prepared) != len(crops):
                    result["measurements"][direct_name] = {"skipped": "crop preparation failed"}
                    continue
                known_roi(prepared)  # warmup
                known_roi(prepared)
                direct_times = []
                for _ in range(repeats):
                    t0 = time.perf_counter()
                    decoded, _elapsed = known_roi(prepared)
                    direct_times.append((time.perf_counter() - t0) * 1000.0)
                    if decoded is None or len(decoded) != len(prepared):
                        raise RuntimeError("recognition-only crop batch was unavailable or incomplete")
                result["measurements"][direct_name] = {
                    "p50_ms": percentile(direct_times, 50),
                    "p95_ms": percentile(direct_times, 95),
                    "mean_ms": statistics.fmean(direct_times),
                    "runs": len(direct_times),
                }
        result["status"] = "OK"
        return result
    except Exception as exc:
        return {"label": label, "active": active, "status": f"SKIPPED: {type(exc).__name__}: {exc}"}
    finally:
        try:
            del engine
        except UnboundLocalError:
            pass
        gc.collect()


def main():
    parser = argparse.ArgumentParser(description="Benchmark RapidOCR CUDA/DirectML/CPU configs locally.")
    parser.add_argument("--repeats", type=int, default=8, help="Measured runs per image shape (default: 8).")
    args = parser.parse_args()
    repeats = max(3, min(20, int(args.repeats)))
    if sys.platform != "win32":
        print("ПОМИЛКА: порівняння OCR provider призначене для Windows build environment.")
        return 2

    import cv2
    import numpy as np
    import onnxruntime as ort
    import scanner_core

    available = ort.get_available_providers()
    samples = image_samples(cv2, np)
    print("NG Market Scanner — OCR provider latency benchmark")
    print("Available ONNX Runtime providers:", ", ".join(available))
    print(f"Measured runs/provider/shape: {repeats}; warmup: 2 calls per shape.")
    print("Закрий сам сканер перед тестом. Зображення синтетичні; тест не змінює налаштування й нічого не купує.\n")
    print("Додатково вимірюється recognition-only batch на вже відомих текстових crop-ах; це інференс без detector/classifier, а не повний час покупки.\n")

    results = []
    for label, params in provider_configs(scanner_core, available):
        print(f"[{label}] initializing…", flush=True)
        result = run_config(label, params, cv2, np, samples, repeats, scanner_core)
        results.append(result)
        print(f"  status: {result['status']} · active: {', '.join(result.get('active') or []) or 'not reported'}")
        for sample_name, metrics in result.get("measurements", {}).items():
            print(f"  {sample_name}: p50={metrics['p50_ms']:.2f} ms · p95={metrics['p95_ms']:.2f} ms · mean={metrics['mean_ms']:.2f} ms")
        print()
        time.sleep(.2)

    for metric_name, label_ua in (
        ("detail_1152x346", "повний detector OCR для detail-панелі"),
        ("known_roi_rec_only_detail_3lines", "recognition-only batch для 3 рядків деталей"),
        ("known_roi_rec_only_badges_3", "recognition-only batch для 3 бейджів"),
    ):
        valid = [r for r in results if r.get("status") == "OK"
                 and isinstance(r.get("measurements", {}).get(metric_name), dict)
                 and r["measurements"][metric_name].get("p50_ms") is not None]
        if valid:
            best = min(valid, key=lambda r: r["measurements"][metric_name]["p50_ms"])
            metric = best["measurements"][metric_name]
            print(f"Найшвидший виміряний шлях ({label_ua}): {best['label']} — p50 {metric['p50_ms']:.2f} ms, p95 {metric['p95_ms']:.2f} ms.")
        else:
            print(f"Немає валідного виміру для '{label_ua}'. Перевір SKIPPED/помилки вище.")
    print("Перевір також правильність розпізнавання; найнижчий median сам по собі не гарантує кращої якості.")
    print("\nЦі результати вимірюють локальний OCR інференс на синтетичних зображеннях, а не весь час покупки у GTA RP.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
