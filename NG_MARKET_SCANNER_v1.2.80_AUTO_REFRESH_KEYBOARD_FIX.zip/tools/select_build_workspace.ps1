$ErrorActionPreference = 'SilentlyContinue'
$minimumFreeBytes = 10GB
$fixedDisks = @()
try {
    $fixedDisks = @(Get-CimInstance -ClassName Win32_LogicalDisk -Filter 'DriveType=3' |
        Where-Object { $_.FreeSpace -ge $minimumFreeBytes } |
        Sort-Object -Property FreeSpace -Descending)
} catch {
    $fixedDisks = @()
}

foreach ($disk in $fixedDisks) {
    $workRoot = Join-Path $disk.DeviceID 'NGMS_Build'
    $probe = $null
    try {
        New-Item -ItemType Directory -Path $workRoot -Force | Out-Null
        $probe = Join-Path $workRoot ('.write_' + [guid]::NewGuid().ToString('N'))
        [IO.File]::WriteAllText($probe, 'ok')
        Remove-Item -LiteralPath $probe -Force
        [Console]::WriteLine((Join-Path $workRoot 'NGMS1274_FinalFastOCR_Source'))
        exit 0
    } catch {
        if ($probe -and (Test-Path -LiteralPath $probe)) {
            Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
        }
    }
}

[Console]::WriteLine('NGMS_NO_SPACE')
exit 41
