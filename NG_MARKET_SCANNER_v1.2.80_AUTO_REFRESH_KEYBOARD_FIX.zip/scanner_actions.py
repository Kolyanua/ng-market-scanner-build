"""Fast, adaptive Windows click workflow for NG Market Scanner.

The OCR layer must mark an in-catalog listing eligible before this worker is started.
Clicks use calibrated 1920x1080 coordinates. The worker polls for the green purchase CTA; when it appears, Windows receives mouse-down and mouse-up in one SendInput batch without a deliberate hold sleep. A temporary 1 ms timer resolution helps polling, but Windows/game/server latency cannot be guaranteed at exactly 1 ms.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Optional, Tuple

from PySide6.QtCore import QThread, Signal

CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"
CLICK_LATENCY_PATCH_VERSION = "1.2.65-fast-coalesce-compact-detail-ocr"
CLICK_BUTTON_PROBE_PATCH_VERSION = "1.2.65.1-2k-offtext-probes"
CLICK_MARKET_RETURN_PATCH_VERSION = "1.2.66-return-market-recover"
CLICK_RELEASE_PATCH_VERSION = "1.2.67-persistent-dxcam-market-roi"
CLICK_DYNAMIC_CONFIRM_PATCH_VERSION = "1.2.70-dynamic-cta-and-lot-not-found-guard"
FAST_COORDINATE_FLOW_VERSION = "1.2.71-fixed-coordinate-fast-chain-no-postcheck"
CLICK_WAIT_TIMER_PATCH_VERSION = "1.2.75-cancellable-highres-wait"
FAST_COORDINATE_HOVER_MS = 10
FAST_COORDINATE_GAP_MS = 50
FAST_COORDINATE_TARGET_MS = 250

REFERENCE_WIDTH = 1920
REFERENCE_HEIGHT = 1080
# Calibrated from the user's market screenshots (1650x926 display capture),
# scaled to the required 1920x1080 reference screen. These points are the centers
# of the green detail-page Buy button and the final confirmation button.
DETAIL_BUY = (1484, 1005)
FINAL_CONFIRM = (1070, 717)
BACK_MARKET = (320, 42)

# Maximum safety timeouts only. The worker polls the calibrated button's green surface
# and clicks immediately after it appears, instead of always burning 850/700 ms.
DETAIL_TRANSITION_MS = 1400
CONFIRM_TRANSITION_MS = 1400
DETAIL_OCR_START_DELAY_MS = 220
BUTTON_POLL_INTERVAL_MS = 1


def _looks_like_green_button(colorref: int) -> bool:
    """Recognize the mint-green purchase CTA used by the supplied NG market UI."""
    if colorref == 0xFFFFFFFF or colorref < 0:
        return False
    red = colorref & 0xFF
    green = (colorref >> 8) & 0xFF
    blue = (colorref >> 16) & 0xFF
    return green >= 150 and red <= 110 and blue >= 80 and green > red * 1.45 and green > blue * 1.06


def scale_reference_point(point: Tuple[int, int], screen_size: Tuple[int, int]) -> Tuple[int, int]:
    width, height = int(screen_size[0]), int(screen_size[1])
    if width <= 0 or height <= 0:
        raise ValueError("Не вдалося визначити роздільну здатність монітора.")
    if abs((width / height) - (16 / 9)) > 0.035:
        raise ValueError("Автоклік дозволено лише для співвідношення сторін 16:9. Налаштуй роздільну здатність або вимкни автоклік.")
    return round(point[0] * width / REFERENCE_WIDTH), round(point[1] * height / REFERENCE_HEIGHT)


def button_probe_offsets(screen_size: Tuple[int, int], button_kind: str = 'confirm'):
    """Screen-scaled test points intentionally sample green button background, not white label glyphs.

    The compact detail-page Buy CTA and the wide final-confirm modal have different widths.
    The previous shared ±22/±8 offsets landed on the button text; at 2K the confirm label is
    large enough that several probes can hit white glyphs, causing a valid button to time out.
    """
    width, height = int(screen_size[0]), int(screen_size[1])
    if width <= 0 or height <= 0:
        raise ValueError('Не вдалося визначити роздільну здатність для перевірки кнопки.')
    kind = str(button_kind or 'confirm').casefold()
    if kind in {'detail_buy', 'detail-buy', 'buy', 'compact'}:
        ref_x, ref_y = 38, 15
    else:
        ref_x, ref_y = 108, 17
    dx = max(1, round(ref_x * width / REFERENCE_WIDTH))
    dy = max(1, round(ref_y * height / REFERENCE_HEIGHT))
    return ((-dx, -dy), (dx, -dy), (-dx, dy), (dx, dy), (-dx, 0), (dx, 0))


def locate_green_button_center_bgr(frame_bgr, region_left, region_top, expected_center,
                                   screen_size, button_kind='confirm'):
    """Locate a mint-green CTA near its calibrated point in a captured BGR ROI.

    The fixed probe remains the fastest path. This helper is a fallback for modal
    banners such as "Лот не знайдено", which can move the confirm button vertically.
    It only returns a center if a button-shaped green component is found close to the
    expected location; otherwise it fails closed and the caller must not click blindly.
    """
    try:
        import cv2
        import numpy as np
        if frame_bgr is None or getattr(frame_bgr, 'size', 0) == 0:
            return None
        image = np.asarray(frame_bgr)
        if image.ndim != 3 or image.shape[2] < 3:
            return None
        bgr = np.ascontiguousarray(image[:, :, :3])
        h, w = bgr.shape[:2]
        sx = max(0.1, float(screen_size[0]) / REFERENCE_WIDTH)
        sy = max(0.1, float(screen_size[1]) / REFERENCE_HEIGHT)
        kind = str(button_kind or 'confirm').casefold()
        if kind in {'detail_buy', 'detail-buy', 'buy', 'compact'}:
            min_width = max(36, int(round(42 * sx)))
            min_height = max(12, int(round(12 * sy)))
            max_dx = int(round(100 * sx))
            min_dy = int(round(-45 * sy))
            max_dy = int(round(55 * sy))
            close_w = max(5, int(round(48 * sx)))
        else:
            min_width = max(100, int(round(105 * sx)))
            min_height = max(16, int(round(19 * sy)))
            max_dx = int(round(150 * sx))
            min_dy = int(round(-55 * sy))
            max_dy = int(round(105 * sy))
            close_w = max(7, int(round(170 * sx)))
        blue = bgr[:, :, 0].astype('int16')
        green = bgr[:, :, 1].astype('int16')
        red = bgr[:, :, 2].astype('int16')
        mask = ((green >= 150) & (red <= 110) & (blue >= 80)
                & (green > red * 1.45) & (green > blue * 1.06)).astype('uint8') * 255
        kernel = np.ones((max(3, int(round(5 * sy))), close_w), dtype='uint8')
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        expected_x, expected_y = int(expected_center[0]), int(expected_center[1])
        best = None
        for contour in contours:
            bx, by, bw, bh = cv2.boundingRect(contour)
            if bw < min_width or bh < min_height:
                continue
            cx = int(region_left) + bx + bw // 2
            cy = int(region_top) + by + bh // 2
            dx, dy = cx - expected_x, cy - expected_y
            if abs(dx) > max_dx or dy < min_dy or dy > max_dy:
                continue
            # Prefer a centered, wide CTA over unrelated small green labels.
            score = abs(dx) + 1.25 * abs(dy) - min(bw, 500 * sx) * 0.025
            if best is None or score < best[0]:
                best = (score, (cx, cy), (bw, bh))
        return best[1] if best is not None else None
    except Exception:
        return None


class PurchaseWorker(QThread):
    progress = Signal(str)
    finished_result = Signal(bool, str)

    def __init__(self, card_xy, scan_screen_size, click_delay_ms=1, auto_confirm=False,
                 target_hwnd=None, candidate_detected_at=None, parent=None,
                 pre_buy_validator=None, expected_discount=None,
                 fast_coordinate_flow=False):
        super().__init__(parent)
        self.card_xy = (int(card_xy[0]), int(card_xy[1]))
        self.scan_screen_size = (int(scan_screen_size[0]), int(scan_screen_size[1]))
        self.click_delay_ms = max(1, min(100, int(click_delay_ms)))
        self.auto_confirm = bool(auto_confirm)
        self.fast_coordinate_flow = bool(fast_coordinate_flow and self.auto_confirm)
        try:
            self.target_hwnd = int(target_hwnd) if target_hwnd not in (None, 0, '0') else None
        except (TypeError, ValueError):
            self.target_hwnd = None
        try:
            self.candidate_detected_at = float(candidate_detected_at) if candidate_detected_at is not None else None
        except (TypeError, ValueError):
            self.candidate_detected_at = None
        self.pre_buy_validator = pre_buy_validator
        try:
            self.expected_discount = int(expected_discount) if expected_discount is not None else None
        except (TypeError, ValueError):
            self.expected_discount = None
        self.validated_details = None
        self._card_click_sent_at = None
        self.cancel_event = threading.Event()
        # A single action flow may send at most one click to each calibrated point.
        self._clicked_points = set()
        self._result_emitted = False
        self._located_button_centers = {}
        # The direct fast path uses a native, cancellable one-shot waitable timer.
        # This avoids relying on condition-variable timeout granularity for each
        # inter-page gap and records the actual time spent waiting.
        self._native_wait_lock = threading.Lock()
        self._native_cancel_handle = None
        self._native_timer_handle = None
        self._native_kernel32 = None
        self._wait_backend = "threading.Event.wait fallback"
        self._wait_planned_ms = 0.0
        self._wait_actual_ms = 0.0

    def cancel(self):
        self.cancel_event.set()
        # Wake a thread blocked in WaitForMultipleObjects immediately.
        try:
            with self._native_wait_lock:
                handle = self._native_cancel_handle
                kernel32 = self._native_kernel32
                if handle and kernel32 is not None:
                    kernel32.SetEvent(handle)
        except Exception:
            pass

    def _init_precise_wait_backend(self):
        """Create cancellable native timer handles; gracefully fall back on older Windows."""
        if os.name != "nt":
            self._wait_backend = "threading.Event.wait fallback"
            return
        import ctypes
        from ctypes import wintypes

        kernel32 = ctypes.windll.kernel32
        cancel_handle = None
        timer_handle = None
        backend = "threading.Event.wait fallback"
        try:
            kernel32.CreateEventW.argtypes = [
                ctypes.c_void_p, wintypes.BOOL, wintypes.BOOL, ctypes.c_wchar_p
            ]
            kernel32.CreateEventW.restype = wintypes.HANDLE
            kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
            kernel32.CloseHandle.restype = wintypes.BOOL
            kernel32.SetEvent.argtypes = [wintypes.HANDLE]
            kernel32.SetEvent.restype = wintypes.BOOL
            kernel32.WaitForMultipleObjects.argtypes = [
                wintypes.DWORD, ctypes.POINTER(wintypes.HANDLE), wintypes.BOOL, wintypes.DWORD
            ]
            kernel32.WaitForMultipleObjects.restype = wintypes.DWORD
            kernel32.SetWaitableTimer.argtypes = [
                wintypes.HANDLE, ctypes.POINTER(ctypes.c_longlong), wintypes.LONG,
                ctypes.c_void_p, ctypes.c_void_p, wintypes.BOOL
            ]
            kernel32.SetWaitableTimer.restype = wintypes.BOOL

            cancel_handle = kernel32.CreateEventW(
                None, True, bool(self.cancel_event.is_set()), None
            )
            # CREATE_WAITABLE_TIMER_HIGH_RESOLUTION is available starting with
            # Windows 10 1803. Try it first; fall back to an ordinary waitable timer.
            try:
                kernel32.CreateWaitableTimerExW.argtypes = [
                    ctypes.c_void_p, ctypes.c_wchar_p, wintypes.DWORD, wintypes.DWORD
                ]
                kernel32.CreateWaitableTimerExW.restype = wintypes.HANDLE
                timer_handle = kernel32.CreateWaitableTimerExW(
                    None, None, 0x00000002, 0x00100002  # high-res + SYNCHRONIZE|MODIFY_STATE
                )
                if timer_handle:
                    backend = "Win32 high-resolution waitable timer"
            except Exception:
                timer_handle = None

            if not timer_handle:
                try:
                    kernel32.CreateWaitableTimerW.argtypes = [
                        ctypes.c_void_p, wintypes.BOOL, ctypes.c_wchar_p
                    ]
                    kernel32.CreateWaitableTimerW.restype = wintypes.HANDLE
                    timer_handle = kernel32.CreateWaitableTimerW(None, False, None)
                    if timer_handle:
                        backend = "Win32 waitable timer fallback"
                except Exception:
                    timer_handle = None

            if not cancel_handle or not timer_handle:
                if cancel_handle:
                    kernel32.CloseHandle(cancel_handle)
                if timer_handle:
                    kernel32.CloseHandle(timer_handle)
                self._wait_backend = "threading.Event.wait fallback"
                return

            with self._native_wait_lock:
                self._native_kernel32 = kernel32
                self._native_cancel_handle = cancel_handle
                self._native_timer_handle = timer_handle
                self._wait_backend = backend
                if self.cancel_event.is_set():
                    kernel32.SetEvent(cancel_handle)
        except Exception:
            try:
                if cancel_handle:
                    kernel32.CloseHandle(cancel_handle)
            except Exception:
                pass
            try:
                if timer_handle:
                    kernel32.CloseHandle(timer_handle)
            except Exception:
                pass
            self._native_kernel32 = None
            self._native_cancel_handle = None
            self._native_timer_handle = None
            self._wait_backend = "threading.Event.wait fallback"

    def _wait_precise_ms(self, milliseconds):
        """Wait for a small interval while remaining promptly cancellable; return True on timeout."""
        ms = max(0, int(milliseconds))
        if ms <= 0:
            return not self._cancelled()
        started = time.perf_counter()
        self._wait_planned_ms += float(ms)
        completed = False
        try:
            with self._native_wait_lock:
                kernel32 = self._native_kernel32
                cancel_handle = self._native_cancel_handle
                timer_handle = self._native_timer_handle
            if kernel32 is not None and cancel_handle and timer_handle:
                import ctypes
                from ctypes import wintypes
                due_time = ctypes.c_longlong(-max(1, int(ms * 10_000)))  # relative 100-ns units
                if kernel32.SetWaitableTimer(
                    timer_handle, ctypes.byref(due_time), 0, None, None, False
                ):
                    handles = (wintypes.HANDLE * 2)(cancel_handle, timer_handle)
                    result = int(kernel32.WaitForMultipleObjects(2, handles, False, 0xFFFFFFFF))
                    # Handle order: cancellation event first, timer second.
                    if result == 1:
                        completed = not self._cancelled()
                    elif result == 0:
                        completed = False
                    else:
                        # WAIT_FAILED or any unexpected status must not kill a valid
                        # purchase chain merely because the native timer API failed.
                        self._wait_backend = "threading.Event.wait fallback (native wait failed)"
                        elapsed = time.perf_counter() - started
                        remaining_s = max(0.0, ms / 1000.0 - elapsed)
                        completed = not self.cancel_event.wait(remaining_s)
                else:
                    completed = not self.cancel_event.wait(ms / 1000.0)
            else:
                completed = not self.cancel_event.wait(ms / 1000.0)
        except Exception:
            completed = not self.cancel_event.wait(ms / 1000.0)
        finally:
            self._wait_actual_ms += (time.perf_counter() - started) * 1000.0
        return bool(completed and not self._cancelled())

    def _close_precise_wait_backend(self):
        """Close native timer handles after the worker has left every wait."""
        try:
            with self._native_wait_lock:
                kernel32 = self._native_kernel32
                handles = (self._native_cancel_handle, self._native_timer_handle)
                self._native_cancel_handle = None
                self._native_timer_handle = None
                self._native_kernel32 = None
            if kernel32 is not None:
                for handle in handles:
                    if handle:
                        try:
                            kernel32.CloseHandle(handle)
                        except Exception:
                            pass
        except Exception:
            pass

    def _emit_result(self, success: bool, message: str):
        """Emit one terminal result and expose its state to the GUI-thread cleanup guard."""
        if self._result_emitted:
            return
        self._result_emitted = True
        self.finished_result.emit(bool(success), str(message))

    def _cancelled(self) -> bool:
        return self.cancel_event.is_set()

    def _detection_elapsed_ms(self):
        if self.candidate_detected_at is None:
            return None
        return max(0.0, (time.perf_counter() - self.candidate_detected_at) * 1000.0)

    def _timed(self, message):
        elapsed = self._detection_elapsed_ms()
        if elapsed is None:
            return str(message)
        return f'{message} · t+{elapsed:.1f} мс від передачі кандидата'

    @staticmethod
    def _find_target_window():
        """Find a recognizable NG/GTA window; never fall back to an arbitrary foreground app."""
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        candidates = []
        title_terms = (
            'grand theft auto', 'gta v', 'fivem', 'rage multiplayer',
            'new generation', 'ng rp', 'ng mp', 'ng market', 'market - ng',
        )
        process_terms = ('gta5.exe', 'fivem.exe', 'ragemp.exe', 'ragemp_v.exe', 'ng_gameprocess.exe')
        PROCESS_QUERY_LIMITED_INFORMATION = 0x1000

        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.IsWindowVisible.argtypes = [wintypes.HWND]
        user32.GetWindowTextLengthW.argtypes = [wintypes.HWND]
        user32.GetWindowTextLengthW.restype = ctypes.c_int
        user32.GetWindowTextW.argtypes = [wintypes.HWND, wintypes.LPWSTR, ctypes.c_int]
        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.QueryFullProcessImageNameW.argtypes = [wintypes.HANDLE, wintypes.DWORD, wintypes.LPWSTR, ctypes.POINTER(wintypes.DWORD)]
        kernel32.QueryFullProcessImageNameW.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        enum_callback = ctypes.WINFUNCTYPE(wintypes.BOOL, wintypes.HWND, wintypes.LPARAM)
        query_process = user32.GetWindowThreadProcessId

        def callback(hwnd, lparam):
            try:
                if not user32.IsWindowVisible(hwnd):
                    return True
                length = user32.GetWindowTextLengthW(hwnd)
                title = ''
                if length > 0:
                    buf = ctypes.create_unicode_buffer(length + 1)
                    user32.GetWindowTextW(hwnd, buf, length + 1)
                    title = buf.value.strip()
                title_low = title.casefold()
                if 'ng market scanner' in title_low:
                    return True
                pid = wintypes.DWORD(0)
                query_process(hwnd, ctypes.byref(pid))
                process = ''
                handle = kernel32.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, False, pid.value)
                if handle:
                    try:
                        image_buf = ctypes.create_unicode_buffer(1024)
                        size = wintypes.DWORD(len(image_buf))
                        if kernel32.QueryFullProcessImageNameW(handle, 0, image_buf, ctypes.byref(size)):
                            process = image_buf.value.rsplit('\\', 1)[-1].casefold()
                    finally:
                        kernel32.CloseHandle(handle)
                if any(term in title_low for term in title_terms) or process in process_terms or process.startswith('gta5_'):
                    candidates.append((hwnd, title, process))
            except Exception:
                return True
            return True

        callback_ref = enum_callback(callback)
        user32.EnumWindows(callback_ref, 0)
        # Prefer a title match over a process-only match, and prefer the active window.
        foreground = user32.GetForegroundWindow()
        candidates.sort(key=lambda item: (item[0] == foreground, bool(item[1])), reverse=True)
        return candidates[0] if candidates else None

    @staticmethod
    def _window_covers_screen(hwnd, screen_size: Tuple[int, int]) -> bool:
        """The configured 3x5 grid assumes the NG/GTA window covers the scanned monitor."""
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        class RECT(ctypes.Structure):
            _fields_ = [('left', wintypes.LONG), ('top', wintypes.LONG),
                        ('right', wintypes.LONG), ('bottom', wintypes.LONG)]
        rect = RECT()
        user32.GetWindowRect.argtypes = [wintypes.HWND, ctypes.POINTER(RECT)]
        user32.GetWindowRect.restype = wintypes.BOOL
        if not user32.GetWindowRect(hwnd, ctypes.byref(rect)):
            return False
        width, height = int(screen_size[0]), int(screen_size[1])
        window_width = int(rect.right - rect.left)
        window_height = int(rect.bottom - rect.top)
        # Borderless/fullscreen windows can have a 1-2 px frame; don't accept a
        # small window because the saved card coordinates would point elsewhere.
        return (abs(int(rect.left)) <= 12 and abs(int(rect.top)) <= 12
                and window_width >= width * 0.95 and window_height >= height * 0.92)

    @staticmethod
    def _activate_target_window(hwnd) -> bool:
        import ctypes
        user32 = ctypes.windll.user32
        from ctypes import wintypes
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL
        try:
            user32.ShowWindow(hwnd, 9)  # SW_RESTORE
            user32.SetForegroundWindow(hwnd)
            end = time.perf_counter() + 1.2
            while time.perf_counter() < end:
                if user32.GetForegroundWindow() == hwnd:
                    return True
                time.sleep(0.02)
            return user32.GetForegroundWindow() == hwnd
        except Exception:
            return False

    @staticmethod
    def _screen_size() -> Tuple[int, int]:
        import ctypes
        user32 = ctypes.windll.user32
        return int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))

    def _wait_transition(self, delay_ms: int) -> bool:
        """Wait a fixed, cancellable UI transition delay without inspecting pixels."""
        deadline = time.perf_counter() + max(0, int(delay_ms)) / 1000.0
        while True:
            if self._cancelled():
                return False
            remaining = deadline - time.perf_counter()
            if remaining <= 0:
                return True
            time.sleep(min(0.01, remaining))

    def _find_dynamic_green_button(self, x, y, expected_hwnd=None, button_kind='confirm'):
        """Capture a small ROI and locate a shifted CTA; called only after static probes miss."""
        try:
            if self._cancelled() or os.name != 'nt':
                return None
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            user32.GetForegroundWindow.restype = wintypes.HWND
            if expected_hwnd is not None and user32.GetForegroundWindow() != expected_hwnd:
                return None
            import mss
            import numpy as np
            width, height = self.scan_screen_size
            sx = width / REFERENCE_WIDTH
            sy = height / REFERENCE_HEIGHT
            kind = str(button_kind or 'confirm').casefold()
            half_w = int(round((190 if kind not in {'detail_buy','detail-buy','buy','compact'} else 100) * sx))
            above = int(round((55 if kind not in {'detail_buy','detail-buy','buy','compact'} else 45) * sy))
            below = int(round((110 if kind not in {'detail_buy','detail-buy','buy','compact'} else 55) * sy))
            left = max(0, int(x) - half_w)
            top = max(0, int(y) - above)
            right = min(width, int(x) + half_w)
            bottom = min(height, int(y) + below)
            if right <= left or bottom <= top:
                return None
            region = {'left': left, 'top': top, 'width': right-left, 'height': bottom-top}
            with mss.mss() as capture:
                pixels = np.asarray(capture.grab(region))
            center = locate_green_button_center_bgr(
                pixels[:, :, :3], left, top, (int(x), int(y)), self.scan_screen_size, button_kind
            )
            return center
        except Exception:
            return None

    def _wait_for_green_button(self, x: int, y: int, timeout_ms: int, expected_hwnd=None, button_kind='confirm') -> bool:
        """Poll a small signature around the target point; return as soon as the CTA is visible.

        A full-width button has green pixels at all six probes; a green discount badge is
        too small to satisfy this pattern. A timeout fails closed instead of blind-clicking.
        """
        if self._cancelled() or os.name != 'nt':
            return False
        import ctypes
        from ctypes import wintypes
        # GetDC/ReleaseDC belong to user32.dll; GetPixel belongs to gdi32.dll.
        # The previous build queried the wrong DLL and raised AttributeError
        # before either the Buy or Confirm click could happen.
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        user32.GetDC.argtypes = [wintypes.HWND]
        user32.GetDC.restype = wintypes.HDC
        user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        user32.ReleaseDC.restype = ctypes.c_int
        gdi32.GetPixel.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        gdi32.GetPixel.restype = ctypes.c_uint
        user32.GetForegroundWindow.restype = wintypes.HWND
        probes = button_probe_offsets(self.scan_screen_size, button_kind)
        deadline = time.perf_counter() + max(1, int(timeout_ms)) / 1000.0
        hdc = user32.GetDC(0)
        if not hdc:
            self.progress.emit('Не вдалося отримати desktop HDC для перевірки зеленої кнопки (GetDC).')
            return False
        last_dynamic_probe = 0.0
        try:
            while time.perf_counter() < deadline:
                if self._cancelled():
                    return False
                if expected_hwnd is not None and user32.GetForegroundWindow() != expected_hwnd:
                    return False
                green_count = 0
                valid_pixels = 0
                for dx, dy in probes:
                    pixel = int(gdi32.GetPixel(hdc, int(x + dx), int(y + dy)))
                    if pixel != 0xFFFFFFFF:
                        valid_pixels += 1
                    if _looks_like_green_button(pixel):
                        green_count += 1
                if valid_pixels == 0:
                    self.progress.emit('GetPixel(gdi32) не зміг зчитати пікселі на позиції кнопки; сліпий клік заблоковано.')
                    return False
                # Require a wide, button-like green patch (not one green label/badge pixel).
                if green_count >= 4:
                    self._located_button_centers[button_kind] = (int(x), int(y))
                    return True
                now = time.perf_counter()
                # Keep the normal static probe extremely fast; only spend a small ROI
                # capture every 20 ms if the expected CTA is not at its nominal point.
                if now - last_dynamic_probe >= 0.020:
                    last_dynamic_probe = now
                    dynamic_center = self._find_dynamic_green_button(
                        x, y, expected_hwnd=expected_hwnd, button_kind=button_kind
                    )
                    if dynamic_center is not None:
                        self._located_button_centers[button_kind] = tuple(map(int, dynamic_center))
                        self.progress.emit(
                            f'BUTTON_PROBE DYNAMIC: {button_kind} знайдено зі зміщенням '
                            f'({int(dynamic_center[0])-int(x):+d},{int(dynamic_center[1])-int(y):+d}) px; '
                            f'центр=({int(dynamic_center[0])},{int(dynamic_center[1])}).'
                        )
                        return True
                time.sleep(BUTTON_POLL_INTERVAL_MS / 1000.0)
            self.progress.emit(
                f'Зелену кнопку не розпізнано: тип={button_kind}, точка=({int(x)},{int(y)}), '
                f'зміщення проб={probes}, екран={self.scan_screen_size[0]}×{self.scan_screen_size[1]}. '
                'Клік не відправлено.'
            )
            return False
        finally:
            user32.ReleaseDC(0, hdc)

    def _wait_for_green_button_gone(self, x, y, timeout_ms=600, expected_hwnd=None, button_kind='confirm'):
        """Return true after the green button is absent for 3 consecutive polls."""
        if self._cancelled() or os.name != 'nt': return False
        import ctypes
        from ctypes import wintypes
        user32=ctypes.windll.user32; gdi32=ctypes.windll.gdi32
        user32.GetDC.argtypes=[wintypes.HWND]; user32.GetDC.restype=wintypes.HDC
        user32.ReleaseDC.argtypes=[wintypes.HWND,wintypes.HDC]; user32.ReleaseDC.restype=ctypes.c_int
        gdi32.GetPixel.argtypes=[wintypes.HDC,ctypes.c_int,ctypes.c_int]; gdi32.GetPixel.restype=ctypes.c_uint
        user32.GetForegroundWindow.restype=wintypes.HWND
        probes=button_probe_offsets(self.scan_screen_size, button_kind)
        hdc=user32.GetDC(0)
        if not hdc: return False
        deadline=time.perf_counter()+max(1,int(timeout_ms))/1000.0
        absent=0
        last_dynamic_probe=0.0
        try:
            while time.perf_counter()<deadline:
                if self._cancelled(): return False
                if expected_hwnd is not None and user32.GetForegroundWindow()!=expected_hwnd: return False
                green_count=0
                for dx,dy in probes:
                    if _looks_like_green_button(int(gdi32.GetPixel(hdc,int(x+dx),int(y+dy)))):
                        green_count+=1
                if green_count >= 4:
                    absent = 0
                else:
                    now = time.perf_counter()
                    dynamic_center = None
                    dynamic_sampled = False
                    # A server warning can push the modal down while the green CTA remains.
                    # Only count a miss after probing the expanded region, not from the
                    # old fixed pixel alone.
                    if now - last_dynamic_probe >= 0.025:
                        last_dynamic_probe = now
                        dynamic_sampled = True
                        dynamic_center = self._find_dynamic_green_button(
                            x, y, expected_hwnd=expected_hwnd, button_kind=button_kind
                        )
                    if dynamic_center is not None:
                        self._located_button_centers[button_kind] = tuple(map(int, dynamic_center))
                        absent = 0
                    elif dynamic_sampled:
                        absent += 1
                        if absent >= 3:
                            return True
                time.sleep(BUTTON_POLL_INTERVAL_MS/1000.0)
            self.progress.emit(
                f'Зелена кнопка підтвердження не зникла: тип={button_kind}, '
                f'точка=({int(x)},{int(y)}), зміщення проб={probes}. '
                'Сканер не вважає покупку завершеною.'
            )
            return False
        finally:
            user32.ReleaseDC(0,hdc)

    @staticmethod
    def _send_atomic_left_click() -> bool:
        """Send mouse-down/up in one OS call; don't sleep while the button is held."""
        import ctypes
        from ctypes import wintypes

        class MOUSEINPUT(ctypes.Structure):
            _fields_ = [
                ("dx", wintypes.LONG), ("dy", wintypes.LONG),
                ("mouseData", wintypes.DWORD), ("dwFlags", wintypes.DWORD),
                ("time", wintypes.DWORD), ("dwExtraInfo", ctypes.c_size_t),
            ]

        class INPUTUNION(ctypes.Union):
            _fields_ = [("mi", MOUSEINPUT)]

        class INPUT(ctypes.Structure):
            _fields_ = [("type", wintypes.DWORD), ("union", INPUTUNION)]

        mouse_input_type = 0
        left_down = 0x0002
        left_up = 0x0004
        events = (INPUT * 2)()
        events[0].type = mouse_input_type
        events[0].union.mi = MOUSEINPUT(0, 0, 0, left_down, 0, 0)
        events[1].type = mouse_input_type
        events[1].union.mi = MOUSEINPUT(0, 0, 0, left_up, 0, 0)
        user32 = ctypes.windll.user32
        user32.SendInput.argtypes = [wintypes.UINT, ctypes.POINTER(INPUT), ctypes.c_int]
        user32.SendInput.restype = wintypes.UINT
        return int(user32.SendInput(2, events, ctypes.sizeof(INPUT))) == 2

    def _click(self, x: int, y: int, expected_hwnd=None, hover_dwell_ms=None):
        if self._cancelled():
            return False
        point = (int(x), int(y))
        # Fail closed if the same action flow ever attempts a second click at the
        # same screen point; card, detail Buy and final confirm are distinct points.
        if point in self._clicked_points:
            self.progress.emit(f"Дубльований клік заблоковано для координат {point[0]}, {point[1]}.")
            return False
        import ctypes
        user32 = ctypes.windll.user32
        if expected_hwnd is not None:
            from ctypes import wintypes
            user32.GetForegroundWindow.restype = wintypes.HWND
            if user32.GetForegroundWindow() != expected_hwnd:
                return False
        user32.SetCursorPos.argtypes = [ctypes.c_int, ctypes.c_int]
        user32.SetCursorPos.restype = ctypes.c_bool
        if not user32.SetCursorPos(int(x), int(y)):
            return False
        # The fast coordinate path provides a calibrated short hover dwell explicitly;
        # the legacy path keeps its existing click-delay setting. Mouse-down/up remain
        # atomic in one SendInput batch, so no sleep occurs while the button is held.
        if hover_dwell_ms is not None:
            dwell = max(0, min(40, int(hover_dwell_ms)))
        else:
            dwell = max(0, min(100, self.click_delay_ms)) if self.click_delay_ms > 1 else 0
        if dwell and not self._wait_precise_ms(dwell):
            return False
        if self._cancelled() or (expected_hwnd is not None and user32.GetForegroundWindow() != expected_hwnd):
            return False
        if not self._send_atomic_left_click():
            self.progress.emit(f"SendInput did not accept both click events at {point[0]},{point[1]}.")
            return False
        self._clicked_points.add(point)
        return not self._cancelled()

    def _try_return_to_market(self, hwnd, current_size, reason='CTA_TIMEOUT') -> bool:
        """Best-effort BACK recovery after a card click, only while the same game/screen is active."""
        try:
            import ctypes
            from ctypes import wintypes
            user32 = ctypes.windll.user32
            user32.GetForegroundWindow.restype = wintypes.HWND
            if self._cancelled() or self._screen_size() != tuple(current_size):
                return False
            if hwnd is not None and user32.GetForegroundWindow() != hwnd:
                return False
            back_xy = scale_reference_point(BACK_MARKET, current_size)
            if not self._click(*back_xy, expected_hwnd=hwnd):
                return False
            self.progress.emit(self._timed(
                f'RETURN MARKET RECOVERY: {reason}; BACK ({back_xy[0]},{back_xy[1]}) відправлено.'
            ))
            # Only the recovery path pays this short repaint allowance. The normal Buy path
            # has no fixed delay; this lets the market grid reappear before the next OCR pass.
            if self.cancel_event.wait(0.18):
                return False
            return self._screen_size() == tuple(current_size) and (hwnd is None or user32.GetForegroundWindow() == hwnd)
        except Exception as exc:
            self.progress.emit(f'RETURN MARKET RECOVERY не вдалося: {type(exc).__name__}: {exc}.')
            return False

    @staticmethod
    def _retryable_detail_validation_failure(check):
        """Only OCR/readiness failures are retried; policy failures stay final."""
        reason=str((check or {}).get('reason') or '').casefold()
        return any(token in reason for token in (
            'модель не підтверджено', 'ціну не підтверджено',
            'знижку в деталях не підтверджено', 'порожня область деталей',
            'не вдалося отримати розмір екрана', 'помилка перевірки деталей',
        ))

    def _call_pre_buy_validator(self):
        """Pass the click timestamp to upgraded validators without breaking older test hooks."""
        validator = self.pre_buy_validator
        if validator is None:
            return {'ok': True, 'reason': 'перевірку деталей не налаштовано'}
        try:
            import inspect
            parameters = inspect.signature(validator).parameters
            if 'after_perf_counter' in parameters:
                return validator(self.expected_discount, after_perf_counter=self._card_click_sent_at)
        except (TypeError, ValueError):
            pass
        return validator(self.expected_discount)

    def _start_parallel_detail_validation(self):
        """Run detail OCR alongside CTA polling, using a post-click watcher frame when available."""
        if self.pre_buy_validator is None:
            return None
        done=threading.Event()
        state={}
        def validate():
            try:
                # Starting OCR in parallel hides most of its processing time behind UI
                # transition. A short paint delay avoids grabbing the outgoing catalog
                # on the first 1–2 frames; the validator prefers a fresh watcher frame
                # captured after the click, and the CTA/discount gates still run in order.
                if self.cancel_event.wait(DETAIL_OCR_START_DELAY_MS / 1000.0):
                    state['check']={'ok':False,'reason':'перевірку деталей скасовано'}
                    return
                started=time.perf_counter()
                check=self._call_pre_buy_validator()
                state['check']=dict(check or {})
                state['worker_seconds']=time.perf_counter()-started
            except Exception as exc:
                state['check']={'ok':False,'reason':f'{type(exc).__name__}: {exc}'}
                state['worker_seconds']=0.0
            finally:
                done.set()
        thread=threading.Thread(target=validate,name='NGMarketDetailValidator',daemon=True)
        state['started_at']=time.perf_counter()
        thread.start()
        return thread,done,state

    def _run_fast_coordinate_flow(self, hwnd, current_size, detail_xy, confirm_xy, title):
        """Send the three calibrated clicks with short hover/gap intervals and no post-confirm inspection.

        Candidate eligibility is established on the market grid before this worker starts.
        This path intentionally does not wait for page paint, run detail OCR, sample CTA
        pixels, or inspect the "лот не знайдено" banner after FINAL_CONFIRM. Those checks
        happened too late in prior builds and delayed/blocked the final click. Because the
        post-confirm result is deliberately not inspected, the caller must pause scanning
        rather than OCR a possible modal.
        """
        sequence_started = time.perf_counter()
        self.progress.emit(
            f"FAST COORDINATE FLOW {FAST_COORDINATE_FLOW_VERSION}: "
            f"hover={FAST_COORDINATE_HOVER_MS} мс, gap={FAST_COORDINATE_GAP_MS} мс; "
            f"wait={CLICK_WAIT_TIMER_PATCH_VERSION}/{self._wait_backend}; "
            "CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM; без очікування пікселів/OCR після входу."
        )

        if self._cancelled():
            self._emit_result(False, 'FAST FLOW скасовано перед CARD_CLICK; жодного кліку не виконано.')
            return
        if not self._click(*self.card_xy, expected_hwnd=hwnd, hover_dwell_ms=FAST_COORDINATE_HOVER_MS):
            self._emit_result(False, 'FAST FLOW: CARD_CLICK не відправлено; подальші кліки скасовано.')
            return
        self._card_click_sent_at = time.perf_counter()
        self.progress.emit(self._timed(f'FAST STEP 1/3 SENT: CARD_CLICK ({self.card_xy[0]},{self.card_xy[1]}).'))

        if not self._wait_precise_ms(FAST_COORDINATE_GAP_MS):
            self._emit_result(False, 'FAST FLOW скасовано після CARD_CLICK; Buy/Confirm не відправлялися.')
            return
        if self._screen_size() != tuple(current_size):
            self._emit_result(False, 'FAST FLOW зупинено: роздільна здатність змінилася до DETAIL_BUY.')
            return
        if not self._click(*detail_xy, expected_hwnd=hwnd, hover_dwell_ms=FAST_COORDINATE_HOVER_MS):
            self._emit_result(False, 'FAST FLOW: DETAIL_BUY не відправлено; FINAL_CONFIRM скасовано.')
            return
        self.progress.emit(self._timed(f'FAST STEP 2/3 SENT: DETAIL_BUY ({detail_xy[0]},{detail_xy[1]}).'))

        if not self._wait_precise_ms(FAST_COORDINATE_GAP_MS):
            self._emit_result(False, 'FAST FLOW скасовано після DETAIL_BUY; FINAL_CONFIRM не відправлено.')
            return
        if self._screen_size() != tuple(current_size):
            self._emit_result(False, 'FAST FLOW зупинено: роздільна здатність змінилася до FINAL_CONFIRM.')
            return
        if not self._click(*confirm_xy, expected_hwnd=hwnd, hover_dwell_ms=FAST_COORDINATE_HOVER_MS):
            self._emit_result(False, 'FAST FLOW: FINAL_CONFIRM не відправлено.')
            return

        sequence_ms = (time.perf_counter() - sequence_started) * 1000.0
        candidate_ms = self._detection_elapsed_ms()
        wait_overrun_ms = max(0.0, self._wait_actual_ms - self._wait_planned_ms)
        wait_note = (f'очікування {self._wait_actual_ms:.1f}/{self._wait_planned_ms:.0f} мс; '
                     f'перевищення {wait_overrun_ms:.1f} мс; таймер={self._wait_backend}')
        candidate_note = f'; t+{candidate_ms:.1f} мс від preflight-кандидата' if candidate_ms is not None else ''
        budget_note = 'у межах цілі 250 мс' if candidate_ms is not None and candidate_ms <= FAST_COORDINATE_TARGET_MS else 'ціль 250 мс не підтверджена цим запуском'
        self.progress.emit(
            f'FAST STEP 3/3 SENT: FINAL_CONFIRM ({confirm_xy[0]},{confirm_xy[1]}); '
            f'послідовність кліків {sequence_ms:.1f} мс{candidate_note}; {budget_note}; {wait_note}. '
            'Після цього статус/банер лота не перевіряється.'
        )
        self._emit_result(
            True,
            f'[FAST_FLOW_NO_POSTCHECK] CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM відправлено; '
            f'клік-послідовність {sequence_ms:.1f} мс{candidate_note}; {wait_note}. '
            'Результат сервера навмисно не перевірявся. Безперервний режим дочекається підтвердження каталогу перед новим OCR-циклом.'
        )

    def run(self):
        timer_resolution_active = False
        try:
            self._init_precise_wait_backend()
            # The direct fast path uses a high-resolution waitable timer when available.
            # Request timeBeginPeriod only for legacy/fallback flows; Windows 11 may ignore
            # it for fully occluded windows and unnecessary high rates can hurt power use.
            needs_legacy_timer_resolution = (
                os.name == 'nt' and
                (not self.fast_coordinate_flow or
                 self._wait_backend != "Win32 high-resolution waitable timer")
            )
            if needs_legacy_timer_resolution:
                try:
                    import ctypes
                    timer_resolution_active = int(ctypes.windll.winmm.timeBeginPeriod(1)) == 0
                except Exception:
                    timer_resolution_active = False
            self.progress.emit(
                f"CLICK WORKFLOW {CLICK_WORKFLOW_VERSION} | BUTTON_PROBE={CLICK_BUTTON_PROBE_PATCH_VERSION} | "
                f"DETAIL_BUY=({DETAIL_BUY[0]},{DETAIL_BUY[1]}) | "
                f"FINAL_CONFIRM=({FINAL_CONFIRM[0]},{FINAL_CONFIRM[1]}) | "
                f"AUTO_CONFIRM={int(self.auto_confirm)} | "
                "Порядок обов’язковий: КАРТКА → DETAIL_BUY → FINAL_CONFIRM."
            )
            if os.name != 'nt':
                self._emit_result(False, 'Автоклік доступний лише у Windows; жодного кліку не виконано.')
                return
            current_size = self._screen_size()
            if current_size != self.scan_screen_size:
                self._emit_result(False, f'Роздільна здатність змінилася після сканування ({self.scan_screen_size[0]}×{self.scan_screen_size[1]} → {current_size[0]}×{current_size[1]}). Жодного кліку не виконано.')
                return

            # Reference points were calibrated against the supplied screenshots.
            detail_xy = scale_reference_point(DETAIL_BUY, current_size)
            confirm_xy = scale_reference_point(FINAL_CONFIRM, current_size)
            if self._cancelled():
                self._emit_result(False, 'Автодію скасовано до кліку по картці.')
                return

            if self.target_hwnd is not None:
                # The scan worker already validated this exact game HWND as foreground.
                # Reuse it to avoid an unnecessary EnumWindows + activation path; fail
                # closed if focus moved between OCR and the first click.
                import ctypes
                from ctypes import wintypes
                user32 = ctypes.windll.user32
                user32.GetForegroundWindow.restype = wintypes.HWND
                hwnd = self.target_hwnd
                try:
                    user32.IsWindow.argtypes = [wintypes.HWND]
                    user32.IsWindow.restype = wintypes.BOOL
                except Exception:
                    pass
                if not user32.IsWindow(hwnd) or user32.GetForegroundWindow() != hwnd:
                    self._emit_result(False, 'Фокус гри змінився після виявлення пропозиції. Жодного кліку не виконано.')
                    return
                title = 'перевірене вікно гри'
                process = ''
            else:
                target = self._find_target_window()
                if not target:
                    self._emit_result(False, 'Не знайдено впізнаване вікно NG/GTA. Жодного кліку не виконано; відкрий гру/ринок у вікні з відповідною назвою.')
                    return
                hwnd, title, process = target
                if not self._activate_target_window(hwnd):
                    self._emit_result(False, f'Не вдалося активувати вікно ринку «{title}». Жодного кліку не виконано.')
                    return
            if not self._window_covers_screen(hwnd, current_size):
                self._emit_result(False, f'Автодію заблоковано: вікно «{title}» не займає майже весь монітор, а координати 3×5 сітки тоді небезпечні. Розгорни гру/ринок на весь екран.')
                return

            if self.fast_coordinate_flow and self.auto_confirm:
                self._run_fast_coordinate_flow(hwnd, current_size, detail_xy, confirm_xy, title)
                return

            if self._cancelled():
                self._emit_result(False, 'Автодію скасовано перед кліком по картці.')
                return
            self.progress.emit(f'Автодія: відкриваю картку в «{title}» за координатами {self.card_xy[0]}, {self.card_xy[1]}.')
            if not self._click(*self.card_xy, expected_hwnd=hwnd):
                self._emit_result(False, 'STEP 1/3 FAILED: клік по картці не виконано або отримано СТОП.')
                return
            self._card_click_sent_at = time.perf_counter()
            self.progress.emit(self._timed(f'STEP 1/3 SENT: CARD_CLICK ({self.card_xy[0]},{self.card_xy[1]}).'))

            # Start detail OCR in parallel with CTA polling. OCR waits briefly for page
            # paint and reuses the watcher's fresh post-click frame, avoiding a second
            # 700–800 ms MSS capture on machines where DXcam is unavailable.
            validation_task = self._start_parallel_detail_validation() if self.pre_buy_validator is not None else None
            button_wait_started=time.perf_counter()
            self.progress.emit(f'STEP 2/3 WAIT_BUTTON: шукаю зелену кнопку «Купити» до {DETAIL_TRANSITION_MS} мс ({detail_xy[0]},{detail_xy[1]}); OCR працює паралельно після затримки {DETAIL_OCR_START_DELAY_MS} мс.')
            button_ready = self._wait_for_green_button(*detail_xy, timeout_ms=DETAIL_TRANSITION_MS, expected_hwnd=hwnd, button_kind='detail_buy')
            button_wait_ms=(time.perf_counter()-button_wait_started)*1000.0
            if not button_ready:
                recovered = self._try_return_to_market(hwnd, current_size, reason='DETAIL_BUY_TIMEOUT')
                if recovered:
                    self._emit_result(False, f'[RECOVERED_TO_MARKET] Кнопка «Купити» не з’явилася за {button_wait_ms:.1f} мс; сліпого кліку не було. BACK виконано, ринок відновлюється.')
                else:
                    self._emit_result(False, f'Кнопка «Купити» не з’явилася за тайм-аут або втрачено фокус; сліпого кліку не виконано (очікування {button_wait_ms:.1f} мс). Автосканування призупиняється для ручної перевірки.')
                return
            detail_xy = self._located_button_centers.get('detail_buy', detail_xy)
            if self._cancelled():
                self._emit_result(False, 'Автодію скасовано перед натисканням «Купити».')
                return
            if validation_task is not None:
                _,validation_done,validation_state=validation_task
                validation_done.wait()
                self.validated_details=dict(validation_state.get('check') or {'ok':False,'reason':'перевірка деталей не повернула результат'})
                validation_ms=float(validation_state.get('worker_seconds') or self.validated_details.get('validation_seconds') or 0.0)*1000.0
                if (not bool(self.validated_details.get('ok'))
                        and not bool(self.validated_details.get('detail_retry_attempted'))
                        and self._retryable_detail_validation_failure(self.validated_details)):
                    retry_started=time.perf_counter()
                    retry_check=self._call_pre_buy_validator()
                    retry_check=dict(retry_check or {})
                    retry_ms=(time.perf_counter()-retry_started)*1000.0
                    self.validated_details=retry_check
                    validation_ms += retry_ms
                    self.progress.emit(f'DETAIL OCR RETRY: CTA вже була готова; повторна перевірка після OCR-помилки ({retry_ms:.1f} мс).')
                self.progress.emit(self._timed(
                    f'FAST DETAIL VALIDATION: CTA готова за {button_wait_ms:.1f} мс; перевірка деталей {validation_ms:.1f} мс; '
                    f'capture {float(self.validated_details.get('capture_seconds') or 0.0)*1000.0:.1f} мс '
                    f'({self.validated_details.get('capture_backend', 'невідомо')}) / '
                    f'OCR {float(self.validated_details.get('ocr_seconds') or 0.0)*1000.0:.1f} мс.'
                ))
                if not bool(self.validated_details.get('ok')):
                    reason = str(self.validated_details.get('reason') or 'не вдалося перевірити деталі')
                    self.progress.emit(f'ПЕРЕВІРКА ДЕТАЛЕЙ ВІДХИЛИЛА КАРТКУ: {reason}. «Купити» не натискаю.')
                    recovered = self._try_return_to_market(hwnd, current_size, reason='DETAIL_VALIDATION_REJECT')
                    if recovered:
                        self._emit_result(False, f'[RECOVERED_TO_MARKET] Картку безпечно пропущено: {reason}. «Купити» та підтвердження не натискалися; BACK виконано.')
                    else:
                        self._emit_result(False, f'Картку безпечно пропущено: {reason}. «Купити» та підтвердження не натискалися; автосканування призупинене для ручної перевірки.')
                    return
                detail_retry_note = (' повторно підтверджено розбіжність бейджа картки та деталей.'
                                     if self.validated_details.get('badge_mismatch_retry_confirmed') else
                                     ' виконано повторне OCR-зчитування.'
                                     if self.validated_details.get('detail_retry_attempted') else '')
                self.progress.emit(self._timed(
                    'Деталі підтверджені перед «Купити»: '
                    f"знижка -{self.validated_details.get('discount_value')}%, "
                    f"поріг -{self.validated_details.get('threshold')}%; "
                    f"перевірка: {self.validated_details.get('detail_discount_validation_method', 'OCR')}; "
                    f"ринкова ціна {self.validated_details.get('market_reference_price_value') or '—'}."
                    f"{detail_retry_note}"
                ))
            if self._screen_size() != self.scan_screen_size or __import__('ctypes').windll.user32.GetForegroundWindow() != hwnd:
                self._emit_result(False, 'Клік «Купити» заблоковано: фокус гри втрачено або змінилася роздільна здатність.')
                return
            self.progress.emit(f'STEP 2/3 CLICK: DETAIL_BUY ({detail_xy[0]},{detail_xy[1]}).')
            if not self._click(*detail_xy, expected_hwnd=hwnd):
                self._emit_result(False, 'STEP 2/3 FAILED: клік DETAIL_BUY не виконано або скасований.')
                return
            self.progress.emit(self._timed(f'STEP 2/3 SENT: DETAIL_BUY ({detail_xy[0]},{detail_xy[1]}).'))

            # If auto-confirm is disabled, do not wait for or click the modal button.
            # The user can inspect the confirmation dialog manually.
            if not self.auto_confirm:
                self._emit_result(True, f'STEP 1/3 + 2/3 завершено: картку відкрито і DETAIL_BUY натиснуто за координатами ({detail_xy[0]},{detail_xy[1]}). Фінальне підтвердження залишено вручну.')
                return

            self.progress.emit(f'STEP 3/3 WAIT_BUTTON: шукаю зелене фінальне підтвердження до {CONFIRM_TRANSITION_MS} мс ({confirm_xy[0]},{confirm_xy[1]}).')
            if not self._wait_for_green_button(*confirm_xy, timeout_ms=CONFIRM_TRANSITION_MS, expected_hwnd=hwnd, button_kind='confirm'):
                self._emit_result(False, 'Кнопка фінального підтвердження не з’явилася за тайм-аут або втрачено фокус; сліпого кліку не виконано.')
                return
            confirm_xy = self._located_button_centers.get('confirm', confirm_xy)
            if self._cancelled():
                self._emit_result(False, 'Автодію скасовано перед фінальним підтвердженням.')
                return
            if self._screen_size() != self.scan_screen_size or __import__('ctypes').windll.user32.GetForegroundWindow() != hwnd:
                self._emit_result(False, 'Фінальний клік заблоковано: фокус гри втрачено або змінилася роздільна здатність.')
                return

            self.progress.emit(f'STEP 3/3 CLICK: FINAL_CONFIRM ({confirm_xy[0]},{confirm_xy[1]}).')
            if not self._click(*confirm_xy, expected_hwnd=hwnd):
                self._emit_result(False, 'STEP 3/3 FAILED: FINAL_CONFIRM не виконано або скасовано.')
                return
            self.progress.emit(self._timed(f'STEP 3/3 SENT: FINAL_CONFIRM ({confirm_xy[0]},{confirm_xy[1]}).'))
            # Wait briefly for the confirmation modal to close. If it closed and the
            # details page is still visible, return to the market so watch mode resumes.
            # These are adaptive ceilings, not fixed sleeps: normal transitions return on the
            # first three matching samples. Longer ceilings only help slower 2K UI transitions.
            if self._wait_for_green_button_gone(*confirm_xy, timeout_ms=1800, expected_hwnd=hwnd, button_kind='confirm'):
                if self._wait_for_green_button(*detail_xy, timeout_ms=700, expected_hwnd=hwnd, button_kind='detail_buy'):
                    back_xy=scale_reference_point(BACK_MARKET,current_size)
                    if self._cancelled() or not self._click(*back_xy,expected_hwnd=hwnd):
                        self._emit_result(False, '[NEEDS_MANUAL_RECOVERY] Підтвердження зникло, але повернення до каталогу не вдалося. Автосканування не поновлюю, щоб не OCR-ити сторінку деталей.')
                        return
                    self.progress.emit(self._timed(f'Повернення до каталогу після підтвердження: BACK ({back_xy[0]},{back_xy[1]}).'))
                    if self.cancel_event.wait(0.18):
                        self._emit_result(False, '[NEEDS_MANUAL_RECOVERY] Клік BACK відправлено, але дію скасовано до завершення перемальовування каталогу.')
                        return
                else:
                    self.progress.emit('Підтвердження зникло; зелена кнопка деталей не знайдена за 700 мс, отже сторінка, ймовірно, вже змінилася. Наступний цикл перевірить сітку.')
                self._emit_result(True, self._timed('Усі 3 кроки відправлено: CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM. SENT підтверджує відправлення кліків ОС, а не серверне прийняття покупки.'))
            else:
                self._emit_result(False, self._timed('Клік FINAL_CONFIRM надіслано, але кнопка підтвердження не зникла. Інші кліки не виконую; перевір діалог у грі.'))
        except Exception as exc:
            self._emit_result(False, f'Автодію перервано безпечним способом: {type(exc).__name__}: {exc}')
        finally:
            self._close_precise_wait_backend()
            if timer_resolution_active:
                try:
                    import ctypes
                    ctypes.windll.winmm.timeEndPeriod(1)
                except Exception:
                    pass
