"""OCR parsing helpers for NG Market Scanner.

This module is deliberately kept outside the packaged executable so OCR parsing
can be patched without rebuilding the EXE after the initial v1.2.11 migration.
"""
from __future__ import annotations

import re
import unicodedata
from difflib import SequenceMatcher
from typing import Iterable, Optional, Tuple


def normalize_vehicle_key(text: str) -> str:
    """Normalize catalog/model OCR text while keeping matching conservative."""
    if not text:
        return ""
    value = unicodedata.normalize("NFKD", str(text)).encode("ascii", "ignore").decode("ascii").lower()
    value = re.sub(r"[^a-z0-9]", "", value)
    # Frequent OCR confusions: VIII may be read as Vill, Vlll, or Vlll-like
    # mixtures of capital I and lowercase L. Normalize only this known model code.
    value = value.replace("bfgolfvlll", "bfgolfviii").replace("bfgolfvill", "bfgolfviii")
    # The earlier NG OCR script used this normalization on BOTH the OCR result
    # and canonical model names. It helps distinguish Obey/0bey consistently.
    value = value.replace("0", "o")
    return value


def clean_model_text(text: str) -> str:
    """Take the title line from a title+distance OCR crop."""
    if not text:
        return ""
    value = str(text).replace("|", " ").replace("\n", " ")
    value = re.split(r"\b(?:\d{1,3}(?:[\s,]\d{3})?|[oO])?\s*(?:km|kms|км|xm|xм)\b", value, flags=re.IGNORECASE)[0]
    value = re.sub(r"\s+", " ", value).strip(" \t|·—-:;,.!?")
    value = re.sub(r"^[^A-Za-z0-9]+", "", value)
    value = re.sub(r"[^A-Za-z0-9 .()'\-]+$", "", value).strip()
    # A distance-only result such as "0 KM" must not be presented as a model.
    letters = re.sub(r"[^A-Za-z]", "", value)
    if len(letters) < 3:
        return ""
    return value


def _model_tokens(text: str) -> list[str]:
    """Tokenize a model/title while preserving alphanumeric model codes."""
    if not text:
        return []
    ascii_text = unicodedata.normalize('NFKD', str(text)).encode('ascii', 'ignore').decode().lower()
    ascii_text = ascii_text.replace('redeve', 'redeye')
    # Windows OCR commonly confuses the three strokes in VIII with lowercase Ls.
    ascii_text = re.sub(r'\bvlll\b', 'viii', ascii_text)
    ascii_text = re.sub(r'\bvill\b', 'viii', ascii_text)
    tokens = re.findall(r'[a-z]+\d*|\d+', ascii_text)
    # Keep pure numbers unchanged (80, 429, 8601); normalize letter-containing
    # tokens only so model codes and mileage remain distinguishable.
    return [token if token.isdigit() else normalize_vehicle_key(token) for token in tokens if token]


def match_catalog_model(text: str, models: Iterable[str]) -> Tuple[Optional[str], float]:
    """Return an exact or high-confidence, unambiguous catalog match.

    The marketplace title OCR can append mileage to the title and sometimes puts
    the model family before its make (for example, ``EVO IX Maibatsu Lancer 8601``).
    Match token sets before fuzzy comparison so the mileage number/order does not
    cause a false 'outside catalog' result. Ambiguous fuzzy ties stay unmatched.
    """
    names = [str(m).strip() for m in models if str(m).strip()]
    cleaned = clean_model_text(text) or str(text or '')
    haystack = normalize_vehicle_key(cleaned)
    if not haystack:
        return None, 0.0

    canonical = [(name, normalize_vehicle_key(name), _model_tokens(name)) for name in names]

    # First: normalized exact substring (most reliable, longest title wins).
    exact = [(name, key) for name, key, _ in canonical if key and key in haystack]
    if exact:
        exact.sort(key=lambda pair: len(pair[1]), reverse=True)
        return exact[0][0], 1.0

    # Second: every canonical token occurs in the OCR title, independent of word
    # order. Additional standalone numeric token(s) can be mileage (e.g. 8601).
    ocr_tokens = _model_tokens(cleaned)
    ocr_set = set(ocr_tokens)
    subset_matches = []
    for name, key, tokens in canonical:
        if tokens and all(token in ocr_set for token in tokens):
            extras = [token for token in ocr_tokens if token not in set(tokens)]
            # Extra letters usually imply a different title; numeric extras are
            # typical OCR mileage contamination in the market's title strip.
            if all(token.isdigit() for token in extras):
                subset_matches.append((len(tokens), len(key), name))
    if subset_matches:
        subset_matches.sort(reverse=True)
        if len(subset_matches) == 1 or subset_matches[0][:2] != subset_matches[1][:2]:
            return subset_matches[0][2], 0.97

    # Third: conservative fuzzy similarity. Compare the full text and sliding
    # windows; require a clear margin over the second-best model.
    scores = []
    for name, key, _ in canonical:
        if len(key) < 6:
            continue
        best = SequenceMatcher(None, key, haystack).ratio()
        low = max(5, len(key) - 2)
        high = min(len(haystack), len(key) + 2)
        for length in range(low, high + 1):
            for start in range(0, len(haystack) - length + 1):
                score = SequenceMatcher(None, key, haystack[start:start + length]).ratio()
                if score > best:
                    best = score
        # Token-sort comparison handles occasional word ordering variations.
        sorted_key = ''.join(sorted(_model_tokens(name)))
        sorted_ocr = ''.join(sorted(ocr_tokens))
        token_score = SequenceMatcher(None, sorted_key, sorted_ocr).ratio() if sorted_key else 0.0
        best = max(best, token_score * 0.96)
        scores.append((best, name))
    if not scores:
        return None, 0.0
    scores.sort(key=lambda item: item[0], reverse=True)
    best_score, best_name = scores[0]
    second_score = scores[1][0] if len(scores) > 1 else 0.0
    if best_score >= 0.88 and (best_score - second_score) >= 0.045:
        return best_name, round(best_score, 3)
    return None, round(best_score, 3)


INFORMATIONAL_MODELS = [
    'Maibatsu Lancer EVO IX', 'BF Surfer', 'Declasse Volt', 'Vapid Model T',
    'Grotti F40', 'Bravado Charger Daytona EV', 'BF T6.1',
    'Annis GT-R R35 Japan Spec', 'Vapid Mustang GT S550', 'Dinka S2000',
    'Annis Silvia S15', 'Obey E-Tron GT',
]

def match_informational_model(text: str) -> Tuple[Optional[str], float]:
    """Canonicalize visible market names outside the buy catalog without authorizing a purchase."""
    return match_catalog_model(text, INFORMATIONAL_MODELS)



def effective_threshold(category: str, model_override, category_threshold, global_threshold) -> int:
    """Resolve the live minimum discount for a model in this precedence order:
    per-model override > priority/special rule > global ordinary threshold.
    """
    try:
        if model_override is not None and str(model_override).strip() != '':
            return abs(int(model_override))
    except (TypeError, ValueError):
        pass
    normalized = str(category or '').strip()
    if normalized in ('Пріоритетне', 'Пріоритетна', 'Спеціальне', 'Спеціальна'):
        try:
            return abs(int(category_threshold))
        except (TypeError, ValueError):
            return abs(int(global_threshold))
    return abs(int(global_threshold))

def build_candidate_status(display_model: str, catalog_model: Optional[str], price_value: Optional[int],
                           badge_color: str, discount_value: Optional[int], threshold: Optional[int],
                           selected: bool, blacklisted: bool) -> Tuple[str, bool]:
    """One authoritative eligibility decision, shared by scan and tests."""
    if not display_model:
        return 'Модель не розпізнано', False
    if not catalog_model:
        return 'Поза каталогом · без автоматичних дій', False
    if blacklisted:
        return 'Чорний список · ігнорувати', False
    if badge_color == 'RED':
        return 'Націнка · ігнорувати', False
    if badge_color == 'UNKNOWN':
        return 'Колір бейджа не визначено', False
    if badge_color == 'NONE':
        return 'Без бейджа знижки', False
    if discount_value is None:
        return 'Знижку не прочитано', False
    if price_value is None:
        return 'Ціну не прочитано', False
    # `selected` is a boolean for this model, not a collection. This was the
    # TypeError in v1.2.11 (`catalog_model not in selected`).
    if not bool(selected):
        return 'Вимкнено в каталозі', False
    if threshold is None:
        return 'Поріг моделі не задано', False
    if int(discount_value) >= abs(int(threshold)):
        return f'ВИГІДНА · поріг -{abs(int(threshold))}%', True
    return f'Мала знижка · потрібно -{abs(int(threshold))}%', False


def parse_price(text: str) -> Optional[int]:
    """Parse a listing price, returning an integer amount or None."""
    if not text:
        return None
    value = str(text).replace("\u00a0", " ").replace("\u202f", " ")
    value = value.replace("O", "0").replace("o", "0")
    # Common OCR result in price footers: "$850 ooo" -> "$850 000".
    value = re.sub(r"(?<=\d)\s*0{0,1}(?:\s*[oO]){2,}\b", " 000", value, flags=re.IGNORECASE)
    # Grouped thousands first, then ungrouped integers. We read from the price
    # footer only, so these candidates do not include mileage or model numbers.
    candidates = re.findall(r"(?<!\d)(\d{1,3}(?:[\s.,]\d{3})+|\d{3,9})(?!\d)", value)
    numbers = []
    for candidate in candidates:
        digits = re.sub(r"\D", "", candidate)
        if 3 <= len(digits) <= 9:
            try:
                numbers.append(int(digits))
            except ValueError:
                continue
    if not numbers:
        return None
    # Longest value is safest if OCR also caught a stray one/two digit glyph.
    return sorted(numbers, key=lambda number: len(str(number)), reverse=True)[0]


def format_price(value: Optional[int]) -> str:
    if value is None:
        return "Не прочитано"
    return "$" + f"{int(value):,}".replace(",", " ")


def parse_percent(text: str) -> Optional[int]:
    """Extract the magnitude from text such as '-9%', '+254%' or '9 %'."""
    if not text:
        return None
    value = str(text).replace("−", "-").replace("–", "-").replace("—", "-")
    match = re.search(r"(?<!\d)(\d{1,3})\s*%", value)
    if match:
        number = int(match.group(1))
        return number if 0 <= number <= 999 else None
    return None



def should_retry_initial_color_capture(badge_colors, cache_valid: bool, fast_color_filter_enabled: bool) -> bool:
    """Retry one transient first frame when every badge samples as uncolored.

    This is deliberately limited to an invalid/empty cache and an all-NONE frame;
    steady-state 50 ms polling and normal no-discount frames are not delayed.
    """
    colors = [str(color or 'UNKNOWN').upper() for color in (badge_colors or [])]
    return bool(fast_color_filter_enabled and not cache_valid and colors
                and all(color == 'NONE' for color in colors))

def should_stabilize_initial_color_capture(badge_colors, cache_valid: bool,
                                           fast_color_filter_enabled: bool,
                                           minimum_colored_badges: int = 3) -> bool:
    """Stabilize an uncached startup frame when only a few badge colors rendered.

    The worker takes at most three additional frames 20 ms apart. This is startup /
    screen-change only; cached steady-state scans are never delayed by this gate.
    """
    colors = [str(color or 'UNKNOWN').upper() for color in (badge_colors or [])]
    colored = sum(1 for color in colors if color not in ('NONE', 'UNKNOWN', ''))
    return bool(fast_color_filter_enabled and not cache_valid and colors
                and colored < max(1, int(minimum_colored_badges)))

BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"


def classify_badge_color(bgr_crop) -> str:
    """Classify a badge with the same central sampler as the user's AHK OCR.

    This preserves the exact RGB ranges, center rounding, inclusive endpoints,
    two-pixel sampling stride, and fail-closed decision thresholds of the previous
    implementation. The hot loop is vectorized with NumPy instead of iterating over
    every sampled pixel in Python; no OCR or color policy is changed.
    """
    try:
        import numpy as np
        if bgr_crop is None or getattr(bgr_crop, 'size', 0) == 0:
            return 'UNKNOWN'
        arr = np.asarray(bgr_crop)
        if arr.ndim != 3 or arr.shape[2] < 3:
            return 'UNKNOWN'
        height, width = arr.shape[:2]
        # AHK uses Math.Round(left + width/2.0) for the center pixel.
        cx = int(width / 2.0 + 0.5)
        cy = int(height / 2.0 + 0.5)
        x0, x1 = max(0, cx - 18), min(width - 1, cx + 18)
        y0, y1 = max(0, cy - 8), min(height - 1, cy + 8)
        # Slicing mirrors range(start, end + 1, 2) exactly.
        samples = arr[y0:y1 + 1:2, x0:x1 + 1:2, :3]
        b = samples[..., 0].astype(np.int16, copy=False)
        g = samples[..., 1].astype(np.int16, copy=False)
        r = samples[..., 2].astype(np.int16, copy=False)
        red_mask = ((r >= 30) & (r <= 75) & (g >= 12) & (g <= 36)
                    & (b >= 12) & (b <= 42) & (r > g + 6) & (r > b + 3))
        green_mask = ((r >= 12) & (r <= 42) & (g >= 32) & (g <= 68)
                      & (b >= 12) & (b <= 42) & (g > r + 7) & (g > b + 6))
        red_count = int(np.count_nonzero(red_mask))
        green_count = int(np.count_nonzero(green_mask))
        if green_count >= 5 and green_count >= red_count * 1.4:
            return 'GREEN'
        if red_count >= 5 and red_count >= green_count * 1.4:
            return 'RED'
        if green_count == 0 and red_count == 0:
            return 'NONE'
        return 'UNKNOWN'
    except Exception:
        return 'UNKNOWN'


def resolve_discount(text: str, badge_color: str) -> Tuple[Optional[int], str, str]:
    """Return (magnitude, display text, kind) using color as the sign authority."""
    if badge_color == "NONE":
        return None, "—", "none"
    if badge_color not in ("GREEN", "RED"):
        return None, "Не визначено", "unknown"
    number = parse_percent(text)
    if number is None:
        # Only look for a plain number when the badge's color was positively
        # identified. This avoids treating price/mileage digits as a discount.
        nums = re.findall(r"(?<!\d)(\d{1,3})(?!\d)", str(text or ""))
        valid = [int(n) for n in nums if 0 < int(n) <= 999]
        if len(valid) == 1:
            number = valid[0]
    if number is None:
        return None, "Не прочитано", "discount" if badge_color == "GREEN" else "markup"
    if badge_color == "GREEN":
        return number, f"-{number}%", "discount"
    return number, f"+{number}%", "markup"

def changed_card_indices(current_signatures, previous_signatures, cache_ready=True):
    """Return card indices that need OCR; None signatures always force a retry.

    This small pure helper is tested independently so the cache optimization cannot
    silently skip a newly changed listing or a card whose previous OCR was uncertain.
    """
    current = list(current_signatures or [])
    previous = list(previous_signatures or [])
    if not cache_ready or len(current) != len(previous):
        return list(range(len(current)))
    return [i for i, signature in enumerate(current)
            if previous[i] is None or signature is None or previous[i] != signature]


def group_montage_ocr(ocr_rows, layout, count=15):
    """Assign OCR detections from a compact montage to card fields and retain per-field scores."""
    count = max(0, int(count))
    row_height = max(1.0, float(layout.get('row_height', 1)))
    name_boundary = float(layout.get('name_boundary', 0))
    price_boundary = float(layout.get('price_boundary', name_boundary))
    grouped = [
        {'name': [], 'price': [], 'badge': [], 'ocr_scores': []}
        for _ in range(count)
    ]

    for item in (ocr_rows if ocr_rows is not None else []):
        try:
            if item is None or len(item) < 2:
                continue
            box = item[0]
            text = str(item[1] or '').strip()
            if not text:
                continue
            points = list(box)
            xs = [float(point[0]) for point in points]
            ys = [float(point[1]) for point in points]
            if not xs or not ys:
                continue
            center_x = (min(xs) + max(xs)) / 2.0
            center_y = (min(ys) + max(ys)) / 2.0
            card_index = int(center_y // row_height)
            if card_index < 0 or card_index >= count:
                continue
            zones = layout.get('field_zones')
            if isinstance(zones, list):
                field = None
                for zone in zones:
                    if float(zone.get('left', 0)) <= center_x < float(zone.get('right', 0)):
                        field = str(zone.get('field', ''))
                        break
                if field not in ('name', 'price', 'badge'):
                    continue
            elif center_x < name_boundary:
                field = 'name'
            elif center_x < price_boundary:
                field = 'price'
            else:
                field = 'badge'
            try:
                score = float(item[2]) if len(item) > 2 else 0.0
            except (TypeError, ValueError):
                score = 0.0
            grouped[card_index][field].append((center_y, center_x, text, score))
            if score > 0:
                grouped[card_index]['ocr_scores'].append(score)
        except (TypeError, ValueError, IndexError, AttributeError):
            continue

    output = []
    for item in grouped:
        record = {}
        for field in ('name', 'price', 'badge'):
            pieces = sorted(item[field], key=lambda entry: (entry[0], entry[1]))
            record[field] = ' '.join(entry[2] for entry in pieces).strip()
            scores = [entry[3] for entry in pieces if entry[3] > 0]
            record[f'{field}_confidence'] = sum(scores) / len(scores) if scores else 0.0
        record['ocr_confidence'] = (
            sum(item['ocr_scores']) / len(item['ocr_scores']) if item['ocr_scores'] else 0.0
        )
        output.append(record)
    return output
