NG Market Scanner v1.2.74 — FINAL FAST OCR / 2K

ЄДИНИЙ ЗАПУСКАТОР: BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat

Фінальна збірка об’єднує стабільний координатний fast-click chain v1.2.71, persistent DXcam ROI, BGRA fast path, NumPy-векторизацію кольору бейджа та offer-specific dedupe/diagnostics v1.2.73. Оптимізація v1.2.74 не запускає detector OCR rescue, якщо дві credible known-ROI OCR-версії однаково прочитали знижку; розбіжності й невпевнені результати як і раніше направляються в rescue path.

Тести: запуск `python -m unittest discover -s tests -v` у цьому середовищі. Windows EXE необхідно зібрати й перевірити на Windows 10/11 x64.

Не трактуйте надсилання трьох кліків як серверне підтвердження покупки: fast click flow залишено без post-confirm polling, як у версії, що вам сподобалась.
