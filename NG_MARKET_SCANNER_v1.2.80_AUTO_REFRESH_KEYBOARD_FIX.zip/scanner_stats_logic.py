"""Pure statistics helpers for NG Market Scanner; no Qt dependency."""
from __future__ import annotations

import math
from datetime import datetime, timedelta
from typing import Iterable, Mapping, Sequence


def purchase_dynamics_series(events: Iterable[Mapping], period: str, now: datetime | None = None, max_points: int = 60) -> list[int]:
    """Return confirmed-purchase counts for the selected period.

    Today uses 3-hour buckets, 7/30 days use daily buckets, and all-time
    aggregates the complete retained history into at most ``max_points`` buckets.
    The caller should pass the same event set used by the summary cards.
    """
    now = now or datetime.now()
    max_points = max(2, int(max_points))
    confirmed: list[datetime] = []
    for event in events:
        if not isinstance(event, Mapping) or event.get("type") != "purchase_confirmed":
            continue
        try:
            stamp = datetime.fromisoformat(str(event.get("ts", "")))
            if stamp.tzinfo is not None:
                stamp = stamp.astimezone().replace(tzinfo=None)
            confirmed.append(stamp)
        except (TypeError, ValueError, OverflowError):
            continue

    today = now.replace(hour=0, minute=0, second=0, microsecond=0)
    if period == "Сьогодні":
        start, step, count = today, timedelta(hours=3), 8
    elif period == "7 днів":
        start, step, count = today - timedelta(days=6), timedelta(days=1), 7
    elif period == "30 днів":
        start, step, count = today - timedelta(days=29), timedelta(days=1), 30
    else:
        if not confirmed:
            return [0, 0]
        start = min(confirmed).replace(hour=0, minute=0, second=0, microsecond=0)
        span_days = max(1, (today.date() - start.date()).days + 1)
        bucket_days = max(1, math.ceil(span_days / max_points))
        step = timedelta(days=bucket_days)
        count = min(max_points, math.ceil(span_days / bucket_days))

    result: list[int] = []
    for index in range(count):
        bucket_start = start + step * index
        bucket_end = bucket_start + step
        result.append(sum(1 for stamp in confirmed if bucket_start <= stamp < bucket_end))
    return result
