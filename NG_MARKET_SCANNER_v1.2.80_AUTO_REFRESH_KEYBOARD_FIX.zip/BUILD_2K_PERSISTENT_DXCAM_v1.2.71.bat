@echo off
setlocal EnableExtensions DisableDelayedExpansion
title NG Market Scanner v1.2.80 - AUTO REFRESH KEY FIX / CONTINUOUS BUY / Disk Space Safe Build
set "NGMS_SOURCE_DIR=%~dp0"
set "NGMS_STAGE_DIR="
set "NGMS_WORK_ROOT="
set "NGMS_OUTPUT_DIR="
set "NGMS_PRESERVE_AUTOBUY=1"

echo ============================================================
echo NG Market Scanner v1.2.80 - AUTO REFRESH KEY FIX / CONTINUOUS FAST OCR / 2K
echo Stable click-chain base: NG Market Scanner v1.2.71
echo ============================================================
echo.
echo Selecting a local build drive with at least 10 GB free...
for /f "usebackq delims=" %%D in (`powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%NGMS_SOURCE_DIR%tools\select_build_workspace.ps1"`) do set "NGMS_STAGE_DIR=%%D"
if not defined NGMS_STAGE_DIR goto workspace_unavailable
if "%NGMS_STAGE_DIR%"=="NGMS_NO_SPACE" goto workspace_unavailable
for %%I in ("%NGMS_STAGE_DIR%") do set "NGMS_WORK_ROOT=%%~dpI"
set "NGMS_OUTPUT_DIR=%NGMS_WORK_ROOT%Output"
set "TEMP=%NGMS_WORK_ROOT%Temp"
set "TMP=%NGMS_WORK_ROOT%Temp"
set "TMPDIR=%NGMS_WORK_ROOT%Temp"
set "PIP_CACHE_DIR=%NGMS_WORK_ROOT%pip-cache"
set "PYINSTALLER_CONFIG_DIR=%NGMS_WORK_ROOT%PyInstallerConfig"
if not exist "%TEMP%" mkdir "%TEMP%" >nul 2>&1
if not exist "%PIP_CACHE_DIR%" mkdir "%PIP_CACHE_DIR%" >nul 2>&1
if not exist "%PYINSTALLER_CONFIG_DIR%" mkdir "%PYINSTALLER_CONFIG_DIR%" >nul 2>&1
if not exist "%NGMS_OUTPUT_DIR%" mkdir "%NGMS_OUTPUT_DIR%" >nul 2>&1
if not exist "%TEMP%" goto workspace_unavailable
if not exist "%NGMS_OUTPUT_DIR%" goto workspace_unavailable

echo Build workspace: "%NGMS_WORK_ROOT%"
echo Final EXE folder: "%NGMS_OUTPUT_DIR%"
echo.
echo Validating current sources and preparing clean ASCII staging folder...

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $s=$env:NGMS_SOURCE_DIR; $d=$env:NGMS_STAGE_DIR; foreach($f in @('main.py','scanner_core.py','scanner_actions.py','build_single_exe_internal.bat','requirements.txt','tools\select_build_workspace.ps1')) { if(!(Test-Path -LiteralPath (Join-Path $s $f))) { Write-Output ('ERROR: required file missing: '+$f); exit 10 } }; $m=Get-Content -LiteralPath (Join-Path $s 'main.py') -Raw -Encoding UTF8; $a=Get-Content -LiteralPath (Join-Path $s 'scanner_actions.py') -Raw -Encoding UTF8; $c=Get-Content -LiteralPath (Join-Path $s 'scanner_core.py') -Raw -Encoding UTF8; foreach($marker in @('NG Market Scanner v1.2.71','1.2.71-fixed-coordinate-fast-chain-no-postcheck','1.2.67-persistent-dxcam-market-roi','1.2.69-known-roi-batched-recognition-only','1.2.70-single-card-batched-recognition-only','1.2.70-dynamic-cta-and-lot-not-found-guard','1.2.68-dxcam-bgra-fastpath','1.2.72-vectorized-badge-sampling','1.2.73-offer-signature-dedupe-and-scan-profile','1.2.74-fast-badge-consensus-no-detector-fallback','1.2.75-market-return-state-gate','1.2.75-cancellable-highres-wait','1.2.75-runtime-dpi-before-qt-no-custom-manifest','self.timer.start(max(20,')) { if((($m+$a+$c).Contains($marker)) -eq $false) { Write-Output ('ERROR: required source marker missing: '+$marker); exit 17 } }; New-Item -ItemType Directory -Path $d -Force | Out-Null; Get-ChildItem -LiteralPath $d -Force | Where-Object { $_.Name -ne '.venv' } | Remove-Item -Recurse -Force; $skipDirs=@('.venv','dist','build','__pycache__','.git'); $skipFiles=@('*.pyc','scanner.log','*.log','last_scan_diagnostics.json','last_ocr_diagnostics.json','.ng_*','NG Market Scanner.exe','*.zip'); foreach($i in Get-ChildItem -LiteralPath $s -Force) { if($i.PSIsContainer -and $skipDirs -contains $i.Name) { continue }; $skip=$false; if(!$i.PSIsContainer) { foreach($p in $skipFiles) { if($i.Name -like $p) { $skip=$true; break } } }; if($skip) { continue }; Copy-Item -LiteralPath $i.FullName -Destination $d -Recurse -Force }; $old=Join-Path $s 'dist\NG Market Scanner'; if(Test-Path -LiteralPath $old) { $target=Join-Path $d 'dist\NG Market Scanner'; New-Item -ItemType Directory -Path $target -Force | Out-Null; foreach($n in @('selected_vehicles.txt','blacklist_vehicles.txt','all_vehicles.txt','vehicle_rules.txt','priority_vehicles.txt','special_vehicles.txt')) { $q=Join-Path $old $n; if(Test-Path -LiteralPath $q) { Copy-Item -LiteralPath $q -Destination $target -Force } } }; Write-Output 'SOURCE_STAGE_OK'; exit 0"
if errorlevel 1 goto stage_failed
if not exist "%NGMS_STAGE_DIR%\build_single_exe_internal.bat" goto stage_builder_missing
pushd "%NGMS_STAGE_DIR%"
if errorlevel 1 goto stage_enter_failed
call build_single_exe_internal.bat
set "NGMS_BUILD_RC=%ERRORLEVEL%"
popd
if not "%NGMS_BUILD_RC%"=="0" goto build_failed

echo.
echo Publishing the completed EXE without copying a second large binary...
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $src=Join-Path $env:NGMS_STAGE_DIR 'dist\NG Market Scanner.exe'; $outDir=$env:NGMS_OUTPUT_DIR; New-Item -ItemType Directory -Path $outDir -Force | Out-Null; $dst=Join-Path $outDir 'NG Market Scanner.exe'; $pending=Join-Path $outDir 'NG Market Scanner.exe.new'; if(!(Test-Path -LiteralPath $src)) { Write-Output 'ERROR: completed EXE not found'; exit 20 }; if(Test-Path -LiteralPath $pending) { Remove-Item -LiteralPath $pending -Force }; Move-Item -LiteralPath $src -Destination $pending -Force; if(!(Test-Path -LiteralPath $pending)) { Write-Output 'ERROR: completed EXE could not be moved into the output folder'; exit 21 }; if(Test-Path -LiteralPath $dst) { Remove-Item -LiteralPath $dst -Force }; Move-Item -LiteralPath $pending -Destination $dst -Force; if(!(Test-Path -LiteralPath $dst)) { Write-Output 'ERROR: final EXE was not published'; exit 22 }; $hash=(Get-FileHash -LiteralPath $dst -Algorithm SHA256).Hash; Write-Output ('EXE_SHA256='+$hash); Write-Output ('OUTPUT_EXE='+$dst); Remove-Item -LiteralPath $env:NGMS_STAGE_DIR -Recurse -Force -ErrorAction SilentlyContinue; exit 0"
if errorlevel 1 goto publish_failed

echo.
echo ============================================================
echo BUILD SUCCESS: "%NGMS_OUTPUT_DIR%\NG Market Scanner.exe"
echo Opened final EXE folder on the drive selected for free space.
echo Runtime flow: stable fast purchase chain; periodic tablet-based market refresh is optional.
echo Post-purchase scan continuation is configurable in Settings.
echo Result is sent to the game; server purchase success is not inferred.
echo ============================================================
start "" explorer.exe "%NGMS_OUTPUT_DIR%"
echo.
pause >nul
exit /b 0

:workspace_unavailable
echo [ERROR] No writable local drive has at least 10 GB free.
echo Free at least 10 GB on a local drive, then run the builder again.
goto failed
:stage_failed
echo [ERROR] PowerShell could not validate or stage the source tree. Check Windows PowerShell and disk space.
goto failed
:stage_builder_missing
echo [ERROR] build_single_exe_internal.bat is missing from the staged source.
goto failed
:stage_enter_failed
echo [ERROR] Could not enter the ASCII staging folder.
goto failed
:build_failed
echo [ERROR] Internal build failed with exit code %NGMS_BUILD_RC%.
echo Cleaning large PyInstaller intermediates to recover disk space; sources and test log are retained.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='SilentlyContinue'; foreach($n in @('build','dist')) { $p=Join-Path $env:NGMS_STAGE_DIR $n; if(Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Recurse -Force } }; Write-Output 'PyInstaller build/dist cache cleaned.'"
echo Staging folder retained for diagnostics: %NGMS_STAGE_DIR%
goto failed
:publish_failed
echo [ERROR] Build completed but EXE could not be published to the output folder.
echo Check the source EXE and output folder:
echo %NGMS_STAGE_DIR%\dist\NG Market Scanner.exe
echo %NGMS_OUTPUT_DIR%\NG Market Scanner.exe
goto failed
:failed
echo.
echo BUILD FAILED. Send a screenshot of the first [ERROR] line.
pause
exit /b 1
