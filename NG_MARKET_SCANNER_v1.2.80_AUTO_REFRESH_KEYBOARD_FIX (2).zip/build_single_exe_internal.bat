@echo off
chcp 65001 >nul
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
echo ============================================================
echo NG Market Scanner v1.2.81 POST-PURCHASE NAVIGATION + CONTINUOUS BUY - PyInstaller ONEFILE
echo Stable click-chain base: NG Market Scanner v1.2.71
echo ============================================================

set "PYTHON_CMD="
if not exist ".venv\Scripts\python.exe" (
  py -V:3.12 --version >nul 2>&1
  if not errorlevel 1 set "PYTHON_CMD=py -V:3.12"
  if not defined PYTHON_CMD (
    py -3.12 --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=py -3.12"
  )
  if not defined PYTHON_CMD (
    python3.12 --version >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python3.12"
  )
  if not defined PYTHON_CMD goto python_missing
  echo Creating Python 3.12 x64 virtual environment...
  !PYTHON_CMD! -m venv .venv
  if errorlevel 1 goto failed
)
call .venv\Scripts\activate.bat
if errorlevel 1 goto failed
python -c "import struct,sys; print('Python:',sys.version); print('Bits:',struct.calcsize('P')*8); raise SystemExit(0 if sys.version_info[:2]==(3,12) and struct.calcsize('P')*8==64 else 1)"
if errorlevel 1 goto wrong_python

python -m pip install --upgrade pip
if errorlevel 1 goto failed
python -m pip install -r requirements.txt
if errorlevel 1 goto failed

REM Check and repair the real PySide6 Qt plugin directory before PyInstaller's Qt hook runs.
echo Checking Qt plugin directory...
python -c "from pathlib import Path; from PySide6.QtCore import QLibraryInfo; p=Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)); print('Qt plugins:',p); raise SystemExit(0 if p.is_dir() and (p/'platforms').is_dir() else 1)" >nul 2>&1
if errorlevel 1 (
  echo [WARN] Qt plugin directory is missing; reinstalling matched PySide6 packages...
  python -m pip uninstall -y PySide6 PySide6-Addons PySide6-Essentials shiboken6
  if errorlevel 1 goto failed
  python -m pip install --no-cache-dir --force-reinstall PySide6
  if errorlevel 1 goto failed
  python -c "from pathlib import Path; from PySide6.QtCore import QLibraryInfo; p=Path(QLibraryInfo.path(QLibraryInfo.LibraryPath.PluginsPath)); print(p); raise SystemExit(0 if p.is_dir() and (p/'platforms').is_dir() else 1)"
  if errorlevel 1 goto qt_failed
)

REM Force an actual DirectML-capable runtime, otherwise stop with a readable error.
python -c "import onnxruntime as ort,sys; print('Providers:',ort.get_available_providers()); sys.exit(0 if 'DmlExecutionProvider' in ort.get_available_providers() else 1)" >nul 2>&1
if errorlevel 1 (
  echo Installing ONNX Runtime DirectML...
  python -m pip uninstall -y onnxruntime onnxruntime-gpu >nul 2>&1
  python -m pip install --upgrade onnxruntime-directml
  if errorlevel 1 goto failed
)
python -c "import onnxruntime as ort,sys; print('ONNX Runtime providers:',ort.get_available_providers()); sys.exit(0 if 'DmlExecutionProvider' in ort.get_available_providers() else 1)"
if errorlevel 1 goto directml_failed

findstr /C:"NG Market Scanner v1.2.71" main.py >nul
if errorlevel 1 goto wrong_version
findstr /C:"1.2.71-fixed-coordinate-fast-chain-no-postcheck" main.py >nul
if errorlevel 1 goto wrong_fast_coordinate
findstr /C:"1.2.71-fixed-coordinate-fast-chain-no-postcheck" scanner_actions.py >nul
if errorlevel 1 goto wrong_fast_coordinate
findstr /C:"1.2.69-known-roi-batched-recognition-only" main.py >nul
if errorlevel 1 goto wrong_recognition_only
findstr /C:"1.2.70-single-card-batched-recognition-only" main.py >nul
if errorlevel 1 goto wrong_single_card_batch
findstr /C:"1.2.67-persistent-dxcam-market-roi" main.py >nul
if errorlevel 1 goto wrong_market_preflight
findstr /C:"1.2.67-persistent-dxcam-market-roi" scanner_core.py >nul
if errorlevel 1 goto wrong_market_capture
findstr /C:"1.2.68-dxcam-bgra-fastpath" scanner_core.py >nul
if errorlevel 1 goto wrong_capture_fastpath
findstr /C:"1.2.73-offer-signature-dedupe-and-scan-profile" scanner_core.py >nul
if errorlevel 1 goto wrong_purchase_diagnostics
findstr /C:"1.2.73-offer-signature-dedupe-and-scan-profile" main.py >nul
if errorlevel 1 goto wrong_purchase_diagnostics
findstr /C:"1.2.74-fast-badge-consensus-no-detector-fallback" scanner_core.py >nul
if errorlevel 1 goto wrong_fast_badge_consensus
findstr /C:"1.2.74-fast-badge-consensus-no-detector-fallback" main.py >nul
if errorlevel 1 goto wrong_fast_badge_consensus
findstr /C:"NG Market Scanner v1.2.81" main.py >nul
if errorlevel 1 goto wrong_final_version
findstr /C:"1.2.75-market-return-state-gate" scanner_core.py >nul
if errorlevel 1 goto wrong_market_return_gate
findstr /C:"1.2.75-market-return-state-gate" main.py >nul
if errorlevel 1 goto wrong_market_return_gate
findstr /C:"1.2.69-known-roi-batched-recognition-only" scanner_core.py >nul
if errorlevel 1 goto wrong_recognition_only
findstr /C:"1.2.70-single-card-batched-recognition-only" scanner_core.py >nul
if errorlevel 1 goto wrong_single_card_batch
findstr /C:"1.2.60-position-independent-discount-watch" scanner_core.py >nul
if errorlevel 1 goto wrong_core
findstr /C:"1.2.60-responsive-ui-fast-detail" scanner_core.py >nul
if errorlevel 1 goto wrong_speed_core
findstr /C:"1.2.63-shared-watch-frame-detail-capture" scanner_core.py >nul
if errorlevel 1 goto wrong_capture_core
findstr /C:"1.2.65-fast-coalesce-compact-detail-ocr" scanner_actions.py >nul
if errorlevel 1 goto wrong_click_speed
findstr /C:"1.2.75-cancellable-highres-wait" scanner_actions.py >nul
if errorlevel 1 goto wrong_click_timer
findstr /C:"1.2.75-runtime-dpi-before-qt-no-custom-manifest" main.py >nul
if errorlevel 1 goto wrong_dpi_bootstrap
findstr /C:"1.2.65-retry-confirm-detail-discount" scanner_core.py >nul
if errorlevel 1 goto wrong_discount_core
findstr /C:"1.2.65-perceptual-offer-dedupe" scanner_core.py >nul
if errorlevel 1 goto wrong_fingerprint_core
findstr /C:"1.2.65-compact-detail-ocr" scanner_core.py >nul
if errorlevel 1 goto wrong_detail_ocr_core
findstr /C:"1.2.65-stable-offer-dedupe" scanner_actions.py >nul
if errorlevel 1 goto wrong_version
findstr /C:"1.2.65.1-2k-offtext-probes" scanner_actions.py >nul
if errorlevel 1 goto wrong_button_probe
findstr /C:"1.2.66-return-market-recover" scanner_actions.py >nul
if errorlevel 1 goto wrong_return_recovery
findstr /C:"1.2.70-dynamic-cta-and-lot-not-found-guard" scanner_actions.py >nul
if errorlevel 1 goto wrong_dynamic_confirm
if exist "tools\download_vehicle_photos.ps1" (
  echo Downloading optional licensed reference photos before embedding them...
  powershell -NoProfile -ExecutionPolicy Bypass -File "tools\download_vehicle_photos.ps1"
  if errorlevel 1 echo [WARN] Some photos could not be downloaded; bundled render fallbacks will be used.
)
python -m py_compile main.py scanner_core.py scanner_core_logic.py scanner_actions.py scanner_stats_logic.py
if errorlevel 1 goto failed
python -m unittest discover -s tests -v > NGMS_BUILD_TESTS.log 2>&1
if errorlevel 1 goto tests_failed
type NGMS_BUILD_TESTS.log

echo Preparing and validating OCR model weights for a truly bundled one-file EXE...
python tools\prepare_ocr_models.py
if errorlevel 1 goto ocr_prepare_failed

REM Shareable builds default to no purchases. The personalized final-build wrapper sets
REM NGMS_PRESERVE_AUTOBUY=1 to retain the user's explicit settings from this kit.
if defined NGMS_PRESERVE_AUTOBUY (
  echo Personal build: preserving auto_click/auto_confirm from settings.json.
  python -c "import json; from pathlib import Path; p=Path('settings.json'); d=json.loads(p.read_text(encoding='utf-8-sig')); p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); Path('stats_history.json').write_text('[]\n',encoding='utf-8')"
) else (
  echo Shareable build: automatic purchases disabled by default.
  python -c "import json; from pathlib import Path; p=Path('settings.json'); d=json.loads(p.read_text(encoding='utf-8-sig')); d['auto_click']=False; d['auto_confirm']=False; p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n',encoding='utf-8'); Path('stats_history.json').write_text('[]\n',encoding='utf-8')"
)
if errorlevel 1 goto failed

REM Bundle all runtime dependencies, dynamic sidecars, UI assets and vehicle renders into ONE EXE.
python -m PyInstaller --noconfirm --clean --windowed --onefile --name "NG Market Scanner" --icon "assets\ng_market_scanner.ico" --collect-all rapidocr --collect-all onnxruntime --collect-binaries onnxruntime --hidden-import mss --hidden-import dxcam --collect-all dxcam --hidden-import numpy --hidden-import cv2 --add-data "all_vehicles.txt;." --add-data "priority_vehicles.txt;." --add-data "special_vehicles.txt;." --add-data "vehicle_rules.txt;." --add-data "selected_vehicles.txt;." --add-data "blacklist_vehicles.txt;." --add-data "settings.json;." --add-data "hero_bg.jpg;." --add-data "vehicle_renders;vehicle_renders" --add-data "vehicle_photos;vehicle_photos" --add-data "theme;theme" --add-data "assets;assets" --add-data "stats_history.json;." --add-data "scanner_core.py;." --add-data "scanner_core_logic.py;." --add-data "scanner_actions.py;." --add-data "VEHICLE_CUTOUTS_PROVENANCE_UA.txt;." --add-data "REAL_CAR_PHOTO_CREDITS_UA.txt;." main.py
if errorlevel 1 goto failed
if not exist "dist\NG Market Scanner.exe" goto exe_missing
for %%F in ("dist\NG Market Scanner.exe") do set "EXE_SIZE=%%~zF"
echo Single EXE size: !EXE_SIZE! bytes
if !EXE_SIZE! LSS 50000000 goto too_small

echo.
echo BUILD COMPLETE: dist\NG Market Scanner.exe
echo Runtime assets are embedded. User settings/logs are stored in %%LOCALAPPDATA%%\NGMarketScanner.
if defined NGMS_PRESERVE_AUTOBUY (echo Personal settings preserved: auto-click/auto-confirm follow settings.json.) else (echo Safe shareable defaults: auto-click/auto-confirm disabled.)
exit /b 0

:python_missing
echo [ERROR] Python 3.12 x64 was not found. Install Python 3.12 64-bit and rerun.
goto failed
:wrong_python
echo [ERROR] This build requires Python 3.12 64-bit.
goto failed
:qt_failed
echo [ERROR] PySide6 Qt platform plugins are still missing after reinstall.
goto failed
:directml_failed
echo [ERROR] ONNX Runtime DirectML provider is not available. Build stopped rather than claiming GPU acceleration.
goto failed
:wrong_version
echo [ERROR] Main/action/core sources are not the v1.2.75 final build with stable v1.2.71 coordinate-fast flow.
goto failed
:wrong_market_preflight
echo [ERROR] Main source is missing the v1.2.67 persistent-DXcam market-ROI marker.
goto failed
:wrong_capture_fastpath
echo [ERROR] scanner_core.py is missing 1.2.68-dxcam-bgra-fastpath.
goto failed
:wrong_purchase_diagnostics
echo [ERROR] Offer-specific dedupe / slow-cycle diagnostic patch marker is missing.
goto failed
:wrong_fast_badge_consensus
echo [ERROR] Fast badge consensus OCR optimization marker is missing.
goto failed
:wrong_final_version
echo [ERROR] Main source is not the v1.2.81 post-purchase navigation and continuous-scan release.
goto failed
:wrong_market_return_gate
echo [ERROR] Market-return state gate marker 1.2.75 is missing or mismatched in main/core.
goto failed
:wrong_recognition_only
echo [ERROR] scanner_core.py is missing 1.2.69-known-roi-batched-recognition-only.
goto failed

:wrong_single_card_batch
echo [ERROR] Main/core single-card OCR batching markers are missing or mismatched.
goto failed
:wrong_dynamic_confirm
echo [ERROR] scanner_actions.py is missing the dynamic confirm baseline marker.
goto failed

:wrong_fast_coordinate
echo [ERROR] Stable v1.2.71 fixed-coordinate fast-flow marker is missing or mismatched in the v1.2.75 build.
goto failed

:wrong_market_capture
echo [ERROR] scanner_core.py is missing the persistent DXcam market-ROI source.
goto failed
:wrong_return_recovery
echo [ERROR] scanner_actions.py is missing 1.2.66-return-market-recover.
goto failed

:wrong_button_probe
echo [ERROR] scanner_actions.py is missing the 2K off-text button probe fix. Extract the complete matching 2K hotfix kit.
goto failed
:wrong_core
echo [ERROR] scanner_core.py is not 1.2.60-position-independent-discount-watch.
goto failed
:wrong_discount_core
echo [ERROR] scanner_core.py does not include detail-discount retry-confirm patch 1.2.65. Extract the complete matching hotfix kit.
goto failed

:wrong_speed_core
echo [ERROR] scanner_core.py is missing 1.2.60-responsive-ui-fast-detail.
goto failed
:wrong_capture_core
echo [ERROR] scanner_core.py is missing 1.2.63-shared-watch-frame-detail-capture.
goto failed
:wrong_click_speed
echo [ERROR] scanner_actions.py is missing 1.2.65-fast-coalesce-compact-detail-ocr.
goto failed
:wrong_click_timer
echo [ERROR] scanner_actions.py is missing the cancellable high-resolution wait-timer patch.
goto failed
:wrong_dpi_bootstrap
echo [ERROR] main.py is missing the early runtime DPI bootstrap.
goto failed
:exe_missing
echo [ERROR] PyInstaller completed but the EXE is missing.
goto failed
:too_small
echo [ERROR] The EXE is unexpectedly small; refusing to publish a potentially incomplete build.
goto failed
:ocr_prepare_failed
echo [ERROR] OCR models could not be prepared for bundling. Check internet access and RapidOCR diagnostics.
goto failed
:tests_failed
echo [ERROR] Automated tests failed. Full test output follows; log saved as NGMS_BUILD_TESTS.log.
type NGMS_BUILD_TESTS.log
goto failed
:failed
echo.
echo SINGLE-EXE BUILD FAILED. Send the FIRST [ERROR] line from this window.
pause
exit /b 1
