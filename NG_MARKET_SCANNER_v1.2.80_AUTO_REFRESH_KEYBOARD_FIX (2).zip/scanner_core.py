"""Fast external OCR worker for NG Market Scanner.

v1.2.54: configurable color-first or all-card OCR with persistent RapidOCR sessions and safe eligibility gates,
aligned within a small pixel tolerance so only changed text fields are re-read.
All buying eligibility rules remain fail-closed and live configuration changes
invalidate the OCR-result cache.
"""
from __future__ import annotations

import copy
import hashlib
from collections import deque
import json
import os
import re
import sys
import threading
import time
import traceback
from datetime import datetime
from pathlib import Path

from PySide6.QtCore import QThread, Signal

from scanner_core_logic import (
    clean_model_text,
    normalize_vehicle_key,
    match_catalog_model,
    parse_price,
    format_price,
    classify_badge_color,
    resolve_discount,
    build_candidate_status,
    match_informational_model,
    effective_threshold,
    group_montage_ocr,
    changed_card_indices,
    should_stabilize_initial_color_capture,
    parse_percent,
)

OCR_PATCH_VERSION = "1.2.60-position-independent-discount-watch"
DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION = "1.2.65-retry-confirm-detail-discount"
WATCH_FINGERPRINT_PATCH_VERSION = "1.2.65-perceptual-offer-dedupe"
DETAIL_OCR_FASTPATH_PATCH_VERSION = "1.2.65-compact-detail-ocr"
OCR_SPEED_PATCH_VERSION = "1.2.60-responsive-ui-fast-detail"
DETAIL_CAPTURE_CACHE_PATCH_VERSION = "1.2.63-shared-watch-frame-detail-capture"
CAPTURE_OPTIMIZATION_PATCH_VERSION = "1.2.67-persistent-dxcam-market-roi"
CAPTURE_COLOR_FASTPATH_PATCH_VERSION = "1.2.68-dxcam-bgra-fastpath"
RECOGNITION_ONLY_PATCH_VERSION = "1.2.69-known-roi-batched-recognition-only"
SINGLE_CARD_BATCH_PATCH_VERSION = "1.2.70-single-card-batched-recognition-only"
BADGE_COLOR_VECTOR_PATCH_VERSION = "1.2.72-vectorized-badge-sampling"
PURCHASE_DIAGNOSTICS_PATCH_VERSION = "1.2.73-offer-signature-dedupe-and-scan-profile"
FAST_BADGE_CONSENSUS_PATCH_VERSION = "1.2.74-fast-badge-consensus-no-detector-fallback"
MARKET_RETURN_GATE_PATCH_VERSION = "1.2.75-market-return-state-gate"

# Persist the first GPU warm-up failure even when a CPU fallback succeeds. This is
# included in last_scan_diagnostics.json so provider failures are diagnosable.
_OCR_LAST_WARMUP_ERROR = ""
_OCR_LAST_WARMUP_TRACEBACK = ""
# Keep detailed constructor/provider errors: these happen before OCR warmup and
# were previously discarded, making a CPU fallback impossible to diagnose.
_OCR_LAST_INIT_ERRORS = []

# The engine and card cache belong to this sidecar module. main.py caches the
# imported sidecar, so the same OCR sessions/cache survive every scan cycle.
_OCR_ENGINE = None
_OCR_ENGINE_LOCK = threading.RLock()
_OCR_ENGINE_INIT_SECONDS = 0.0
_OCR_ENGINE_WARMUP_SECONDS = 0.0
_OCR_ENGINE_CONFIG = "not-initialized"

# Persistent MSS capture avoids reinitializing the Windows capture backend for every
# validation. The first instance is created during warm-up, before the market watcher
# is enabled. Access is serialized because the same session may be reused by a QThread
# and the action worker.
_DETAIL_CAPTURE_LOCK = threading.RLock()
_DETAIL_CAPTURE = None
_DETAIL_CAPTURE_FACTORY = None
_DETAIL_CAPTURE_INIT_SECONDS = 0.0
_DETAIL_CAPTURE_LAST_ERROR = ""

# Persistent DXcam/DXGI source for the main market-grid scanner.
# One capture thread serves all single-flight ScanWorker cycles. The scan loop
# reads a small ROI rather than re-creating a full-screen MSS grab every pass.
MARKET_CAPTURE_PATCH_VERSION = "1.2.67-persistent-dxcam-market-roi"
_MARKET_CAPTURE_LOCK = threading.RLock()
_MARKET_CAPTURE_CAMERA = None
_MARKET_CAPTURE_REGION = None
_MARKET_CAPTURE_SCREEN_SIZE = None
_MARKET_CAPTURE_ORIGIN = (0, 0)
_MARKET_CAPTURE_DESKTOP_ORIGIN = (0, 0)
_MARKET_CAPTURE_BACKEND = "not-started"
_MARKET_CAPTURE_COLOR_MODE = "not-started"
_MARKET_CAPTURE_LAST_ERROR = ""
_MARKET_CAPTURE_FPS = 120

def _market_capture_region(grid, screen_size, margin_ratio=0.02):
    """Return a clipped DXcam region covering the configured normalized market grid."""
    screen_w, screen_h = int(screen_size[0]), int(screen_size[1])
    if screen_w < 320 or screen_h < 240:
        raise ValueError("invalid primary monitor size")
    g = grid or {}
    left = float(g.get("left", .153)); top = float(g.get("top", .095))
    right = float(g.get("right", .985)); bottom = float(g.get("bottom", .895))
    if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
        raise ValueError("invalid normalized market grid")
    mx = max(12, int(screen_w * float(margin_ratio)))
    my = max(12, int(screen_h * float(margin_ratio)))
    x0 = max(0, int(left * screen_w) - mx)
    y0 = max(0, int(top * screen_h) - my)
    x1 = min(screen_w, int(right * screen_w) + mx)
    y1 = min(screen_h, int(bottom * screen_h) + my)
    if x1 - x0 < 100 or y1 - y0 < 100:
        raise ValueError("market capture region is too small")
    return (x0, y0, x1, y1)

def _primary_screen_size():
    """Read physical primary-monitor pixels without creating a screen-capture session."""
    try:
        import ctypes
        user32 = ctypes.windll.user32
        width, height = int(user32.GetSystemMetrics(0)), int(user32.GetSystemMetrics(1))
        if width >= 320 and height >= 240:
            return (width, height)
    except Exception:
        pass
    return None

def _dispose_market_camera(camera):
    """Best-effort stop/release for a DXcam object, including failed startup."""
    if camera is None:
        return
    try:
        camera.stop()
    except Exception:
        pass
    try:
        release = getattr(camera, "release", None)
        if callable(release):
            release()
    except Exception:
        pass

def _close_market_capture_locked():
    """Stop the cached DXcam camera. Caller must hold _MARKET_CAPTURE_LOCK."""
    global _MARKET_CAPTURE_CAMERA, _MARKET_CAPTURE_REGION, _MARKET_CAPTURE_SCREEN_SIZE
    global _MARKET_CAPTURE_ORIGIN, _MARKET_CAPTURE_DESKTOP_ORIGIN, _MARKET_CAPTURE_BACKEND
    global _MARKET_CAPTURE_COLOR_MODE
    camera = _MARKET_CAPTURE_CAMERA
    _MARKET_CAPTURE_CAMERA = None
    _MARKET_CAPTURE_REGION = None
    _MARKET_CAPTURE_SCREEN_SIZE = None
    _MARKET_CAPTURE_ORIGIN = (0, 0)
    _MARKET_CAPTURE_DESKTOP_ORIGIN = (0, 0)
    _MARKET_CAPTURE_BACKEND = "not-started"
    _MARKET_CAPTURE_COLOR_MODE = "not-started"
    _dispose_market_camera(camera)

def close_market_capture():
    """Public cleanup hook used at app shutdown and by tests."""
    with _MARKET_CAPTURE_LOCK:
        _close_market_capture_locked()

def _read_latest_dxcam_frame(camera, wait_timeout_seconds=0.0, include_view_info=False):
    """Read the newest DXcam frame.

    Prefer the zero-copy view API and let the caller detach the final BGR ROI in
    one copy. Older DXcam builds may not expose ``copy=False``; in that case the
    default API already returns an owned copy, which should not be copied again.
    ``include_view_info=True`` adds a third bool telling the caller whether the
    returned array aliases DXcam's ring buffer.
    """
    deadline = time.perf_counter() + max(0.0, float(wait_timeout_seconds))
    while True:
        is_ring_buffer_view = False
        try:
            value = camera.get_latest_frame(copy=False, with_timestamp=True)
            is_ring_buffer_view = True
        except TypeError:
            try:
                value = camera.get_latest_frame(with_timestamp=True)
            except TypeError:
                value = camera.get_latest_frame()
            # Legacy calls use the API's default copy=True semantics.
            is_ring_buffer_view = False
        if isinstance(value, tuple) and len(value) >= 2:
            frame, timestamp = value[0], value[1]
        else:
            frame, timestamp = value, None
        if frame is not None:
            if include_view_info:
                return frame, timestamp, is_ring_buffer_view
            # Safe public/default behavior: never expose a mutable ring-buffer view.
            if is_ring_buffer_view:
                copier = getattr(frame, "copy", None)
                if callable(copier):
                    frame = copier()
                else:
                    raise RuntimeError("DXcam frame view cannot be copied safely")
            return frame, timestamp
        if time.perf_counter() >= deadline:
            raise RuntimeError("DXcam did not provide a fresh frame")
        # Startup-only wait: DXcam creates its capture thread asynchronously.
        # A 1-ms sleep avoids busy-spinning without adding a fixed delay.
        time.sleep(0.001)


def _capture_market_frame(grid, np_module, screen_size_override=None):
    """Return (frame, frame_origin, desktop_origin, screen_size, backend, seconds, timestamp).

    DXcam is started once for a 120-FPS ROI and reused across cycles. A stable,
    persistent MSS session is the compatibility fallback; no new MSS instance is
    created for every scan.
    """
    global _MARKET_CAPTURE_CAMERA, _MARKET_CAPTURE_REGION, _MARKET_CAPTURE_SCREEN_SIZE
    global _MARKET_CAPTURE_ORIGIN, _MARKET_CAPTURE_DESKTOP_ORIGIN
    global _MARKET_CAPTURE_BACKEND, _MARKET_CAPTURE_COLOR_MODE, _MARKET_CAPTURE_LAST_ERROR
    started = time.perf_counter()
    camera = None
    camera_just_started = False
    size = tuple(int(v) for v in screen_size_override) if screen_size_override else _primary_screen_size()
    if size and len(size) == 2 and size[0] >= 320 and size[1] >= 240:
        try:
            region = _market_capture_region(grid, size)
            with _MARKET_CAPTURE_LOCK:
                if (_MARKET_CAPTURE_CAMERA is None or _MARKET_CAPTURE_REGION != region
                        or _MARKET_CAPTURE_SCREEN_SIZE != size):
                    camera_just_started = True
                    _close_market_capture_locked()
                    import dxcam
                    # DXcam's native duplication surface is BGRA. Requesting BGRA
                    # avoids an additional provider-side color conversion; we strip
                    # alpha while making the one stable BGR copy required by OCR.
                    try:
                        camera = dxcam.create(output_idx=0, output_color="BGRA", max_buffer_len=2)
                        color_mode = "BGRA fast path"
                    except Exception as bgra_exc:
                        # Compatibility fallback for older builds/drivers that reject BGRA.
                        try:
                            camera = dxcam.create(output_idx=0, output_color="BGR", max_buffer_len=2)
                            color_mode = "BGR compatibility fallback"
                        except Exception as bgr_exc:
                            raise RuntimeError(
                                f"DXcam BGRA and BGR initialization failed: "
                                f"BGRA={type(bgra_exc).__name__}: {bgra_exc}; "
                                f"BGR={type(bgr_exc).__name__}: {bgr_exc}"
                            ) from bgr_exc
                    capture_origin = (region[0], region[1])
                    backend = f"DXGI/DXcam persistent ROI {color_mode} {region[2]-region[0]}x{region[3]-region[1]} @120 target"
                    try:
                        camera.start(region=region, target_fps=_MARKET_CAPTURE_FPS, video_mode=False)
                    except TypeError:
                        # Older DXcam versions do not support a region argument. Keep
                        # the same persistent camera but use the full primary frame.
                        try:
                            camera.stop()
                        except Exception:
                            pass
                        camera.start(target_fps=_MARKET_CAPTURE_FPS, video_mode=False)
                        capture_origin = (0, 0)
                        backend = "DXGI/DXcam persistent full-frame @120 target (region API fallback)"
                    _MARKET_CAPTURE_CAMERA = camera
                    _MARKET_CAPTURE_REGION = region
                    _MARKET_CAPTURE_SCREEN_SIZE = size
                    _MARKET_CAPTURE_ORIGIN = capture_origin
                    _MARKET_CAPTURE_DESKTOP_ORIGIN = (0, 0)
                    _MARKET_CAPTURE_BACKEND = backend
                    _MARKET_CAPTURE_COLOR_MODE = color_mode
                camera = _MARKET_CAPTURE_CAMERA
                # The very first frame may arrive a few milliseconds after start().
                # Wait only for a newly-created camera; established capture cycles remain
                # non-blocking so a stalled DXcam quickly falls back to persistent MSS.
                frame, timestamp, frame_is_ring_buffer_view = _read_latest_dxcam_frame(
                    camera,
                    wait_timeout_seconds=0.040 if camera_just_started else 0.002,
                    include_view_info=True,
                )
                frame = np_module.asarray(frame)
                if frame.ndim != 3 or frame.shape[2] < 3 or frame.size == 0:
                    raise RuntimeError("DXcam frame has unexpected shape")
                origin = _MARKET_CAPTURE_ORIGIN
                expected_roi = (region[3]-region[1], region[2]-region[0])
                if origin != (0, 0) and frame.shape[:2] != expected_roi:
                    # Do not crop with a mismatched origin: release DXcam and use MSS.
                    raise RuntimeError(f"DXcam ROI shape mismatch: {frame.shape[:2]} != {expected_roi}")
                if origin == (0, 0) and frame.shape[:2] != (size[1], size[0]):
                    raise RuntimeError(f"DXcam full-frame shape mismatch: {frame.shape[:2]} != {(size[1], size[0])}")
                if _MARKET_CAPTURE_COLOR_MODE.startswith("BGRA") or frame_is_ring_buffer_view:
                    # Exactly one detach/conversion copy for BGRA or ring-buffer views.
                    # A legacy owned BGR array can safely be sliced without a second copy.
                    screenshot = frame[:, :, :3].copy()
                else:
                    screenshot = frame[:, :, :3]
                _MARKET_CAPTURE_LAST_ERROR = ""
                return (screenshot, origin, _MARKET_CAPTURE_DESKTOP_ORIGIN, size,
                        _MARKET_CAPTURE_BACKEND, max(0.0, time.perf_counter()-started), timestamp)
        except Exception as capture_exc:
            _MARKET_CAPTURE_LAST_ERROR = f"{type(capture_exc).__name__}: {capture_exc}"
            with _MARKET_CAPTURE_LOCK:
                # If camera.start() failed before publishing the object globally, it
                # would otherwise leak an initialized DXcam resource on the MSS path.
                if camera is not None and camera is not _MARKET_CAPTURE_CAMERA:
                    _dispose_market_camera(camera)
                _close_market_capture_locked()

    # Safe fallback: reuse the existing MSS session under its lock rather than
    # repeatedly creating a new mss.mss() object during each 20-ms poll.
    import mss as mss_module
    with _DETAIL_CAPTURE_LOCK:
        capture = _get_detail_capture(mss_module)
        monitor = capture.monitors[1] if len(capture.monitors) > 1 else capture.monitors[0]
        desktop_left = int(monitor.get("left", 0)); desktop_top = int(monitor.get("top", 0))
        screen = (int(monitor.get("width", 0)), int(monitor.get("height", 0)))
        if screen[0] <= 0 or screen[1] <= 0:
            raise RuntimeError("MSS did not report primary-monitor dimensions")
        raw = capture.grab(monitor)
        screenshot = np_module.asarray(raw)[:, :, :3].copy()
    return (screenshot, (0, 0), (desktop_left, desktop_top), screen,
            "MSS persistent full-screen fallback", max(0.0, time.perf_counter()-started), None)

try:
    import atexit as _capture_atexit
    _capture_atexit.register(close_market_capture)
except Exception:
    pass

def _get_detail_capture(mss_module=None):
    global _DETAIL_CAPTURE, _DETAIL_CAPTURE_FACTORY, _DETAIL_CAPTURE_INIT_SECONDS, _DETAIL_CAPTURE_LAST_ERROR
    if mss_module is None:
        import mss as mss_module
    factory = getattr(mss_module, "mss")
    with _DETAIL_CAPTURE_LOCK:
        if _DETAIL_CAPTURE is not None and _DETAIL_CAPTURE_FACTORY is factory:
            return _DETAIL_CAPTURE
        previous = _DETAIL_CAPTURE
        if previous is not None:
            try:
                previous.close()
            except Exception:
                pass
        started = time.perf_counter()
        capture = factory()
        _DETAIL_CAPTURE = capture
        _DETAIL_CAPTURE_FACTORY = factory
        _DETAIL_CAPTURE_INIT_SECONDS = max(0.0, time.perf_counter() - started)
        _DETAIL_CAPTURE_LAST_ERROR = ""
        return capture

def _close_detail_capture():
    global _DETAIL_CAPTURE, _DETAIL_CAPTURE_FACTORY
    with _DETAIL_CAPTURE_LOCK:
        capture = _DETAIL_CAPTURE
        _DETAIL_CAPTURE = None
        _DETAIL_CAPTURE_FACTORY = None
        if capture is not None:
            try:
                capture.close()
            except Exception:
                pass


# Shared fresh frames from the active direct green watcher avoid a second, slow MSS
# grab for the detail panel. Frames are published only while the watcher is paused on
# a purchase candidate, and the validator requires a frame captured after CARD_CLICK.
_WATCH_DETAIL_FRAME_LOCK = threading.RLock()
_WATCH_DETAIL_FRAME = None
_WATCH_DETAIL_FRAME_META = None
_WATCH_DETAIL_FRAME_LAST_COPY_AT = 0.0
_WATCH_DETAIL_FRAME_MIN_COPY_INTERVAL = 1.0 / 30.0

def _publish_watch_detail_frame(frame, screen_size, capture_origin, target_hwnd=None):
    global _WATCH_DETAIL_FRAME, _WATCH_DETAIL_FRAME_META, _WATCH_DETAIL_FRAME_LAST_COPY_AT
    now = time.perf_counter()
    with _WATCH_DETAIL_FRAME_LOCK:
        if now - _WATCH_DETAIL_FRAME_LAST_COPY_AT < _WATCH_DETAIL_FRAME_MIN_COPY_INTERVAL:
            return
        try:
            _WATCH_DETAIL_FRAME = frame.copy()
            _WATCH_DETAIL_FRAME_META = {
                'captured_at': now,
                'screen_size': (int(screen_size[0]), int(screen_size[1])),
                'origin': (int(capture_origin[0]), int(capture_origin[1])),
                'target_hwnd': int(target_hwnd) if target_hwnd not in (None, 0, '0') else None,
            }
            _WATCH_DETAIL_FRAME_LAST_COPY_AT = now
        except Exception:
            # Detail validation can safely fall back to the independent MSS path.
            pass

def _latest_watch_detail_panel(target_hwnd=None, not_before_perf_counter=None, max_age_seconds=1.5):
    """Return a copy of the right-hand detail panel from a fresh watcher frame, if available."""
    with _WATCH_DETAIL_FRAME_LOCK:
        frame = _WATCH_DETAIL_FRAME
        meta = dict(_WATCH_DETAIL_FRAME_META or {})
        if frame is None or not meta:
            return None
        captured_at = float(meta.get('captured_at') or 0.0)
        now = time.perf_counter()
        if captured_at <= 0.0 or now - captured_at > float(max_age_seconds):
            return None
        if not_before_perf_counter is not None and captured_at + 1e-6 < float(not_before_perf_counter):
            return None
        wanted = int(target_hwnd) if target_hwnd not in (None, 0, '0') else None
        if meta.get('target_hwnd') != wanted:
            return None
        try:
            frame = frame.copy()
        except Exception:
            return None
    try:
        screen_w, screen_h = meta['screen_size']
        origin_x, origin_y = meta['origin']
        # Same normalized detail-panel ROI as the independent MSS capture, translated
        # into the watcher's ROI coordinates (the watcher usually captures only part of screen).
        x0, x1 = int(.690 * screen_w) - origin_x, int(.990 * screen_w) - origin_x
        y0, y1 = int(.135 * screen_h) - origin_y, int(.295 * screen_h) - origin_y
        if x0 < 0 or y0 < 0 or x1 > frame.shape[1] or y1 > frame.shape[0] or x1 <= x0 or y1 <= y0:
            return None
        panel = frame[y0:y1, x0:x1].copy()
        if panel.size == 0:
            return None
        return panel, {'screen_size': (screen_w, screen_h), 'origin': (origin_x, origin_y),
                       'captured_at': captured_at, 'capture_backend': 'shared-direct-watch-frame'}
    except Exception:
        return None

try:
    import atexit as _detail_capture_atexit
    _detail_capture_atexit.register(_close_detail_capture)
except Exception:
    pass

_CARD_CACHE_LOCK = threading.RLock()
_CARD_CACHE_SIGNATURES = None
_CARD_CACHE_RESULTS = None
_CARD_CACHE_FIELD_SIGNATURES = None
# Per-field retry timestamps prevent unchanged, uncertain OCR fields from being re-run every 1 Hz poll.
_CARD_CACHE_FIELD_LAST_OCR_AT = {}
_UNCERTAIN_FIELD_RETRY_SECONDS = 12.0
_CARD_CACHE_CONFIG_KEY = None
_CARD_CACHE_SCREEN_KEY = None
_DIAGNOSTICS_LOCK = threading.RLock()
_LAST_DIAGNOSTICS_WRITE_AT = 0.0

# RapidOCR 3.4.1 documents dotted parameter names and DirectML through
# EngineConfig.onnxruntime.use_dml. Active providers are checked after warmup.
_FAST_OCR_PARAMS = {
    "Global.use_cls": False,                  # all market text is horizontal
    "Global.log_level": "warning",
    "Global.max_side_len": 1400,
    "Det.lang_type": "en",                  # market listings use Latin text and digits
    "Rec.lang_type": "en",
    "Det.limit_side_len": 736,
    "Det.limit_type": "max",                 # cap the long side; avoid oversized montage inference
    "Det.max_candidates": 160,
    "Det.use_dilation": False,
    "Rec.rec_batch_num": 48,                  # recognize multiple crop rows in one batch
    "EngineConfig.onnxruntime.intra_op_num_threads": 4,
    "EngineConfig.onnxruntime.inter_op_num_threads": 1,
}


def _rapidocr_typed_params(params):
    """Convert RapidOCR 3.x enum-backed lang settings from strings to enums.

    RapidOCR 3.4.1 rejects strings for Det.lang_type and Rec.lang_type even though
    their YAML equivalents are strings. Its Python ``params`` API requires the
    exported LangDet/LangRec enum instances. Keeping conversion at construction time
    preserves string templates in diagnostics/config assembly and avoids importing
    RapidOCR at scanner module import time.
    """
    typed = dict(params or {})
    if "Det.lang_type" in typed or "Rec.lang_type" in typed:
        from rapidocr import LangDet, LangRec

        if "Det.lang_type" in typed:
            value = getattr(typed["Det.lang_type"], "value", typed["Det.lang_type"])
            if not isinstance(value, LangDet):
                typed["Det.lang_type"] = LangDet(str(value).strip().lower())
        if "Rec.lang_type" in typed:
            value = getattr(typed["Rec.lang_type"], "value", typed["Rec.lang_type"])
            if not isinstance(value, LangRec):
                typed["Rec.lang_type"] = LangRec(str(value).strip().lower())
    return typed


def _engine_config_attempts(available_providers):
    """Build configs for maintained RapidOCR 3.x, preferring actual GPU providers."""
    providers = set(available_providers or [])
    attempts = []
    if "CUDAExecutionProvider" in providers:
        attempts.append(("cuda-fast", {
            **_FAST_OCR_PARAMS,
            "EngineConfig.onnxruntime.use_cuda": True,
            "EngineConfig.onnxruntime.use_dml": False,
        }))
    if "DmlExecutionProvider" in providers:
        attempts.append(("directml-fast", {
            **_FAST_OCR_PARAMS,
            "EngineConfig.onnxruntime.use_cuda": False,
            "EngineConfig.onnxruntime.use_dml": True,
        }))
    attempts.extend([
        ("fast-cpu-fallback", {
            **_FAST_OCR_PARAMS,
            "EngineConfig.onnxruntime.use_cuda": False,
            "EngineConfig.onnxruntime.use_dml": False,
        }),
        ("common-fast-cpu", {
            "Global.use_cls": False,
            "Global.max_side_len": 1400,
            "Det.lang_type": "en",
            "Det.limit_side_len": 736,
            "Det.limit_type": "max",
            "Det.max_candidates": 160,
            "Rec.lang_type": "en",
            "Rec.rec_batch_num": 48,
        }),
    ])
    return attempts


def _same_target_window_or_process(target_hwnd, foreground_hwnd, target_root=None,
                                   foreground_root=None, target_pid=None, foreground_pid=None):
    """Pure helper: accept an exact HWND, its owned/root window, or another HWND in the same process."""
    try:
        target = int(target_hwnd or 0)
        foreground = int(foreground_hwnd or 0)
    except (TypeError, ValueError):
        return False
    if target <= 0 or foreground <= 0:
        return False
    if target == foreground:
        return True
    try:
        if int(target_root or 0) > 0 and int(target_root) == int(foreground_root or 0):
            return True
    except (TypeError, ValueError):
        pass
    try:
        target_process = int(target_pid or 0)
        foreground_process = int(foreground_pid or 0)
        return target_process > 0 and target_process == foreground_process
    except (TypeError, ValueError):
        return False


def _foreground_matches_target(target_hwnd, foreground_hwnd=None):
    """Fail closed unless foreground belongs to the target game window/process.

    Supplying ``foreground_hwnd`` retains exact-match semantics for deterministic unit
    tests. At runtime, owned modal/root windows and top-level windows in the same game
    process are also accepted; purchases can temporarily change HWND during transitions,
    while the app must still reject an unrelated foreground process.
    """
    if target_hwnd in (None, 0):
        return True
    if foreground_hwnd is not None:
        return _same_target_window_or_process(target_hwnd, foreground_hwnd)
    if os.name != "nt":
        return True
    try:
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        target = int(target_hwnd)
        user32.GetForegroundWindow.restype = wintypes.HWND
        foreground = int(user32.GetForegroundWindow() or 0)
        if _same_target_window_or_process(target, foreground):
            return True
        if foreground <= 0 or not user32.IsWindow(wintypes.HWND(target)) or not user32.IsWindow(wintypes.HWND(foreground)):
            return False

        user32.GetAncestor.argtypes = [wintypes.HWND, ctypes.c_uint]
        user32.GetAncestor.restype = wintypes.HWND
        target_root = int(user32.GetAncestor(wintypes.HWND(target), 3) or 0)  # GA_ROOTOWNER
        foreground_root = int(user32.GetAncestor(wintypes.HWND(foreground), 3) or 0)

        user32.GetWindowThreadProcessId.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.DWORD)]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        target_pid = wintypes.DWORD()
        foreground_pid = wintypes.DWORD()
        user32.GetWindowThreadProcessId(wintypes.HWND(target), ctypes.byref(target_pid))
        user32.GetWindowThreadProcessId(wintypes.HWND(foreground), ctypes.byref(foreground_pid))
        return _same_target_window_or_process(
            target, foreground, target_root, foreground_root,
            target_pid.value, foreground_pid.value)
    except Exception:
        return False


def _available_onnxruntime_providers():
    try:
        import onnxruntime as ort
        return list(ort.get_available_providers())
    except Exception:
        return []


def _active_engine_providers(engine):
    """Find providers from actual ONNX sessions without depending on private class names."""
    found = []
    seen = set()
    stack = [(engine, 0)]
    while stack:
        obj, depth = stack.pop()
        if obj is None or id(obj) in seen or depth > 5:
            continue
        seen.add(id(obj))
        get_providers = getattr(obj, "get_providers", None)
        if callable(get_providers):
            try:
                for name in get_providers() or []:
                    if str(name) not in found:
                        found.append(str(name))
            except Exception:
                pass
        if isinstance(obj, dict):
            children = list(obj.values())[:30]
        elif isinstance(obj, (list, tuple)):
            children = list(obj)[:30]
        else:
            try:
                children = list(vars(obj).values())[:40]
            except Exception:
                children = []
        for child in children:
            if isinstance(child, (str, bytes, int, float, bool, type(None))):
                continue
            if hasattr(child, "shape") and hasattr(child, "dtype"):
                continue
            stack.append((child, depth + 1))
    return found


def _provider_label(engine=None):
    active = _active_engine_providers(engine) if engine is not None else []
    if active:
        return "+".join(active)
    available = _available_onnxruntime_providers()
    return "available-only:" + "+".join(available) if available else "unknown-or-cpu"



class _RapidOCRAdapter:
    """Normalize RapidOCR 3.x output to the scanner's historical tuple format.

    The scan pipeline expects ``engine(image) -> (rows, elapsed)`` where each row
    is ``[box, text, confidence]``. RapidOCR 3.x returns RapidOCROutput with
    ``boxes``, ``txts``, ``scores`` and ``elapse`` fields.
    """
    def __init__(self, engine):
        self._engine = engine

    def __getattr__(self, name):
        return getattr(self._engine, name)

    def __call__(self, image):
        result = self._engine(image)
        if isinstance(result, tuple) and len(result) == 2:
            # Useful for injected test doubles and backwards-compatible adapters.
            return result
        boxes = getattr(result, "boxes", None)
        texts = getattr(result, "txts", None)
        scores = getattr(result, "scores", None)
        rows = []
        if boxes is not None and texts is not None and scores is not None:
            for box, text, score in zip(boxes, texts, scores):
                box_value = box.tolist() if hasattr(box, "tolist") else box
                try:
                    confidence = float(score)
                except (TypeError, ValueError):
                    confidence = 0.0
                rows.append([box_value, str(text), confidence])
        elapsed = getattr(result, "elapse", None)
        if elapsed is None:
            elapsed_values = getattr(result, "elapse_list", None) or ()
            try:
                elapsed = sum(float(value or 0.0) for value in elapsed_values)
            except (TypeError, ValueError):
                elapsed = 0.0
        try:
            elapsed = float(elapsed or 0.0)
        except (TypeError, ValueError):
            elapsed = 0.0
        return rows, elapsed

    def recognize_crops(self, images):
        """Batch-recognize pre-cropped, horizontal text lines without detector/classifier.

        The market scanner already knows the exact ROI for each title, price and badge.
        RapidOCR's own recognition stage accepts a list of image crops, so this bypasses
        redundant text detection and direction classification. Returns ``[(text, score), ...]``
        in input order, or ``(None, elapsed)`` when this RapidOCR build cannot expose the
        recognition-only path; callers then use the proven detector-based fallback.
        """
        started = time.perf_counter()
        if not images:
            return [], 0.0
        try:
            import numpy as np_module
            underlying = self._engine
            loader = getattr(underlying, "_load_rec_model", None)
            if callable(loader):
                loader()
            recognize = getattr(underlying, "recognize_txt", None)
            if not callable(recognize):
                return None, time.perf_counter() - started
            stable_images = []
            for image in images:
                if image is None or getattr(image, "size", 0) == 0:
                    return None, time.perf_counter() - started
                arr = np_module.asarray(image)
                if arr.ndim == 2:
                    arr = np_module.repeat(arr[:, :, None], 3, axis=2)
                elif arr.ndim == 3 and arr.shape[2] == 4:
                    arr = arr[:, :, :3]
                if arr.ndim != 3 or arr.shape[2] != 3:
                    return None, time.perf_counter() - started
                stable_images.append(np_module.ascontiguousarray(arr))
            result = recognize(stable_images)
            texts = getattr(result, "txts", None)
            scores = getattr(result, "scores", None)
            if texts is None or scores is None or len(texts) != len(stable_images) or len(scores) != len(stable_images):
                return None, time.perf_counter() - started
            decoded = []
            for text, score in zip(texts, scores):
                try:
                    confidence = float(score) if score is not None else 0.0
                except (TypeError, ValueError):
                    confidence = 0.0
                decoded.append((str(text or "").strip(), confidence))
            return decoded, time.perf_counter() - started
        except Exception:
            # A private RapidOCR API change must never disable the established OCR path.
            return None, time.perf_counter() - started


def _prepare_known_text_crop(image, field='text', target_height=48, enhanced=False):
    """Prepare a known single-line ROI for RapidOCR recognition-only inference.

    The caller already knows which UI field is in the crop, so this removes empty
    background around the glyphs and normalizes line height. It does not infer text
    or alter any purchase rule. When foreground extraction is inconclusive, the
    original crop is kept; detector-based OCR remains the caller's fallback.
    """
    try:
        import cv2
        import numpy as np
        if image is None or getattr(image, 'size', 0) == 0:
            return None
        arr=np.asarray(image)
        if arr.ndim==2:
            arr=cv2.cvtColor(arr, cv2.COLOR_GRAY2BGR)
        elif arr.ndim==3 and arr.shape[2]>=4:
            arr=arr[:,:,:3]
        if arr.ndim!=3 or arr.shape[2]!=3 or arr.size==0:
            return None
        arr=np.ascontiguousarray(arr)
        h,w=arr.shape[:2]
        if h<2 or w<2:
            return None

        gray=cv2.cvtColor(arr,cv2.COLOR_BGR2GRAY)
        median=float(np.percentile(gray,50))
        # Text is brighter than the dark market panel; a relative threshold also
        # works for green badges because the letter strokes are brighter than the
        # badge's green fill. Padding preserves anti-aliased edge pixels.
        threshold=max(44,min(185,int(median+28)))
        mask=gray>threshold
        ys,xs=np.where(mask)
        if len(xs)>=5:
            x0,x1=int(xs.min()),int(xs.max())+1
            y0,y1=int(ys.min()),int(ys.max())+1
            # Ignore rare nearly-full-frame detections: those usually mean the UI
            # background is bright and a contrast mask cannot identify text safely.
            bw,bh=x1-x0,y1-y0
            if bw>=4 and bh>=3 and (bw < .97*w or bh < .90*h):
                px=max(2,min(8,int(round(bh*.14))))
                py=max(2,min(5,int(round(bh*.12))))
                arr=arr[max(0,y0-py):min(h,y1+py),max(0,x0-px):min(w,x1+px)]

        if enhanced:
            eg=cv2.cvtColor(arr,cv2.COLOR_BGR2GRAY)
            eg=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(4,2)).apply(eg)
            eg=cv2.threshold(eg,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
            arr=cv2.cvtColor(eg,cv2.COLOR_GRAY2BGR)

        h,w=arr.shape[:2]
        target_height=max(24,int(target_height))
        scale=float(target_height)/max(1,h)
        # Prevent pathological long inputs from exploding recognizer tensor width.
        scale=min(scale,720.0/max(1,w))
        nw=max(8,int(round(w*scale)))
        nh=max(16,int(round(h*scale)))
        interpolation=cv2.INTER_CUBIC if scale>=1.0 else cv2.INTER_AREA
        resized=cv2.resize(arr,(nw,nh),interpolation=interpolation)
        return np.ascontiguousarray(resized)
    except Exception:
        return None


def _recognize_known_roi_batch(engine, crops, field='text', target_height=48, enhanced=False):
    """Fast batched recognition for a list of already-localized text-line crops.

    Returns (recognized, elapsed) or (None, elapsed) for unsupported/unreliable API
    access. Each recognized entry is (text, confidence), aligned to input crop order.
    """
    started=time.perf_counter()
    try:
        recognize=getattr(engine,'recognize_crops',None)
        if not callable(recognize) or not crops:
            return None,time.perf_counter()-started
        field_names=list(field) if isinstance(field,(list,tuple)) else [field]*len(crops)
        if len(field_names)!=len(crops):
            return None,time.perf_counter()-started
        prepared=[_prepare_known_text_crop(crop,field_names[index],target_height,enhanced) for index,crop in enumerate(crops)]
        if any(crop is None or getattr(crop,'size',0)==0 for crop in prepared):
            return None,time.perf_counter()-started
        result,reported_elapsed=recognize(prepared)
        if result is None or len(result)!=len(prepared):
            return None,time.perf_counter()-started
        normalized=[]
        for item in result:
            if not isinstance(item,(tuple,list)) or len(item)<2:
                return None,time.perf_counter()-started
            try: confidence=float(item[1] or 0.0)
            except (TypeError,ValueError): confidence=0.0
            normalized.append((str(item[0] or '').strip(),confidence))
        elapsed=max(time.perf_counter()-started,float(reported_elapsed or 0.0))
        return normalized,elapsed
    except Exception:
        return None,time.perf_counter()-started


def _resolve_discount_ocr_evidence(candidate, evidence_rows):
    """Resolve repeated badge readings conservatively, allowing a clear 2-of-3 consensus.

    Two conflicting reads remain ambiguous. When three independent reads (original,
    enhanced-recognition and detector fallback) agree 2-to-1, accept the majority only
    when both agreeing reads are credible; otherwise fail closed.
    """
    evidence=[]
    for row in evidence_rows or []:
        text=str(row.get('badge_ocr_text') or '').strip()
        try: conf=float(row.get('badge_ocr_confidence') or 0.0)
        except (TypeError,ValueError): conf=0.0
        value=row.get('discount_value')
        if value is None:
            value=parse_percent(text)
        try: value=int(value) if value is not None else None
        except (TypeError,ValueError): value=None
        evidence.append({'text':text,'confidence':conf,'value':value,'source':str(row.get('badge_ocr_source') or '')})
    credible=[item for item in evidence if item['value'] is not None and item['confidence']>=0.35]
    counts={}
    for item in credible:
        counts[item['value']]=counts.get(item['value'],0)+1
    result=dict(candidate)
    chosen_value=None
    conflict=False
    if len(counts)==1:
        chosen_value=next(iter(counts))
    elif len(counts)>1:
        max_count=max(counts.values())
        winners=[value for value,count in counts.items() if count==max_count]
        # Only allow 2-of-3 consensus; never resolve a two-read disagreement by score.
        if max_count==2 and len(winners)==1 and len(credible)==3:
            chosen_value=winners[0]
        else:
            conflict=True
    matching=[item for item in credible if item['value']==chosen_value] if chosen_value is not None else []
    if matching:
        chosen=max(matching,key=lambda item:item['confidence'])
    elif evidence:
        chosen=max(evidence,key=lambda item:item['confidence'])
    else:
        chosen={'text':'','confidence':0.0,'source':''}
    result.update({'discount_value':None if conflict else chosen_value,'badge_ocr_text':chosen['text'] if not conflict else ' | '.join(item['text'] for item in evidence if item['text']),
                   'badge_ocr_confidence':float(chosen['confidence'] or 0.0) if not conflict else 0.0,
                   'badge_ocr_conflict':bool(conflict),
                   'badge_ocr_sources':[item['source'] for item in evidence if item['source']]})
    return result


def _has_credible_recognition_only_badge_consensus(evidence_rows, min_confidence=0.45):
    """True only when the original and enhanced known-ROI recognizers agree credibly.

    On small green percentage badges, the detector fallback is disproportionately costly
    and has the same recognition model downstream. If both differently preprocessed,
    known-ROI reads parse the same integer at confidence >= 0.45, they provide enough
    corroboration to avoid the full detector pass. A missing read, low score, or any
    disagreement still follows the existing detector-rescue path (fail closed).
    """
    values_by_source = {}
    for row in evidence_rows or []:
        if not isinstance(row, dict):
            continue
        source = str(row.get('badge_ocr_source') or '').strip().lower()
        if source not in ('recognition-only', 'recognition-only-enhanced'):
            continue
        try:
            confidence = float(row.get('badge_ocr_confidence') or 0.0)
        except (TypeError, ValueError):
            confidence = 0.0
        value = row.get('discount_value')
        if value is None:
            value = parse_percent(row.get('badge_ocr_text') or '')
        try:
            value = int(value) if value is not None else None
        except (TypeError, ValueError):
            value = None
        if value is not None and confidence >= float(min_confidence):
            values_by_source[source] = value
    original = values_by_source.get('recognition-only')
    enhanced = values_by_source.get('recognition-only-enhanced')
    return original is not None and enhanced is not None and original == enhanced


def _badge_requires_detector_rescue(candidate, evidence_rows, min_confidence=0.55):
    """Preserve detector rescue unless two credible known-ROI reads agree."""
    if _has_credible_recognition_only_badge_consensus(evidence_rows):
        return False
    merged = _resolve_discount_ocr_evidence(candidate, evidence_rows)
    return (
        merged.get('discount_value') is None
        or float(merged.get('badge_ocr_confidence') or 0.0) < float(min_confidence)
        or bool(merged.get('badge_ocr_conflict'))
    )


def _get_ocr_engine():
    """Create once, prefer CUDA/DirectML GPU execution, and retain every failed attempt."""
    global _OCR_ENGINE, _OCR_ENGINE_INIT_SECONDS, _OCR_ENGINE_CONFIG, _OCR_LAST_INIT_ERRORS
    if _OCR_ENGINE is not None:
        return _OCR_ENGINE
    with _OCR_ENGINE_LOCK:
        if _OCR_ENGINE is not None:
            return _OCR_ENGINE
        from rapidocr import RapidOCR
        start = time.perf_counter()
        providers = _available_onnxruntime_providers()
        attempts = _engine_config_attempts(providers)
        last_error = None
        attempt_errors = []
        for label, params in attempts:
            try:
                candidate = _RapidOCRAdapter(RapidOCR(params=_rapidocr_typed_params(params)))
                # Construction may not create all sessions yet; warmup below checks again.
                actual = _active_engine_providers(candidate)
                if label.startswith(("cuda", "directml")) and actual:
                    requested = "CUDAExecutionProvider" if label.startswith("cuda") else "DmlExecutionProvider"
                    if requested not in actual:
                        last_error = RuntimeError(
                            f"Requested {requested}, but active providers are {actual}"
                        )
                        attempt_errors.append({
                            "attempt": label,
                            "error": f"{type(last_error).__name__}: {last_error}",
                            "traceback": "Provider mismatch observed after engine construction; no Python exception traceback.",
                        })
                        continue
                _OCR_ENGINE = candidate
                _OCR_ENGINE_CONFIG = f"{label}:{'+'.join(actual) if actual else 'provider-unreported'}"
                break
            except Exception as exc:
                last_error = exc
                attempt_errors.append({
                    "attempt": label,
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                })
        if _OCR_ENGINE is None:
            # Use RapidOCR's package defaults only as a last resort, but keep the
            # exact errors from all parameterized attempts in last_scan_diagnostics.json.
            try:
                _OCR_ENGINE = _RapidOCRAdapter(RapidOCR())
                actual = _active_engine_providers(_OCR_ENGINE)
                _OCR_ENGINE_CONFIG = (
                    f"default-fallback:{type(last_error).__name__ if last_error else 'unknown'}:"
                    f"{'+'.join(actual) if actual else 'provider-unreported'}"
                )
            except Exception as exc:
                attempt_errors.append({
                    "attempt": "default-fallback",
                    "error": f"{type(exc).__name__}: {exc}",
                    "traceback": traceback.format_exc(),
                })
                _OCR_LAST_INIT_ERRORS = attempt_errors
                raise
        _OCR_LAST_INIT_ERRORS = attempt_errors
        _OCR_ENGINE_INIT_SECONDS = time.perf_counter() - start
    return _OCR_ENGINE


class OCRWarmupWorker(QThread):
    """Warm OCR model sessions before the first user-requested market scan."""
    completed = Signal(bool, str, float)

    def run(self):
        global _OCR_ENGINE, _OCR_ENGINE_WARMUP_SECONDS, _OCR_ENGINE_CONFIG
        global _OCR_LAST_WARMUP_ERROR, _OCR_LAST_WARMUP_TRACEBACK
        started = time.perf_counter()
        try:
            import cv2
            import numpy as np
            engine = _get_ocr_engine()
            # Pre-open the Windows capture backend before scanning starts. MSS creation
            # can be costly on some game/driver combinations; paying it here removes
            # that cold-start cost from each time-critical purchase flow.
            try:
                import mss as _mss_module
                _get_detail_capture(_mss_module)
            except Exception as capture_warmup_exc:
                global _DETAIL_CAPTURE_LAST_ERROR
                _DETAIL_CAPTURE_LAST_ERROR = f"{type(capture_warmup_exc).__name__}: {capture_warmup_exc}"
            # Initialize the actual ONNX sessions before checking which provider is active.
            # Warm the detector/recognizer with a grid-sized montage, not only a
            # tiny single-card sample. DirectML can incur a large first-inference
            # cost when the first real scan has a different tensor shape; warming
            # the same 15-row layout moves that cost before scanning is enabled.
            sample = np.full((15 * 36, 360, 3), (15, 19, 22), dtype=np.uint8)
            for row in range(15):
                y = row * 36 + 24
                cv2.putText(sample, "Dinka Civic FK2", (5, y), cv2.FONT_HERSHEY_SIMPLEX,
                            0.42, (245, 245, 245), 1, cv2.LINE_AA)
                cv2.putText(sample, "$15 499", (165, y), cv2.FONT_HERSHEY_SIMPLEX,
                            0.42, (245, 245, 245), 1, cv2.LINE_AA)
                cv2.putText(sample, "-6%", (280, y), cv2.FONT_HERSHEY_SIMPLEX,
                            0.42, (70, 240, 120), 1, cv2.LINE_AA)
            try:
                engine(sample)
                # Warm the exact normalized detail-panel inference shape used before Buy.
                # This avoids a first-use shape allocation/optimization after the card opens.
                detail_sample = np.full((346, 1152, 3), (15, 19, 22), dtype=np.uint8)
                cv2.putText(detail_sample, "Maibatsu Lancer EVO IX", (18, 58),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.05, (245, 245, 245), 2, cv2.LINE_AA)
                cv2.putText(detail_sample, "Price: $65 000", (18, 180),
                            cv2.FONT_HERSHEY_SIMPLEX, 1.0, (245, 245, 245), 2, cv2.LINE_AA)
                cv2.putText(detail_sample, "Good price: -89%", (18, 284),
                            cv2.FONT_HERSHEY_SIMPLEX, .95, (245, 245, 245), 2, cv2.LINE_AA)
                engine(detail_sample)
                # Multi-card max-discount priority uses a 3-tile badge montage most often.
                badge_sample = np.full((80, 510, 3), 245, dtype=np.uint8)
                for col, label in enumerate(("-45%", "-89%", "-62%")):
                    cv2.putText(badge_sample, label, (col * 170 + 12, 52),
                                cv2.FONT_HERSHEY_SIMPLEX, .9, (25, 25, 25), 2, cv2.LINE_AA)
                engine(badge_sample)
                # Warm the recognition-only known-ROI path used on every candidate. RapidOCR
                # has a dedicated recognition stage; this moves its first model/session cost
                # out of the live purchase path. Failure here is non-fatal because the mature
                # detector-based OCR path remains the fallback for this runtime/build.
                try:
                    direct_rec = getattr(engine, 'recognize_crops', None)
                    if callable(direct_rec):
                        known_lines = [
                            _prepare_known_text_crop(detail_sample[20:100, :], 'detail', 48),
                            _prepare_known_text_crop(detail_sample[130:210, :], 'detail', 48),
                            _prepare_known_text_crop(detail_sample[220:310, :], 'detail', 48),
                        ]
                        if all(line is not None and getattr(line, 'size', 0) for line in known_lines):
                            direct_rec(known_lines)
                except Exception:
                    pass
                _OCR_LAST_WARMUP_ERROR = ""
                _OCR_LAST_WARMUP_TRACEBACK = ""
                active = _active_engine_providers(_OCR_ENGINE)
                requested_gpu = None
                if _OCR_ENGINE_CONFIG.startswith("directml-fast"):
                    requested_gpu = "DmlExecutionProvider"
                elif _OCR_ENGINE_CONFIG.startswith("cuda-fast"):
                    requested_gpu = "CUDAExecutionProvider"
                if requested_gpu and requested_gpu not in active:
                    raise RuntimeError(
                        f"Запитано {requested_gpu}, але активний провайдер не підтверджено; "
                        f"виявлено: {active or 'none'}"
                    )
                if active:
                    _OCR_ENGINE_CONFIG = f"{_OCR_ENGINE_CONFIG.split(':', 1)[0]}:{'+'.join(active)}"
            except Exception as warmup_exc:
                # Retain the full original exception before trying the safe CPU fallback.
                # The previous release kept only the exception class/message and hid the
                # RapidOCR/ONNX Runtime frame that explains provider failures.
                _OCR_LAST_WARMUP_ERROR = f"{type(warmup_exc).__name__}: {warmup_exc}"
                _OCR_LAST_WARMUP_TRACEBACK = traceback.format_exc()
                # GPU creation/inference can fail on a specific driver. Recreate the
                # maintained RapidOCR engine explicitly on CPU and report the fallback.
                from rapidocr import RapidOCR
                cpu_params = {
                    **_FAST_OCR_PARAMS,
                    "EngineConfig.onnxruntime.use_cuda": False,
                    "EngineConfig.onnxruntime.use_dml": False,
                }
                with _OCR_ENGINE_LOCK:
                    try:
                        _OCR_ENGINE = _RapidOCRAdapter(RapidOCR(params=_rapidocr_typed_params(cpu_params)))
                    except Exception:
                        _OCR_ENGINE = _RapidOCRAdapter(RapidOCR())
                    active = _active_engine_providers(_OCR_ENGINE)
                    _OCR_ENGINE_CONFIG = (
                        f"cpu-after-warmup-fallback:{type(warmup_exc).__name__}:"
                        f"{'+'.join(active) if active else 'provider-unreported'}"
                    )
                    engine = _OCR_ENGINE
                engine(sample)
                active = _active_engine_providers(_OCR_ENGINE)
                if active:
                    _OCR_ENGINE_CONFIG = (
                        f"cpu-after-warmup-fallback:{type(warmup_exc).__name__}:"
                        f"{'+'.join(active)}"
                    )
            _OCR_ENGINE_WARMUP_SECONDS = time.perf_counter() - started
            self.completed.emit(
                True,
                f"OCR-модель прогріта · backend {_OCR_ENGINE_CONFIG}",
                _OCR_ENGINE_WARMUP_SECONDS,
            )
        except Exception as exc:
            elapsed = time.perf_counter() - started
            self.completed.emit(False, f"{type(exc).__name__}: {exc}", elapsed)


def _package_version(package_name):
    try:
        from importlib.metadata import version
        return version(package_name)
    except Exception:
        return None




# --- v1.2.65 robust per-offer fingerprinting ---
def _perceptual_hash_hex(image, cv2_module=None, np_module=None):
    """Compact DCT perceptual hash, robust to harmless frame noise/brightness shifts."""
    if cv2_module is None:
        import cv2 as cv2_module
    if np_module is None:
        import numpy as np_module
    if image is None or getattr(image, 'size', 0) == 0:
        return '0' * 16
    gray = image
    if getattr(gray, 'ndim', 0) == 3:
        gray = cv2_module.cvtColor(gray, cv2_module.COLOR_BGR2GRAY)
    gray = cv2_module.resize(gray, (32, 32), interpolation=cv2_module.INTER_AREA)
    low = cv2_module.dct(np_module.float32(gray))[:8, :8].reshape(-1)
    median = float(np_module.median(low[1:]))
    value = 0
    for bit in (low[1:] > median):
        value = (value << 1) | int(bool(bit))
    return f'{value:016x}'


def _bit_distance_hex(left, right):
    try:
        return (int(str(left), 16) ^ int(str(right), 16)).bit_count()
    except (TypeError, ValueError):
        return 10**9


def _identity_fingerprint_parts(value):
    value = str(value or '')
    if value.startswith('idp:'):
        parts = value.split(':')
        if len(parts) == 3 and all(re.fullmatch(r'[0-9a-f]{16}', x) for x in parts[1:]):
            return parts[1], parts[2]
    return None


def _discount_fingerprint_parts(value):
    value = str(value or '')
    if value.startswith('dpm:'):
        parts = value.split(':', 2)
        if len(parts) == 3 and re.fullmatch(r'[0-9a-f]{16}', parts[1]) and re.fullmatch(r'[0-9a-f]+', parts[2]):
            return parts[1], parts[2]
    return None


def _identity_signatures_similar(left, right):
    """Exact legacy matching or tolerant perceptual matching for the same card."""
    left, right = str(left or ''), str(right or '')
    if left == right:
        return bool(left)
    a, b = _identity_fingerprint_parts(left), _identity_fingerprint_parts(right)
    if not a or not b:
        return False
    # Whole-card hash tolerates UI anti-aliasing and tiny rendered-picture changes;
    # the title/price hash is stricter so a genuinely different offer is not merged.
    return _bit_distance_hex(a[0], b[0]) <= 8 and _bit_distance_hex(a[1], b[1]) <= 5


def _discount_signatures_similar(left, right):
    """Compare the visible badge glyphs while allowing a few threshold/AA pixels of noise."""
    left, right = str(left or ''), str(right or '')
    if left == right:
        return bool(left)
    a, b = _discount_fingerprint_parts(left), _discount_fingerprint_parts(right)
    if not a or not b or len(a[1]) != len(b[1]):
        return False
    if _bit_distance_hex(a[0], b[0]) > 2:
        return False
    try:
        aa, bb = bytes.fromhex(a[1]), bytes.fromhex(b[1])
        mask_distance = sum((x ^ y).bit_count() for x, y in zip(aa, bb))
    except ValueError:
        return False
    return mask_distance <= 4


def _candidate_signatures_similar(left, right):
    if not isinstance(left, dict) or not isinstance(right, dict):
        return False
    left_sig, right_sig = str(left.get('signature') or ''), str(right.get('signature') or '')
    if left_sig and left_sig == right_sig:
        return True
    left_id = str(left.get('identity_signature') or (left_sig.split('|', 1)[0] if '|' in left_sig else left_sig))
    right_id = str(right.get('identity_signature') or (right_sig.split('|', 1)[0] if '|' in right_sig else right_sig))
    left_discount = str(left.get('discount_signature') or (left_sig.split('|', 1)[1] if '|' in left_sig else left_sig))
    right_discount = str(right.get('discount_signature') or (right_sig.split('|', 1)[1] if '|' in right_sig else right_sig))
    return (_identity_signatures_similar(left_id, right_id)
            and _discount_signatures_similar(left_discount, right_discount))


def _offer_signature_was_attempted(signature, attempted):
    signature = str(signature or '')
    if not signature:
        return False
    if signature in attempted:
        return True
    # Approximate comparisons are only needed for the new perceptual fingerprint form;
    # legacy test fixtures/older serialized signatures retain their exact semantics.
    if not (signature.startswith('idp:') and '|dpm:' in signature):
        return False
    probe = {'signature': signature}
    return any(_candidate_signatures_similar(probe, {'signature': item}) for item in attempted)


def _compact_detail_ocr_image(panel, np_module=None):
    """Stack only the title/price/status bands; return a reversible y-coordinate map."""
    if np_module is None:
        import numpy as np_module
    height, width = panel.shape[:2]
    bands = ((20, 100), (130, 210), (220, 310))
    chunks, mapping = [], []
    cursor = 0
    separator_h = 2
    background = np_module.median(panel.reshape(-1, panel.shape[2]), axis=0).astype(panel.dtype)
    for index, (start, end) in enumerate(bands):
        start = max(0, min(int(start), height))
        end = max(start + 1, min(int(end), height))
        strip = panel[start:end]
        if strip.size == 0:
            continue
        chunks.append(strip)
        mapping.append((cursor, cursor + strip.shape[0], start))
        cursor += strip.shape[0]
        if index < len(bands) - 1:
            chunks.append(np_module.empty((separator_h, width, panel.shape[2]), dtype=panel.dtype))
            chunks[-1][:] = background
            cursor += separator_h
    if not chunks:
        return panel, None
    return np_module.concatenate(chunks, axis=0), mapping


def _detail_ocr_zones(detections, y_map, y0, height, scale_y):
    zones = {'title': [], 'price': [], 'status': [], 'other': []}
    for item in (detections or []):
        try:
            if item is None or len(item) < 2:
                continue
            pts = list(item[0])
            ys = [float(p[1]) for p in pts]
            xs = [float(p[0]) for p in pts]
            if not ys or not xs:
                continue
            center_y = (min(ys) + max(ys)) / 2.0
            if y_map is not None:
                mapped_y = None
                for out_start, out_end, source_start in y_map:
                    if out_start <= center_y < out_end:
                        mapped_y = source_start + (center_y - out_start)
                        break
                if mapped_y is None:  # Ignore divider/background detections.
                    continue
                center_y = mapped_y
            abs_y = (y0 + center_y / scale_y) / height
            entry = ((min(xs) + max(xs)) / 2.0, str(item[1] or '').strip())
            if .140 <= abs_y < .195:
                zones['title'].append(entry)
            elif .190 <= abs_y < .238:
                zones['price'].append(entry)
            elif .232 <= abs_y < .292:
                zones['status'].append(entry)
            else:
                zones['other'].append(entry)
        except Exception:
            continue
    for key in zones:
        zones[key].sort(key=lambda entry: entry[0])
    return zones


# --- v1.2.60 position-independent discount watcher with parallel detail validation ---
# Capture and badge-color detection run independently from OCR. A frame watcher
# keeps consuming the latest DXGI frame while OCR/action workers handle a single
# short candidate path. This removes the single-flight OCR loop from the hot path.
def _direct_watch_card_candidates(frame, grid, screen_size, target_hwnd=None,
                                 monitor_left=0, monitor_top=0, include_all_states=False):
    """Detect market badge colors in either a full-screen or cropped DXGI frame.

    ``screen_size`` always describes the full monitor. ``monitor_left`` and
    ``monitor_top`` are the screen-space origin of ``frame`` when region capture
    is enabled. This lets DXcam/MSS avoid copying most pixels without changing
    the calibrated market coordinates or click points.
    """
    try:
        import cv2
        import numpy as np
        if frame is None or getattr(frame, 'size', 0) == 0 or frame.ndim < 3:
            return []
        height, width = frame.shape[:2]
        screen_w, screen_h = int(screen_size[0]), int(screen_size[1])
        origin_x, origin_y = int(monitor_left or 0), int(monitor_top or 0)
        if screen_w <= 0 or screen_h <= 0:
            return []
        grid = dict(grid or {})
        cols = max(1, int(grid.get('cols', 5) or 5))
        rows = max(1, int(grid.get('rows', 3) or 3))
        left = float(grid.get('left', .153)); right = float(grid.get('right', .985))
        top = float(grid.get('top', .095)); bottom = float(grid.get('bottom', .895))
        use_ahk = (cols == 5 and rows == 3 and abs(left-.153) <= .008
                   and abs(right-.985) <= .008 and abs(top-.095) <= .008
                   and abs(bottom-.895) <= .012)
        ahk_lefts = (.155, .322, .489, .655, .822)
        ahk_rights = (.315, .481, .647, .813, .981)
        row_offsets = (0.0, .270, .540)
        cell_w = (right-left)*screen_w/cols
        cell_h = (bottom-top)*screen_h/rows
        out=[]

        def local_box(x0s, y0s, x1s, y1s):
            x0=max(0, min(width-1, int(x0s)-origin_x))
            x1=max(x0+1, min(width, int(x1s)-origin_x))
            y0=max(0, min(height-1, int(y0s)-origin_y))
            y1=max(y0+1, min(height, int(y1s)-origin_y))
            return x0, y0, x1, y1

        for idx in range(rows*cols):
            row, col = divmod(idx, cols)
            if use_ahk:
                xa_screen=int(ahk_lefts[col]*screen_w)
                xb_screen=int(ahk_rights[col]*screen_w)
                ya_screen=int((.095+row_offsets[row])*screen_h)
                yb_screen=int((.095+row_offsets[row]+.265)*screen_h)
            else:
                xa_screen=int(left*screen_w+col*cell_w)
                xb_screen=int(left*screen_w+(col+1)*cell_w)
                ya_screen=int(top*screen_h+row*cell_h)
                yb_screen=int(top*screen_h+(row+1)*cell_h)
            xa, ya, xb, yb = local_box(xa_screen, ya_screen, xb_screen, yb_screen)
            card=frame[ya:yb,xa:xb]
            if card.size == 0:
                continue
            if use_ahk:
                card_width=xb_screen-xa_screen
                bx0s=xa_screen+int(.775*card_width)
                bx1s=xa_screen+int(.980*card_width)
                by0s=int((.321+row_offsets[row])*screen_h)
                by1s=by0s+max(1,int(.027*screen_h))
                bx0, by0, bx1, by1 = local_box(bx0s, by0s, bx1s, by1s)
                color_crop=frame[by0:by1,bx0:bx1]
            else:
                color_crop=card[int(.8475*card.shape[0]):max(1,int(.94875*card.shape[0])),
                                int(.757*card.shape[1]):max(2,int(.954*card.shape[1]))]
            badge_color = classify_badge_color(color_crop)
            if badge_color != 'GREEN' and not include_all_states:
                continue
            # Green offers get two position-independent fingerprints:
            # identity_signature ignores the discount badge; discount_signature
            # tracks only the badge/percentage. The combined offer signature is
            # deliberately NOT prefixed with the grid index, so a card moving
            # between cells does not look like a new offer.
            text_crop=None
            identity_signature=None
            discount_signature=None
            if badge_color == 'GREEN':
                tx0=max(0,min(card.shape[1]-1,int(.775*card.shape[1])))
                ty0=max(0,min(card.shape[0]-1,int(.853*card.shape[0])))
                tx1=max(tx0+1,min(card.shape[1],int(.980*card.shape[1])))
                ty1=max(ty0+1,min(card.shape[0],int(.955*card.shape[0])))
                text_crop=card[ty0:ty1,tx0:tx1].copy()
                if text_crop.size:
                    # The badge is green/white text on a dark UI. A thresholded glyph mask
                    # keeps the fingerprint stable under small brightness/AA changes while
                    # remaining sensitive to a real percentage change (-27% -> -22%).
                    badge_gray=cv2.cvtColor(text_crop,cv2.COLOR_BGR2GRAY)
                    badge_mask=(badge_gray >= 120).astype(np.uint8)
                    badge_mask=cv2.resize(badge_mask,(48,16),interpolation=cv2.INTER_NEAREST)
                    badge_mask_hex=np.packbits(badge_mask.reshape(-1)).tobytes().hex()
                    badge_phash=_perceptual_hash_hex(text_crop,cv2,np)
                    discount_signature=f'dpm:{badge_phash}:{badge_mask_hex}'
                # Perceptual hashes avoid SHA-1's all-or-nothing reaction to a tiny pixel
                # change. The title/price region is separate so different listings of
                # the same model remain distinguishable; the discount badge is masked.
                if card.size:
                    stable_color=card.copy()
                    mask_y0=max(0,min(card.shape[0]-1,int(.80*card.shape[0])))
                    mask_y1=max(mask_y0+1,min(card.shape[0],int(.99*card.shape[0])))
                    mask_x0=max(0,min(card.shape[1]-1,int(.73*card.shape[1])))
                    stable_color[mask_y0:mask_y1,mask_x0:]=0
                    visual_hash=_perceptual_hash_hex(stable_color,cv2,np)
                    text_y0=max(0,min(card.shape[0]-1,int(.70*card.shape[0])))
                    text_y1=max(text_y0+1,min(card.shape[0],int(.99*card.shape[0])))
                    text_x1=max(1,min(card.shape[1],int(.74*card.shape[1])))
                    title_price_crop=card[text_y0:text_y1,:text_x1]
                    text_hash=_perceptual_hash_hex(title_price_crop,cv2,np)
                    identity_signature=f'idp:{visual_hash}:{text_hash}'
                if not identity_signature:
                    # Stable fallback, not a timestamp: time-based signatures caused
                    # unchanged/unreadable cards to appear new on every captured frame.
                    fallback_bytes=cv2.resize(card,(32,24),interpolation=cv2.INTER_AREA)
                    identity_signature='id:'+hashlib.sha1(fallback_bytes.tobytes()).hexdigest()
                if not discount_signature:
                    discount_bytes=(text_crop if text_crop is not None and text_crop.size else card)
                    discount_signature='disc:'+hashlib.sha1(discount_bytes.tobytes()).hexdigest()
                signature=f'{identity_signature}|{discount_signature}'
            else:
                # Non-green states only need to tell us when a badge becomes green.
                signature=f'{idx}:NON_GREEN:{badge_color}'
            out.append({
                'card_index':idx, 'card':idx+1,
                'xy':(int(origin_x+(xa+xb)//2),int(origin_y+(ya+yb)//2)),
                'screen_size':(screen_w,screen_h),
                'badge_crop':text_crop, 'signature':signature,
                'identity_signature':identity_signature,
                'discount_signature':discount_signature,
                'badge_color':badge_color, 'target_hwnd':target_hwnd,
                'detected_at':time.perf_counter(),
            })
        return out
    except Exception:
        return []


DIRECT_GREEN_CANDIDATE_COALESCE_SECONDS = 0.004


def _merge_green_candidate_window(pending_by_card, current_states, changed_green, attempted):
    """Coalesce short bursts by perceptually stable offer identity, not cell/index."""
    pending = {str(key): dict(value) for key, value in (pending_by_card or {}).items()}
    attempted = set(attempted or ())
    visible_green = [dict(item) for item in (current_states or [])
                     if str(item.get('badge_color') or '').upper() == 'GREEN'
                     and item.get('signature')]

    # Refresh pending coordinates across grid movement and minor render noise. Only
    # remove the candidate if it is no longer visible as the same perceptual offer.
    for key in list(pending):
        prior = pending[key]
        matches = [item for item in visible_green if _candidate_signatures_similar(prior, item)]
        if not matches:
            pending.pop(key, None)
        else:
            latest = max(matches, key=lambda item: float(item.get('detected_at') or 0.0))
            pending[key] = dict(latest)

    for item in changed_green or []:
        signature = str(item.get('signature') or '')
        if not signature or _offer_signature_was_attempted(signature, attempted):
            continue
        matching_key = next((key for key, prior in pending.items()
                             if _candidate_signatures_similar(prior, item)), None)
        if matching_key is not None:
            pending[matching_key] = dict(item)
        else:
            pending[signature] = dict(item)
    return pending


def _changed_green_watch_candidates(states, previous_by_card):
    """Detect new offers/real discount changes, tolerating harmless frame noise."""
    current = {}
    previous_green = []
    for value in (previous_by_card or {}).values():
        if isinstance(value, dict):
            prior_color = str(value.get('badge_color') or 'UNKNOWN').upper()
            prior_signature = str(value.get('signature') or '')
            identity = str(value.get('identity_signature') or
                           (prior_signature.split('|', 1)[0] if '|' in prior_signature else prior_signature))
            discount = str(value.get('discount_signature') or
                           (prior_signature.split('|', 1)[1] if '|' in prior_signature else prior_signature))
        else:
            try:
                prior_signature, prior_badge = value
            except Exception:
                continue
            prior_color = str(prior_badge or 'UNKNOWN').upper()
            prior_signature = str(prior_signature or '')
            identity, discount = (prior_signature.split('|', 1) + [prior_signature])[:2] if '|' in prior_signature else (prior_signature, prior_signature)
        if prior_color == 'GREEN' and identity:
            previous_green.append((identity, discount))

    changed = []
    for item in states or []:
        if item.get('card_index') is None:
            continue
        index = int(item.get('card_index', -1))
        signature = str(item.get('signature') or '')
        color = str(item.get('badge_color') or 'UNKNOWN').upper()
        if color != 'GREEN':
            current[index] = {'signature': signature, 'badge_color': color,
                              'identity_signature': None, 'discount_signature': None}
            continue
        identity = str(item.get('identity_signature') or
                       (signature.split('|', 1)[0] if '|' in signature else signature))
        discount = str(item.get('discount_signature') or
                       (signature.split('|', 1)[1] if '|' in signature else signature))
        current[index] = {'signature': signature, 'badge_color': 'GREEN',
                          'identity_signature': identity, 'discount_signature': discount}
        prior_matches = [(prior_id, prior_discount) for prior_id, prior_discount in previous_green
                         if _identity_signatures_similar(identity, prior_id)]
        is_new_identity = not prior_matches
        is_new_discount = bool(prior_matches) and not any(
            _discount_signatures_similar(discount, prior_discount)
            for _, prior_discount in prior_matches
        )
        if not (is_new_identity or is_new_discount) or not signature:
            continue
        if any(_candidate_signatures_similar(item, old) for old in changed):
            continue
        changed.append(item)
    return changed, current


def _looks_like_green_cta_colorref(colorref):
    """COLORREF helper shared with the action worker's green-CTA guard."""
    try:
        value = int(colorref)
        if value < 0 or value == 0xFFFFFFFF:
            return False
        red = value & 0xFF
        green = (value >> 8) & 0xFF
        blue = (value >> 16) & 0xFF
        return green >= 150 and red <= 110 and blue >= 80 and green > red * 1.45 and green > blue * 1.06
    except (TypeError, ValueError):
        return False


def _direct_watch_has_detail_buy_button_screen(screen_size, target_hwnd=None):
    """Check the detail CTA with a few desktop pixels, allowing capture to end at the grid."""
    if os.name != 'nt' or not screen_size or len(screen_size) < 2:
        return False
    try:
        if not _foreground_matches_target(target_hwnd):
            return False
        import ctypes
        from ctypes import wintypes
        user32 = ctypes.windll.user32
        gdi32 = ctypes.windll.gdi32
        user32.GetDC.argtypes = [wintypes.HWND]
        user32.GetDC.restype = wintypes.HDC
        user32.ReleaseDC.argtypes = [wintypes.HWND, wintypes.HDC]
        user32.ReleaseDC.restype = ctypes.c_int
        gdi32.GetPixel.argtypes = [wintypes.HDC, ctypes.c_int, ctypes.c_int]
        gdi32.GetPixel.restype = ctypes.c_uint
        width, height = int(screen_size[0]), int(screen_size[1])
        x, y = int(.773 * width), int(.930 * height)
        probes = ((-22,-8),(22,-8),(-22,8),(22,8),(-22,0),(22,0))
        hdc = user32.GetDC(0)
        if not hdc:
            return False
        try:
            valid = 0
            green = 0
            for dx, dy in probes:
                color = int(gdi32.GetPixel(hdc, x + dx, y + dy))
                if color != 0xFFFFFFFF:
                    valid += 1
                if _looks_like_green_cta_colorref(color):
                    green += 1
            return valid > 0 and green >= 4
        finally:
            user32.ReleaseDC(0, hdc)
    except Exception:
        return False


def _direct_watch_has_detail_buy_button(frame, monitor_left=0, monitor_top=0,
                                         screen_size=None):
    """Detect the known detail-page CTA even when only a screen region is captured."""
    try:
        import numpy as np
        h,w=frame.shape[:2]
        if screen_size and len(screen_size) >= 2:
            cx=int(.773*int(screen_size[0]))-int(monitor_left or 0)
            cy=int(.930*int(screen_size[1]))-int(monitor_top or 0)
        else:
            cx=int(.773*w); cy=int(.930*h)
        x0=max(0,cx-30); x1=min(w,cx+31); y0=max(0,cy-22); y1=min(h,cy+23)
        p=frame[y0:y1,x0:x1]
        if p.size == 0 or p.ndim != 3 or p.shape[2] < 3:
            return False
        b=p[:,:,0].astype(np.int16); g=p[:,:,1].astype(np.int16); r=p[:,:,2].astype(np.int16)
        green=(g>=150)&(r<=110)&(b>=80)&(g>r*1.45)&(g>b*1.06)
        return int(np.count_nonzero(green)) >= 28
    except Exception:
        return False


class GreenBadgeWatcher(QThread):
    """High-cadence, OCR-free detector for newly visible green discount cards.

    DXcam/DXGI is preferred on Windows. MSS is a compatibility fallback. Capture
    continues while candidate OCR or the click worker is busy; detection is latched
    until the GUI explicitly resumes after the candidate was handled.
    """
    candidates_found = Signal(list)
    status = Signal(str)

    def __init__(self, grid, target_hwnd, screen_size, parent=None):
        super().__init__()
        self.grid=dict(grid or {})
        self.target_hwnd=int(target_hwnd) if target_hwnd not in (None,0,'0') else None
        self.screen_size=(int(screen_size[0]),int(screen_size[1]))
        self._stop_event=threading.Event()
        self._paused=threading.Event()
        self._attempted=set()
        self._attempted_order=deque()
        self._previous_by_card={}
        self._baseline_ready=False
        self._lock=threading.Lock()
        self.capture_backend='not-started'
        self.last_frame_at=None
        self.frames_seen=0
        self._capture_origin=(0,0)
        self._capture_frame_size=self.screen_size
        self._capture_region=None
        self._capture_is_paced=False
        self._last_capture_timestamp=None

    def cancel(self):
        self._stop_event.set()

    def pause_detection(self):
        self._paused.set()

    def resume_after_action(self):
        self._paused.clear()

    def _mark_attempted_locked(self, signature):
        signature = str(signature or '')
        if not signature or signature in self._attempted:
            return
        self._attempted.add(signature)
        self._attempted_order.append(signature)
        # Keep a true FIFO of the most recent signatures. Trimming a set by list order
        # is arbitrary and could accidentally forget a recent offer while keeping an old one.
        while len(self._attempted_order) > 5000:
            oldest = self._attempted_order.popleft()
            self._attempted.discard(oldest)

    def mark_attempted(self, signature):
        if not signature:
            return
        with self._lock:
            self._mark_attempted_locked(signature)

    def mark_attempted_many(self, signatures):
        with self._lock:
            for signature in signatures or []:
                self._mark_attempted_locked(signature)

    def _get_frame_source(self):
        # Capture only the market area plus the detail-page CTA. In DXcam's
        # video_mode=False, consumers do not repeatedly process synthetic copies
        # of an unchanged frame; DXcam get_latest_frame waits for new captured data.
        screen_w, screen_h = self.screen_size
        grid = self.grid or {}
        left = float(grid.get('left', .153)); top = float(grid.get('top', .095))
        margin_x = int(.02 * screen_w)
        margin_y = int(.02 * screen_h)
        region_left = max(0, int(left * screen_w) - margin_x)
        region_top = max(0, int(top * screen_h) - margin_y)
        # Capture only the 3x5 listing grid plus a small safety margin. The detail-page
        # Buy CTA sits below this ROI, so its state is checked via six desktop pixels.
        region_right = min(screen_w, int(float(grid.get('right', .985)) * screen_w) + margin_x)
        region_bottom = min(screen_h, int(float(grid.get('bottom', .895)) * screen_h) + margin_y)
        region = (region_left, region_top, region_right, region_bottom)
        expected = (region_right - region_left, region_bottom - region_top)
        # Returns (next_frame_callable, cleanup_callable, backend_name).
        try:
            import dxcam
            camera=dxcam.create(output_idx=0, output_color='BGR', max_buffer_len=4)
            try:
                camera.start(region=region, target_fps=120, video_mode=False)
                self._capture_origin=(region_left,region_top)
                self._capture_frame_size=expected
                self._capture_region=region
                backend='DXGI/DXcam ROI 120-FPS target'
            except TypeError:
                # Compatibility fallback for older DXcam APIs that do not accept region.
                try:
                    camera.stop()
                except Exception:
                    pass
                camera.start(target_fps=120, video_mode=False)
                self._capture_origin=(0,0)
                self._capture_frame_size=self.screen_size
                self._capture_region=None
                backend='DXGI/DXcam full-frame 120-FPS target'
            def next_frame():
                try:
                    # DXcam exposes frame presentation timestamps in current releases.
                    # Fall back for older compatible builds without that keyword.
                    try:
                        return camera.get_latest_frame(with_timestamp=True)
                    except TypeError:
                        return camera.get_latest_frame()
                except Exception:
                    return None
            def cleanup():
                try: camera.stop()
                except Exception: pass
                try: camera.release()
                except Exception: pass
            return next_frame,cleanup,backend
        except Exception as dx_error:
            try:
                import mss
                import numpy as np
                capture=mss.mss()
                monitor={'left':region_left,'top':region_top,
                         'width':expected[0],'height':expected[1]}
                self._capture_origin=(region_left,region_top)
                self._capture_frame_size=expected
                self._capture_region=region
                def next_frame():
                    try:
                        raw=np.asarray(capture.grab(monitor))
                        return raw[:,:,:3].copy() # mss BGRA -> BGR channels
                    except Exception:
                        return None
                def cleanup():
                    try: capture.close()
                    except Exception: pass
                return next_frame,cleanup,f'MSS ROI fallback ({type(dx_error).__name__})'
            except Exception as mss_error:
                raise RuntimeError(f'Не вдалося запустити DXGI/DXcam або MSS: {type(dx_error).__name__}; {type(mss_error).__name__}: {mss_error}')

    def run(self):
        cleanup=lambda:None
        try:
            if os.name=='nt' and self.target_hwnd is not None and not _foreground_matches_target(self.target_hwnd):
                self.status.emit('ERROR: перед запуском DIRECT GREEN WATCH активне не вікно гри.')
                return
            next_frame,cleanup,self.capture_backend=self._get_frame_source()
            self._capture_is_paced = 'DXcam' in self.capture_backend
            self.status.emit(f'DIRECT GREEN WATCH запущено · {self.capture_backend} · OCR не блокує захоплення кадрів.')
            empty_frames=0
            pending_by_card={}
            pending_deadline=None

            def flush_due_pending(now=None):
                nonlocal pending_by_card, pending_deadline
                if now is None:
                    now=time.perf_counter()
                if not pending_by_card or pending_deadline is None or now < pending_deadline:
                    return False
                with self._lock:
                    unseen=[dict(c) for c in pending_by_card.values()
                            if not _offer_signature_was_attempted(c.get('signature'), self._attempted)]
                pending_by_card.clear()
                pending_deadline=None
                if not unseen:
                    return False
                unseen.sort(key=lambda c:int(c.get('card_index',999)))
                self._paused.set()
                self.candidates_found.emit(unseen)
                if not self._capture_is_paced:
                    time.sleep(.001)
                return True

            while not self._stop_event.is_set():
                captured=next_frame()
                frame_timestamp=None
                if isinstance(captured, tuple) and len(captured)==2 and hasattr(captured[0], 'shape'):
                    frame,frame_timestamp=captured
                else:
                    frame=captured
                if frame is None:
                    empty_frames+=1
                    if empty_frames>250:
                        self.status.emit('ERROR: захоплення екрана не повертає кадри; DIRECT GREEN WATCH зупинено.')
                        return
                    time.sleep(.004)
                    continue
                empty_frames=0
                if frame_timestamp is not None:
                    try:
                        timestamp_key=float(frame_timestamp)
                        if self._last_capture_timestamp is not None and timestamp_key == self._last_capture_timestamp:
                            # The DXcam API may return the most recent buffer entry again
                            # between real desktop frames. A sub-ms yield prevents a busy
                            # loop; still flush a candidate window by wall clock even when
                            # the desktop does not present another frame immediately.
                            if flush_due_pending(time.perf_counter()):
                                continue
                            time.sleep(.0005)
                            continue
                        self._last_capture_timestamp=timestamp_key
                    except (TypeError, ValueError):
                        pass
                self.frames_seen+=1
                self.last_frame_at=time.perf_counter()
                try:
                    if tuple((int(frame.shape[1]),int(frame.shape[0]))) != tuple(self._capture_frame_size):
                        time.sleep(.004)
                        continue
                except Exception:
                    continue
                if self._paused.is_set():
                    _publish_watch_detail_frame(
                        frame, self.screen_size, self._capture_origin, self.target_hwnd
                    )
                    pending_by_card.clear(); pending_deadline=None
                    if not self._capture_is_paced: time.sleep(.001)
                    continue
                if not _foreground_matches_target(self.target_hwnd):
                    pending_by_card.clear(); pending_deadline=None
                    if not self._capture_is_paced: time.sleep(.004)
                    continue
                if _direct_watch_has_detail_buy_button_screen(self.screen_size, self.target_hwnd):
                    # We are still on details, not the 3x5 listing grid.
                    pending_by_card.clear(); pending_deadline=None
                    if not self._capture_is_paced: time.sleep(.004)
                    continue
                states=_direct_watch_card_candidates(
                    frame,self.grid,self.screen_size,self.target_hwnd,
                    monitor_left=self._capture_origin[0], monitor_top=self._capture_origin[1],
                    include_all_states=True)
                if not states:
                    if not self._capture_is_paced: time.sleep(.002)
                    continue
                changed_green,current=_changed_green_watch_candidates(states,self._previous_by_card)
                if not self._baseline_ready:
                    # Prime current listings without clicking stale green cards that existed
                    # before monitoring began. Only a subsequent transition/change can trigger.
                    self._previous_by_card=current
                    self._baseline_ready=True
                    self.status.emit('DIRECT GREEN WATCH: базовий кадр зафіксовано; очікую нові/змінені зелені пропозиції.')
                    if not self._capture_is_paced: time.sleep(.002)
                    continue
                self._previous_by_card=current
                with self._lock:
                    attempted=set(self._attempted)
                previous_pending=len(pending_by_card)
                pending_by_card=_merge_green_candidate_window(
                    pending_by_card, states, changed_green, attempted)
                now=time.perf_counter()
                if not pending_by_card:
                    pending_deadline=None
                elif len(pending_by_card) > 1:
                    # All green badges visible in a single frame can be ranked immediately;
                    # there is no benefit to paying another coalescing delay.
                    pending_deadline=now
                elif pending_deadline is None:
                    pending_deadline=now+DIRECT_GREEN_CANDIDATE_COALESCE_SECONDS
                if flush_due_pending(now):
                    continue
                # DXcam is already paced at the capture thread; avoid adding 1–2 ms
                # after every fresh frame. MSS needs a small throttle to protect the CPU.
                if not self._capture_is_paced:
                    time.sleep(.001 if (changed_green or previous_pending or pending_by_card) else .002)
        except Exception as exc:
            self.status.emit(f'ERROR: DIRECT GREEN WATCH: {type(exc).__name__}: {exc}')
        finally:
            try: cleanup()
            except Exception: pass
            self.status.emit(f'DIRECT GREEN WATCH зупинено · кадрів отримано: {self.frames_seen}.')


class GreenBadgeBatchWorker(QThread):
    """One tiny OCR montage of green badge text, independent from screen capture."""
    results_ready=Signal(list,str,float)
    def __init__(self,candidates,parent=None):
        super().__init__()
        self.candidates=[dict(c) for c in (candidates or [])]
        self.cancel_event=threading.Event()
    def cancel(self): self.cancel_event.set()
    def run(self):
        started=time.perf_counter()
        try:
            import cv2
            import numpy as np
            usable=[c for c in self.candidates if c.get('badge_crop') is not None and getattr(c.get('badge_crop'),'size',0)]
            if not usable:
                self.results_ready.emit([], 'Немає придатних crop зелених бейджів.', time.perf_counter()-started); return
            tile_w=170; tile_h=80; cols=3; scale=2.5
            tile_rows=max(1,(len(usable)+cols-1)//cols)

            def make_montage(enhanced=False):
                image=np.full((tile_rows*tile_h,cols*tile_w,3),255,dtype=np.uint8)
                for idx,c in enumerate(usable):
                    crop=c['badge_crop']
                    h,w=crop.shape[:2]
                    factor=min(scale,(tile_w-8)/max(1,w),(tile_h-8)/max(1,h))
                    resized=cv2.resize(crop,(max(1,int(w*factor)),max(1,int(h*factor))),interpolation=cv2.INTER_CUBIC)
                    if enhanced:
                        # Retry only when needed: normalize contrast and present dark glyphs
                        # on a light background, while keeping the same compact tile layout.
                        gray=cv2.cvtColor(resized,cv2.COLOR_BGR2GRAY)
                        gray=cv2.createCLAHE(clipLimit=2.0,tileGridSize=(4,2)).apply(gray)
                        binary=cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)[1]
                        resized=cv2.cvtColor(binary,cv2.COLOR_GRAY2BGR)
                    row,col=divmod(idx,cols)
                    x=col*tile_w+(tile_w-resized.shape[1])//2
                    y=row*tile_h+(tile_h-resized.shape[0])//2
                    image[y:y+resized.shape[0],x:x+resized.shape[1]]=resized
                return image

            def decode(image):
                rows_found,_=engine(image)
                by_index=[[] for _ in usable]
                for item in (rows_found or []):
                    try:
                        if item is None or len(item)<2: continue
                        pts=list(item[0]); xs=[float(p[0]) for p in pts]; ys=[float(p[1]) for p in pts]
                        cx=sum(xs)/len(xs); cy=sum(ys)/len(ys)
                        row=int(cy//tile_h); col=int(cx//tile_w)
                        idx=row*cols+col
                        if 0<=idx<len(by_index):
                            score=float(item[2]) if len(item)>2 and item[2] is not None else 0.0
                            by_index[idx].append((cx,str(item[1] or '').strip(),score))
                    except Exception: continue
                decoded=[]
                for candidate,detections in zip(usable,by_index):
                    detections.sort(key=lambda item:item[0])
                    text=' '.join(t for _,t,_ in detections if t)
                    discount=parse_percent(text)
                    confidence=max((score for _,token,score in detections
                                    if parse_percent(token) is not None or '%' in token),default=0.0)
                    result=dict(candidate)
                    result.update({'discount_value':discount,'badge_ocr_text':text,
                                   'badge_ocr_confidence':confidence})
                    decoded.append(result)
                return decoded

            if self.cancel_event.is_set():
                self.results_ready.emit([], 'Скасовано.', time.perf_counter()-started); return
            engine=_get_ocr_engine()

            def direct_decode(candidates, enhanced=False):
                direct, direct_elapsed = _recognize_known_roi_batch(
                    engine, [c.get('badge_crop') for c in candidates],
                    field='badge', target_height=48, enhanced=enhanced)
                if direct is None:
                    return None
                output=[]
                for candidate,(text,confidence) in zip(candidates,direct):
                    row=dict(candidate)
                    row.update({'discount_value':parse_percent(text), 'badge_ocr_text':str(text or '').strip(),
                                'badge_ocr_confidence':float(confidence or 0.0),
                                'badge_ocr_source':'recognition-only-enhanced' if enhanced else 'recognition-only'})
                    output.append(row)
                return output

            # Fast path: known badge coordinates let RapidOCR skip text detection and
            # orientation classification. Only uncertain crops are retried/enhanced.
            direct_rows=direct_decode(usable,False)
            if direct_rows is None:
                first=decode(make_montage(False))
                first_by_index={int(c.get('card_index',c.get('card',999))):c for c in first}
                needs_retry=any(c.get('discount_value') is None or
                                float(c.get('badge_ocr_confidence') or 0.0)<0.55 for c in first)
                final_by_index=first_by_index
                if needs_retry and not self.cancel_event.is_set():
                    second=decode(make_montage(True))
                    second_by_index={int(c.get('card_index',c.get('card',999))):c for c in second}
                    final_by_index={}
                    for idx,original in first_by_index.items():
                        retry=second_by_index.get(idx)
                        merged=_resolve_discount_ocr_evidence(
                            original,[original] + ([retry] if retry else []))
                        final_by_index[idx]=merged
            else:
                evidence_by_index={}
                direct_by_index={}
                for row in direct_rows:
                    idx=int(row.get('card_index',row.get('card',999)))
                    direct_by_index[idx]=row
                    evidence_by_index[idx]=[row]
                uncertain=[c for c in usable if (
                    direct_by_index.get(int(c.get('card_index',c.get('card',999))),{}).get('discount_value') is None
                    or float(direct_by_index.get(int(c.get('card_index',c.get('card',999))),{}).get('badge_ocr_confidence') or 0.0)<0.55)]
                if uncertain and not self.cancel_event.is_set():
                    enhanced_rows=direct_decode(uncertain,True)
                    if enhanced_rows is not None:
                        for row in enhanced_rows:
                            idx=int(row.get('card_index',row.get('card',999)))
                            evidence_by_index.setdefault(idx,[]).append(row)
                def unresolved_candidates():
                    pending=[]
                    for c in usable:
                        idx=int(c.get('card_index',c.get('card',999)))
                        merged=_resolve_discount_ocr_evidence(c,evidence_by_index.get(idx,[]))
                        if merged.get('discount_value') is None or float(merged.get('badge_ocr_confidence') or 0.0)<0.55 or merged.get('badge_ocr_conflict'):
                            pending.append(c)
                    return pending
                # The detector-based path is preserved as an exceptional fallback only;
                # it no longer runs for the common high-confidence badge case.
                pending=unresolved_candidates()
                if pending and not self.cancel_event.is_set():
                    fallback_rows=decode(make_montage(False))
                    fallback_by_index={int(c.get('card_index',c.get('card',999))):c for c in fallback_rows}
                    pending_indices={int(c.get('card_index',c.get('card',999))) for c in pending}
                    for idx in pending_indices:
                        fallback=fallback_by_index.get(idx)
                        if fallback:
                            fallback=dict(fallback); fallback['badge_ocr_source']='detector-fallback'
                            evidence_by_index.setdefault(idx,[]).append(fallback)
                pending=unresolved_candidates()
                if pending and not self.cancel_event.is_set():
                    fallback_rows=decode(make_montage(True))
                    fallback_by_index={int(c.get('card_index',c.get('card',999))):c for c in fallback_rows}
                    pending_indices={int(c.get('card_index',c.get('card',999))) for c in pending}
                    for idx in pending_indices:
                        fallback=fallback_by_index.get(idx)
                        if fallback:
                            fallback=dict(fallback); fallback['badge_ocr_source']='detector-fallback-enhanced'
                            evidence_by_index.setdefault(idx,[]).append(fallback)
                final_by_index={}
                for c in usable:
                    idx=int(c.get('card_index',c.get('card',999)))
                    final_by_index[idx]=_resolve_discount_ocr_evidence(c,evidence_by_index.get(idx,[]))
            ranked=list(final_by_index.values())
            total_elapsed=time.perf_counter()-started
            for row in ranked:
                row['badge_ocr_elapsed_seconds']=round(total_elapsed,4)
            ranked.sort(key=lambda c:(c.get('discount_value') is not None, int(c.get('discount_value') or 0),float(c.get('badge_ocr_confidence') or 0)),reverse=True)
            self.results_ready.emit(ranked,'',total_elapsed)
        except Exception as exc:
            self.results_ready.emit([],f'{type(exc).__name__}: {exc}',time.perf_counter()-started)


DETAIL_DISCOUNT_TOLERANCE_PCT = 2


def _normalize_price_status_ocr(text):
    """Normalize common Latin/Cyrillic homoglyphs in the detail price label."""
    value = str(text or '').casefold().replace('ё', 'е')
    # RapidOCR occasionally emits Latin glyphs inside Ukrainian text, for example
    # ``до pинку`` (Latin p) instead of ``до ринку``. Normalize only visually
    # confusable characters; keep English phrases available in the original text.
    value = value.translate(str.maketrans({
        'a': 'а', 'c': 'с', 'e': 'е', 'i': 'і', 'k': 'к', 'm': 'м',
        'o': 'о', 'p': 'р', 't': 'т', 'x': 'х', 'y': 'у',
        'h': 'н', 'b': 'в',
    }))
    value = re.sub(r'[^\w%$+\-]+', ' ', value, flags=re.UNICODE)
    return re.sub(r'\s+', ' ', value).strip()


def _detail_price_label_flags(status_text):
    """Return robust good/bad label flags, tolerating small OCR spelling errors."""
    original = str(status_text or '').casefold()
    normalized = _normalize_price_status_ocr(status_text)
    good = any(term in original for term in ('good price', 'below market'))
    good = good or any(term in normalized for term in ('добра ціна', 'хороша ціна', 'гарна ціна', 'до ринку', 'нижче ринку'))
    # Tolerate common one-character OCR errors such as ``хорова ціна`` while
    # deliberately not matching the negative phrase ``погана ціна``.
    good = good or bool(re.search(r'\b(?:хор\w{2,5}|доб\w{1,5}|гар\w{1,5})\s+цін\w*\b', normalized))
    bad = any(term in original for term in ('погана ціна', 'дороже ринку', 'дорожче за ринок', 'above market', 'markup'))
    bad = bad or bool(re.search(r'\bпоган\w*\s+цін\w*\b|\bдорожч\w*\s+(?:за\s+)?ринк\w*\b|\bнадцінк\w*\b', normalized))
    return bool(good), bool(bad), normalized


def validate_market_detail_screen(all_models, active_models, rules, global_threshold,
                                  model_thresholds, blacklisted_models, expected_discount,
                                  target_hwnd=None, confidence_floor=0.93,
                                  detail_frame_not_before=None, _retry_discount_mismatch=True,
                                  _allow_confirmed_badge_mismatch=False,
                                  _previous_detail_discount=None,
                                  _previous_detail_arithmetic_mismatch=False):
    """Read the opened car detail panel; retry once when card/detail discounts disagree."""
    started=time.perf_counter()
    capture_seconds=0.0
    ocr_seconds=0.0
    capture_backend='unavailable'
    result={'ok':False,'eligible':False,'reason':'деталі не перевірено','validation_seconds':None,
            'capture_seconds':0.0,'ocr_seconds':0.0,'capture_backend':capture_backend,
            'detail_ocr_fastpath_patch':DETAIL_OCR_FASTPATH_PATCH_VERSION}
    try:
        if not _foreground_matches_target(target_hwnd):
            result['reason']='втрачено фокус вікна гри'; return result
        import cv2, numpy as np, mss
        capture_started=time.perf_counter()
        # First reuse the fresh frame already being acquired by DIRECT GREEN WATCH.
        # It avoids opening a second MSS capture (the user's log showed 700–800 ms per grab).
        cached = _latest_watch_detail_panel(target_hwnd, detail_frame_not_before)
        # Only on the exceptional retry path, wait up to 50 ms for the next watcher
        # frame. The normal eligible-candidate path gains no extra delay; on mismatch
        # this short bounded wait can avoid a 700-800 ms independent MSS capture.
        if cached is None and _allow_confirmed_badge_mismatch and detail_frame_not_before is not None:
            frame_wait_deadline = time.perf_counter() + 0.050
            while cached is None and time.perf_counter() < frame_wait_deadline:
                time.sleep(0.005)
                cached = _latest_watch_detail_panel(target_hwnd, detail_frame_not_before)
        capture_backend = 'shared-direct-watch-frame'
        if cached is not None:
            panel, cached_meta = cached
            width, height = cached_meta['screen_size']
            x0=int(.690*width); x1=int(.990*width)
            y0=int(.135*height); y1=int(.295*height)
        else:
            # Safe fallback if no fresh same-window frame is available. The MSS session
            # is persistent so this path does not repeatedly initialize capture resources.
            with _DETAIL_CAPTURE_LOCK:
                capture=_get_detail_capture(mss)
                monitor=capture.monitors[1] if len(capture.monitors)>1 else capture.monitors[0]
                width,height=int(monitor['width']),int(monitor['height'])
                monitor_left=int(monitor.get('left',0)); monitor_top=int(monitor.get('top',0))
                if width<=0 or height<=0:
                    result['reason']='не вдалося отримати розмір екрана'; return result
                x0=int(.690*width); x1=int(.990*width)
                y0=int(.135*height); y1=int(.295*height)
                region={'left':monitor_left+x0,'top':monitor_top+y0,
                        'width':max(1,x1-x0),'height':max(1,y1-y0)}
                panel=np.asarray(capture.grab(region))[:,:,:3].copy()
            capture_backend = 'persistent-mss-fallback'
        capture_seconds=time.perf_counter()-capture_started
        if panel.size==0:
            result['reason']='порожня область деталей'; return result
        source_h,source_w=panel.shape[:2]
        # Fixed OCR dimensions make first-use inference predictable across Full HD/2K.
        # 1152x346 approximates a 2x detail panel at 1920x1080 and is smaller than
        # the old 2x image on 2K, reducing detector work while preserving text detail.
        ocr_width,ocr_height=1152,346
        scale_y=ocr_height/max(1,source_h)
        panel=cv2.resize(panel,(ocr_width,ocr_height),interpolation=cv2.INTER_CUBIC)
        engine=_get_ocr_engine()

        # Three known detail-panel bands have fixed positions. Recognition-only
        # inference skips detector/classifier work on the common path; we fall back
        # to the tested detector pipeline whenever a line, price, or model match is
        # uncertain. The purchase safety gates below are unchanged.
        compact_panel, compact_y_map = _compact_detail_ocr_image(panel, np)
        def extract_zone_text(zone_map):
            return (' '.join(t for _,t in zone_map['title'] if t),
                    ' '.join(t for _,t in zone_map['price'] if t),
                    ' '.join(t for _,t in zone_map['status'] if t))

        direct_used=False
        direct_started=time.perf_counter()
        direct_rows, direct_elapsed = _recognize_known_roi_batch(
            engine,
            [panel[20:100, :], panel[130:210, :], panel[220:310, :]],
            field='detail', target_height=48)
        if direct_rows is not None and len(direct_rows)==3:
            direct_texts=[str(item[0] or '').strip() for item in direct_rows]
            direct_scores=[float(item[1] or 0.0) for item in direct_rows]
            candidate_title,candidate_price,candidate_status=direct_texts
            candidate_model,candidate_model_confidence=match_catalog_model(candidate_title,all_models)
            direct_quality=(
                all(direct_texts)
                and min(direct_scores)>=0.48
                and candidate_model is not None
                and float(candidate_model_confidence)>=float(confidence_floor)
                and parse_price(candidate_price) is not None
                and (parse_percent(candidate_status) is not None or parse_price(candidate_status) is not None)
            )
            if direct_quality:
                title_text,price_text,status_text=direct_texts
                matched,confidence=candidate_model,float(candidate_model_confidence)
                direct_used=True
                result['detail_ocr_mode']='recognition-only-batch'
        if direct_used:
            ocr_seconds += max(time.perf_counter()-direct_started,float(direct_elapsed or 0.0))
        else:
            ocr_started=time.perf_counter()
            detections=engine(compact_panel)[0] or []
            ocr_seconds += time.perf_counter()-ocr_started
            zones=_detail_ocr_zones(detections, compact_y_map, y0, height, scale_y)
            title_text, price_text, status_text = extract_zone_text(zones)
            matched,confidence=match_catalog_model(title_text,all_models)
            needs_full_ocr=(not title_text or not price_text or not status_text or not matched
                            or float(confidence) < float(confidence_floor) or parse_price(price_text) is None)
            if needs_full_ocr:
                ocr_started=time.perf_counter()
                full_detections=engine(panel)[0] or []
                ocr_seconds += time.perf_counter()-ocr_started
                zones=_detail_ocr_zones(full_detections, None, y0, height, scale_y)
                title_text, price_text, status_text = extract_zone_text(zones)
                matched,confidence=match_catalog_model(title_text,all_models)
                result['detail_ocr_mode']='detector-full-fallback'
            else:
                result['detail_ocr_mode']='detector-compact'
        if not matched or float(confidence)<float(confidence_floor):
            result.update({'reason':f'модель не підтверджено (OCR: {title_text!r}, match: {matched!r}, confidence: {confidence:.2f})',
                           'detail_title_text':title_text,'model_confidence':float(confidence)})
            return result
        active_keys={normalize_vehicle_key(m) for m in active_models or []}
        blocked_keys={normalize_vehicle_key(m) for m in blacklisted_models or []}
        if normalize_vehicle_key(matched) not in active_keys:
            result.update({'reason':f'модель «{matched}» не входить до активного каталогу','catalog_model':matched,'detail_title_text':title_text})
            return result
        if normalize_vehicle_key(matched) in blocked_keys:
            result.update({'reason':f'модель «{matched}» у чорному списку','catalog_model':matched,'detail_title_text':title_text})
            return result
        price=parse_price(price_text)
        if not price:
            result.update({'reason':f'ціну не підтверджено (OCR: {price_text!r})','catalog_model':matched,'detail_price_text':price_text})
            return result
        ocr_discount=parse_percent(status_text)
        good_price_label,bad_price_label,normalized_status=_detail_price_label_flags(status_text)
        # The status row also carries the reference market price, e.g.:
        # ``Хороша ціна: -27% до ринку ($11 651)``. Use it as an independent
        # arithmetic cross-check so a single bad OCR character in ``Хороша ціна``
        # or ``до ринку`` cannot discard an otherwise clearly valid offer.
        reference_price=parse_price(status_text)
        calculated_discount=None
        if reference_price is not None and int(reference_price)>int(price)>0:
            calculated_discount=int(round((int(reference_price)-int(price))*100.0/int(reference_price)))
        try:
            expected=int(expected_discount) if expected_discount not in (None, '') else None
        except (TypeError,ValueError):
            expected=None
        # Use independent arithmetic as evidence from the detail page. The card
        # badge is a separate observation: do not let a >2 pp card/detail mismatch
        # prevent the fresh detail retry that can resolve a stale or misread badge.
        discount=ocr_discount if ocr_discount is not None else calculated_discount
        numeric_market_confirmation = (
            calculated_discount is not None and (
                (ocr_discount is not None and
                 abs(int(ocr_discount) - int(calculated_discount)) <= DETAIL_DISCOUNT_TOLERANCE_PCT)
                or (ocr_discount is None and expected is not None and
                    abs(int(expected) - int(calculated_discount)) <= DETAIL_DISCOUNT_TOLERANCE_PCT)
                or (_allow_confirmed_badge_mismatch and _previous_detail_discount is not None and
                    abs(int(_previous_detail_discount) - int(calculated_discount)) <= DETAIL_DISCOUNT_TOLERANCE_PCT)
            )
        )

        def retry_fresh_detail(first_reason, previous_arithmetic_mismatch=False):
            """Retry once on a fresh post-trigger frame; keep the normal path unchanged."""
            nonlocal capture_seconds, ocr_seconds
            if not _retry_discount_mismatch:
                return None
            retry_started = time.perf_counter()
            first_capture_seconds = float(capture_seconds or 0.0)
            first_ocr_seconds = float(ocr_seconds or 0.0)
            retry_result = validate_market_detail_screen(
                all_models, active_models, rules, global_threshold,
                model_thresholds, blacklisted_models, expected_discount,
                target_hwnd=target_hwnd, confidence_floor=confidence_floor,
                detail_frame_not_before=retry_started,
                _retry_discount_mismatch=False,
                _allow_confirmed_badge_mismatch=True,
                _previous_detail_discount=(int(discount) if discount is not None else None),
                _previous_detail_arithmetic_mismatch=bool(previous_arithmetic_mismatch))
            capture_seconds = first_capture_seconds + float(retry_result.get('capture_seconds') or 0.0)
            ocr_seconds = first_ocr_seconds + float(retry_result.get('ocr_seconds') or 0.0)
            if retry_result.get('ok'):
                retry_result['detail_retry_attempted'] = True
                retry_result['detail_retry_first_reason'] = first_reason
                retry_result['capture_seconds'] = round(capture_seconds, 4)
                retry_result['ocr_seconds'] = round(ocr_seconds, 4)
                retry_result['validation_seconds'] = round(time.perf_counter() - started, 4)
                return retry_result
            # Keep the initial clue and retry failure in the log so a missed offer
            # can be diagnosed from one screenshot instead of guessing.
            result.update({
                'reason': f'{first_reason}; повторне зчитування не підтвердило кандидата: {retry_result.get("reason", "без результату")}',
                'catalog_model': matched, 'price_value': price,
                'discount_value': discount, 'badge_discount_value': expected,
                'detail_title_text': title_text, 'detail_price_text': price_text,
                'detail_status_text': status_text,
                'discount_retry_reason': retry_result.get('reason'),
                'detail_retry_attempted': True,
            })
            return result

        if bad_price_label:
            result.update({'reason':f'деталі прямо позначають ціну як невигідну (OCR: {status_text!r})','catalog_model':matched,
                           'price_value':price,'detail_price_text':price_text,'detail_status_text':status_text})
            return result

        if discount is None:
            first_reason = f'не вдалося зчитати відсоток або ринкову ціну (OCR: {status_text!r})'
            if _retry_discount_mismatch:
                return retry_fresh_detail(first_reason)
            result.update({'reason':first_reason,'catalog_model':matched,
                           'detail_title_text':title_text,'detail_price_text':price_text,'detail_status_text':status_text})
            return result

        # A percentage contradicting the arithmetic is the classic OCR-error case.
        # Re-read once before rejecting; on the retry this remains a hard failure
        # unless the fresh OCR and the lot/reference prices agree within ±2 pp.
        arithmetic_mismatch = (
            ocr_discount is not None and calculated_discount is not None and
            abs(int(ocr_discount) - int(calculated_discount)) > DETAIL_DISCOUNT_TOLERANCE_PCT
        )
        if arithmetic_mismatch:
            first_reason = (
                f'відсоток OCR ({ocr_discount}%) суперечить ціні лота/ринковій ціні '
                f'({calculated_discount}%; допуск ±{DETAIL_DISCOUNT_TOLERANCE_PCT}%)'
            )
            if _retry_discount_mismatch:
                return retry_fresh_detail(first_reason, previous_arithmetic_mismatch=True)
            result.update({'reason':first_reason,'catalog_model':matched,'price_value':price,
                           'discount_value':discount,'calculated_discount_value':calculated_discount,
                           'detail_title_text':title_text,'detail_price_text':price_text,'detail_status_text':status_text})
            return result

        if not good_price_label and not numeric_market_confirmation:
            first_reason = f'знижку в деталях не підтверджено (OCR: {status_text!r}; нормалізовано: {normalized_status!r})'
            if _retry_discount_mismatch:
                return retry_fresh_detail(first_reason)
            result.update({'reason':first_reason,'catalog_model':matched,
                           'detail_price_text':price_text,'detail_status_text':status_text})
            return result

        badge_mismatch = expected is not None and abs(int(discount) - int(expected)) > DETAIL_DISCOUNT_TOLERANCE_PCT
        repeated_detail_is_confirmed = (
            badge_mismatch and _allow_confirmed_badge_mismatch
            and _previous_detail_discount is not None
            and (abs(int(discount) - int(_previous_detail_discount)) <= DETAIL_DISCOUNT_TOLERANCE_PCT
                 or _previous_detail_arithmetic_mismatch)
            and calculated_discount is not None
            and abs(int(discount) - int(calculated_discount)) <= DETAIL_DISCOUNT_TOLERANCE_PCT
            and not bad_price_label
            and (good_price_label or numeric_market_confirmation)
        )
        if badge_mismatch and not repeated_detail_is_confirmed:
            first_reason = (
                f'розбіжність бейджа -{expected}% і деталей -{discount}% перевищує '
                f'допуск ±{DETAIL_DISCOUNT_TOLERANCE_PCT} відсоткові пункти'
            )
            if _retry_discount_mismatch:
                return retry_fresh_detail(first_reason)
            result.update({'reason':f'{first_reason}; повторне зчитування не підтвердило однаковий відсоток і арифметичну звірку',
                           'catalog_model':matched,'price_value':price,'discount_value':discount,
                           'detail_title_text':title_text,'detail_price_text':price_text,'detail_status_text':status_text,
                           'badge_discount_value':expected,'calculated_discount_value':calculated_discount})
            return result

        rule=dict((rules or {}).get(matched,{}) or {})
        category=str(rule.get('category','Звичайне')).strip()
        if category in ('Пріоритетне','Пріоритетна'): category_threshold=15
        elif category in ('Спеціальне','Спеціальна'): category_threshold=50
        else: category_threshold=int(global_threshold)
        threshold=effective_threshold(category,(model_thresholds or {}).get(matched),category_threshold,int(global_threshold))
        if int(discount)<abs(int(threshold)):
            result.update({'reason':f'знижка -{discount}% нижча за поріг моделі -{abs(int(threshold))}%',
                           'catalog_model':matched,'price_value':price,'discount_value':discount,'threshold':int(threshold),
                           'detail_title_text':title_text,'detail_price_text':price_text,'detail_status_text':status_text})
            return result
        validation_method = ('OCR-відсоток + арифметична звірка з ринковою ціною'
                             if calculated_discount is not None and ocr_discount is not None
                             else 'арифметична звірка з ринковою ціною'
                             if calculated_discount is not None
                             else 'OCR-підпис і відсоток')
        success_reason = ('повторно підтверджено деталі та ринкову ціну; розбіжність бейджа картки прийнята за підтвердженим відсотком'
                          if repeated_detail_is_confirmed else
                          'модель, ціна, зелена знижка та поріг підтверджені')
        result.update({'ok':True,'eligible':True,'reason':success_reason,
                       'catalog_model':matched,'model':matched,'model_confidence':float(confidence),
                       'price_value':int(price),'price':format_price(price),'discount_value':int(discount),
                       'discount':f'-{int(discount)}%','discount_kind':'discount','badge_color':'GREEN',
                       'threshold':abs(int(threshold)),'detail_title_text':title_text,'detail_price_text':price_text,
                       'detail_status_text':status_text,'detail_discount_validation_patch':DETAIL_DISCOUNT_VALIDATION_PATCH_VERSION,
                       'detail_discount_validation_method':validation_method,
                       'market_reference_price_value':int(reference_price) if reference_price is not None else None,
                       'calculated_discount_value':calculated_discount,
                       'badge_discount_value':expected,
                       'badge_mismatch_retry_confirmed':bool(repeated_detail_is_confirmed)})
        return result
    except Exception as exc:
        result['reason']=f'помилка перевірки деталей: {type(exc).__name__}: {exc}'
        return result
    finally:
        result['validation_seconds']=round(time.perf_counter()-started,4)
        result['capture_seconds']=round(float(capture_seconds or 0.0),4)
        result['ocr_seconds']=round(float(ocr_seconds or 0.0),4)
        result['capture_backend']=capture_backend




def _remap_cached_rows_by_signature(current_signatures, previous_signatures,
                                    previous_rows, previous_field_signatures):
    """Reuse OCR rows across cell shifts, but never guess when fingerprints collide.

    Exact same-cell matches are pinned first. A card can move to a different cell only
    when its fingerprint is unique in both frames. Unmatched cells retain the old
    same-cell row as a per-field comparison fallback (unless that old row has already
    moved elsewhere); changed field masks then force OCR for only the changed fields.
    """
    from collections import Counter

    current_signatures = list(current_signatures or [])
    previous_signatures = list(previous_signatures or [])
    previous_rows = list(previous_rows or [])
    previous_field_signatures = list(previous_field_signatures or [])
    count = len(current_signatures)
    rows = [None] * count
    fields = [None] * count
    mapping = {}
    used_previous = set()

    def valid_previous(index):
        return (index < len(previous_rows) and isinstance(previous_rows[index], dict)
                and index < len(previous_field_signatures)
                and isinstance(previous_field_signatures[index], dict))

    current_counts = Counter(signature for signature in current_signatures if signature)
    previous_counts = Counter(signature for signature in previous_signatures if signature)

    # Prefer exact same-cell rows first; this is safest when identical lots appear twice.
    for index, signature in enumerate(current_signatures):
        if (signature and index < len(previous_signatures)
                and previous_signatures[index] == signature and valid_previous(index)):
            rows[index] = copy.deepcopy(previous_rows[index])
            fields[index] = copy.deepcopy(previous_field_signatures[index])
            mapping[index] = index
            used_previous.add(index)

    # A moved card is remapped only when the fingerprint uniquely identifies exactly
    # one card in both frames. Ambiguous repeated signatures fall back to same-cell
    # per-field comparisons instead of borrowing an arbitrary card's cached data.
    unique_previous = {
        signature: index
        for index, signature in enumerate(previous_signatures)
        if signature and previous_counts[signature] == 1 and valid_previous(index)
    }
    for current_index, signature in enumerate(current_signatures):
        if current_index in mapping or not signature or current_counts[signature] != 1:
            continue
        previous_index = unique_previous.get(signature)
        if previous_index is None or previous_index in used_previous:
            continue
        rows[current_index] = copy.deepcopy(previous_rows[previous_index])
        fields[current_index] = copy.deepcopy(previous_field_signatures[previous_index])
        mapping[current_index] = previous_index
        used_previous.add(previous_index)

    # Keep old same-cell information only as a field-level fallback. Do not duplicate a
    # cached row that was already moved to another current cell.
    for current_index in range(count):
        if current_index in mapping or current_index in used_previous or not valid_previous(current_index):
            continue
        rows[current_index] = copy.deepcopy(previous_rows[current_index])
        fields[current_index] = copy.deepcopy(previous_field_signatures[current_index])
        mapping[current_index] = current_index
        used_previous.add(current_index)

    return rows, fields, mapping

def _market_grid_presence_score(frame, grid, screen_size, monitor_left=0, monitor_top=0):
    """Cheap OCR-free evidence that a real 3x5 listing grid is painted on screen.

    It scores thumbnail-like image texture plus title/price footer texture per card.
    This is intentionally conservative: it is used only to decide when it is safe to
    resume scanning after a click flow, never to authorize a purchase.
    """
    result = {'market_grid_visible': False, 'valid_cells': 0,
              'image_like_cells': 0, 'footer_like_cells': 0,
              'distinct_thumbnail_cells': 0, 'score': 0.0}
    try:
        import cv2
        import numpy as np
        if frame is None or getattr(frame, 'size', 0) == 0 or frame.ndim != 3:
            return result
        frame_h, frame_w = frame.shape[:2]
        screen_w, screen_h = int(screen_size[0]), int(screen_size[1])
        if min(frame_w, frame_h, screen_w, screen_h) <= 0:
            return result
        origin_x, origin_y = int(monitor_left or 0), int(monitor_top or 0)
        g = dict(grid or {})
        cols = max(1, int(g.get('cols', 5) or 5))
        rows = max(1, int(g.get('rows', 3) or 3))
        left, right = float(g.get('left', .153)), float(g.get('right', .985))
        top, bottom = float(g.get('top', .095)), float(g.get('bottom', .895))
        use_ahk = (cols == 5 and rows == 3 and abs(left-.153) <= .008
                   and abs(right-.985) <= .008 and abs(top-.095) <= .008
                   and abs(bottom-.895) <= .012)
        ahk_lefts = (.155, .322, .489, .655, .822)
        ahk_rights = (.315, .481, .647, .813, .981)
        row_offsets = (0.0, .270, .540)
        cell_w = (right-left) * screen_w / cols
        cell_h = (bottom-top) * screen_h / rows
        image_like = 0
        footer_like = 0
        valid_cells = 0
        thumbnail_hashes = set()

        def local_box(x0s, y0s, x1s, y1s):
            xa = max(0, min(frame_w-1, int(x0s)-origin_x))
            xb = max(xa+1, min(frame_w, int(x1s)-origin_x))
            ya = max(0, min(frame_h-1, int(y0s)-origin_y))
            yb = max(ya+1, min(frame_h, int(y1s)-origin_y))
            return xa, ya, xb, yb

        for index in range(rows * cols):
            row, col = divmod(index, cols)
            if use_ahk:
                xa_s, xb_s = int(ahk_lefts[col]*screen_w), int(ahk_rights[col]*screen_w)
                ya_s = int((.095 + row_offsets[row])*screen_h)
                yb_s = int((.095 + row_offsets[row] + .265)*screen_h)
            else:
                xa_s = int(left*screen_w + col*cell_w)
                xb_s = int(left*screen_w + (col+1)*cell_w)
                ya_s = int(top*screen_h + row*cell_h)
                yb_s = int(top*screen_h + (row+1)*cell_h)
            xa, ya, xb, yb = local_box(xa_s, ya_s, xb_s, yb_s)
            card = frame[ya:yb, xa:xb]
            if card.size == 0 or card.shape[0] < 24 or card.shape[1] < 24:
                continue
            valid_cells += 1
            ch, cw = card.shape[:2]
            thumb = card[int(.025*ch):max(int(.026*ch)+1, int(.70*ch)),
                         int(.02*cw):max(int(.021*cw)+1, int(.74*cw))]
            if thumb.size:
                gray = cv2.cvtColor(thumb, cv2.COLOR_BGR2GRAY)
                gray_std = float(gray.std())
                edges = cv2.Canny(gray, 45, 130)
                edge_density = float(np.count_nonzero(edges)) / max(1, edges.size)
                hsv = cv2.cvtColor(thumb, cv2.COLOR_BGR2HSV)
                saturated_fraction = float(np.count_nonzero(hsv[:, :, 1] >= 42)) / max(1, hsv.shape[0]*hsv.shape[1])
                if (gray_std >= 14.0 and edge_density >= .012
                        and (saturated_fraction >= .012 or edge_density >= .030)):
                    image_like += 1
                    tiny = cv2.resize(gray, (8, 8), interpolation=cv2.INTER_AREA)
                    thumbnail_hashes.add(bytes((tiny // 12).reshape(-1).tolist()))
            footer = card[int(.70*ch):max(int(.71*ch)+1, int(.99*ch)), :max(1, int(.75*cw))]
            if footer.size:
                footer_gray = cv2.cvtColor(footer, cv2.COLOR_BGR2GRAY)
                footer_edges = cv2.Canny(footer_gray, 45, 130)
                footer_density = float(np.count_nonzero(footer_edges)) / max(1, footer_edges.size)
                if float(footer_gray.std()) >= 7.0 and footer_density >= .008:
                    footer_like += 1
        denominator = max(1, rows * cols)
        distinct = len(thumbnail_hashes)
        # On the calibrated market layout there should be many independent vehicle
        # thumbnails and compact text footers. A details page generally has only one
        # large car image and an information panel, so it fails the thumbnail count.
        visible = (valid_cells >= max(12, int(denominator*.80))
                   and image_like >= max(8, int(denominator*.53))
                   and footer_like >= max(8, int(denominator*.53))
                   and distinct >= max(6, int(denominator*.38)))
        result.update({
            'market_grid_visible': bool(visible), 'valid_cells': int(valid_cells),
            'image_like_cells': int(image_like), 'footer_like_cells': int(footer_like),
            'distinct_thumbnail_cells': int(distinct),
            'score': round(min(image_like, footer_like) / float(denominator), 3),
        })
        return result
    except Exception as exc:
        result['error'] = f'{type(exc).__name__}: {exc}'
        return result


def _locate_green_confirm_button_center_in_frame(frame, screen_size,
                                                 monitor_left=0, monitor_top=0):
    """Locate the modal's green Confirm CTA in screen coordinates without OCR.

    The location is based on the same 1920x1080 reference space as scanner_actions.
    A bounded search around that point allows the modal to shift vertically when an
    alert/banner is shown. This probe is used only for post-action navigation; it does
    not participate in candidate analysis or the purchase click chain.
    """
    try:
        import cv2
        import numpy as np
        if frame is None or getattr(frame, 'size', 0) == 0 or getattr(frame, 'ndim', 0) != 3:
            return None
        screen_w, screen_h = int(screen_size[0]), int(screen_size[1])
        if screen_w <= 0 or screen_h <= 0 or frame.shape[2] < 3:
            return None
        sx, sy = screen_w / 1920.0, screen_h / 1080.0
        origin_x, origin_y = int(monitor_left or 0), int(monitor_top or 0)
        expected_x = int(round(1070 * sx)) - origin_x
        expected_y = int(round(717 * sy)) - origin_y
        frame_h, frame_w = frame.shape[:2]
        radius_x = max(100, int(round(165 * sx)))
        min_dy, max_dy = int(round(-60 * sy)), int(round(115 * sy))
        x0, x1 = max(0, expected_x-radius_x), min(frame_w, expected_x+radius_x+1)
        y0, y1 = max(0, expected_y+min_dy), min(frame_h, expected_y+max_dy+1)
        if x1 <= x0 or y1 <= y0:
            return None
        patch = np.ascontiguousarray(frame[y0:y1, x0:x1, :3])
        b = patch[:, :, 0].astype(np.int16)
        g = patch[:, :, 1].astype(np.int16)
        r = patch[:, :, 2].astype(np.int16)
        mask = ((g >= 150) & (r <= 110) & (b >= 80)
                & (g > r * 1.45) & (g > b * 1.06)).astype('uint8') * 255
        # Close only small holes around text glyphs; do not merge unrelated controls.
        kernel = np.ones((max(3, int(round(5 * sy))), max(3, int(round(13 * sx)))), dtype='uint8')
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel, iterations=1)
        contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        min_width = max(90, int(round(100 * sx)))
        min_height = max(16, int(round(18 * sy)))
        best = None
        for contour in contours:
            bx, by, bw, bh = cv2.boundingRect(contour)
            if bw < min_width or bh < min_height:
                continue
            local_cx, local_cy = x0 + bx + bw // 2, y0 + by + bh // 2
            dx, dy = local_cx - expected_x, local_cy - expected_y
            if abs(dx) > radius_x or dy < min_dy or dy > max_dy:
                continue
            # Wide rectangular mint-green controls score better than stray green pixels.
            score = abs(dx) + 1.25 * abs(dy) - min(bw, int(round(320 * sx))) * 0.025
            if best is None or score < best[0]:
                best = (score, (origin_x + local_cx, origin_y + local_cy))
        return best[1] if best is not None else None
    except Exception:
        return None


def _green_confirm_button_visible_in_frame(frame, screen_size, monitor_left=0, monitor_top=0):
    """Compatibility boolean probe built on the dynamic CTA locator."""
    return _locate_green_confirm_button_center_in_frame(
        frame, screen_size, monitor_left=monitor_left, monitor_top=monitor_top
    ) is not None


def probe_market_return_state(grid, target_hwnd=None):
    """Return an OCR-free, conservative UI state for post-purchase continuation.

    States: market (two-frame stability is checked by main.py), detail, confirm,
    not_foreground, unknown. For a visible confirm modal it also returns dynamic
    confirm/cancel button centers for post-action dismissal. It never authorizes a purchase.
    """
    result = {'state': 'unknown', 'reason': 'state not recognized', 'frame_timestamp': None,
              'capture_seconds': 0.0, 'capture_backend': 'not-started',
              'market_score': {}}
    if os.name != 'nt':
        result['reason'] = 'market UI probe requires Windows desktop capture'
        return result
    try:
        size = _primary_screen_size()
        if not size:
            result['reason'] = 'physical screen size unavailable'
            return result
        if not _foreground_matches_target(target_hwnd):
            result['state'] = 'not_foreground'
            result['reason'] = 'game window is not foreground'
            return result
        import numpy as np
        (frame, capture_origin, desktop_origin, actual_size, backend,
         capture_seconds, frame_timestamp) = _capture_market_frame(grid, np)
        if tuple(actual_size) != tuple(size):
            result['reason'] = 'screen size changed during UI probe'
            return result
        result['frame_timestamp'] = frame_timestamp
        result['capture_seconds'] = max(0.0, float(capture_seconds or 0.0))
        result['capture_backend'] = str(backend or 'unknown')
        # Confirmation modal is checked before the detail CTA because the modal can
        # overlay a details page while the old button remains visible underneath it.
        confirm_center = _locate_green_confirm_button_center_in_frame(
            frame, actual_size, monitor_left=int(capture_origin[0]),
            monitor_top=int(capture_origin[1]))
        if confirm_center is not None:
            # The Cancel button is laid out immediately to the left of the green CTA.
            # Derive its point from the observed button rather than assuming a fixed
            # absolute screen coordinate; this also follows vertical modal shifts.
            cancel_offset_x = int(round(256 * actual_size[0] / 1920.0))
            cancel_center = (int(confirm_center[0] - cancel_offset_x), int(confirm_center[1]))
            result.update({'state': 'confirm',
                           'reason': 'FINAL_CONFIRM-style green modal button is visible',
                           'confirm_button_center': tuple(map(int, confirm_center)),
                           'cancel_button_center': cancel_center})
            return result
        if _direct_watch_has_detail_buy_button_screen(actual_size, target_hwnd):
            result.update({'state': 'detail', 'reason': 'detail-page Buy CTA is still visible'})
            return result
        evidence = _market_grid_presence_score(
            frame, grid, actual_size, monitor_left=int(capture_origin[0]), monitor_top=int(capture_origin[1]))
        result['market_score'] = evidence
        if evidence.get('market_grid_visible'):
            result.update({'state': 'market', 'reason': '3x5 grid texture and card-footer evidence is stable enough'})
        else:
            result.update({'state': 'unknown', 'reason': 'market grid evidence is not strong enough; OCR remains paused'})
        return result
    except Exception as exc:
        result['reason'] = f'{type(exc).__name__}: {exc}'
        return result


class ScanWorker(QThread):
    result = Signal(list, str, float)
    progress = Signal(int, str)
    # Sent as soon as a fully validated GREEN candidate is parsed; the UI can
    # begin the purchase workflow without waiting for unrelated card parsing.
    candidate_found = Signal(dict)

    def __init__(self, models, rules, global_threshold, model_thresholds, grid,
                 active_models=None, blacklisted_models=None, target_hwnd=None,
                 fast_color_filter_enabled=True, confidence_protection_enabled=True,
                 fast_candidate_mode=False):
        super().__init__()
        self.models = list(models)
        self.rules = {k: dict(v) for k, v in (rules or {}).items()}
        self.global_threshold = abs(int(global_threshold))
        self.model_thresholds = dict(model_thresholds or {})
        self.grid = dict(grid or {})
        self.active_models = set(active_models if active_models is not None else self.models)
        self.blacklisted_models = set(blacklisted_models or [])
        self._blacklisted_model_keys = {normalize_vehicle_key(name) for name in self.blacklisted_models if normalize_vehicle_key(name)}
        self.target_hwnd = int(target_hwnd) if target_hwnd not in (None, 0) else None
        self.fast_color_filter_enabled = bool(fast_color_filter_enabled)
        self.confidence_protection_enabled = bool(confidence_protection_enabled)
        # The auto-buy path uses a GREEN badge pre-pass and then prioritizes the
        # largest discounts, OCRing one candidate's remaining fields at a time.
        # The normal viewer can keep the compact full GREEN-only batch path.
        self.fast_candidate_mode = bool(fast_candidate_mode and self.fast_color_filter_enabled)
        self.cancel_event = threading.Event()
        self._ocr_call_count = 0
        self._ocr_elapsed_seconds = 0.0
        self._ocr_engine_init_seconds = 0.0
        self._changed_cards = 15
        self._cache_hits = 0
        self._changed_fields = 0
        self._ocr_fields = []
        self._changed_field_map = {}
        self._stage_seconds = {}
        self._last_stage_seconds = {}
        self._last_stage_info = {}
        self._last_ocr_engine_init_seconds = 0.0
        self._last_ocr_engine_warmup_seconds = 0.0
        self._last_ocr_engine_config = 'not-initialized'
        self._last_ocr_active_providers = []
        self._cache_debug = {}
        self._field_change_counts = {'name': 0, 'price': 0, 'badge': 0}
        self._fast_color_skipped_indices = []
        self._green_badge_count = 0
        self._first_candidate_elapsed_seconds = None
        self._candidate_signal_count = 0
        self._fast_lane_below_threshold_skipped = 0

    def cancel(self):
        self.cancel_event.set()

    def _emit_fast_candidate(self, row, scan_started):
        """Send a validated GREEN purchase candidate before the rest of the scan finishes.

        This is deliberately a strict gate: the UI receives only results which the
        normal eligibility engine already approved and which have usable coordinates.
        The purchase worker still re-checks the foreground game and calibrated screen.
        """
        if not isinstance(row, dict):
            return False
        if (str(row.get('badge_color', '')).upper() != 'GREEN'
                or row.get('discount_kind') != 'discount'
                or not bool(row.get('eligible'))
                or row.get('price_value') is None
                or row.get('threshold') is None):
            return False
        model = str(row.get('catalog_model') or '').strip()
        if not model or model not in self.active_models:
            return False
        if normalize_vehicle_key(model) in self._blacklisted_model_keys:
            return False
        try:
            confidence = float(row.get('model_confidence') or 0.0)
            discount = int(row.get('discount_value'))
            threshold = abs(int(row.get('threshold')))
            xy = row.get('xy')
            size = row.get('screen_size')
            x, y = int(xy[0]), int(xy[1])
            width, height = int(size[0]), int(size[1])
        except (TypeError, ValueError, IndexError):
            return False
        confidence_floor = 0.93 if self.confidence_protection_enabled else 0.80
        if (confidence < confidence_floor or discount < threshold or width <= 0 or height <= 0
                or x < 0 or y < 0 or x >= width or y >= height):
            return False
        if self._first_candidate_elapsed_seconds is None:
            self._first_candidate_elapsed_seconds = max(0.0, time.perf_counter() - scan_started)
        self._candidate_signal_count += 1
        detected_at = time.perf_counter()
        candidate = copy.deepcopy(row)
        candidate['_fast_candidate_detected_after_seconds'] = round(
            max(0.0, detected_at - scan_started), 4
        )
        candidate['_fast_candidate_detected_at_perf_counter'] = detected_at
        # Reuse the already verified foreground game window. The purchase worker
        # revalidates that it is still the foreground window before sending input.
        candidate['_target_hwnd'] = self.target_hwnd
        signal = getattr(self, 'candidate_found', None)
        if hasattr(signal, 'emit'):
            signal.emit(candidate)
            return True
        # Unit harnesses can replace Qt signals with lightweight collectors; the
        # ordinary result payload remains complete when no fast signal is available.
        return False

    def _run_green_fast_lane(self, changed_contexts, contexts, previous_rows,
                             previous_field_signatures, changed_indices, fast_skipped_indices,
                             signatures, screen_size, config_key, screen_key,
                             rows, cols, cv2, np, started, stage, field_order):
        """Prioritize largest GREEN discounts; return rows, error, elapsed.

        With auto-buy enabled, badge text is read for changed GREEN cards in one small
        batch. Cards are then sorted by their visible discount, and each card's changed
        name/price fields are OCRed individually. An eligible high discount can therefore
        trigger the guarded purchase flow before the remaining green cards are parsed.
        If no candidate qualifies, the worker still returns a complete, cacheable grid.
        """
        global _CARD_CACHE_SIGNATURES, _CARD_CACHE_RESULTS, _CARD_CACHE_FIELD_SIGNATURES
        global _CARD_CACHE_CONFIG_KEY, _CARD_CACHE_SCREEN_KEY
        parse_started = time.perf_counter()
        self._fast_lane_below_threshold_skipped = 0
        self._ocr_fields = ['badge']
        # When exactly one new/changed green card needs OCR, batch its badge, title,
        # and price ROIs in one recognition-only call. This removes a sequential OCR
        # round-trip before the first candidate while keeping the multi-card priority
        # path (badge ranking first) unchanged.
        predecoded_name_price_by_index = {}
        records_by_index = {}
        skipped_set = set(fast_skipped_indices)
        for i, prior_row in enumerate(previous_rows):
            if i in skipped_set:
                prior_fields = previous_field_signatures[i] if i < len(previous_field_signatures) else None
                records_by_index[i] = self._color_gate_result(
                    contexts[i], prior_row, prior_fields, contexts[i].get('field_signatures'), cv2, np
                )
            elif i not in changed_indices and prior_row is not None:
                prior_row['xy'] = contexts[i].get('xy')
                prior_row['screen_size'] = screen_size
                prior_row['_cache_hit'] = True
                records_by_index[i] = prior_row
            elif prior_row is None and i not in changed_indices:
                records_by_index[i] = self._color_gate_result(
                    contexts[i], None, None, contexts[i].get('field_signatures'), cv2, np
                )

        # Because per-model/category overrides are already resolved by _threshold_for,
        # the minimum threshold across enabled models is a safe lower bound. Any known
        # GREEN percentage below it can never qualify, so its title/price OCR is wasted.
        try:
            active_threshold_floor = min(
                (int(self._threshold_for(model)) for model in self.active_models),
                default=None,
            )
        except (TypeError, ValueError):
            active_threshold_floor = None

        original_fields = {}
        badge_contexts = []
        for ctx in changed_contexts:
            idx = int(ctx['card_index'])
            original_fields[idx] = list(ctx.get('_fields_to_ocr', field_order))
            previous = previous_rows[idx] if idx < len(previous_rows) else None
            # Only run badge OCR when the badge itself changed (or this is a new
            # card with no reusable prior result). A name/price-only refresh must
            # not make us re-read an unchanged discount badge.
            needs_badge_ocr = ('badge' in original_fields[idx] or not isinstance(previous, dict))
            ctx['_fields_to_ocr'] = ['badge'] if needs_badge_ocr else []
            if needs_badge_ocr:
                badge_contexts.append(ctx)

        badge_by_index = {}
        engine = None
        if badge_contexts:
            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                stage['parse_and_rules'] = time.perf_counter() - parse_started
                stage['total'] = elapsed
                return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed

            engine = _get_ocr_engine()
            self._ocr_engine_init_seconds = _OCR_ENGINE_INIT_SECONDS
            badge_started = time.perf_counter()
            direct_rows = None
            direct_elapsed = 0.0
            combined_rows = None
            combined_fields_order = []
            # The common urgent case is one newly appeared green offer. Its exact
            # text ROIs are already known, so avoid a badge pass followed by a second
            # title/price pass. If there are multiple changed green cards, preserve
            # largest-discount-first selection and keep this optimization disabled.
            if len(badge_contexts) == 1 and callable(getattr(engine, 'recognize_crops', None)):
                only_ctx = badge_contexts[0]
                only_idx = int(only_ctx['card_index'])
                combined_fields_order = ['badge'] + [
                    field_name for field_name in ('name', 'price')
                    if field_name in original_fields.get(only_idx, [])
                ]
                if len(combined_fields_order) > 1:
                    combined_crops = [only_ctx.get(f'{field_name}_crop') for field_name in combined_fields_order]
                    combined_rows, combined_elapsed = _recognize_known_roi_batch(
                        engine, combined_crops, field=combined_fields_order, target_height=48)
                    if combined_rows is not None and len(combined_rows) == len(combined_fields_order):
                        direct_rows = [combined_rows[0]]
                        direct_elapsed = combined_elapsed
                        predecoded_name_price_by_index[only_idx] = {
                            field_name: {'text': str(text or '').strip(), 'confidence': float(confidence or 0.0)}
                            for field_name, (text, confidence) in zip(combined_fields_order[1:], combined_rows[1:])
                        }
                        stage['fast_lane_combined_candidate_batch'] = float(combined_elapsed or 0.0)
                        stage['fast_lane_combined_candidate_batch_fields'] = list(combined_fields_order)
            if direct_rows is None:
                direct_rows, direct_elapsed = _recognize_known_roi_batch(
                    engine, [ctx.get('badge_crop') for ctx in badge_contexts],
                    field='badge', target_height=48)
            if direct_rows is not None:
                self._ocr_call_count += 1
                self._ocr_elapsed_seconds += float(direct_elapsed or 0.0)
                stage['fast_lane_badge_recognition_only'] = float(direct_elapsed or 0.0)
                stage['ocr'] = self._ocr_elapsed_seconds
                evidence_by_index = {}
                for ctx, (text, confidence) in zip(badge_contexts, direct_rows):
                    idx = int(ctx['card_index'])
                    evidence_by_index[idx] = [{
                        'discount_value': parse_percent(text), 'badge_ocr_text': str(text or '').strip(),
                        'badge_ocr_confidence': float(confidence or 0.0), 'badge_ocr_source': 'recognition-only'
                    }]

                detector_fallback_skipped_consensus = set()

                def unresolved_badge_contexts():
                    pending=[]
                    for candidate_ctx in badge_contexts:
                        idx=int(candidate_ctx['card_index'])
                        evidence = evidence_by_index.get(idx, [])
                        if _has_credible_recognition_only_badge_consensus(evidence):
                            detector_fallback_skipped_consensus.add(idx)
                            continue
                        if _badge_requires_detector_rescue(candidate_ctx, evidence):
                            pending.append(candidate_ctx)
                    return pending

                # Only uncertain badges get the contrast-normalized recognition retry.
                uncertain=unresolved_badge_contexts()
                if uncertain and not self.cancel_event.is_set():
                    enhanced_rows, enhanced_elapsed = _recognize_known_roi_batch(
                        engine, [ctx.get('badge_crop') for ctx in uncertain],
                        field='badge', target_height=48, enhanced=True)
                    if enhanced_rows is not None:
                        self._ocr_call_count += 1
                        self._ocr_elapsed_seconds += float(enhanced_elapsed or 0.0)
                        stage['fast_lane_badge_recognition_retry'] = float(enhanced_elapsed or 0.0)
                        for candidate_ctx,(text,confidence) in zip(uncertain,enhanced_rows):
                            idx=int(candidate_ctx['card_index'])
                            evidence_by_index.setdefault(idx,[]).append({
                                'discount_value':parse_percent(text),'badge_ocr_text':str(text or '').strip(),
                                'badge_ocr_confidence':float(confidence or 0.0),
                                'badge_ocr_source':'recognition-only-enhanced'})

                # Detector OCR remains only a rescue path for uncertain small text,
                # rather than running on every changed badge in the normal cycle.
                uncertain=unresolved_badge_contexts()
                stage['fast_lane_badge_detector_fallback_skipped_consensus_calls'] = len(detector_fallback_skipped_consensus)
                if uncertain and not self.cancel_event.is_set():
                    montage_started=time.perf_counter()
                    for candidate_ctx in uncertain:
                        candidate_ctx['_fields_to_ocr']=['badge']
                    fallback_montage,fallback_layout=self._build_ocr_montage(
                        uncertain,cv2,np,selected_fields=['badge'])
                    stage['fast_lane_badge_fallback_montage_build']=time.perf_counter()-montage_started
                    fallback_started=time.perf_counter()
                    self._ocr_call_count += 1
                    try:
                        fallback_rows,_=engine(fallback_montage)
                    finally:
                        fallback_elapsed=time.perf_counter()-fallback_started
                        self._ocr_elapsed_seconds += fallback_elapsed
                    stage['fast_lane_badge_detector_fallback']=fallback_elapsed
                    fallback_groups=group_montage_ocr(fallback_rows,fallback_layout,count=len(uncertain))
                    for candidate_ctx,group in zip(uncertain,fallback_groups):
                        idx=int(candidate_ctx['card_index'])
                        group=group or {}
                        fallback_text=str(group.get('badge') or '').strip()
                        evidence_by_index.setdefault(idx,[]).append({
                            'discount_value':parse_percent(fallback_text),'badge_ocr_text':fallback_text,
                            'badge_ocr_confidence':float(group.get('badge_confidence') or 0.0),
                            'badge_ocr_source':'detector-fallback'})

                for candidate_ctx in badge_contexts:
                    idx=int(candidate_ctx['card_index'])
                    merged=_resolve_discount_ocr_evidence(candidate_ctx,evidence_by_index.get(idx,[]))
                    badge_by_index[idx]={
                        'badge': '' if merged.get('badge_ocr_conflict') else str(merged.get('badge_ocr_text') or ''),
                        'badge_confidence': 0.0 if merged.get('badge_ocr_conflict') else float(merged.get('badge_ocr_confidence') or 0.0),
                        '_badge_ocr_conflict': bool(merged.get('badge_ocr_conflict')),
                        'badge_ocr_sources': merged.get('badge_ocr_sources',[]),
                    }
            else:
                # Proven detector/montage fallback for older RapidOCR adapters and
                # any engine that cannot expose its recognition-only model method.
                montage_started = time.perf_counter()
                badge_montage, badge_layout = self._build_ocr_montage(
                    badge_contexts, cv2, np, selected_fields=['badge']
                )
                stage['fast_lane_badge_montage_build'] = time.perf_counter() - montage_started
                badge_started = time.perf_counter()
                self._ocr_call_count += 1
                try:
                    badge_ocr_rows, _ = engine(badge_montage)
                finally:
                    badge_elapsed = time.perf_counter() - badge_started
                    self._ocr_elapsed_seconds += badge_elapsed
                stage['fast_lane_badge_ocr'] = badge_elapsed
                stage['ocr'] = self._ocr_elapsed_seconds
                badge_groups = group_montage_ocr(badge_ocr_rows, badge_layout, count=len(badge_contexts))
                badge_by_index = {
                    int(ctx['card_index']): (group or {})
                    for ctx, group in zip(badge_contexts, badge_groups)
                }

        for ctx in changed_contexts:
            ctx['_fields_to_ocr'] = list(original_fields[int(ctx['card_index'])])
        self._ocr_fields = ['badge'] if badge_contexts else []
        if self.cancel_event.is_set():
            elapsed = time.perf_counter() - started
            stage['parse_and_rules'] = time.perf_counter() - parse_started
            stage['total'] = elapsed
            stage['ocr'] = self._ocr_elapsed_seconds
            return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed

        ranked = []
        for ctx in changed_contexts:
            idx = int(ctx['card_index'])
            previous = previous_rows[idx] if idx < len(previous_rows) else None
            if idx in badge_by_index:
                badge_fields = badge_by_index[idx]
                badge_text = str((badge_fields or {}).get('badge') or '').strip()
                badge_confidence = float((badge_fields or {}).get('badge_confidence') or 0.0)
                # Keep a previous, pixel-identical badge when the OCR engine returned
                # nothing useful; do not accidentally demote a cached valid discount.
                if (not badge_text and not bool((badge_fields or {}).get('_badge_ocr_conflict'))
                        and isinstance(previous, dict)):
                    badge_text = str(previous.get('badge_text') or '')
                    badge_confidence = float(previous.get('badge_confidence') or 0.0)
            else:
                badge_text = str((previous or {}).get('badge_text') or '')
                try:
                    badge_confidence = float((previous or {}).get('badge_confidence') or 0.0)
                except (TypeError, ValueError):
                    badge_confidence = 0.0
            discount_value, _, discount_kind = resolve_discount(badge_text, ctx.get('badge_color', 'UNKNOWN'))
            try:
                rank_discount = int(discount_value) if discount_kind == 'discount' and discount_value is not None else -1
            except (TypeError, ValueError):
                rank_discount = -1
            ranked.append({
                'ctx': ctx, 'badge_text': badge_text, 'badge_confidence': badge_confidence,
                'discount_value': rank_discount, 'index': idx,
            })
        # The biggest visible discount is evaluated first, regardless of grid position.
        ranked.sort(key=lambda item: (-int(item['discount_value']), int(item['index'])))

        # Prepare only metadata here. Crucially, do NOT OCR every green card's
        # name/price before emitting the first candidate. The old implementation
        # waited for one large name/price montage to finish, then emitted candidates
        # in priority order; that made the 'fast lane' slow for the exact offers we
        # care about. The new path reads one candidate's name/price, validates it,
        # and offers it to the auto-buyer before moving on to the next candidate.
        fields_by_index = {}
        for item in ranked:
            idx = int(item['index'])
            fields_by_index[idx] = [
                field for field in ('name', 'price') if field in original_fields[idx]
            ]

        for local_idx, item in enumerate(ranked):
            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                stage['parse_and_rules'] = time.perf_counter() - parse_started
                stage['total'] = elapsed
                return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed

            ctx = item['ctx']
            original_idx = int(item['index'])
            previous = previous_rows[original_idx] if original_idx < len(previous_rows) else None
            # Fast negative gate: if even the smallest enabled-model threshold is
            # higher than this known discount, skip title/price OCR entirely. This is
            # mathematically safe regardless of which enabled model occupies the card.
            if (active_threshold_floor is not None
                    and int(item['discount_value']) >= 0
                    and int(item['discount_value']) < active_threshold_floor):
                prior_fields = (previous_field_signatures[original_idx]
                                if original_idx < len(previous_field_signatures) else None)
                row = self._color_gate_result(
                    ctx, previous, prior_fields, ctx.get('field_signatures'), cv2, np
                )
                discount_value, discount_display, discount_kind = resolve_discount(
                    item['badge_text'], ctx.get('badge_color', 'UNKNOWN')
                )
                row.update({
                    'badge_color': 'GREEN',
                    'badge_text': str(item['badge_text'] or ''),
                    'badge_confidence': float(item['badge_confidence'] or 0.0),
                    'discount_value': discount_value,
                    'discount': discount_display,
                    'discount_kind': discount_kind,
                    'threshold': int(active_threshold_floor),
                    'eligible': False,
                    'status': (f'Знижка {discount_display} нижча за мінімальний поріг вибраних моделей '
                               f'(-{int(active_threshold_floor)}%); OCR назви й ціни пропущено.'),
                    'discount_source': 'badge-ocr',
                })
                records_by_index[original_idx] = row
                self._fast_lane_below_threshold_skipped += 1
                continue

            fields_to_read = fields_by_index.get(original_idx, [])
            name_price_fields = {}
            if fields_to_read:
                if engine is None:
                    engine = _get_ocr_engine()
                    self._ocr_engine_init_seconds = _OCR_ENGINE_INIT_SECONDS
                for field_name in fields_to_read:
                    if field_name not in self._ocr_fields:
                        self._ocr_fields.append(field_name)
                if self.cancel_event.is_set():
                    elapsed = time.perf_counter() - started
                    stage['parse_and_rules'] = time.perf_counter() - parse_started
                    stage['total'] = elapsed
                    stage['ocr'] = self._ocr_elapsed_seconds
                    return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed

                # The field ROIs already isolate the title and price lines. Batch
                # recognition-only inference skips the text detector; only a weak or
                # unparsable result pays for the established montage/detector fallback.
                roi_crops=[ctx.get(f'{field_name}_crop') for field_name in fields_to_read]
                recognizer_available=callable(getattr(engine,'recognize_crops',None))
                predecoded = predecoded_name_price_by_index.get(original_idx, {})
                reused_combined_batch = bool(fields_to_read) and all(
                    field_name in predecoded for field_name in fields_to_read
                )
                if reused_combined_batch:
                    direct_rows = [
                        (predecoded[field_name]['text'], predecoded[field_name]['confidence'])
                        for field_name in fields_to_read
                    ]
                    direct_elapsed = 0.0
                    stage['fast_lane_card_fields_reused_combined_batch'] = True
                else:
                    direct_rows,direct_elapsed=_recognize_known_roi_batch(
                        engine,roi_crops,field=fields_to_read,target_height=48)
                direct_accepted=False
                if recognizer_available and not reused_combined_batch:
                    self._ocr_call_count += 1
                    self._ocr_elapsed_seconds += float(direct_elapsed or 0.0)
                    stage['fast_lane_card_recognition_only_seconds']=float(
                        stage.get('fast_lane_card_recognition_only_seconds',0.0)
                    )+float(direct_elapsed or 0.0)
                    stage['fast_lane_card_recognition_only_calls']=int(
                        stage.get('fast_lane_card_recognition_only_calls',0)
                    )+1
                if direct_rows is not None:
                    direct_fields={}
                    direct_accepted=True
                    required_ocr_confidence=0.68
                    required_model_confidence=0.93 if self.confidence_protection_enabled else 0.80
                    for field_name,(text,ocr_confidence) in zip(fields_to_read,direct_rows):
                        text=str(text or '').strip()
                        ocr_confidence=float(ocr_confidence or 0.0)
                        direct_fields[field_name]=text
                        direct_fields[f'{field_name}_confidence']=ocr_confidence
                        if not text or ocr_confidence<required_ocr_confidence:
                            direct_accepted=False
                        if field_name=='price' and parse_price(text) is None:
                            direct_accepted=False
                        elif field_name=='name':
                            cleaned=clean_model_text(text) or text
                            model_match,model_match_confidence=match_catalog_model(cleaned,self.models)
                            if (not model_match or float(model_match_confidence)<required_model_confidence
                                    or normalize_vehicle_key(model_match) in self._blacklisted_model_keys):
                                direct_accepted=False
                    if direct_accepted:
                        name_price_fields=direct_fields
                        stage['fast_lane_card_recognition_only_used']=True
                    else:
                        stage['fast_lane_card_recognition_only_rejected']=int(
                            stage.get('fast_lane_card_recognition_only_rejected',0)
                        )+1

                if not direct_accepted:
                    # Fallback is intentionally limited to this single ranked candidate.
                    # It is never run across every card before the first eligible offer.
                    previous_to_ocr = list(ctx.get('_fields_to_ocr', field_order))
                    ctx['_fields_to_ocr'] = list(fields_to_read)
                    montage_started = time.perf_counter()
                    try:
                        card_montage, card_layout = self._build_ocr_montage(
                            [ctx], cv2, np, selected_fields=fields_to_read
                        )
                    finally:
                        ctx['_fields_to_ocr'] = previous_to_ocr
                    stage['fast_lane_card_montage_build'] = float(
                        stage.get('fast_lane_card_montage_build', 0.0)
                    ) + (time.perf_counter() - montage_started)
                    candidate_ocr_started = time.perf_counter()
                    self._ocr_call_count += 1
                    try:
                        candidate_ocr_rows, _ = engine(card_montage)
                    finally:
                        candidate_ocr_elapsed = time.perf_counter() - candidate_ocr_started
                        self._ocr_elapsed_seconds += candidate_ocr_elapsed
                        stage['fast_lane_card_ocr_seconds'] = float(
                            stage.get('fast_lane_card_ocr_seconds', 0.0)
                        ) + candidate_ocr_elapsed
                        stage['fast_lane_card_ocr_calls'] = int(
                            stage.get('fast_lane_card_ocr_calls', 0)
                        ) + 1
                        stage['ocr'] = self._ocr_elapsed_seconds
                    parsed_one = group_montage_ocr(candidate_ocr_rows, card_layout, count=1)
                    name_price_fields = dict(parsed_one[0] or {}) if parsed_one else {}

                if self.cancel_event.is_set():
                    elapsed = time.perf_counter() - started
                    stage['parse_and_rules'] = time.perf_counter() - parse_started
                    stage['total'] = elapsed
                    stage['ocr'] = self._ocr_elapsed_seconds
                    return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed

            merged_fields = dict(name_price_fields)
            merged_fields['badge'] = item['badge_text']
            merged_fields['badge_confidence'] = float(item['badge_confidence'] or 0.0)
            field_text_keys = {'name': 'name_text', 'price': 'price_text', 'badge': 'badge_text'}
            for field_name in field_order:
                if field_name == 'badge':
                    continue
                if field_name not in original_fields[original_idx] and isinstance(previous, dict):
                    merged_fields[field_name] = previous.get(field_text_keys[field_name], '')
                    merged_fields[f'{field_name}_confidence'] = previous.get(f'{field_name}_confidence', 0.0)
                else:
                    merged_fields.setdefault(field_name, '')
                    merged_fields.setdefault(f'{field_name}_confidence', 0.0)
            confidences = [float(merged_fields.get(f'{name}_confidence', 0.0) or 0.0)
                           for name in field_order]
            positive_confidences = [value for value in confidences if value > 0]
            merged_fields['ocr_confidence'] = (
                sum(positive_confidences) / len(positive_confidences) if positive_confidences else 0.0
            )
            row = self._empty_result(ctx) if ctx.get('empty') else self._parse_changed_card(
                ctx, merged_fields, engine, allow_fallback=False
            )
            # A plausible but low-confidence top-ranked offer gets its narrow footer
            # recheck NOW, before we spend time OCRing the next candidate. Only models
            # that are selected, not blacklisted, and could meet their threshold can
            # enter this rescue path.
            if self._needs_fast_fallback(ctx, row):
                if engine is None:
                    engine = _get_ocr_engine()
                    self._ocr_engine_init_seconds = _OCR_ENGINE_INIT_SECONDS
                row = self._parse_changed_card(ctx, merged_fields, engine, allow_fallback=True)
            records_by_index[original_idx] = row
            emitted = self._emit_fast_candidate(row, started)
            if emitted and self.cancel_event.wait(0.020):
                elapsed = time.perf_counter() - started
                stage['parse_and_rules'] = time.perf_counter() - parse_started
                stage['total'] = elapsed
                stage['ocr'] = self._ocr_elapsed_seconds
                return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed
            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                stage['parse_and_rules'] = time.perf_counter() - parse_started
                stage['total'] = elapsed
                stage['ocr'] = self._ocr_elapsed_seconds
                return [records_by_index[i] for i in sorted(records_by_index)], '__CANCELLED__', elapsed
            self.progress.emit(local_idx + 1, f'FAST GREEN: перевіряю найбільшу знижку · {local_idx + 1}/{len(ranked)}')

        found = [records_by_index[i] for i in range(rows * cols) if i in records_by_index]
        elapsed = time.perf_counter() - started
        stage['parse_and_rules'] = time.perf_counter() - parse_started
        stage['ocr'] = self._ocr_elapsed_seconds
        stage['total'] = elapsed
        if len(found) == rows * cols and not self.cancel_event.is_set():
            with _CARD_CACHE_LOCK:
                _CARD_CACHE_SIGNATURES = [signatures[i] for i in range(rows * cols)]
                _CARD_CACHE_RESULTS = copy.deepcopy(found)
                _CARD_CACHE_FIELD_SIGNATURES = [copy.deepcopy(contexts[i].get('field_signatures')) for i in range(rows * cols)]
                _CARD_CACHE_CONFIG_KEY = config_key
                _CARD_CACHE_SCREEN_KEY = screen_key
        self._ocr_fields = [field for field in field_order if field in set(self._ocr_fields)]
        return found, '', elapsed

    @staticmethod
    def _field_retry_identity(field_signature):
        """Stable retry identity for a field, independent of its current card index."""
        try:
            import hashlib
            if isinstance(field_signature, dict):
                mask = field_signature.get('mask', b'')
                shape = field_signature.get('shape', ())
                color = field_signature.get('color', '')
                if not isinstance(mask, bytes):
                    mask = str(mask).encode('utf-8', 'ignore')
                payload = mask + repr(shape).encode('ascii', 'ignore') + str(color).encode('ascii', 'ignore')
            elif isinstance(field_signature, bytes):
                payload = field_signature
            else:
                payload = repr(field_signature).encode('utf-8', 'ignore')
            return hashlib.blake2b(payload, digest_size=10).hexdigest()
        except Exception:
            return repr(field_signature)

    @staticmethod
    def _uncertain_retry_due(last_attempt, now=None):
        """Return True only after the retry cooldown; visual changes bypass this helper."""
        if now is None:
            now = time.monotonic()
        try:
            last_attempt = float(last_attempt)
        except (TypeError, ValueError):
            last_attempt = 0.0
        return float(now) - last_attempt >= _UNCERTAIN_FIELD_RETRY_SECONDS

    @staticmethod
    def _crop(image, x0, y0, x1, y1):
        h, w = image.shape[:2]
        xa = max(0, min(w - 1, int(x0 * w)))
        xb = max(xa + 1, min(w, int(x1 * w)))
        ya = max(0, min(h - 1, int(y0 * h)))
        yb = max(ya + 1, min(h, int(y1 * h)))
        return image[ya:yb, xa:xb].copy()

    @staticmethod
    def _sort_ocr_rows(rows):
        def position(item):
            try:
                box = item[0]
                ys = [float(p[1]) for p in box]
                xs = [float(p[0]) for p in box]
                return (sum(ys) / max(len(ys), 1), min(xs) if xs else 0.0)
            except Exception:
                return (0.0, 0.0)
        return sorted(rows or [], key=position)

    @staticmethod
    def _signature_for_crop(crop, size, cv2):
        """Return a contrast-normalized binary glyph mask, packed into bytes.

        Hashing raw greyscale pixels is too sensitive to tiny capture changes. The
        canonical mask ignores uniform brightness shifts and small anti-aliasing
        changes while preserving the text shapes that matter for price/model/badge.
        """
        import numpy as np

        width, height = int(size[0]), int(size[1])
        expected_bits = width * height
        packed_length = (expected_bits + 7) // 8
        if crop is None or getattr(crop, 'size', 0) == 0:
            return bytes(packed_length)

        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        tiny = cv2.resize(gray, (width, height), interpolation=cv2.INTER_AREA)
        # Suppress one-level capture noise before contrast normalization.
        smooth = cv2.GaussianBlur(tiny, (3, 3), 0).astype(np.float32)
        background = float(np.percentile(smooth, 50))
        bright = float(np.percentile(smooth, 98))
        contrast = bright - background
        if contrast < 12.0:
            # Flat zones (including an empty/white field) have no stable glyphs.
            mask = np.zeros((height, width), dtype=np.uint8)
        else:
            normalized = np.clip((smooth - background) * (255.0 / contrast), 0, 255).astype(np.uint8)
            # A deliberately high normalized threshold omits faint anti-aliased edges.
            mask = (normalized >= 76).astype(np.uint8) * 255
            # A one-pixel close removes tiny gaps caused by capture resampling.
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((2, 2), dtype=np.uint8))
        return np.packbits((mask.reshape(-1) > 0).astype(np.uint8)).tobytes()

    @staticmethod
    def _native_field_signature(crop, cv2):
        """Store a packed glyph mask at the crop's native pixel resolution.

        Downscaling to a 22px-high signature made a one-pixel capture/render shift
        behave like a large shape change. Native-resolution masks retain more shape
        detail and let the comparator align small (up to 2px) shifts safely.
        """
        import numpy as np

        if crop is None or getattr(crop, 'size', 0) == 0:
            return {'mask': b'', 'shape': (0, 0)}
        gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
        smooth = cv2.GaussianBlur(gray, (3, 3), 0).astype(np.float32)
        background = float(np.percentile(smooth, 50))
        bright = float(np.percentile(smooth, 99))
        contrast = bright - background
        height, width = gray.shape[:2]
        if contrast < 12.0:
            mask = np.zeros((height, width), dtype=np.uint8)
        else:
            normalized = np.clip((smooth - background) * (255.0 / contrast), 0, 255).astype(np.uint8)
            mask = (normalized >= 76).astype(np.uint8)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, np.ones((2, 2), dtype=np.uint8))
        packed = np.packbits(mask.reshape(-1).astype(np.uint8)).tobytes()
        return {'mask': packed, 'shape': (int(height), int(width))}

    @classmethod
    def _field_signatures_for_crops(cls, name_crop, price_crop, badge_crop, badge_color, cv2):
        """Fingerprint title, price and badge separately, including badge color."""
        return {
            'name': cls._native_field_signature(name_crop, cv2),
            'price': cls._native_field_signature(price_crop, cv2),
            'badge': {
                **cls._native_field_signature(badge_crop, cv2),
                'color': str(badge_color),
            },
        }

    @staticmethod
    def _combine_field_signatures(field_signatures):
        """Build a deterministic whole-card signature from native field masks."""
        digest = hashlib.blake2b(digest_size=12)
        for field in ('name', 'price', 'badge'):
            signature = (field_signatures or {}).get(field, b'')
            if isinstance(signature, dict):
                mask = signature.get('mask', b'')
                digest.update(mask if isinstance(mask, bytes) else str(mask).encode('utf-8', 'ignore'))
                digest.update(str(signature.get('shape', '')).encode('ascii', 'ignore'))
                digest.update(str(signature.get('color', '')).encode('ascii', 'ignore'))
            elif isinstance(signature, bytes):
                digest.update(signature)
            else:
                digest.update(str(signature).encode('utf-8', 'ignore'))
        return digest.hexdigest()

    @staticmethod
    def _field_signature_changed(current, previous, field, cv2, np):
        """Compare packed glyph masks with small spatial tolerance, preserving digit changes."""
        if current is None or previous is None:
            return current is not previous

        if field == 'badge':
            current_color = current.get('color') if isinstance(current, dict) else None
            previous_color = previous.get('color') if isinstance(previous, dict) else None
            # Badge color is a separate safety signal. Never let a mask tolerance hide it.
            if current_color != previous_color:
                return True

        def unpack(value, default_size):
            if isinstance(value, dict):
                packed = value.get('mask')
                shape = value.get('shape')
            else:
                # Compatibility for direct helper tests/legacy canonical masks.
                packed = value
                shape = None
            if not isinstance(packed, bytes):
                return None, None
            if shape is None:
                width, height = default_size
                shape = (height, width)
            try:
                height, width = int(shape[0]), int(shape[1])
                if height <= 0 or width <= 0:
                    return np.zeros((0, 0), dtype=np.uint8), (height, width)
                needed = (height * width + 7) // 8
                if len(packed) != needed:
                    return None, None
                arr = np.unpackbits(np.frombuffer(packed, dtype=np.uint8), count=height * width)
                return arr.reshape(height, width).astype(np.uint8), (height, width)
            except Exception:
                return None, None

        default_sizes = {'name': (128, 22), 'price': (96, 22), 'badge': (64, 22)}
        a, shape_a = unpack(current, default_sizes[field])
        b, shape_b = unpack(previous, default_sizes[field])
        if a is None or b is None or shape_a != shape_b:
            # Unknown/legacy signature format: fail safe and re-read the field.
            return current != previous
        if a.size == 0 or b.size == 0:
            return bool(np.count_nonzero(a) != np.count_nonzero(b))
        if np.array_equal(a, b):
            return False

        count_a = int(np.count_nonzero(a))
        count_b = int(np.count_nonzero(b))
        if count_a == 0 or count_b == 0:
            return count_a != count_b

        height, width = a.shape
        best_mismatch = 1.0
        best_area_delta = 1.0
        # Native-resolution masks can be aligned with integer shifts. This avoids
        # false invalidations caused by sub-pixel changes introduced by downscaling.
        for dy in range(-2, 3):
            for dx in range(-2, 3):
                aligned = np.zeros_like(a)
                src_x0, src_x1 = max(0, -dx), min(width, width - dx)
                src_y0, src_y1 = max(0, -dy), min(height, height - dy)
                dst_x0, dst_x1 = max(0, dx), min(width, width + dx)
                dst_y0, dst_y1 = max(0, dy), min(height, height + dy)
                if src_x1 > src_x0 and src_y1 > src_y0:
                    aligned[dst_y0:dst_y1, dst_x0:dst_x1] = a[src_y0:src_y1, src_x0:src_x1]
                union = int(np.count_nonzero((aligned > 0) | (b > 0)))
                mismatch = int(np.count_nonzero(aligned != b)) / max(union, 1)
                area_delta = abs(int(np.count_nonzero(aligned)) - count_b) / max(count_a, count_b, 1)
                if mismatch < best_mismatch:
                    best_mismatch = mismatch
                    best_area_delta = area_delta

        # A 1.2% mask difference absorbs faint renderer/capture noise but still
        # catches the tested one-digit changes (6->8, 0->8, EK6->EK8).
        return best_mismatch > 0.012 or best_area_delta > 0.025

    @classmethod
    def _signature_for_crops(cls, name_crop, price_crop, badge_crop, badge_color, cv2, np):
        """Hash canonical text masks (not vehicle imagery) for diagnostics/cache metadata."""
        field_signatures = cls._field_signatures_for_crops(
            name_crop, price_crop, badge_crop, badge_color, cv2
        )
        return cls._combine_field_signatures(field_signatures)

    def _extract_card_contexts(self, screenshot, x0, x1, y0, y1, cols, rows,
                               monitor_left, monitor_top, screen_size, cv2, np, capture_origin=(0, 0)):
        """Extract the 15 cards; match the AHK reference layout when default grid is used.

        The reference layout uses real card bounds with small gutters, not equal-width
        grid cells. Those gutters and the exact central badge sample box are important:
        a slight right/down shift can turn a dark-green badge into NONE under the fast gate.
        Custom grid settings retain the adaptable equal-cell crop path.
        """
        height, width = screenshot.shape[:2]
        frame_left, frame_top = (int(capture_origin[0]), int(capture_origin[1])) if capture_origin else (0, 0)
        screen_width, screen_height = int(screen_size[0]), int(screen_size[1])
        # x0..y1 are local coordinates within the acquired frame; normalize using
        # the physical monitor coordinate system so ROI and full-screen paths match.
        left_norm = (x0 + frame_left) / max(screen_width, 1)
        right_norm = (x1 + frame_left) / max(screen_width, 1)
        top_norm = (y0 + frame_top) / max(screen_height, 1)
        bottom_norm = (y1 + frame_top) / max(screen_height, 1)
        use_ahk_layout = (
            cols == 5 and rows == 3
            and abs(left_norm - 0.153) <= 0.008
            and abs(right_norm - 0.985) <= 0.008
            and abs(top_norm - 0.095) <= 0.008
            and abs(bottom_norm - 0.895) <= 0.012
        )
        ahk_lefts = (0.155, 0.322, 0.489, 0.655, 0.822)
        ahk_rights = (0.315, 0.481, 0.647, 0.813, 0.981)
        row_offsets = (0.000, 0.270, 0.540)
        cell_w = (x1 - x0) / cols
        cell_h = (y1 - y0) / rows
        contexts = []
        for idx in range(rows * cols):
            row, col = divmod(idx, cols)
            if use_ahk_layout:
                # Same normalized card bounds as ng_discount_ocr.ps1.
                xa = max(0, min(width - 1, int(ahk_lefts[col] * screen_width) - frame_left))
                xb = max(xa + 1, min(width, int(ahk_rights[col] * screen_width) - frame_left))
                ya = max(0, min(height - 1, int((0.095 + row_offsets[row]) * screen_height) - frame_top))
                yb = max(ya + 1, min(height, int((0.095 + row_offsets[row] + 0.265) * screen_height) - frame_top))
            else:
                xa = int(x0 + col * cell_w)
                xb = int(x0 + (col + 1) * cell_w)
                ya = int(y0 + row * cell_h)
                yb = int(y0 + (row + 1) * cell_h)
            card = screenshot[ya:yb, xa:xb]
            ctx = {
                'card_index': idx, 'card': idx + 1,
                'xy': (monitor_left + frame_left + (xa + xb) // 2, monitor_top + frame_top + (ya + yb) // 2),
                'screen_size': screen_size,
                'badge_color_method': 'ahk-central-rgb-sampler' if use_ahk_layout else 'ahk-rgb-sampler-relative',
            }
            if card.size == 0:
                empty_fields = self._field_signatures_for_crops(None, None, None, 'UNKNOWN', cv2)
                ctx.update({
                    'empty': True, 'name_crop': None, 'price_crop': None,
                    'badge_crop': None, 'footer_crop': None,
                    'badge_color': 'UNKNOWN',
                    'field_signatures': empty_fields,
                    'signature': self._combine_field_signatures(empty_fields),
                })
            else:
                # Title strip remains tightly cropped; price strip and discount badge
                # are aligned to the proven AHK price-band/badge geometry.
                name_crop = self._crop(card, .015, .645, .920, .820)
                price_crop = self._crop(card, .020, .800, .480, .962)
                badge_crop = self._crop(card, .775, .853, .980, .955)
                footer_crop = self._crop(card, .006, .800, .994, .962)
                if use_ahk_layout:
                    # Exact PowerShell/AHK badge-color rectangle, scaled to this capture.
                    card_left = xa
                    card_width = xb - xa
                    badge_x = card_left + int(0.775 * card_width)
                    badge_y = int((0.321 + row_offsets[row]) * screen_height) - frame_top
                    badge_w = max(1, int(0.205 * card_width))
                    badge_h = max(1, int(0.027 * screen_height))
                    bx0 = max(0, min(width - 1, badge_x))
                    by0 = max(0, min(height - 1, badge_y))
                    bx1 = max(bx0 + 1, min(width, badge_x + badge_w))
                    by1 = max(by0 + 1, min(height, badge_y + badge_h))
                    badge_color_crop = screenshot[by0:by1, bx0:bx1]
                else:
                    # In a manually adjusted grid, position the color crop around the
                    # badge center, rather than the previous overly-right crop.
                    badge_color_crop = self._crop(card, .757, .8475, .954, .94875)
                badge_color = classify_badge_color(badge_color_crop)
                field_signatures = self._field_signatures_for_crops(
                    name_crop, price_crop, badge_crop, badge_color, cv2
                )
                # Position-independent lot identity: pHash the card's vehicle/image
                # content with the volatile discount corner masked, plus title/price.
                # This is computed only for GREEN cards, so it never adds image hashing
                # cost to the negative/non-candidate hot path.
                offer_identity_signature = ''
                if badge_color == 'GREEN':
                    stable_card = card.copy()
                    card_h, card_w = stable_card.shape[:2]
                    mask_y0 = max(0, min(card_h-1, int(.80*card_h)))
                    mask_y1 = max(mask_y0+1, min(card_h, int(.99*card_h)))
                    mask_x0 = max(0, min(card_w-1, int(.73*card_w)))
                    stable_card[mask_y0:mask_y1, mask_x0:] = 0
                    visual_hash = _perceptual_hash_hex(stable_card, cv2, np)
                    title_price = card[int(.70*card_h):max(int(.71*card_h)+1, int(.99*card_h)),
                                        :max(1, int(.74*card_w))]
                    title_price_hash = _perceptual_hash_hex(title_price, cv2, np)
                    offer_identity_signature = f'idp:{visual_hash}:{title_price_hash}'
                ctx.update({
                    'empty': False, 'name_crop': name_crop, 'price_crop': price_crop,
                    'badge_crop': badge_crop, 'footer_crop': footer_crop,
                    'badge_color': badge_color,
                    'badge_color_sample_size': tuple(int(v) for v in badge_color_crop.shape[:2]),
                    'field_signatures': field_signatures,
                    'signature': self._combine_field_signatures(field_signatures),
                    'offer_identity_signature': offer_identity_signature,
                })
            contexts.append(ctx)
        return contexts

    def _build_ocr_montage(self, contexts, cv2, np, selected_fields=None):
        """OCR only changed text fields, stacking card rows into one compact inference call."""
        field_order = ('name', 'price', 'badge')
        if selected_fields is None:
            selected_fields = list(field_order)
        selected_fields = [field for field in field_order if field in set(selected_fields)]
        if not selected_fields:
            selected_fields = list(field_order)

        # Native-scale crops avoid a 2x upscale followed by detector downscaling.
        # This reduces inference pixels substantially when 4-10 cards change, while full-grid
        # OCR still reaches approximately the same effective text size at the 736px detector cap.
        scale = 1.0
        gap, pad = 8, 4
        resized_rows = []
        max_widths = {field: 1 for field in selected_fields}
        max_height = 1
        crop_names = {'name': 'name_crop', 'price': 'price_crop', 'badge': 'badge_crop'}
        for ctx in contexts:
            row_fields = {}
            to_ocr = set(ctx.get('_fields_to_ocr', field_order))
            for field in selected_fields:
                crop = ctx.get(crop_names[field]) if field in to_ocr and not ctx.get('empty') else None
                if crop is None or getattr(crop, 'size', 0) == 0:
                    row_fields[field] = None
                    continue
                image = cv2.resize(crop, None, fx=scale, fy=scale,
                                   interpolation=cv2.INTER_CUBIC)
                row_fields[field] = image
                max_widths[field] = max(max_widths[field], int(image.shape[1]))
                max_height = max(max_height, int(image.shape[0]))
            resized_rows.append(row_fields)

        row_height = int(max_height + pad * 2)
        field_zones = []
        x_positions = {}
        cursor_x = pad
        for field in selected_fields:
            x_positions[field] = cursor_x
            field_zones.append({
                'field': field,
                'left': cursor_x,
                'right': cursor_x + max_widths[field],
            })
            cursor_x += max_widths[field] + gap
        montage_width = max(1, cursor_x - gap + pad)
        montage = np.full((row_height * len(contexts), montage_width, 3),
                          (15, 19, 22), dtype=np.uint8)
        for row_idx, row_fields in enumerate(resized_rows):
            row_y = row_idx * row_height + pad
            for field in selected_fields:
                image = row_fields.get(field)
                if image is None:
                    continue
                x = x_positions[field]
                h = min(image.shape[0], row_height - pad * 2)
                w = min(image.shape[1], max_widths[field])
                if h > 0 and w > 0:
                    montage[row_y:row_y + h, x:x + w] = image[:h, :w]
        layout = {
            'row_height': row_height,
            'field_zones': field_zones,
            'fields': selected_fields,
            'scale': scale,
        }
        # Keep legacy boundaries for callers/tests that inspect the old three-column layout.
        starts = {z['field']: z['left'] for z in field_zones}
        ends = {z['field']: z['right'] for z in field_zones}
        if 'name' in starts:
            layout['name_boundary'] = ends['name'] + gap / 2.0
        if 'price' in starts:
            layout['price_boundary'] = ends['price'] + gap / 2.0
        elif 'name' in starts:
            layout['price_boundary'] = ends['name'] + gap / 2.0
        return montage, layout

    def _config_cache_key(self, screen_size, monitor_left, monitor_top, x0, x1, y0, y1, cols, rows):
        config = {
            'models': self.models,
            'rules': self.rules,
            'global_threshold': self.global_threshold,
            'model_thresholds': self.model_thresholds,
            'active_models': sorted(self.active_models),
            'blacklist': sorted(self.blacklisted_models),
            'fast_color_filter_enabled': self.fast_color_filter_enabled,
            'confidence_protection_enabled': self.confidence_protection_enabled,
            'fast_candidate_mode': self.fast_candidate_mode,
        }
        encoded = json.dumps(config, ensure_ascii=False, sort_keys=True, default=str, separators=(',', ':'))
        config_key = hashlib.sha256(encoded.encode('utf-8')).hexdigest()
        screen_key = (tuple(screen_size), monitor_left, monitor_top, x0, x1, y0, y1, cols, rows)
        return config_key, screen_key

    def _threshold_for(self, model):
        rule = self.rules.get(model, {})
        category = str(rule.get('category', 'Звичайне')).strip()
        override = self.model_thresholds.get(model)
        if category in ('Пріоритетне', 'Пріоритетна'):
            category_threshold = 15
        elif category in ('Спеціальне', 'Спеціальна'):
            category_threshold = 50
        else:
            category_threshold = self.global_threshold
        return effective_threshold(category, override, category_threshold, self.global_threshold)

    def _build_status(self, display_model, catalog_model, price_value, badge_color,
                      discount_value, threshold, selected, blacklisted):
        return build_candidate_status(
            display_model, catalog_model, price_value, badge_color,
            discount_value, threshold, bool(selected), bool(blacklisted)
        )

    def _recognize(self, engine, crop, scale=4):
        """Rare fallback for low-confidence fields only."""
        if self.cancel_event.is_set() or crop is None or crop.size == 0:
            return ""
        import cv2

        def run(image):
            call_started = time.perf_counter()
            self._ocr_call_count += 1
            try:
                rows, _ = engine(image)
            except Exception:
                return ""
            finally:
                self._ocr_elapsed_seconds += time.perf_counter() - call_started
            if not rows:
                return ""
            parts = []
            for row in self._sort_ocr_rows(rows):
                try:
                    text = str(row[1]).strip()
                    if text:
                        parts.append(text)
                except Exception:
                    continue
            return " ".join(parts)

        bigger = cv2.resize(crop, None, fx=scale, fy=scale, interpolation=cv2.INTER_CUBIC)
        text = run(bigger)
        if text or self.cancel_event.is_set():
            return text
        gray = cv2.cvtColor(bigger, cv2.COLOR_BGR2GRAY)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(4, 4)).apply(gray)
        enhanced = cv2.cvtColor(clahe, cv2.COLOR_GRAY2BGR)
        return run(enhanced)

    def _save_diagnostics(self, rows, screen_size, elapsed, error='', stage_seconds=None):
        global _LAST_DIAGNOSTICS_WRITE_AT
        # Keep the latest timing data on the worker even when the on-disk sidecar is throttled.
        current_stages = stage_seconds if isinstance(stage_seconds, dict) else self._stage_seconds
        self._last_stage_seconds = {k: v for k, v in (current_stages or {}).items() if isinstance(v, (int, float))}
        self._last_stage_info = {k: v for k, v in (current_stages or {}).items() if not isinstance(v, (int, float))}
        self._last_ocr_engine_init_seconds = float(_OCR_ENGINE_INIT_SECONDS or 0.0)
        self._last_ocr_engine_warmup_seconds = float(_OCR_ENGINE_WARMUP_SECONDS or 0.0)
        self._last_ocr_engine_config = str(_OCR_ENGINE_CONFIG or 'not-initialized')
        try:
            self._last_ocr_active_providers = list(_active_engine_providers(_OCR_ENGINE)) if _OCR_ENGINE is not None else []
        except Exception:
            self._last_ocr_active_providers = []
        self._stage_seconds = dict(current_stages or {})
        # Cache-only cycles can run 5–10 times per second. Keep diagnostics current
        # at most once per second on those cycles; OCR/error cycles are written at once.
        # Any OCR-free color-first poll is throttled, even if changed non-green cards were skipped.
        cache_only_cycle = self._ocr_call_count == 0 and not error
        now = time.monotonic()
        with _DIAGNOSTICS_LOCK:
            if cache_only_cycle and now - _LAST_DIAGNOSTICS_WRITE_AT < 1.0:
                return
        data = {
            'scanner_core_version': OCR_PATCH_VERSION,
            'purchase_diagnostics_patch_version': PURCHASE_DIAGNOSTICS_PATCH_VERSION,
            'fast_badge_consensus_patch_version': FAST_BADGE_CONSENSUS_PATCH_VERSION,
            'recognition_only_patch_version': RECOGNITION_ONLY_PATCH_VERSION,
            'created_at': datetime.now().isoformat(timespec='seconds'),
            'screen': {'width': int(screen_size[0]), 'height': int(screen_size[1])},
            'elapsed_seconds': round(float(elapsed), 3),
            'cancelled': bool(self.cancel_event.is_set()),
            'error': error or None,
            'cards': rows,
            'cache_debug': dict(self._cache_debug),
            'performance': {
                "strategy": (
                    'GREEN PRIORITY FASTLANE: OCR green discount badges first, rank largest discount, '
                    'OCR one candidate name/price at a time and signal purchase immediately; '
                    'RED/NONE/UNKNOWN card text skipped; cache enabled'
                    if self.fast_candidate_mode else
                    ('GREEN ONLY: inspect badge color first, OCR only GREEN cards; '
                     'text on other cards is skipped; cache enabled'
                     if self.fast_color_filter_enabled else
                     'full-card OCR: read text on all 15 cards regardless of badge color; '
                     'only confirmed green discounts can be eligible; cache enabled')
                ),
                'fast_color_filter_enabled': bool(self.fast_color_filter_enabled),
                'fast_candidate_mode': bool(self.fast_candidate_mode),
                'full_card_ocr_enabled': not bool(self.fast_color_filter_enabled),
                'confidence_protection_enabled': bool(self.confidence_protection_enabled),
                'ocr_speed_patch_version': OCR_SPEED_PATCH_VERSION,
                'first_eligible_candidate_after_seconds': (round(float(self._first_candidate_elapsed_seconds), 4) if self._first_candidate_elapsed_seconds is not None else None),
                'eligible_candidate_signals': int(self._candidate_signal_count),
                'fast_lane_below_threshold_cards_skipped_ocr': int(self._fast_lane_below_threshold_skipped),
                'uncertain_field_retry_interval_seconds': float(_UNCERTAIN_FIELD_RETRY_SECONDS),
                'ocr_calls': int(self._ocr_call_count),
                'ocr_seconds': round(float(self._ocr_elapsed_seconds), 3),
                'ocr_engine_init_seconds': round(float(_OCR_ENGINE_INIT_SECONDS), 3),
                'ocr_engine_warmup_seconds': round(float(_OCR_ENGINE_WARMUP_SECONDS), 3),
                'ocr_engine_config': _OCR_ENGINE_CONFIG,
                'ocr_engine_init_errors': list(_OCR_LAST_INIT_ERRORS),
                'ocr_engine_warmup_error': _OCR_LAST_WARMUP_ERROR or None,
                'ocr_engine_warmup_traceback': _OCR_LAST_WARMUP_TRACEBACK or None,
                'python_version': sys.version,
                'python_executable': sys.executable,
                'rapidocr_version': _package_version('rapidocr'),
                'onnxruntime_version': _package_version('onnxruntime'),
                'onnxruntime_available_providers': _available_onnxruntime_providers(),
                'onnxruntime_active_providers': _active_engine_providers(_OCR_ENGINE) if _OCR_ENGINE is not None else [],
                'gpu_acceleration_active': any(
                    name in ('DmlExecutionProvider', 'CUDAExecutionProvider')
                    for name in (_active_engine_providers(_OCR_ENGINE) if _OCR_ENGINE is not None else [])
                ),
                'changed_cards_reocr': int(len(self._changed_field_map)),
                'fast_color_skipped_cards': len(self._fast_color_skipped_indices),
                'fast_color_skipped_card_numbers': [int(i) + 1 for i in self._fast_color_skipped_indices],
                'green_badge_cards_detected': int(self._green_badge_count),
                'full_card_ocr_enabled': not bool(self.fast_color_filter_enabled),
                'changed_fields_reocr': int(self._changed_fields),
                'fields_sent_to_ocr': list(self._ocr_fields),
                'changed_field_map': dict(self._changed_field_map),
                'changed_fields_by_type': dict(self._field_change_counts),
                'unchanged_cards_cache_hits': int(self._cache_hits),
                'stage_seconds': {k: round(float(v), 4) for k, v in (stage_seconds or self._stage_seconds).items() if isinstance(v, (int, float))},
                'stage_info': {k: v for k, v in (stage_seconds or self._stage_seconds).items() if not isinstance(v, (int, float))},
            },
        }
        # Sidecar code is extracted to a temporary _MEI directory in one-file builds.
        # Diagnostics must survive process exit, so write them to the same per-user
        # LocalAppData directory that main.py uses for persistent state.
        if getattr(sys, 'frozen', False) and Path(getattr(sys, '_MEIPASS', '')).name.casefold().startswith('_mei'):
            base = Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local')) / 'NGMarketScanner'
        else:
            base = Path(sys.executable).resolve().parent if getattr(sys, 'frozen', False) else Path(__file__).resolve().parent
        try:
            base.mkdir(parents=True, exist_ok=True)
        except Exception:
            base = Path(os.getenv('TEMP', str(Path.home())))
        target = base / ('last_scan_cancelled.json' if self.cancel_event.is_set() else 'last_scan_diagnostics.json')
        try:
            serialized = json.dumps(data, ensure_ascii=False, indent=2)
            target.write_text(serialized, encoding='utf-8')
            # Preserve the latest real OCR pass separately. Cache-only polling cycles
            # may update last_scan_diagnostics.json and must not erase the OCR timing.
            if self._ocr_call_count > 0 and not self.cancel_event.is_set():
                try:
                    (base / 'last_ocr_diagnostics.json').write_text(serialized, encoding='utf-8')
                except Exception:
                    pass
            with _DIAGNOSTICS_LOCK:
                _LAST_DIAGNOSTICS_WRITE_AT = time.monotonic()
        except Exception:
            try:
                target = Path(os.getenv('TEMP', str(base))) / 'NG_Market_Scanner_last_scan_diagnostics.json'
                target.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
                with _DIAGNOSTICS_LOCK:
                    _LAST_DIAGNOSTICS_WRITE_AT = time.monotonic()
            except Exception:
                pass

    def _empty_result(self, ctx):
        return {
            'card': ctx['card'], 'model': '—', 'catalog_model': '',
            'price': 'Не прочитано', 'price_value': None,
            'discount': '—', 'discount_value': None, 'discount_kind': 'none',
            'threshold': None, 'category': '—', 'status': 'Порожня область',
            'eligible': False, 'model_confidence': 0.0, 'badge_color': 'UNKNOWN',
            'name_text': '', 'price_text': '', 'badge_text': '',
            'xy': ctx.get('xy'), 'screen_size': ctx.get('screen_size'),
            'offer_signature': str(ctx.get('signature') or ''),
            'offer_identity_signature': str(ctx.get('offer_identity_signature') or ''),
            '_cacheable': False, '_cache_hit': False,
        }

    def _color_gate_result(self, ctx, previous, prior_fields, current_fields, cv2, np):
        """Build a truthful non-GREEN result without running OCR on its text.

        Reuse previous text only if its pixel signature is unchanged. Never display
        a stale model/price for a visually changed non-GREEN card, and never authorize
        auto-actions from a color-gated placeholder.
        """
        if ctx.get('empty'):
            return self._empty_result(ctx)

        color = str(ctx.get('badge_color') or 'UNKNOWN').upper()
        have_previous = isinstance(previous, dict) and isinstance(prior_fields, dict) and isinstance(current_fields, dict)

        def field_same(field):
            if not have_previous:
                return False
            return not self._field_signature_changed(
                current_fields.get(field), prior_fields.get(field), field, cv2, np
            )

        same_name = field_same('name')
        same_price = field_same('price')
        same_badge = field_same('badge') and str(previous.get('badge_color', 'UNKNOWN')).upper() == color if have_previous else False

        if same_name:
            model = str(previous.get('model') or '—')
            catalog_model = str(previous.get('catalog_model') or '')
            name_text = str(previous.get('name_text') or '')
            model_confidence = float(previous.get('model_confidence', 0.0) or 0.0)
            category = str(previous.get('category') or '—')
            threshold = previous.get('threshold')
        else:
            model, catalog_model, name_text = '—', '', ''
            model_confidence, category, threshold = 0.0, '—', None

        if same_price:
            price_value = previous.get('price_value')
            price_text = str(previous.get('price_text') or '')
            price_display = str(previous.get('price') or format_price(price_value))
            price_confidence = float(previous.get('price_confidence', 0.0) or 0.0)
        else:
            price_value, price_text, price_display, price_confidence = None, '', 'Не перевірено', 0.0

        if same_badge:
            badge_text = str(previous.get('badge_text') or '')
            discount_value = previous.get('discount_value')
            discount = str(previous.get('discount') or '—')
            discount_kind = str(previous.get('discount_kind') or 'none')
            badge_confidence = float(previous.get('badge_confidence', 0.0) or 0.0)
        else:
            badge_text = ''
            discount_value = None
            badge_confidence = 0.0
            if color == 'NONE':
                discount, discount_kind = '—', 'none'
            elif color == 'RED':
                discount, discount_kind = 'Не зчитано', 'markup'
            else:
                discount, discount_kind = 'Не визначено', 'unknown'

        if color == 'RED':
            status = 'Червоний бейдж · текст не читався у швидкому режимі'
        elif color == 'NONE':
            status = 'Бейдж знижки відсутній · текст не читався у швидкому режимі'
        else:
            status = 'Колір бейджа не визначено · текст не читався у швидкому режимі'

        # If the text came from a prior scan and is still pixel-identical, it is safe
        # to display it. Otherwise explain exactly why this card is still unrecognized.
        if model in ('', '—') and self.fast_color_filter_enabled:
            if color == 'RED':
                status = 'Швидкий режим: червоний бейдж · OCR тексту пропущено'
            elif color == 'NONE':
                status = 'Швидкий режим: бейдж відсутній · OCR тексту пропущено'
            else:
                status = 'Швидкий режим: колір не визначено · OCR тексту пропущено'

        return {
            'card': ctx['card'], 'model': model, 'catalog_model': catalog_model,
            'price': price_display, 'price_value': price_value,
            'discount': discount, 'discount_value': discount_value, 'discount_kind': discount_kind,
            'threshold': threshold, 'category': category, 'status': status,
            'eligible': False, 'model_confidence': round(model_confidence, 3),
            'badge_color': color, 'badge_color_method': ctx.get('badge_color_method', ''),
            'badge_color_sample_size': ctx.get('badge_color_sample_size'),
            'name_text': name_text, 'price_text': price_text, 'badge_text': badge_text,
            'ocr_confidence': round(float(previous.get('ocr_confidence', 0.0) or 0.0), 3) if have_previous and same_name and same_price else 0.0,
            'name_confidence': round(float(previous.get('name_confidence', 0.0) or 0.0), 3) if same_name and have_previous else 0.0,
            'price_confidence': round(price_confidence, 3),
            'badge_confidence': round(badge_confidence, 3),
            'xy': ctx.get('xy'), 'screen_size': ctx.get('screen_size'),
            'offer_signature': str(ctx.get('signature') or ''),
            'offer_identity_signature': str(ctx.get('offer_identity_signature') or ''),
            '_cacheable': bool(have_previous and same_name and same_price and same_badge and previous.get('_cacheable', False)),
            '_cache_hit': bool(have_previous and same_name and same_price and same_badge),
            '_fast_color_skipped': True,
        }

    def _needs_fast_fallback(self, ctx, row):
        """Whether a second OCR pass could rescue a plausible GREEN purchase candidate."""
        if str(ctx.get('badge_color', '')).upper() != 'GREEN' or not isinstance(row, dict):
            return False
        model = str(row.get('catalog_model') or '').strip()
        if (not model or model not in self.active_models
                or normalize_vehicle_key(model) in self._blacklisted_model_keys):
            return False
        try:
            model_confidence = float(row.get('model_confidence') or 0.0)
            confidence_floor = 0.93 if self.confidence_protection_enabled else 0.80
            discount = row.get('discount_value')
            threshold = row.get('threshold')
            if discount is not None and threshold is not None and int(discount) < abs(int(threshold)):
                return False
            could_qualify = discount is None or threshold is None or int(discount) >= abs(int(threshold))
            if model_confidence < confidence_floor or not could_qualify:
                return False
            price_missing = row.get('price_value') is None
            discount_missing = row.get('discount_value') is None
            confidence_low = (
                float(row.get('price_confidence') or 0.0) < 0.68
                or float(row.get('badge_confidence') or 0.0) < 0.68
            )
            return bool(price_missing or discount_missing or confidence_low)
        except (TypeError, ValueError):
            return False

    def _parse_changed_card(self, ctx, fields, engine, allow_fallback=True):
        name_text = fields.get('name', '')
        display_model = clean_model_text(name_text)
        catalog_model, model_confidence = match_catalog_model(display_model or name_text, self.models)
        if catalog_model:
            display_model = catalog_model
        else:
            informational_model, info_confidence = match_informational_model(display_model or name_text)
            if informational_model:
                display_model = informational_model
                model_confidence = info_confidence

        price_text = fields.get('price', '')
        price_value = parse_price(price_text)
        badge_text = fields.get('badge', '')
        badge_color = ctx.get('badge_color', 'UNKNOWN')
        percent_match = re.search(r'[+\-−–—]?\s*\d{1,3}\s*%', badge_text or '')
        if percent_match:
            badge_text = percent_match.group(0).strip()

        discount_value, discount_display, discount_kind = resolve_discount(badge_text, badge_color)
        footer_fallback_attempted = False
        # Keep the proven AHK fallback chain: GREEN is the mandatory gate, then
        # recover a missing percentage/price from the wider footer band only when
        # the focused badge/price OCR did not provide a usable value. This is rare
        # and is never used for RED/NONE/UNKNOWN cards.
        confidence_floor = 0.93 if self.confidence_protection_enabled else 0.80
        fallback_model_allowed = bool(
            catalog_model and catalog_model in self.active_models
            and normalize_vehicle_key(catalog_model) not in self._blacklisted_model_keys
            and float(model_confidence or 0.0) >= confidence_floor
        )
        if (allow_fallback and badge_color == 'GREEN' and fallback_model_allowed
                and (discount_value is None or price_value is None)):
            footer_fallback_attempted = True
            fallback_text = self._recognize(engine, ctx.get('footer_crop'), scale=2.0)
            fallback_pct = re.search(r'[+\-−–—]?\s*\d{1,3}\s*%', fallback_text or '')
            fallback_price_text = fallback_text or ''
            if fallback_pct:
                fallback_badge_text = fallback_pct.group(0).strip()
                if discount_value is None:
                    badge_text = fallback_badge_text
                    discount_value, discount_display, discount_kind = resolve_discount(badge_text, badge_color)
                fallback_price_text = (fallback_price_text[:fallback_pct.start()] + ' ' +
                                       fallback_price_text[fallback_pct.end():]).strip()
            if price_value is None:
                fallback_price_value = parse_price(fallback_price_text)
                if fallback_price_value is not None:
                    price_value = fallback_price_value
                    price_text = fallback_price_text
        threshold = self._threshold_for(catalog_model) if catalog_model else None
        rule = self.rules.get(catalog_model, {}) if catalog_model else {}
        category = str(rule.get('category', '—')) if catalog_model else '—'
        selected = bool(catalog_model and catalog_model in self.active_models)
        blacklisted = bool(catalog_model and normalize_vehicle_key(catalog_model) in self._blacklisted_model_keys)
        status, eligible = self._build_status(
            display_model, catalog_model, price_value, badge_color,
            discount_value, threshold, selected, blacklisted
        )
        confidence_floor = 0.93 if self.confidence_protection_enabled else 0.80
        if eligible and float(model_confidence) < confidence_floor:
            status = f'Назву перевірити · збіг {float(model_confidence):.2f}; потрібно не менше {confidence_floor:.2f}'
            eligible = False

        # Avoid a second OCR pass for strong detections; run a candidate-only
        # independent footer check only when one of the relevant OCR scores is low.
        name_conf = float(fields.get('name_confidence', 0.0) or 0.0)
        price_conf = float(fields.get('price_confidence', 0.0) or 0.0)
        badge_conf = float(fields.get('badge_confidence', 0.0) or 0.0)
        verified_independently = False
        needs_independent_check = bool(
            eligible and not footer_fallback_attempted
            and (name_conf < 0.68 or price_conf < 0.68 or badge_conf < 0.68)
        )
        if needs_independent_check and not allow_fallback:
            # Fail closed in the fast lane and defer the slow independent read until
            # after every clear, high-confidence candidate has had a chance to fire.
            status = 'Очікує перевірки OCR · швидка смуга не купує непевний результат'
            eligible = False
        elif needs_independent_check and allow_fallback:
            verify_footer_text = self._recognize(engine, ctx.get('footer_crop'), scale=2.0)
            verified_independently = True
            verify_pct = re.search(r'[+\-−–—]?\s*\d{1,3}\s*%', verify_footer_text or '')
            verify_badge_text = verify_pct.group(0).strip() if verify_pct else ''
            verify_price_text = verify_footer_text or ''
            if verify_pct:
                verify_price_text = (verify_price_text[:verify_pct.start()] + ' ' +
                                     verify_price_text[verify_pct.end():]).strip()
            verify_price = parse_price(verify_price_text)
            if verify_price is None or verify_price != price_value:
                status = 'Перевірити ціну · незалежне читання не збігається; автодію заблоковано'
                eligible = False
            else:
                verify_discount, _, verify_kind = resolve_discount(verify_badge_text, badge_color)
                if verify_kind != 'discount' or verify_discount is None or verify_discount != discount_value:
                    status = 'Перевірити знижку · незалежне читання не збігається; автодію заблоковано'
                    eligible = False

        # Keep an explicit confidence marker for diagnostics. The scan loop also
        # caches uncertain rows against their visual signatures; uncertain rows stay
        # fail-closed, while a real pixel/text change forces fresh OCR on that field.
        cacheable = bool(
            display_model and model_confidence >= 0.80 and price_value is not None
            and badge_color in ('GREEN', 'RED', 'NONE')
            and (badge_color == 'NONE' or discount_value is not None)
            and not (verified_independently and not eligible)
        )
        return {
            'card': ctx['card'], 'model': display_model or '—',
            'catalog_model': catalog_model or '', 'price': format_price(price_value),
            'price_value': price_value, 'discount': discount_display,
            'discount_value': discount_value, 'discount_kind': discount_kind,
            'threshold': threshold, 'category': category, 'status': status,
            'eligible': bool(eligible), 'model_confidence': round(float(model_confidence), 3),
            'badge_color': badge_color, 'badge_color_method': ctx.get('badge_color_method', ''),
            'badge_color_sample_size': ctx.get('badge_color_sample_size'),
            'name_text': name_text, 'price_text': price_text, 'badge_text': badge_text,
            'discount_source': 'footer-fallback' if footer_fallback_attempted and badge_text else 'badge-ocr',
            'ocr_confidence': round(float(fields.get('ocr_confidence', 0.0)), 3),
            'name_confidence': round(name_conf, 3), 'price_confidence': round(price_conf, 3),
            'badge_confidence': round(badge_conf, 3),
            'xy': ctx.get('xy'), 'screen_size': ctx.get('screen_size'),
            'offer_signature': str(ctx.get('signature') or ''),
            'offer_identity_signature': str(ctx.get('offer_identity_signature') or ''),
            '_cacheable': cacheable, '_cache_hit': False,
        }

    def run(self):
        started = time.perf_counter()
        found = []
        screen_size = (0, 0)
        stage = {}
        global _CARD_CACHE_SIGNATURES, _CARD_CACHE_RESULTS, _CARD_CACHE_FIELD_SIGNATURES
        global _CARD_CACHE_CONFIG_KEY, _CARD_CACHE_SCREEN_KEY
        try:
            # AHK's known-good path only scans while the game window is active.
            # Never OCR the scanner's own UI, a terminal, or another desktop window.
            if not _foreground_matches_target(self.target_hwnd):
                elapsed = time.perf_counter() - started
                message = "FOCUS_LOST: активне вікно змінилося; захоплення екрана пропущено."
                stage['total'] = elapsed
                self._save_diagnostics([], screen_size, elapsed, message, stage)
                self.result.emit([], '__FOCUS_LOST__', elapsed)
                return

            import numpy as np
            import cv2

            grid = self.grid
            left, top = float(grid.get('left', .153)), float(grid.get('top', .095))
            right, bottom = float(grid.get('right', .985)), float(grid.get('bottom', .895))
            cols, rows = int(grid.get('cols', 5)), int(grid.get('rows', 3))
            if cols != 5 or rows != 3:
                raise ValueError('Сканер розрахований на 15 карток у сітці 3×5.')
            if not (0 <= left < right <= 1 and 0 <= top < bottom <= 1):
                raise ValueError('Некоректна область сканування. Перевірте межі в Налаштуваннях.')
            if (right - left) < .45 or (bottom - top) < .35:
                raise ValueError('Область сканування надто мала. Вкажіть область, у якій видно всі 15 карток.')

            t = time.perf_counter()
            (screenshot, capture_origin, desktop_origin, screen_size, capture_backend,
             capture_seconds, frame_timestamp) = _capture_market_frame(grid, np)
            height, width = screenshot.shape[:2]
            monitor_left, monitor_top = int(desktop_origin[0]), int(desktop_origin[1])
            frame_left, frame_top = int(capture_origin[0]), int(capture_origin[1])
            screen_width, screen_height = int(screen_size[0]), int(screen_size[1])
            stage['capture'] = max(0.0, float(capture_seconds))
            stage['capture_backend'] = capture_backend
            if capture_backend.startswith('MSS persistent') and _MARKET_CAPTURE_LAST_ERROR:
                stage['capture_error'] = _MARKET_CAPTURE_LAST_ERROR
            stage['capture_origin'] = [frame_left, frame_top]
            stage['capture_frame_size'] = [int(width), int(height)]
            stage['screen_size'] = [screen_width, screen_height]
            if frame_timestamp is not None:
                stage['capture_frame_timestamp'] = float(frame_timestamp)

            # Grid bounds in frame-local coordinates; full-screen coordinates are
            # separately retained for cache keys and physical click positions.
            screen_x0, screen_x1 = int(left * screen_width), int(right * screen_width)
            screen_y0, screen_y1 = int(top * screen_height), int(bottom * screen_height)
            x0, x1 = screen_x0 - frame_left, screen_x1 - frame_left
            y0, y1 = screen_y0 - frame_top, screen_y1 - frame_top
            x0 = max(0, min(width - 1, x0)); x1 = max(x0 + 1, min(width, x1))
            y0 = max(0, min(height - 1, y0)); y1 = max(y0 + 1, min(height, y1))

            t = time.perf_counter()
            contexts = self._extract_card_contexts(
                screenshot, x0, x1, y0, y1, cols, rows,
                monitor_left, monitor_top, screen_size, cv2, np, capture_origin=capture_origin
            )
            stage['crop_and_signatures'] = time.perf_counter() - t
            config_key, screen_key = self._config_cache_key(
                screen_size, monitor_left, monitor_top, screen_x0, screen_x1, screen_y0, screen_y1, cols, rows
            )
            # On the first frame (or after a capture/configuration change), the
            # compositor may have painted only part of the market. A single GREEN
            # badge must not suppress stabilization: keep the best of up to 4 frames
            # spaced 20 ms apart, and stop early once at least 3 badges are visible.
            # This bounded startup-only retry avoids waiting for a whole scan cycle;
            # steady-state 50 ms polling and purchase timings are unchanged.
            with _CARD_CACHE_LOCK:
                pre_cache_valid = bool(
                    isinstance(_CARD_CACHE_RESULTS, list) and len(_CARD_CACHE_RESULTS) == rows * cols
                    and isinstance(_CARD_CACHE_SIGNATURES, list) and len(_CARD_CACHE_SIGNATURES) == rows * cols
                    and isinstance(_CARD_CACHE_FIELD_SIGNATURES, list) and len(_CARD_CACHE_FIELD_SIGNATURES) == rows * cols
                    and _CARD_CACHE_CONFIG_KEY == config_key and _CARD_CACHE_SCREEN_KEY == screen_key
                )
            def _colored_badge_count(card_contexts):
                return sum(
                    1 for card_ctx in card_contexts
                    if str(card_ctx.get('badge_color', 'UNKNOWN')).upper() not in ('NONE', 'UNKNOWN', '')
                )

            initial_badge_count = _colored_badge_count(contexts)
            if (should_stabilize_initial_color_capture(
                    [ctx.get('badge_color', 'UNKNOWN') for ctx in contexts],
                    pre_cache_valid, self.fast_color_filter_enabled, minimum_colored_badges=3)
                    and not self.cancel_event.is_set()):
                best_screenshot = screenshot
                best_contexts = contexts
                best_badge_count = initial_badge_count
                retry_elapsed = 0.0
                crop_elapsed = 0.0
                for _startup_retry in range(3):
                    if self.cancel_event.is_set():
                        break
                    retry_started = time.perf_counter()
                    (candidate_screenshot, candidate_origin, candidate_desktop_origin,
                     candidate_screen_size, candidate_backend, candidate_capture_seconds,
                     candidate_frame_timestamp) = _capture_market_frame(grid, np)
                    retry_elapsed += time.perf_counter() - retry_started
                    candidate_height, candidate_width = candidate_screenshot.shape[:2]
                    candidate_monitor_left, candidate_monitor_top = map(int, candidate_desktop_origin)
                    candidate_frame_left, candidate_frame_top = map(int, candidate_origin)
                    candidate_screen_width, candidate_screen_height = map(int, candidate_screen_size)
                    candidate_screen_x0, candidate_screen_x1 = int(left * candidate_screen_width), int(right * candidate_screen_width)
                    candidate_screen_y0, candidate_screen_y1 = int(top * candidate_screen_height), int(bottom * candidate_screen_height)
                    candidate_x0 = max(0, min(candidate_width-1, candidate_screen_x0-candidate_frame_left))
                    candidate_x1 = max(candidate_x0+1, min(candidate_width, candidate_screen_x1-candidate_frame_left))
                    candidate_y0 = max(0, min(candidate_height-1, candidate_screen_y0-candidate_frame_top))
                    candidate_y1 = max(candidate_y0+1, min(candidate_height, candidate_screen_y1-candidate_frame_top))
                    crop_started = time.perf_counter()
                    candidate_contexts = self._extract_card_contexts(
                        candidate_screenshot, candidate_x0, candidate_x1, candidate_y0, candidate_y1, cols, rows,
                        candidate_monitor_left, candidate_monitor_top, candidate_screen_size, cv2, np,
                        capture_origin=candidate_origin
                    )
                    crop_elapsed += time.perf_counter() - crop_started
                    candidate_badge_count = _colored_badge_count(candidate_contexts)
                    # Prefer the newest frame on ties, since text may have finished
                    # painting even when the number of colored badges is unchanged.
                    if candidate_badge_count >= best_badge_count:
                        best_screenshot = candidate_screenshot
                        best_contexts = candidate_contexts
                        best_badge_count = candidate_badge_count
                        screenshot = candidate_screenshot
                        capture_origin = candidate_origin
                        desktop_origin = candidate_desktop_origin
                        monitor_left, monitor_top = candidate_monitor_left, candidate_monitor_top
                        frame_left, frame_top = candidate_frame_left, candidate_frame_top
                        screen_size = candidate_screen_size
                        screen_width, screen_height = candidate_screen_width, candidate_screen_height
                        x0, x1, y0, y1 = candidate_x0, candidate_x1, candidate_y0, candidate_y1
                        screen_x0, screen_x1 = candidate_screen_x0, candidate_screen_x1
                        screen_y0, screen_y1 = candidate_screen_y0, candidate_screen_y1
                        capture_backend = candidate_backend
                        stage['capture_backend'] = capture_backend
                        stage['capture_origin'] = [frame_left, frame_top]
                        stage['capture_frame_size'] = [int(candidate_width), int(candidate_height)]
                        stage['screen_size'] = [screen_width, screen_height]
                        stage['capture'] = float(stage.get('capture',0.0)) + max(0.0,float(candidate_capture_seconds))
                        if candidate_frame_timestamp is not None:
                            stage['capture_frame_timestamp'] = float(candidate_frame_timestamp)
                    if best_badge_count >= 3:
                        break
                screenshot = best_screenshot
                contexts = best_contexts
                height, width = screenshot.shape[:2]
                stage['capture_retry'] = retry_elapsed
                stage['crop_and_signatures'] = float(stage.get('crop_and_signatures', 0.0)) + crop_elapsed
                config_key, screen_key = self._config_cache_key(
                    screen_size, monitor_left, monitor_top, screen_x0, screen_x1, screen_y0, screen_y1, cols, rows
                )
            signatures = [ctx.get('signature') for ctx in contexts]
            field_order = ('name', 'price', 'badge')

            with _CARD_CACHE_LOCK:
                previous_result_count = len(_CARD_CACHE_RESULTS) if isinstance(_CARD_CACHE_RESULTS, list) else 0
                previous_signature_count = len(_CARD_CACHE_SIGNATURES) if isinstance(_CARD_CACHE_SIGNATURES, list) else 0
                previous_field_count = len(_CARD_CACHE_FIELD_SIGNATURES) if isinstance(_CARD_CACHE_FIELD_SIGNATURES, list) else 0
                config_key_match = (_CARD_CACHE_CONFIG_KEY == config_key)
                screen_key_match = (_CARD_CACHE_SCREEN_KEY == screen_key)
                cache_valid = bool(
                    previous_result_count == rows * cols
                    and previous_signature_count == rows * cols
                    and previous_field_count == rows * cols
                    and config_key_match and screen_key_match
                )
                self._cache_debug = {
                    'valid': cache_valid,
                    'previous_result_count': previous_result_count,
                    'previous_signature_count': previous_signature_count,
                    'previous_field_signature_count': previous_field_count,
                    'config_key_match': config_key_match,
                    'screen_key_match': screen_key_match,
                    'current_card_count': rows * cols,
                }
                if cache_valid:
                    previous_rows = copy.deepcopy(_CARD_CACHE_RESULTS)
                    previous_field_signatures = copy.deepcopy(_CARD_CACHE_FIELD_SIGNATURES)
                    previous_signatures = list(_CARD_CACHE_SIGNATURES)
                else:
                    previous_rows = [None] * (rows * cols)
                    previous_field_signatures = [None] * (rows * cols)
                    previous_signatures = [None] * (rows * cols)

            # A purchase can remove a listing and shift the rest of the grid. Reuse the
            # previously verified text result by field signature instead of treating a
            # moved card as a brand-new card at its new cell. Fresh coordinates always
            # come from the current frame; only OCR values are carried over.
            position_remap_count = 0
            if cache_valid:
                remapped_rows, remapped_fields, position_mapping = _remap_cached_rows_by_signature(
                    signatures, previous_signatures, previous_rows, previous_field_signatures)
                previous_rows = remapped_rows
                previous_field_signatures = remapped_fields
                for current_index, previous_index in position_mapping.items():
                    if current_index != previous_index:
                        position_remap_count += 1
                    row = previous_rows[current_index]
                    if isinstance(row, dict):
                        row['card'] = int(current_index) + 1
                        row['xy'] = contexts[current_index].get('xy')
                        row['screen_size'] = screen_size
                        row['offer_signature'] = str(contexts[current_index].get('signature') or '')
                        row['offer_identity_signature'] = str(contexts[current_index].get('offer_identity_signature') or '')
                        row['_cache_hit'] = True
                self._cache_debug['position_remapped_card_count'] = int(position_remap_count)
                if position_remap_count:
                    stage['position_cache_remapped_cards'] = int(position_remap_count)
                    self.progress.emit(15, f'POSITION CACHE: {position_remap_count} карток зіставлено після зміщення; OCR лише для нових/змінених полів')

            changed_indices = []
            fast_skipped_indices = []
            changed_field_map = {}
            retry_now = time.monotonic()
            uncertain_retry_due = 0
            uncertain_retry_suppressed = 0
            # Do not carry retry timestamps across a different screen/configuration.
            # Visible signature changes still force immediate OCR and bypass this cooldown.
            with _CARD_CACHE_LOCK:
                stale_retry_keys = [
                    key for key, stamp in _CARD_CACHE_FIELD_LAST_OCR_AT.items()
                    if key[0] != config_key or key[1] != screen_key or retry_now - stamp > 120.0
                ]
                for key in stale_retry_keys:
                    _CARD_CACHE_FIELD_LAST_OCR_AT.pop(key, None)

            for idx, ctx in enumerate(contexts):
                current_fields = ctx.get('field_signatures')
                prior_fields = previous_field_signatures[idx] if idx < len(previous_field_signatures) else None
                prior_row = previous_rows[idx] if idx < len(previous_rows) else None
                if (cache_valid and isinstance(current_fields, dict)
                        and isinstance(prior_fields, dict) and isinstance(prior_row, dict)):
                    fields_to_ocr = [
                        field for field in field_order
                        if self._field_signature_changed(
                            current_fields.get(field), prior_fields.get(field), field, cv2, np
                        )
                    ]
                    # Retrying uncertain text is useful only for GREEN cards, where
                    # the OCR result can become an eligible candidate. RED/NONE/UNKNOWN
                    # cards intentionally skip text OCR just like the proven AHK script.
                    unresolved = []
                    if (not self.fast_color_filter_enabled
                            or str(ctx.get('badge_color', 'UNKNOWN')).upper() == 'GREEN'):
                        model_text = str(prior_row.get('model') or '').strip()
                        try:
                            model_conf = float(prior_row.get('model_confidence', 0.0) or 0.0)
                        except (TypeError, ValueError):
                            model_conf = 0.0
                        if not model_text or model_text == '—' or model_conf < 0.80:
                            unresolved.append('name')
                        if prior_row.get('price_value') is None:
                            unresolved.append('price')
                        prior_color = str(prior_row.get('badge_color', 'UNKNOWN'))
                        badge_value = prior_row.get('discount_value')
                        if prior_color == 'UNKNOWN' or (prior_color in ('GREEN', 'RED') and badge_value is None):
                            unresolved.append('badge')
                    retry_fields = []
                    with _CARD_CACHE_LOCK:
                        for field in unresolved:
                            retry_identity = self._field_retry_identity(current_fields.get(field))
                            retry_key = (config_key, screen_key, retry_identity, field)
                            last_attempt = float(_CARD_CACHE_FIELD_LAST_OCR_AT.get(retry_key, 0.0))
                            if self._uncertain_retry_due(last_attempt, retry_now):
                                retry_fields.append(field)
                                uncertain_retry_due += 1
                            elif field not in fields_to_ocr:
                                uncertain_retry_suppressed += 1
                    fields_to_ocr = list(dict.fromkeys(fields_to_ocr + retry_fields))
                else:
                    fields_to_ocr = list(field_order)

                # Fast, purchase-safe mode: sample the badge color first and send
                # text to OCR only for GREEN cards. The auto-buyer only needs model,
                # price and discount for a potentially eligible offer; OCR on RED,
                # NONE or UNKNOWN cards was consuming most of the scan time while
                # never allowing those cards to be purchased. Their text is reused
                # only when the pixel signatures are unchanged; changed non-green
                # cards become truthful placeholders via _color_gate_result.
                if (self.fast_color_filter_enabled
                        and str(ctx.get('badge_color', 'UNKNOWN')).upper() != 'GREEN'):
                    had_field_changes = bool(fields_to_ocr)
                    fields_to_ocr = []
                    ctx['_fast_color_skipped'] = True
                    ctx['_fields_to_ocr'] = []
                    if had_field_changes or not isinstance(prior_row, dict):
                        fast_skipped_indices.append(idx)
                    continue

                if fields_to_ocr:
                    changed_indices.append(idx)
                    changed_field_map[str(idx + 1)] = fields_to_ocr
                    ctx['_fields_to_ocr'] = fields_to_ocr
                    # Timestamp every field submitted for OCR, including immediate visual
                    # changes, so a still-uncertain result isn't reprocessed next second.
                    with _CARD_CACHE_LOCK:
                        for field in fields_to_ocr:
                            retry_identity = self._field_retry_identity(current_fields.get(field))
                            _CARD_CACHE_FIELD_LAST_OCR_AT[(config_key, screen_key, retry_identity, field)] = retry_now
                else:
                    ctx['_fields_to_ocr'] = []

            self._fast_color_skipped_indices = list(fast_skipped_indices)
            self._green_badge_count = sum(1 for ctx in contexts if str(ctx.get('badge_color', 'UNKNOWN')).upper() == 'GREEN')
            self._changed_cards = len(changed_indices) + len(fast_skipped_indices)
            self._cache_hits = rows * cols - len(changed_indices) - len(fast_skipped_indices)
            self._changed_fields = sum(len(v) for v in changed_field_map.values())
            self._changed_field_map = changed_field_map
            self._field_change_counts = {
                field: sum(1 for values in changed_field_map.values() if field in values)
                for field in field_order
            }
            self._cache_debug.update({
                'changed_field_counts': dict(self._field_change_counts),
                'changed_card_count': int(self._changed_cards),
                'cache_hit_count': int(self._cache_hits),
                'fast_color_skipped_card_numbers': [int(i) + 1 for i in fast_skipped_indices],
                'green_badge_cards_detected': int(self._green_badge_count),
                'uncertain_retry_due': int(uncertain_retry_due),
                'uncertain_retry_suppressed': int(uncertain_retry_suppressed),
                'uncertain_retry_interval_seconds': float(_UNCERTAIN_FIELD_RETRY_SECONDS),
            })
            self._ocr_fields = [field for field in field_order
                                if any(field in values for values in changed_field_map.values())]

            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                self._save_diagnostics([], screen_size, elapsed, stage_seconds=stage)
                self.result.emit([], '__CANCELLED__', elapsed)
                return

            # Fast cache path: no OCR and no text/card changes.
            if not changed_indices and not fast_skipped_indices and cache_valid:
                found = previous_rows
                for i, row in enumerate(found):
                    row['xy'] = contexts[i].get('xy')
                    row['screen_size'] = screen_size
                    row['_cache_hit'] = True
                stage['montage_build'] = 0.0
                stage['ocr'] = 0.0
                stage['parse_and_rules'] = 0.0
                stage['total'] = time.perf_counter() - started
                elapsed = stage['total']
                self.progress.emit(15, 'Змін на картках немає — використано кеш попереднього аналізу')
                for row in found:
                    self._emit_fast_candidate(row, started)
                self._save_diagnostics(found, screen_size, elapsed, stage_seconds=stage)
                self.result.emit(found, '', elapsed)
                return

            # If no card has a GREEN badge, do not initialize or call OCR at all.
            # Emit a coherent 15-card result from the color gate and only reuse prior
            # text where name/price pixels are unchanged. This should complete in the
            # capture/signature budget rather than multi-second OCR time.
            if not changed_indices:
                t = time.perf_counter()
                records_by_index = {}
                skipped_set = set(fast_skipped_indices)
                for i, ctx in enumerate(contexts):
                    previous = previous_rows[i] if i < len(previous_rows) else None
                    prior_fields = previous_field_signatures[i] if i < len(previous_field_signatures) else None
                    current_fields = ctx.get('field_signatures')
                    if i in skipped_set or not isinstance(previous, dict):
                        row = self._color_gate_result(ctx, previous, prior_fields, current_fields, cv2, np)
                    else:
                        row = copy.deepcopy(previous)
                        row['xy'] = ctx.get('xy')
                        row['screen_size'] = screen_size
                        row['_cache_hit'] = True
                    records_by_index[i] = row
                found = [records_by_index[i] for i in range(rows * cols)]
                stage['montage_build'] = 0.0
                stage['ocr'] = 0.0
                stage['parse_and_rules'] = time.perf_counter() - t
                stage['total'] = time.perf_counter() - started
                elapsed = stage['total']
                new_signatures = [signatures[i] for i in range(rows * cols)]
                new_field_signatures = [copy.deepcopy(contexts[i].get('field_signatures')) for i in range(rows * cols)]
                with _CARD_CACHE_LOCK:
                    _CARD_CACHE_SIGNATURES = new_signatures
                    _CARD_CACHE_RESULTS = copy.deepcopy(found)
                    _CARD_CACHE_FIELD_SIGNATURES = new_field_signatures
                    _CARD_CACHE_CONFIG_KEY = config_key
                    _CARD_CACHE_SCREEN_KEY = screen_key
                self.progress.emit(15, f'GREEN ONLY: зелених бейджів {self._green_badge_count}; OCR пропущено для {len(fast_skipped_indices)} карток')
                for row in found:
                    self._emit_fast_candidate(row, started)
                self._save_diagnostics(found, screen_size, elapsed, stage_seconds=stage)
                self.result.emit(found, '', elapsed)
                return

            changed_contexts = [contexts[i] for i in changed_indices]
            if self.fast_candidate_mode:
                found, fast_error, fast_elapsed = self._run_green_fast_lane(
                    changed_contexts, contexts, previous_rows, previous_field_signatures,
                    changed_indices, fast_skipped_indices, signatures, screen_size,
                    config_key, screen_key, rows, cols, cv2, np, started, stage, field_order,
                )
                self._save_diagnostics(found, screen_size, fast_elapsed, fast_error, stage_seconds=stage)
                self.result.emit(found, fast_error, fast_elapsed)
                return
            if not self.fast_color_filter_enabled:
                self.progress.emit(0, f'Повне OCR: читаю текст на {len(changed_indices)} картках; це може бути повільніше за швидкий режим.')
            selected_fields = self._ocr_fields or list(field_order)
            t = time.perf_counter()
            montage, montage_layout = self._build_ocr_montage(
                changed_contexts, cv2, np, selected_fields=selected_fields
            )
            stage['montage_build'] = time.perf_counter() - t

            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                self._save_diagnostics([], screen_size, elapsed, stage_seconds=stage)
                self.result.emit([], '__CANCELLED__', elapsed)
                return

            engine = _get_ocr_engine()
            self._ocr_engine_init_seconds = _OCR_ENGINE_INIT_SECONDS
            self.progress.emit(1, f'OCR: {self._changed_fields} змінених полів на {len(changed_indices)} картках')
            batch_started = time.perf_counter()
            self._ocr_call_count += 1
            try:
                ocr_rows, _ = engine(montage)
            finally:
                self._ocr_elapsed_seconds += time.perf_counter() - batch_started
            stage['ocr'] = self._ocr_elapsed_seconds

            if self.cancel_event.is_set():
                elapsed = time.perf_counter() - started
                self._save_diagnostics([], screen_size, elapsed, stage_seconds=stage)
                self.result.emit([], '__CANCELLED__', elapsed)
                return

            t = time.perf_counter()
            grouped = group_montage_ocr(ocr_rows, montage_layout, count=len(changed_contexts))
            records_by_index = {}
            skipped_set = set(fast_skipped_indices)
            for i, row in enumerate(previous_rows):
                if i in skipped_set:
                    prior_fields = previous_field_signatures[i] if i < len(previous_field_signatures) else None
                    records_by_index[i] = self._color_gate_result(
                        contexts[i], row, prior_fields, contexts[i].get('field_signatures'), cv2, np
                    )
                elif i not in changed_indices and row is not None:
                    row['xy'] = contexts[i].get('xy')
                    row['screen_size'] = screen_size
                    row['_cache_hit'] = True
                    records_by_index[i] = row
                elif row is None and i not in changed_indices:
                    # All uncached non-GREEN cards are represented by truthful placeholders.
                    records_by_index[i] = self._color_gate_result(
                        contexts[i], None, None, contexts[i].get('field_signatures'), cv2, np
                    )

            # First pass is deliberately OCR-result-only: no secondary footer OCR is
            # allowed to delay a clear candidate. We emit a validated GREEN offer as
            # soon as its own fields have been parsed. If the UI accepts it, it cancels
            # this worker and the remaining cards are never parsed/fallback-scanned.
            primary_fields_by_index = {}
            primary_context_by_index = {}
            pending_fallback_indices = []
            for local_idx, (ctx, fields) in enumerate(zip(changed_contexts, grouped)):
                if self.cancel_event.is_set():
                    partial = [records_by_index[i] for i in sorted(records_by_index)]
                    elapsed = time.perf_counter() - started
                    stage['parse_and_rules'] = time.perf_counter() - t
                    stage['total'] = elapsed
                    self._save_diagnostics(partial, screen_size, elapsed, stage_seconds=stage)
                    self.result.emit(partial, '__CANCELLED__', elapsed)
                    return
                original_idx = int(ctx['card_index'])
                self.progress.emit(local_idx + 1, f'Обробляю змінені зелені картки {local_idx + 1}/{len(changed_contexts)}')
                if ctx.get('empty'):
                    row = self._empty_result(ctx)
                else:
                    previous = previous_rows[original_idx] if original_idx < len(previous_rows) else None
                    fields_to_ocr = set(ctx.get('_fields_to_ocr', field_order))
                    merged_fields = dict(fields or {})
                    field_text_keys = {'name': 'name_text', 'price': 'price_text', 'badge': 'badge_text'}
                    for field_name in field_order:
                        if field_name not in fields_to_ocr and isinstance(previous, dict):
                            merged_fields[field_name] = previous.get(field_text_keys[field_name], '')
                            merged_fields[f'{field_name}_confidence'] = previous.get(f'{field_name}_confidence', 0.0)
                        else:
                            merged_fields.setdefault(field_name, '')
                            merged_fields.setdefault(f'{field_name}_confidence', 0.0)
                    confidences = [float(merged_fields.get(f'{name}_confidence', 0.0) or 0.0)
                                   for name in field_order]
                    positive_confidences = [value for value in confidences if value > 0]
                    merged_fields['ocr_confidence'] = (
                        sum(positive_confidences) / len(positive_confidences)
                        if positive_confidences else 0.0
                    )
                    primary_fields_by_index[original_idx] = merged_fields
                    primary_context_by_index[original_idx] = ctx
                    row = self._parse_changed_card(ctx, merged_fields, engine, allow_fallback=False)
                    if self._needs_fast_fallback(ctx, row):
                        pending_fallback_indices.append(original_idx)
                records_by_index[original_idx] = row
                self._emit_fast_candidate(row, started)

            # Secondary footer OCR is a rescue path, not part of the normal reaction
            # path. Run it only when a GREEN card already matched an enabled, non-
            # blacklisted catalog model and its discount could meet that model's floor.
            # Non-green cards and non-candidates never enter this pass.
            for original_idx in pending_fallback_indices:
                if self.cancel_event.is_set():
                    partial = [records_by_index[i] for i in sorted(records_by_index)]
                    elapsed = time.perf_counter() - started
                    stage['parse_and_rules'] = time.perf_counter() - t
                    stage['total'] = elapsed
                    self._save_diagnostics(partial, screen_size, elapsed, stage_seconds=stage)
                    self.result.emit(partial, '__CANCELLED__', elapsed)
                    return
                ctx = primary_context_by_index[original_idx]
                merged_fields = primary_fields_by_index[original_idx]
                row = self._parse_changed_card(ctx, merged_fields, engine, allow_fallback=True)
                records_by_index[original_idx] = row
                self._emit_fast_candidate(row, started)

            stage['parse_and_rules'] = time.perf_counter() - t
            stage['ocr'] = self._ocr_elapsed_seconds
            # A full coherent cycle always yields rows in original screen order.
            found = [records_by_index[i] for i in range(rows * cols) if i in records_by_index]
            elapsed = time.perf_counter() - started
            stage['total'] = elapsed

            if len(found) == rows * cols and not self.cancel_event.is_set():
                # Cache OCR output against the observed pixels even when parsing was
                # uncertain. Such rows remain fail-closed (eligible=False); any visual
                # change invalidates their signature and triggers fresh OCR. This avoids
                # re-running the 15-card OCR batch on every unchanged polling cycle.
                new_signatures = [signatures[i] for i in range(rows * cols)]
                new_field_signatures = [
                    copy.deepcopy(contexts[i].get('field_signatures'))
                    for i in range(rows * cols)
                ]
                with _CARD_CACHE_LOCK:
                    _CARD_CACHE_SIGNATURES = new_signatures
                    _CARD_CACHE_RESULTS = copy.deepcopy(found)
                    _CARD_CACHE_FIELD_SIGNATURES = new_field_signatures
                    _CARD_CACHE_CONFIG_KEY = config_key
                    _CARD_CACHE_SCREEN_KEY = screen_key

            self._save_diagnostics(found, screen_size, elapsed, stage_seconds=stage)
            self.result.emit(found, '', elapsed)
        except Exception as exc:
            elapsed = time.perf_counter() - started
            error = f'{type(exc).__name__}: {exc}\n{traceback.format_exc()}'
            stage['total'] = elapsed
            self._save_diagnostics(found, screen_size, elapsed, error, stage)
            self.result.emit(found, error, elapsed)
