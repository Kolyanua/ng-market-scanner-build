import sys
import types
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# The build host may not have the full Qt GUI runtime; these tests exercise pure
# image-coordinate logic only and never create a thread or interact with a desktop.
try:
    from PySide6.QtCore import QThread, Signal  # noqa: F401
except Exception:
    pyside = types.ModuleType('PySide6')
    qtcore = types.ModuleType('PySide6.QtCore')

    class QThread:
        pass

    class _Signal:
        def __init__(self, *args, **kwargs):
            pass

    qtcore.QThread = QThread
    qtcore.Signal = _Signal
    pyside.QtCore = qtcore
    sys.modules.setdefault('PySide6', pyside)
    sys.modules.setdefault('PySide6.QtCore', qtcore)

import numpy as np
import scanner_core


class PostPurchaseNavigationV1281Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / 'main.py').read_text(encoding='utf-8')
        cls.actions = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        cls.core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')

    def test_resume_detects_modal_then_cancel_then_back(self):
        resume = self.main.split('def _resume_continuous_scan_after_action(', 1)[1].split(
            'def _finish_continuous_resume_after_market_confirmed(', 1)[0]
        self.assertIn("state == 'confirm'", resume)
        self.assertIn("'cancel_button_center'", resume)
        self.assertIn("'CANCEL / «Скасувати»'", resume)
        self.assertIn("state in {'detail', 'unknown'}", resume)
        self.assertIn("'BACK / стрілка «назад»'", resume)
        self.assertIn("if state == 'market':", resume)
        self.assertIn("elif state == 'not_foreground':", resume)

    def test_cancel_waits_for_stable_modal_after_final_confirm(self):
        resume = self.main.split('def _resume_continuous_scan_after_action(', 1)[1].split(
            'def _finish_continuous_resume_after_market_confirmed(', 1)[0]
        self.assertIn('POST_PURCHASE_CONFIRM_GRACE_SECONDS = 3.0', self.main)
        self.assertIn('POST_PURCHASE_CONFIRM_MIN_FRESH_FRAMES = 2', self.main)
        self.assertIn('confirm_stable_for >= POST_PURCHASE_CONFIRM_GRACE_SECONDS', resume)
        self.assertIn('self._resume_market_confirm_good_frames >= POST_PURCHASE_CONFIRM_MIN_FRESH_FRAMES', resume)
        self.assertIn('POST_PURCHASE_DETAIL_BACK_MIN_WAIT_SECONDS = 3.0', self.main)
        self.assertIn('POST_PURCHASE_UNKNOWN_BACK_MIN_WAIT_SECONDS = 3.0', self.main)

    def test_recovery_waits_until_purchase_worker_is_idle(self):
        resume = self.main.split('def _resume_continuous_scan_after_action(', 1)[1].split(
            'def _finish_continuous_resume_after_market_confirmed(', 1)[0]
        guard = resume.index('if (self.action_in_progress or self._action_worker_is_running()')
        probe = resume.index('core.probe_market_return_state(')
        self.assertLess(guard, probe)
        self.assertIn('it never repeats any purchase click', resume)

    def test_post_purchase_clicks_are_guarded_by_game_focus_and_resolution(self):
        helper = self.main.split('def _resume_send_game_click(', 1)[1].split(
            'def _resume_continuous_scan_after_action(', 1)[0]
        self.assertIn('_resume_market_screen_size', helper)
        self.assertIn('_foreground_matches_game_target', helper)
        self.assertIn('expected_hwnd=foreground', helper)
        self.assertIn('target_hwnd=foreground', helper)

    def test_confirm_cta_locator_returns_screen_coordinates_and_tracks_shift(self):
        # Simulated captured ROI: full screen is 1920x1080; capture starts at (200, 80).
        frame = np.zeros((850, 1600, 3), dtype=np.uint8)
        frame[607:667, 720:1020] = (183, 255, 43)  # Mint-green CTA, BGR
        center = scanner_core._locate_green_confirm_button_center_in_frame(
            frame, (1920, 1080), monitor_left=200, monitor_top=80)
        self.assertIsNotNone(center)
        self.assertTrue(abs(center[0] - 1070) <= 3, center)
        self.assertTrue(abs(center[1] - 717) <= 3, center)
        cancel = (center[0] - round(256 * 1920 / 1920), center[1])
        self.assertEqual(cancel, (814, center[1]))

        shifted = np.zeros_like(frame)
        shifted[632:692, 735:1035] = (183, 255, 43)
        moved_center = scanner_core._locate_green_confirm_button_center_in_frame(
            shifted, (1920, 1080), monitor_left=200, monitor_top=80)
        self.assertIsNotNone(moved_center)
        self.assertTrue(abs(moved_center[0] - 1085) <= 3, moved_center)
        self.assertTrue(abs(moved_center[1] - 742) <= 3, moved_center)
        self.assertEqual((moved_center[0] - 256, moved_center[1]), (829, moved_center[1]))

    def test_purchase_analysis_and_click_chain_versions_are_unchanged(self):
        # The purchase worker source is intentionally untouched by this navigation fix.
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', self.actions)
        self.assertIn('FAST_COORDINATE_FLOW_VERSION = "1.2.71-fixed-coordinate-fast-chain-no-postcheck"', self.actions)
        self.assertIn('CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM', self.actions)
        self.assertIn('def _emit_fast_candidate(', self.core)
        self.assertIn('def _purchase_gate_reason(', self.main)


if __name__ == '__main__':
    unittest.main(verbosity=2)
