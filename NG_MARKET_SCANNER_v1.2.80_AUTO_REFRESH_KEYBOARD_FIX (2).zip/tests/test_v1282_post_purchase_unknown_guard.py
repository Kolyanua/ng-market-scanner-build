import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PostPurchaseUnknownGuardV1282Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.core = (ROOT / "scanner_core_logic.py").read_text(encoding="utf-8")

    def test_unknown_frame_does_not_clear_modal_latch(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("confirm_was_seen = bool(", resume)
        self.assertIn("self._resume_market_confirm_started_at or self._resume_market_cancel_attempts", resume)
        nonmodal_logic = resume.split("confirm_was_seen = bool(", 1)[1].split(
            "last_attempt = float(self._resume_market_cancel_last_attempt_at", 1)[0]
        self.assertNotIn("self._resume_market_confirm_started_at = 0.0", nonmodal_logic)

    def test_detail_and_unknown_require_three_fresh_nonmodal_frames_and_three_seconds(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_FRESH_FRAMES = 3", self.main)
        self.assertIn("POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_SECONDS = 3.0", self.main)
        self.assertIn("nonmodal_absence_stable = (", resume)
        self.assertIn("and nonmodal_for >= POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_SECONDS", resume)
        self.assertIn("and confirm_seen_for >= POST_PURCHASE_CONFIRM_GRACE_SECONDS", resume)
        self.assertIn("bool(self._resume_market_modal_absence_confirmed)", resume)

    def test_probe_failure_without_a_capture_does_not_count_as_fresh_evidence(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("capture_backend = str((probe or {}).get('capture_backend') or '')", resume)
        self.assertIn("frame_available = bool(capture_backend and capture_backend != 'not-started')", resume)
        self.assertIn("token is None and frame_available", resume)

    def test_back_is_blocked_after_modal_seen_until_absence_and_time_gates_pass(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("confirm_latch_allows_back = (", resume)
        self.assertIn("confirm_latch_active = bool(confirm_seen_at or self._resume_market_cancel_attempts)", resume)
        self.assertIn("not confirm_latch_active", resume)
        self.assertIn("and confirm_back_grace_done and cancel_back_grace_done", resume)
        self.assertIn("and not self._resume_market_back_attempted)", resume)

    def test_purchase_chain_and_analysis_sources_are_not_modified_by_navigation_hotfix(self):
        self.assertIn("CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM", self.actions)
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', self.actions)
        self.assertIn("def build_candidate_status(", self.core)
        self.assertIn("def evaluate_candidate(", self.core) if "def evaluate_candidate(" in self.core else self.assertIn("def match_catalog_model(", self.core)


if __name__ == "__main__":
    unittest.main(verbosity=2)
