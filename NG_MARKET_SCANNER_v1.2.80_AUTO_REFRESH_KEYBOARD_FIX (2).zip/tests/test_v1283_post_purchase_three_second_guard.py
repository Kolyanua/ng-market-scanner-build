import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


class PostPurchaseThreeSecondGuardV1283Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.main = (ROOT / "main.py").read_text(encoding="utf-8")
        cls.actions = (ROOT / "scanner_actions.py").read_text(encoding="utf-8")
        cls.logic = (ROOT / "scanner_core_logic.py").read_text(encoding="utf-8")

    def test_all_recovery_navigation_pauses_are_three_seconds(self):
        for marker in (
            "POST_PURCHASE_CONFIRM_GRACE_SECONDS = 3.0",
            "POST_PURCHASE_DETAIL_BACK_MIN_WAIT_SECONDS = 3.0",
            "POST_PURCHASE_UNKNOWN_BACK_MIN_WAIT_SECONDS = 3.0",
            "POST_PURCHASE_CANCEL_RETRY_SECONDS = 3.0",
            "POST_PURCHASE_CANCEL_BACK_GRACE_SECONDS = 3.0",
            "POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_FRESH_FRAMES = 3",
            "POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_SECONDS = 3.0",
        ):
            with self.subTest(marker=marker):
                self.assertIn(marker, self.main)

    def test_detail_state_cannot_bypass_modal_confirm_grace(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        detail_unknown = resume.split("elif self._resume_after_purchase_navigation and state in {'detail', 'unknown'}:", 1)[1].split(
            "elif state == 'detail' and waited >= 2.5", 1)[0]
        self.assertNotIn("self._resume_market_confirm_started_at = 0.0", detail_unknown)
        self.assertIn("confirm_back_grace_done", detail_unknown)
        self.assertIn("cancel_back_grace_done", detail_unknown)
        self.assertIn("and confirm_back_grace_done and cancel_back_grace_done", detail_unknown)
        self.assertIn("nonmodal_for >= POST_PURCHASE_NONMODAL_AFTER_CONFIRM_MIN_SECONDS", detail_unknown)

    def test_back_after_cancel_has_full_three_second_gap(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("now - last_attempt >= POST_PURCHASE_CANCEL_BACK_GRACE_SECONDS", resume)
        self.assertIn("now-last_attempt >= POST_PURCHASE_CANCEL_RETRY_SECONDS", resume)

    def test_missing_capture_does_not_advance_fresh_frame_gate(self):
        resume = self.main.split("def _resume_continuous_scan_after_action(", 1)[1].split(
            "def _finish_continuous_resume_after_market_confirmed(", 1)[0]
        self.assertIn("frame_available = bool(capture_backend and capture_backend != 'not-started')", resume)
        self.assertIn("token is None and frame_available", resume)

    def test_purchase_analysis_and_three_click_chain_remain_unchanged(self):
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', self.actions)
        self.assertIn("CARD_CLICK → DETAIL_BUY → FINAL_CONFIRM", self.actions)
        self.assertIn("def build_candidate_status(", self.logic)


if __name__ == "__main__":
    unittest.main(verbosity=2)
