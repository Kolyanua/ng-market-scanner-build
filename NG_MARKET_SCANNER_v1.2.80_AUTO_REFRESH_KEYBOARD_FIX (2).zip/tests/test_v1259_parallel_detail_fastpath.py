import sys
import types
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np

import scanner_core

ROOT = Path(__file__).resolve().parents[1]


class _FakeMSSCapture:
    def __init__(self):
        self.monitors = [
            {'left': 0, 'top': 0, 'width': 1920, 'height': 1080},
            {'left': 0, 'top': 0, 'width': 1920, 'height': 1080},
        ]
        self.regions = []

    def __enter__(self):
        return self

    def __exit__(self, *_args):
        return False

    def grab(self, monitor_or_region):
        self.regions.append(dict(monitor_or_region))
        width = int(monitor_or_region['width'])
        height = int(monitor_or_region['height'])
        # MSS returns BGRA; no screen data is needed for these deterministic OCR tests.
        return np.zeros((height, width, 4), dtype=np.uint8)


class _FakeDetailOCREngine:
    def __init__(self):
        self.shapes = []

    @staticmethod
    def _item(cx, cy, text, width=180, height=20):
        x0, x1 = cx - width / 2, cx + width / 2
        y0, y1 = cy - height / 2, cy + height / 2
        return ([ [x0, y0], [x1, y0], [x1, y1], [x0, y1] ], text, 0.99)

    def __call__(self, image):
        self.shapes.append(tuple(image.shape))
        return [[
            self._item(150, 38, 'Dinka Civic EK6', width=220),
            self._item(150, 123, 'Ціна: $10 000', width=220),
            self._item(300, 204, 'Добра ціна: -89% до ринку', width=430),
        ]]


class ParallelDetailFastpathV1259Tests(unittest.TestCase):
    def test_detail_validation_captures_only_the_panel_and_uses_fixed_ocr_shape(self):
        capture = _FakeMSSCapture()
        fake_mss = types.SimpleNamespace(mss=lambda: capture)
        engine = _FakeDetailOCREngine()
        with patch.dict(sys.modules, {'mss': fake_mss}), \
             patch.object(scanner_core, '_foreground_matches_target', return_value=True), \
             patch.object(scanner_core, '_get_ocr_engine', return_value=engine):
            result = scanner_core.validate_market_detail_screen(
                all_models=['Dinka Civic EK6'],
                active_models=['Dinka Civic EK6'],
                rules={'Dinka Civic EK6': {'category': 'Звичайне', 'threshold': 20}},
                global_threshold=20,
                model_thresholds={},
                blacklisted_models=set(),
                expected_discount=89,
                target_hwnd=None,
                confidence_floor=0.93,
            )

        self.assertTrue(result['ok'], result.get('reason'))
        self.assertEqual(result['catalog_model'], 'Dinka Civic EK6')
        self.assertEqual(result['price_value'], 10000)
        self.assertEqual(result['discount_value'], 89)
        self.assertEqual(len(capture.regions), 1)
        region = capture.regions[0]
        self.assertEqual(region['left'], int(.690 * 1920))
        self.assertEqual(region['top'], int(.135 * 1080))
        self.assertLess(region['width'] * region['height'], 0.06 * 1920 * 1080)
        self.assertEqual(engine.shapes, [(254, 1152, 3)])
        for metric in ('validation_seconds', 'capture_seconds', 'ocr_seconds'):
            self.assertIn(metric, result)
            self.assertGreaterEqual(result[metric], 0.0)

    def test_detail_validator_fails_closed_when_price_or_discount_is_missing(self):
        capture = _FakeMSSCapture()
        fake_mss = types.SimpleNamespace(mss=lambda: capture)
        engine = _FakeDetailOCREngine()
        engine.__call__ = lambda image: [[]]
        with patch.dict(sys.modules, {'mss': fake_mss}), \
             patch.object(scanner_core, '_foreground_matches_target', return_value=True), \
             patch.object(scanner_core, '_get_ocr_engine', return_value=lambda image: [[]]):
            result = scanner_core.validate_market_detail_screen(
                ['Dinka Civic EK6'], ['Dinka Civic EK6'],
                {'Dinka Civic EK6': {'category': 'Звичайне'}}, 20, {}, set(), 89,
            )
        self.assertFalse(result['ok'])
        self.assertIn('reason', result)
        self.assertEqual(len(capture.regions), 1)

    def test_fast_detail_validation_runs_before_or_in_parallel_with_button_poll(self):
        source = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        run = source.split('    def run(self):', 1)[1]
        start = run.index('validation_task = self._start_parallel_detail_validation() if self.pre_buy_validator is not None else None')
        poll = run.index('button_ready = self._wait_for_green_button(*detail_xy')
        gate = run.index('validation_done.wait()', poll)
        detail_guard = run.index("if not bool(self.validated_details.get('ok')):", gate)
        buy_click = run.index('if not self._click(*detail_xy')
        self.assertLess(start, poll)
        self.assertLess(poll, gate)
        self.assertLess(gate, detail_guard)
        self.assertLess(detail_guard, buy_click)
        self.assertIn("threading.Thread(target=validate,name='NGMarketDetailValidator',daemon=True)", source)
        self.assertIn('DETAIL_OCR_START_DELAY_MS / 1000.0', source)
        self.assertIn('validation_done.wait()', source)

    def test_green_cta_colorref_classifier_is_fast_and_rejects_invalid_pixels(self):
        self.assertTrue(scanner_core._looks_like_green_cta_colorref(20 | (200 << 8) | (100 << 16)))
        self.assertFalse(scanner_core._looks_like_green_cta_colorref(220 | (55 << 8) | (65 << 16)))
        self.assertFalse(scanner_core._looks_like_green_cta_colorref(0xFFFFFFFF))

    def test_direct_watcher_uses_region_capture_and_new_frame_timestamps(self):
        source = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        watcher = source.split('class GreenBadgeWatcher', 1)[1].split('class GreenBadgeBatchWorker', 1)[0]
        self.assertIn('camera.start(region=region, target_fps=120, video_mode=False)', watcher)
        self.assertIn('camera.get_latest_frame(with_timestamp=True)', watcher)
        self.assertIn('timestamp_key == self._last_capture_timestamp', watcher)
        self.assertIn('time.sleep(.0005)', watcher)
        self.assertIn('if flush_due_pending(time.perf_counter()):', watcher)
        self.assertIn('def flush_due_pending(now=None):', watcher)
        self.assertIn('region_right = min(screen_w', watcher)
        self.assertIn('region_bottom = min(screen_h', watcher)
        self.assertNotIn('video_mode=True', watcher)
        self.assertNotIn('camera.start(target_fps=120, video_mode=True)', watcher)

    def test_release_builders_and_legacy_wrappers_target_1265(self):
        action = (ROOT / 'scanner_actions.py').read_text(encoding='utf-8')
        core = (ROOT / 'scanner_core.py').read_text(encoding='utf-8')
        main = (ROOT / 'main.py').read_text(encoding='utf-8')
        builder = (ROOT / 'build_single_exe_internal.bat').read_text(encoding='utf-8')
        self.assertIn('CLICK_WORKFLOW_VERSION = "1.2.65-stable-offer-dedupe"', action)
        self.assertIn('OCR_PATCH_VERSION = "1.2.60-position-independent-discount-watch"', core)
        self.assertIn('NG Market Scanner v1.2.71', main)
        self.assertIn("setWindowTitle('NG Market Scanner v1.2.81 — POST-PURCHASE NAVIGATION", main)
        self.assertIn('Stable click-chain base from NG Market Scanner v1.2.71', main)
        self.assertIn('1.2.60-position-independent-discount', builder)
        self.assertIn('NGMS271_CoordFast_OneFile', (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'build_single_exe.bat.fixture.txt').read_text(encoding='utf-8'))
        for old in ('BUILD_FINAL_v1.2.54.bat.fixture.txt', 'BUILD_FINAL_v1.2.55_GREEN_ONLY_OCR.bat.fixture.txt',
                    'BUILD_FINAL_v1.2.56_GREEN_FASTLANE.bat.fixture.txt', 'BUILD_FINAL_v1.2.57_DIRECT_GREEN_WATCH.bat.fixture.txt',
                    'BUILD_FINAL_v1.2.58_LARGEST_DISCOUNT_WATCH.bat.fixture.txt', 'BUILD_FINAL_v1.2.59_PARALLEL_DETAIL_FASTPATH.bat.fixture.txt'):
            text = (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / old).read_text(encoding='utf-8')
            self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', text, old)
        self.assertIn('BUILD_2K_PERSISTENT_DXCAM_v1.2.71.bat', (ROOT / 'tests' / 'fixtures' / 'legacy_builds' / 'RUN_CLEAN_INSTALL_AND_START.bat.fixture.txt').read_text(encoding='utf-8'))


if __name__ == '__main__':
    unittest.main(verbosity=2)
